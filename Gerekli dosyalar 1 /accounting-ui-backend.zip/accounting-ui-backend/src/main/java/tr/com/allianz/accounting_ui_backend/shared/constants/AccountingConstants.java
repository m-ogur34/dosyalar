package tr.com.allianz.accounting_ui_backend.shared.constants;

public final class AccountingConstants {

    public static final String API_ROOT = "/api/v1";
}
