package tr.com.allianz.accounting_ui_backend.config.cas;

import com.allianz.auth.client.model.UserDetailsModel;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import tr.com.allianz.accounting_ui_backend.shared.constants.exception.AppException;

@Service
public class ApplicationUserService {

    public ApplicationUserService() {
    }

    public UserDetailsModel getAuthenticatedUser() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        Object details = authentication.getPrincipal();
        if (details instanceof UserDetailsModel) {
            return (UserDetailsModel)details;
        } else {
            throw new AppException("Get Authenticated User Error.");
        }
    }

    public String getUserName() {
        UserDetailsModel authenticatedUser = this.getAuthenticatedUser();
        return authenticatedUser.getUserName();
    }

    public String getChannel() {
        UserDetailsModel authenticatedUser = this.getAuthenticatedUser();
        return authenticatedUser.getUserName();
    }
}
