package tr.com.allianz.accounting_ui_backend.service;

import tr.com.allianz.accounting_ui_backend.request_response.RestResponse;
import tr.com.allianz.pmc.client.DispatcherClientResponse;
import tr.com.allianz.pmc.client.ErrorResponse;
import tr.com.allianz.pmc.commonmessageutils.MessageBucket;
import tr.com.allianz.pmc.commonmessageutils.Severity;

import java.util.Objects;

public abstract class RestClientConsumerService {

    protected <R> R processRestResponse(DispatcherClientResponse<R> dispatcherResponse) {
		//TODO: You may want to check the response is valid or not.
		R result = null;
		if (Objects.nonNull(dispatcherResponse) && dispatcherResponse.isSuccess() && Objects.nonNull(dispatcherResponse.getData())) {
			result = dispatcherResponse.getData();
		}
		return result;
	}

	protected <R>  RestResponse<R> handleErrorResponse(MessageBucket messageBucket,
												       ErrorResponse errorResponse) {
		RestResponse<R> restResponse = new RestResponse<>();
		if (errorResponse == null) {
			messageBucket.addExternalMessage("UNKNOWN ERROR",
					"Muhasebe Servisinden Hata Mesajı Boş Geldi",
					Severity.ERROR);
		} else {
			messageBucket.addExternalMessage(errorResponse.getCode(),
					errorResponse.getMessage(),
					Severity.ERROR);
		}
		restResponse.setUiMessages(messageBucket.getMessages());
		return restResponse;
	}

}
