package tr.com.allianz.accounting_ui_backend.config.cas;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import tr.com.allianz.pmc.commonmessageutils.CommonMessageAccessor;
import tr.com.allianz.pmc.commonmessageutils.MessageBucket;
import tr.com.allianz.pmc.commonmessageutils.UiMessage;

public class DefaultMessageBucket extends MessageBucket {

    private final List<UiMessage> bucket = new ArrayList<>();

    public DefaultMessageBucket() {
        super(null);
    }

    public DefaultMessageBucket(CommonMessageAccessor messageAccessor) {
        super(messageAccessor);
    }

    @Override
    protected Collection<UiMessage> getBucket() {
        return bucket;
    }
}
 