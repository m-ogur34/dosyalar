package tr.com.allianz.accounting_ui_backend.service.config.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.concurrent.TimeUnit;
import okhttp3.OkHttpClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import tr.com.allianz.pmc.client.DispatcherHeaderInjectionFilter;
import tr.com.allianz.pmc.client.endpoint.*;
import tr.com.allianz.pmc.client.extension.DispatcherMetaDataProvider;
import tr.com.allianz.pmc.client.extension.DispatcherRestClient;

public class CustomDispatcherClient {
    private static final Logger log = LoggerFactory.getLogger(CustomDispatcherClient.class);
    public static Gson gson;
    private static Retrofit retrofit;
    public final AlzCyclicAccountMappingControllerApiEndPoint restAlzCyclicAccountMappingControllerApi;
    public final AlzCyclicPostingProcessControllerApiEndPoint restAlzCyclicPostingProcessControllerApi;
    public final AccCoverCodeControllerApiEndPoint restAccCoverCodeControllerApi;
    public final AssistanceCompanyControllerApiEndPoint restAssistanceCompanyControllerApi;
    public final AssistanceProductControllerApiEndPoint restAssistanceProductControllerApi;
    public final AssistancePartitionControllerApiEndPoint restAssistancePartitionControllerApi;
    public final AssistanceQueryControllerApiEndPoint restAssistanceQueryControllerApi;
    public final AssistancePostingControllerApiEndPoint restAssistancePostingControllerApi;
    public CustomDispatcherClient(String baseUrl, OkHttpClient client) {
        this(baseUrl, client, null);
    }

    public CustomDispatcherClient(String baseUrl, OkHttpClient client, DispatcherMetaDataProvider metaDataProvider) {
        if (baseUrl == null) {
            throw new IllegalArgumentException("baseUrl cannot be null!");
        } else {
            if (client == null) {
                if (metaDataProvider == null) {
                    throw new IllegalArgumentException("metaDataProvider cannot be null!");
                }

                client = (new OkHttpClient.Builder()).addInterceptor(new DispatcherHeaderInjectionFilter(metaDataProvider)).readTimeout(60L, TimeUnit.SECONDS).build();
            }

            gson = (new GsonBuilder()).setDateFormat(0, 0).registerTypeAdapter(LocalDate.class, new CustomLocalDateAdapter()).registerTypeAdapter(LocalDateTime.class, new CustomLocalDateTimeAdapter()).create();
            retrofit = (new Retrofit.Builder()).baseUrl(baseUrl).client(client).addConverterFactory(GsonConverterFactory.create(gson)).build();
            this.restAlzCyclicAccountMappingControllerApi = new AlzCyclicAccountMappingControllerApiEndPoint(createService(AlzCyclicAccountMappingControllerApi.class));
            this.restAlzCyclicPostingProcessControllerApi = new AlzCyclicPostingProcessControllerApiEndPoint(createService(AlzCyclicPostingProcessControllerApi.class));
            this.restAccCoverCodeControllerApi = new AccCoverCodeControllerApiEndPoint(createService(AccCoverCodeControllerApi.class));
            this.restAssistanceCompanyControllerApi = new AssistanceCompanyControllerApiEndPoint(createService(AssistanceCompanyControllerApi.class));
            this.restAssistanceProductControllerApi = new AssistanceProductControllerApiEndPoint(createService(AssistanceProductControllerApi.class));
            this.restAssistancePartitionControllerApi = new AssistancePartitionControllerApiEndPoint(createService(AssistancePartitionControllerApi.class));
            this.restAssistanceQueryControllerApi = new AssistanceQueryControllerApiEndPoint(createService(AssistanceQueryControllerApi.class));
            this.restAssistancePostingControllerApi = new AssistancePostingControllerApiEndPoint(createService(AssistancePostingControllerApi.class));
             DispatcherRestClient.gson=gson;
        }
    }

    private static <S> S createService(Class<S> serviceClass) {
        return retrofit.create(serviceClass);
    }
}
