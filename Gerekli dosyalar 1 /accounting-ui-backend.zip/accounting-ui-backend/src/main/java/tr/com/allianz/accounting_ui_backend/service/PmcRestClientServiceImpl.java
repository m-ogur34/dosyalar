package tr.com.allianz.accounting_ui_backend.service;

import lombok.Getter;
import okhttp3.OkHttpClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import tr.com.allianz.accounting_ui_backend.service.config.client.CustomDispatcherClient;
import tr.com.allianz.pmc.client.ErrorResponse;
import tr.com.allianz.pmc.commonmessageutils.MessageBucket;
import tr.com.allianz.pmc.commonmessageutils.Severity;

import java.util.concurrent.TimeUnit;

@Getter
@Service
public class PmcRestClientServiceImpl implements PmcRestClientService {
    private final String apiBaseUrl;
    private final CustomDispatcherClient pmcRestClient;
    private final MessageBucket messageBucket;

    public PmcRestClientServiceImpl(@Value("${accounting-services.url}") String apiBaseUrl,
                                    @Value("${accounting-services.read-time-out}") long readTimeout,
                                    MessageBucket messageBucket) {
        this.apiBaseUrl = apiBaseUrl;
        OkHttpClient okHttpClient = new OkHttpClient.Builder()
                .readTimeout(readTimeout, TimeUnit.MILLISECONDS)
                .build();
        this.pmcRestClient = new CustomDispatcherClient(apiBaseUrl, okHttpClient);
        this.messageBucket = messageBucket;
    }

    @Override
    public void handleBackendResponse(ErrorResponse error) {
        if(error==null){
            messageBucket.addExternalMessage("UNKNOWN ERROR", "Muhasebe Servisinden Hata Mesajı Boş Geldi",
                    Severity.ERROR);
            return;
        }
        messageBucket.addExternalMessage(error.getCode(), error.getMessage(),
                Severity.ERROR);
    }

}
