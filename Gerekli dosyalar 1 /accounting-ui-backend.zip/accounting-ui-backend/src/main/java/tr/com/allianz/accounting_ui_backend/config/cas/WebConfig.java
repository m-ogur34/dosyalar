package tr.com.allianz.accounting_ui_backend.config.cas;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.core.Ordered;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import java.util.List;

/**
 * Created on Aralık, 2020
 *
 * @author huseyin.cakmak
 */
@Configuration
public class WebConfig implements WebMvcConfigurer {


    private static final String SWAGGER_UI_HTML = "swagger-ui.html";

    private static final String CLASSPATH_META_INF_RESOURCES = "classpath:/META-INF/resources/";

    private static final String DEFAULT_PATH_PATTERN = "/";

    private static final String FULL_PATH_PATTERN = "/**/*";


    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {

        registry.addResourceHandler(SWAGGER_UI_HTML).addResourceLocations(CLASSPATH_META_INF_RESOURCES);

    }

    @Override
    public void addViewControllers(ViewControllerRegistry registry) {
        registry.addRedirectViewController(DEFAULT_PATH_PATTERN, SWAGGER_UI_HTML);
        registry.setOrder(Ordered.HIGHEST_PRECEDENCE);
    }

    @Override
    public void extendMessageConverters(List<HttpMessageConverter<?>> converters) {
        for (HttpMessageConverter<?> converter : converters) {
            if (converter instanceof MappingJackson2HttpMessageConverter) {
                final MappingJackson2HttpMessageConverter jsonMessageConverter = (MappingJackson2HttpMessageConverter) converter;
                final ObjectMapper objectMapper = jsonMessageConverter.getObjectMapper();
             //   prepareJavaTimeModule(objectMapper);
                objectMapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
                objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
                break;
            }
        }
    }

    @Bean
    MessageSource ghpMessageSource() {
        ReloadableResourceBundleMessageSource bean = new ReloadableResourceBundleMessageSource();
        bean.setBasename("classpath:GroupHealthProductionMessages");
        bean.setDefaultEncoding("UTF-8");
        return bean;
    }


}
