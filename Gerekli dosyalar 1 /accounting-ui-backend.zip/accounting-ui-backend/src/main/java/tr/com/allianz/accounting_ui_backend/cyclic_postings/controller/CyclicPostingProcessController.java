package tr.com.allianz.accounting_ui_backend.cyclic_postings.controller;


import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import tr.com.allianz.accounting_ui_backend.cyclic_postings.service.CyclicPostingProcessService;
import tr.com.allianz.accounting_ui_backend.request_response.RestResponse;
import tr.com.allianz.accounting_ui_backend.shared.constants.AccountingConstants;
import tr.com.allianz.pmc.client.model.*;

import java.util.Optional;

@RestController
@Slf4j
@RequiredArgsConstructor
@RequestMapping(value = AccountingConstants.API_ROOT + "/cyclic-posting-process")
@CrossOrigin
public class CyclicPostingProcessController {

    private final CyclicPostingProcessService cyclicPostingProcessService;

    @GetMapping("/list")
    public ResponseEntity<RestResponse<AlzCyclicPostingProcessListResponse>> getAlzCyclicMappingList(
            @RequestParam(name = "page", required = false) Optional<Integer> page,
            @RequestParam(name = "size", required = false) Optional<Integer> size,
            @RequestParam(name = "batchId", required = false) Long batchId,
            @RequestParam(name = "cyclicBatchId", required = false) Long cyclicBatchId,
            @RequestParam(name = "status", required = false) String status) {

        return ResponseEntity.ok(cyclicPostingProcessService
                .getAlzCyclicMappingList(page.orElse(0),
                        size.orElse(2000), batchId, cyclicBatchId, status));
    }

    @PostMapping("/create")
    public ResponseEntity<RestResponse<CreateCyclicPostingResponse>>  createCyclicAccountMapping(@RequestBody CreateCyclicPostingRequest request) {
        return ResponseEntity.ok(cyclicPostingProcessService.createAlzCyclicPostingProcess(request));
    }

    @PostMapping("/remove-unprocessed")
    public ResponseEntity<RestResponse<RemoveCyclicPostingProcessResponse>> removeUnprocessedCyclicPostings(@RequestBody RemoveCyclicPostingProcessRequest request) {

        return ResponseEntity.ok(cyclicPostingProcessService.removeUnprocessedCyclicPosting(request));
    }

    @PostMapping("/process")
    public ResponseEntity<RestResponse<ProcessCyclicPostingResponse>> processCyclicPostings(@RequestBody ProcessCyclicPostingRequest request) {
        return ResponseEntity.ok(cyclicPostingProcessService.processCyclicPosting(request));
    }

}
