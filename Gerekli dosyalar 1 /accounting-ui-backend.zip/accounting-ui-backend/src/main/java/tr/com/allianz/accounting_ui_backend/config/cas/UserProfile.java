package tr.com.allianz.accounting_ui_backend.config.cas;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serial;
import java.io.Serializable;

@Getter
@Setter
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class UserProfile implements Serializable {

    @Serial
    private static final long serialVersionUID = -1175937869627535204L;
    private String partnerId;
    private String userName;
    private String name;
    private String email;
    private String userType;
    private Long agenIntId;
    private String agencyTitle;
    private String agencyCode;
    private Long subAgenIntId;
    private String subAgencyTitle;
    private String subAgencyCode;
    @JsonIgnore
    private String identityNo;
    @JsonProperty("identityNo")
    private String maskedIdentityNo;
    @JsonIgnore
    private String taxNumber;
    @JsonProperty("taxNumber")
    private String maskedTaxNumber;
    private boolean active;
    private boolean passwordExpired;
    @JsonIgnore
    private String gsmNo;
    @JsonProperty("gsmNo")
    private String maskedGsmNo;
    @JsonIgnore
    private String vipGsmNo;
    @JsonProperty("vipGsmNo")
    private String maskedVipGsmNo;
    private boolean loginWidthSMS;
    private boolean smsLoginOpen;
    private boolean bgdUser;
    private boolean callCenterUser;
    private String subUserType;
    private String referenceOpusUser;
    private static final String MASK_REPLACE_WITH = "*";
    private static final String MASK_ONLY_DISPLAY_LAST_FOUR_CHARACTERS = ".(?=.{4})";
    private String mfaType;
}
