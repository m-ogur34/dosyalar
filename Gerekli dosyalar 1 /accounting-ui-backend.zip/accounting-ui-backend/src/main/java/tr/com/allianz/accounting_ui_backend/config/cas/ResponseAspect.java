package tr.com.allianz.accounting_ui_backend.config.cas;

import lombok.AllArgsConstructor;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import tr.com.allianz.accounting_ui_backend.request_response.RestResponse;
import tr.com.allianz.pmc.commonmessageutils.MessageBucket;

@Aspect
@Component
@AllArgsConstructor
public class ResponseAspect {

    private final MessageBucket messageBucket;

    @Pointcut("execution(org.springframework.http.ResponseEntity tr.com.allianz.accounting_ui_backend..*controller..*.*(..))")
    private void controller() {
        // pointcut for controller methods
    }

    @AfterReturning(pointcut = "controller()", returning = "retVal")
    private void getResponse(ResponseEntity<?> retVal) {
        if (retVal != null && retVal.hasBody()) {

            assert (retVal.getBody() instanceof RestResponse);

            if (!(retVal.getBody() instanceof RestResponse<?> restResponse)) {
                return;
            }

            restResponse.setUiMessages(messageBucket.getMessages());
        }
    }
}
