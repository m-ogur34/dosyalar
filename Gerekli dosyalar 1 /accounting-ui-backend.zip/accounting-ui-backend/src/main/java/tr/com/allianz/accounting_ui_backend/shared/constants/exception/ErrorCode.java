package tr.com.allianz.accounting_ui_backend.shared.constants.exception;

import java.io.Serializable;

public class ErrorCode implements Serializable
{
    private static final long serialVersionUID = 1L;
    private String code;
    private String name;
    private String message;

    public ErrorCode(String code, String message)
    {
        this.code = code;
        this.message = message;
    }

    public ErrorCode(String code)
    {
        this.code = code;
    }

    public String getCode()
    {
        return code;
    }

    public String getName()
    {
        return name;
    }

    public String getMessage()
    {
        return message;
    }

}
