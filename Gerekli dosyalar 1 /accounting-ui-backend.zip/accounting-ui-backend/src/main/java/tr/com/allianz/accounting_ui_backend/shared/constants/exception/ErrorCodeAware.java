package tr.com.allianz.accounting_ui_backend.shared.constants.exception;

public interface ErrorCodeAware
{
    ErrorCode getCode();
}
