package tr.com.allianz.accounting_ui_backend.cyclic_postings.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import tr.com.allianz.accounting_ui_backend.request_response.RestResponse;
import tr.com.allianz.accounting_ui_backend.service.RestClientConsumerService;
import tr.com.allianz.accounting_ui_backend.service.config.client.CustomDispatcherClient;
import tr.com.allianz.pmc.client.DispatcherClientResponse;
import tr.com.allianz.pmc.client.model.*;
import tr.com.allianz.pmc.commonmessageutils.MessageBucket;

@Slf4j
@Service
@RequiredArgsConstructor
public class CyclicAccountMappingService extends RestClientConsumerService {

    private final CustomDispatcherClient pmcRestClientClient;
    private final MessageBucket messageBucket;

    public RestResponse<AlzCyclicAccountMappingListResponse> getAlzCyclicMappingList() {
        DispatcherClientResponse<ApiResponseAlzCyclicAccountMappingListResponse> response =  pmcRestClientClient.restAlzCyclicAccountMappingControllerApi
                .listCyclicAccountMapping();

        ApiResponseAlzCyclicAccountMappingListResponse apiResponse = processRestResponse(response);
        if(apiResponse!=null)
            return RestResponse.of(apiResponse.getData());

        return handleErrorResponse(messageBucket,response.getError());
    }

    public RestResponse<CreateAlzCyclicAccountMappingResponse> createAlzCyclicAccountMappingResponse(CreateAlzCyclicAccountMappingRequest request){

        DispatcherClientResponse<ApiResponseCreateAlzCyclicAccountMappingResponse> response
                =  pmcRestClientClient.restAlzCyclicAccountMappingControllerApi
                .createCyclicAccountMapping(request);


        ApiResponseCreateAlzCyclicAccountMappingResponse apiResponse =
                processRestResponse(response);

        if(apiResponse!=null)
            return new RestResponse<>(apiResponse.getData());

        return handleErrorResponse(messageBucket,response.getError());

    }

    public RestResponse<RemoveAlzCyclicAccountMappingResponse> removeAlzCyclicAccountMappingResponse(RemoveAlzCyclicAccountMappingRequest request){
        DispatcherClientResponse<ApiResponseRemoveAlzCyclicAccountMappingResponse> response =
                 pmcRestClientClient.restAlzCyclicAccountMappingControllerApi
                .removeCyclicAccountMapping(request);

        ApiResponseRemoveAlzCyclicAccountMappingResponse apiResponse = processRestResponse(response);

        if(apiResponse!=null)
            return new RestResponse<>(apiResponse.getData());

        return handleErrorResponse(messageBucket,response.getError());
    }


}
