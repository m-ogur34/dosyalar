package tr.com.allianz.accounting_ui_backend.request_response;

import lombok.Data;
import tr.com.allianz.pmc.commonmessageutils.UiMessages;

import java.util.Date;

@Data
public class RestResponse<T> {

    private static final RestResponse<Void> EMPTY_RESPONSE = new RestResponse<>(null);

    private T data;

    private UiMessages uiMessages;

    private Long timestamp;

    private int response_code;

    private Object response;

    public RestResponse() {

    }

    public RestResponse(T data) {
        this.data = data;
    }

    public static <T> RestResponse<T> of(T t) {
        return new RestResponse<>(t);
    }

    public static RestResponse<Void> empty() {
        return EMPTY_RESPONSE;
    }

    public void setUiMessages(UiMessages uiMessages) {
        if (uiMessages != null) {
            this.uiMessages = uiMessages;
        }
    }

    public RestResponse(int response_code, Object response) {

        this.timestamp = new Date().getTime();
        this.response_code = response_code;
        this.response = response;
    }
}