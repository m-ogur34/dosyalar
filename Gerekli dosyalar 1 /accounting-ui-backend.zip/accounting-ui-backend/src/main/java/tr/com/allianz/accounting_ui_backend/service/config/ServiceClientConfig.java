package tr.com.allianz.accounting_ui_backend.service.config;


import lombok.RequiredArgsConstructor;
import okhttp3.OkHttpClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.util.AntPathMatcher;
import tr.com.allianz.accounting_ui_backend.service.config.client.CustomDispatcherClient;
import tr.com.allianz.pmc.commonmessageutils.MessageBucket;

import java.util.concurrent.TimeUnit;

/**
 * @author ridvan.yazici
 * @date 29.01.2026
 */
@Configuration
@RequiredArgsConstructor
public class ServiceClientConfig {

    @Value("${accounting-services.url}")
    private String accountingServiceUrl;

    @Value("${accounting-services.read-time-out:60}")
    private Long accountingServiceTimeoutSec;


    @Bean("dispatcherRestClient")
    public CustomDispatcherClient dispatcherRestClient() {
        final OkHttpClient.Builder builder = new OkHttpClient.Builder()
                .connectTimeout(accountingServiceTimeoutSec, TimeUnit.SECONDS)
                .readTimeout(accountingServiceTimeoutSec, TimeUnit.SECONDS)
                .writeTimeout(accountingServiceTimeoutSec, TimeUnit.SECONDS);

        final OkHttpClient client = builder.build();

        return new CustomDispatcherClient(accountingServiceUrl, client);
    }

    @Bean
    public AntPathMatcher antPathMatcher() {
        return new AntPathMatcher();
    }

}
