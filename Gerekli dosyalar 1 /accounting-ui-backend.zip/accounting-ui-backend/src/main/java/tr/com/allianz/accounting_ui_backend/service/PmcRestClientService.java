package tr.com.allianz.accounting_ui_backend.service;


import org.springframework.stereotype.Service;
import tr.com.allianz.accounting_ui_backend.service.config.client.CustomDispatcherClient;
import tr.com.allianz.pmc.client.ErrorResponse;

@Service
public interface PmcRestClientService {
    CustomDispatcherClient getPmcRestClient();

    void handleBackendResponse(ErrorResponse error);
}
