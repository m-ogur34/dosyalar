package tr.com.allianz.accounting_ui_backend.shared.constants.exception;


import org.springframework.beans.factory.annotation.Autowired;

public class AppException extends RuntimeException implements ErrorCodeAware
{
    private static final long serialVersionUID = 1L;
    private ErrorCode code;

    public AppException(String message)
    {
        super(message);
        this.code = new ErrorCode("0");
    }

    public AppException(ErrorCode code)
    {
        super();
        this.code = code;
    }

    public AppException(String code, String message)
    {
        super(message);
        this.code = new ErrorCode(code);
    }
    public AppException(ErrorCode code, String message)
    {
        super(message);
        this.code = code;
    }
    public AppException(ErrorCode code, String message, Throwable cause)
    {
        super(message, cause);
        this.code = code;
    }

    @Autowired
    public ErrorCode getCode()
    {
        return code;
    }

}
