package tr.com.allianz.accounting_ui_backend.config.cas;

import com.allianz.auth.client.model.UserDetailsModel;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

@Slf4j
public class AuthenticatedUserService {

    private static final String ZERO = "0";
    private static final String ONE = "1";

    // @formatter:off
    /**
     *
     * web_v_system_users.user_type --> koc_dmt_agents_ext.type user_type 0 : merkez
     * WNONEL user_type 1 : acente WDA6520_758 user_type 2 : bölge user_type 3 :
     * subagent user_type null : müşteri WFORD9
     *
     * web_v_system_users.sub_user_type --> web_sec_system_users.user_type
     * sub_user_type : 0 -- Acente / Merkez WNONEL WDA6520_758 sub_user_type : 1 --
     * Müşteri WFORD9
     *
     *
     * sub_user_type 1 : müşteri
     *
     * partner_type I : Tüzel
     *
     *
     */

    /*
     *
     * user_type 0 & sub_user_type : 0 MERKEZ -- WNONEL user_type 1 & sub_user_type
     * : 0 ACENTE -- WDA6520_758 user_type 2 : BÖLGE user_type 3 : SUBAGENT
     * user_type null & sub_user_type : 1 MÜŞTERİ -- WFORD9
     *
     *
     */

    // @formatter:on

    private AuthenticatedUserService() {
        throw new AssertionError();
    }

    private static Authentication getAuthenticatedAgency() {
        final SecurityContext context = SecurityContextHolder.getContext();
        return context.getAuthentication();
    }

    public static String getUserName() {
        return getUserProfile().getUserName();
    }

    public static String getTaxNumber() {
        return getUserProfile().getTaxNumber();
    }

    public static String getUserType() {
        return getUserProfile().getUserType();
    }

    public static String getSubUserType() {
        return getUserProfile().getSubUserType();
    }

    public static Integer getAgentIntId() {
        return getUserProfile().getAgenIntId().intValue();
    }

    public static String getSubAgentCode() {
        return getUserProfile().getSubAgencyCode();
    }

    public static String getCompanyCode() {
        //TODO: will be company code
        //return getUserProfile().getAgencyCode();
        return "AZS";
    }

    public static UserProfile getUserProfile() {
        log.info("user Profile");
        UserDetailsModel authenticatedUserProfile = (UserDetailsModel) getAuthenticatedAgency().getPrincipal();
        log.info("agentIntId: {}", authenticatedUserProfile.getAgenIntId());
        UserProfile userProfile=new UserProfile();
        userProfile.setAgenIntId(authenticatedUserProfile.getAgenIntId());
        userProfile.setAgencyCode(authenticatedUserProfile.getAgencyCode());
        userProfile.setUserType(authenticatedUserProfile.getUserType());
        userProfile.setSubUserType(authenticatedUserProfile.getSubUserType());
        userProfile.setUserName(authenticatedUserProfile.getUserName());
        userProfile.setSubAgencyCode(authenticatedUserProfile.getSubAgencyCode());
        userProfile.setTaxNumber(authenticatedUserProfile.getTaxNumber());
        return userProfile;
    }

    public static boolean isAlzUser() {
        return ZERO.equals(getUserType());
    }

    public static boolean isAgency() {
        return ONE.equals(getUserProfile().getUserType());
    }

    public static boolean isCustomer() {
        return ONE.equals(getUserProfile().getSubUserType());
    }

    public static String getUserTypeName() {
        if (isAlzUser()) {
            return "CENTRAL";
        } else if (isAgency()) {
            return "AGENCY";
        } else if (isCustomer()) {
            return "CUSTOMER";
        }
        return StringUtils.EMPTY;
    }

    public static int getAgentRole() {
        return getUserProfile().getAgenIntId().intValue();
    }
}
