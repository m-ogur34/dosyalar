package tr.com.allianz.accounting_ui_backend.shared.constants.exception;

public interface ErrorCodes
{
    
    interface Security{
//        ErrorCode INVALID_USERNAME_OR_PASSWORD = new ErrorCode("1");
//        ErrorCode EXPIRED_ACCOUNT = new ErrorCode("2");
//        ErrorCode NOT_AUTHENTICATED = new ErrorCode("3");
//        ErrorCode UNAUTHORIZED = new ErrorCode("4");
    }

    interface Exception{
        ErrorCode UNDEFINED_ERROR = new ErrorCode("0","UNDEFINED ERROR");
        ErrorCode INTERNAL_SERVER_ERROR = new ErrorCode("10","INTERNAL SERVER ERROR");
        ErrorCode UNPROCESSABLE_INPUT_DATA = new ErrorCode("20","UNPROCESSABLE INPUT DATA");
        ErrorCode BAD_REQUEST = new ErrorCode("30","BAD REQUEST");
        ErrorCode DIGITAL_POS = new ErrorCode("40","DIGITAL POS");
    }

}
