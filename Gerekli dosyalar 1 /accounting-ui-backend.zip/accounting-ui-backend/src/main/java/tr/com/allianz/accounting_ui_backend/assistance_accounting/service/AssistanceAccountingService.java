package tr.com.allianz.accounting_ui_backend.assistance_accounting.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import tr.com.allianz.accounting_ui_backend.request_response.RestResponse;
import tr.com.allianz.accounting_ui_backend.service.RestClientConsumerService;
import tr.com.allianz.accounting_ui_backend.service.config.client.CustomDispatcherClient;
import tr.com.allianz.pmc.client.DispatcherClientResponse;
import tr.com.allianz.pmc.client.model.*;
import tr.com.allianz.pmc.commonmessageutils.MessageBucket;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class AssistanceAccountingService extends RestClientConsumerService {

    private final CustomDispatcherClient pmcRestClientClient;
    private final MessageBucket messageBucket;


    public RestResponse<List<AccCoverCode>> getListAccCoverCode() {
        DispatcherClientResponse<ApiResponseListAccCoverCode> response =  pmcRestClientClient.restAccCoverCodeControllerApi
                .listAccCoverCodes();

        ApiResponseListAccCoverCode apiResponse = processRestResponse(response);
        if(apiResponse!=null)
            return RestResponse.of(apiResponse.getData());

        return handleErrorResponse(messageBucket,response.getError());
    }

    public RestResponse<List<AssistanceCompany>> getListAssistanceCompany() {
        DispatcherClientResponse<ApiResponseListAssistanceCompany> response =  pmcRestClientClient.restAssistanceCompanyControllerApi
                .listAssistanceCompanies();

        ApiResponseListAssistanceCompany apiResponse = processRestResponse(response);
        if(apiResponse!=null)
            return RestResponse.of(apiResponse.getData());

        return handleErrorResponse(messageBucket,response.getError());
    }

    public RestResponse<List<AssistanceProduct>> getListAssistanceProduct(String accCoverCode) {
        DispatcherClientResponse<ApiResponseListAssistanceProduct> response =  pmcRestClientClient.restAssistanceProductControllerApi
                .listAssistanceProducts(accCoverCode);

        ApiResponseListAssistanceProduct apiResponse = processRestResponse(response);
        if(apiResponse!=null)
            return RestResponse.of(apiResponse.getData());

        return handleErrorResponse(messageBucket,response.getError());
    }

    public RestResponse<List<AssistancePartition>> getListAssistancePartition(List<Long> productIds) {
        DispatcherClientResponse<ApiResponseListAssistancePartition> response =  pmcRestClientClient.restAssistancePartitionControllerApi
                .listAssistancePartitions(productIds);

        ApiResponseListAssistancePartition apiResponse = processRestResponse(response);
        if(apiResponse!=null)
            return RestResponse.of(apiResponse.getData());

        return handleErrorResponse(messageBucket,response.getError());
    }
    public RestResponse<List<AssistanceQueryResult>> postListAssistanceQuery(AssistanceQueryCriteria assistanceQueryCriteria) {
        DispatcherClientResponse<ApiResponseListAssistanceQueryResult> response =  pmcRestClientClient.restAssistanceQueryControllerApi
                .listAssistanceQueryResults(assistanceQueryCriteria);

        ApiResponseListAssistanceQueryResult apiResponse = processRestResponse(response);
        if(apiResponse!=null)
            return RestResponse.of(apiResponse.getData());

        return handleErrorResponse(messageBucket,response.getError());
    }

    public RestResponse<Long> postCreateAssistancePosting(CreateAssistancePostingRequest createAssistancePostingRequest) {
        DispatcherClientResponse<ApiResponseLong> response = pmcRestClientClient.restAssistancePostingControllerApi
                .createAssistancePosting(createAssistancePostingRequest);

        ApiResponseLong apiResponse = processRestResponse(response);
        if(apiResponse!=null)
            return RestResponse.of(apiResponse.getData());

        return handleErrorResponse(messageBucket,response.getError());

    }

}

