package tr.com.allianz.accounting_ui_backend.assistance_accounting.controller;


import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import tr.com.allianz.accounting_ui_backend.assistance_accounting.service.AssistanceAccountingService;
import tr.com.allianz.accounting_ui_backend.request_response.RestResponse;
import tr.com.allianz.accounting_ui_backend.shared.constants.AccountingConstants;
import tr.com.allianz.pmc.client.model.*;

import java.util.List;

@RestController
@Slf4j
@RequiredArgsConstructor
@RequestMapping(value = AccountingConstants.API_ROOT + "/assistance-accounting")
@CrossOrigin
public class AssistanceAccountingController {

    private final AssistanceAccountingService assistanceAccountingService;

    @GetMapping("/acc-cover-code")
    public ResponseEntity<RestResponse<List<AccCoverCode>>>  listAccCoverCodes() {
        return ResponseEntity.ok(assistanceAccountingService.getListAccCoverCode());

    }

    @GetMapping("/assistance-company")
    public ResponseEntity<RestResponse<List<AssistanceCompany>>>  listAssistanceCompanies() {
        return ResponseEntity.ok(assistanceAccountingService.getListAssistanceCompany());

    }

    @GetMapping("/assistance-product")
    public ResponseEntity<RestResponse<List<AssistanceProduct>>>  listAssistanceProducts(@RequestParam(required = false) String accCoverCode) {
        return ResponseEntity.ok(assistanceAccountingService.getListAssistanceProduct(accCoverCode));
    }

    @PostMapping("/assistance-partition")
    public ResponseEntity<RestResponse<List<AssistancePartition>>>  listAssistancePartitions(@RequestBody List<Long> productIds) {
        return ResponseEntity.ok(assistanceAccountingService.getListAssistancePartition(productIds));
    }

    @PostMapping("/assistance-query")
    public ResponseEntity<RestResponse<List<AssistanceQueryResult>>> createAssistanceAccountingEntry(@RequestBody AssistanceQueryCriteria assistanceQueryCriteria) {
        return ResponseEntity.ok(assistanceAccountingService.postListAssistanceQuery(assistanceQueryCriteria));
    }

    @PostMapping("/create-posting")
    public ResponseEntity<RestResponse<Long>> createPosting(@RequestBody CreateAssistancePostingRequest createPostingRequest) {
        return ResponseEntity.ok(assistanceAccountingService.postCreateAssistancePosting(createPostingRequest));
    }
}
