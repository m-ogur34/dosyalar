package tr.com.allianz.accounting_ui_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jmx.JmxAutoConfiguration;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.boot.autoconfigure.security.servlet.UserDetailsServiceAutoConfiguration;
import org.springframework.context.annotation.Import;

@SpringBootApplication(
		exclude = { SecurityAutoConfiguration.class,
				    UserDetailsServiceAutoConfiguration.class,
				    JmxAutoConfiguration.class },
		scanBasePackages = { "com.allianz.auth.client",
				             "tr.com.allianz.accounting_ui_backend" }
)
@Import(JmxConfig.class)
public class AccountingUiBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(AccountingUiBackendApplication.class, args);
	}

}
