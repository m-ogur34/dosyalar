package tr.com.allianz.accounting_ui_backend.config.cas;


import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import tr.com.allianz.accounting_ui_backend.shared.constants.AccountingConstants;


@RestController
@CrossOrigin
@RequestMapping( AccountingConstants.API_ROOT + "/cas")
public class AuthenticatedUserController {

    @GetMapping("/user-profile")
    public UserProfile userProfile() {
        return AuthenticatedUserService.getUserProfile();
    }
}