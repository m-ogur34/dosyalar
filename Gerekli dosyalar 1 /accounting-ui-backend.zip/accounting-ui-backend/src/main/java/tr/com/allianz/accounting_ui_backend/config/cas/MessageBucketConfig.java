package tr.com.allianz.accounting_ui_backend.config.cas;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.context.annotation.RequestScope;
import tr.com.allianz.pmc.commonmessageutils.MessageBucket;

@Configuration
public class MessageBucketConfig {

    @Bean
    @RequestScope
    public MessageBucket messageBucket() {
        return new DefaultMessageBucket();
    }
}
 