package tr.com.allianz.accounting_ui_backend.cyclic_postings.service;


import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import tr.com.allianz.accounting_ui_backend.request_response.RestResponse;
import tr.com.allianz.accounting_ui_backend.service.RestClientConsumerService;
import tr.com.allianz.accounting_ui_backend.service.config.client.CustomDispatcherClient;

import tr.com.allianz.pmc.client.DispatcherClientResponse;
import tr.com.allianz.pmc.client.model.*;
import tr.com.allianz.pmc.commonmessageutils.MessageBucket;

@Slf4j
@Service
@RequiredArgsConstructor
public class CyclicPostingProcessService extends RestClientConsumerService {

    private final CustomDispatcherClient pmcRestClientClient;
    private final MessageBucket messageBucket;

    public RestResponse<AlzCyclicPostingProcessListResponse> getAlzCyclicMappingList(
            Integer page,
             Integer size,
             Long batchId,
            Long cyclicBatchId,
            String status

    ) {

        DispatcherClientResponse<ApiResponseAlzCyclicPostingProcessListResponse> response =  pmcRestClientClient.restAlzCyclicPostingProcessControllerApi
                .listAlzCyclicPostingProcess(page,size,batchId,cyclicBatchId,status);

        ApiResponseAlzCyclicPostingProcessListResponse apiResponse = processRestResponse(response);

        if(apiResponse!=null)
            return new RestResponse<>(apiResponse.getData());

        return handleErrorResponse(messageBucket, response.getError());
    }

    public RestResponse<CreateCyclicPostingResponse> createAlzCyclicPostingProcess(CreateCyclicPostingRequest request) {

        DispatcherClientResponse<ApiResponseCreateCyclicPostingResponse> response
                =  pmcRestClientClient.restAlzCyclicPostingProcessControllerApi
                .createCyclicPostings(request);

        ApiResponseCreateCyclicPostingResponse apiResponse =
                processRestResponse(response);

        if(apiResponse!=null)
            return new RestResponse<>(apiResponse.getData());

        return handleErrorResponse(messageBucket, response.getError());
    }

    public RestResponse<RemoveCyclicPostingProcessResponse>  removeUnprocessedCyclicPosting(RemoveCyclicPostingProcessRequest request) {
        DispatcherClientResponse<ApiResponseRemoveCyclicPostingProcessResponse>  response = pmcRestClientClient.restAlzCyclicPostingProcessControllerApi.removeUnprocessedCyclicPostings(request);

        ApiResponseRemoveCyclicPostingProcessResponse apiResponse = processRestResponse(response);

        if(apiResponse!=null)
            return new RestResponse<>(apiResponse.getData());

        return handleErrorResponse(messageBucket, response.getError());
    }

    public RestResponse<ProcessCyclicPostingResponse> processCyclicPosting(ProcessCyclicPostingRequest request) {
        DispatcherClientResponse<ApiResponseProcessCyclicPostingResponse> response = pmcRestClientClient.restAlzCyclicPostingProcessControllerApi
                .processCyclicPostings(request);

        ApiResponseProcessCyclicPostingResponse apiResponse = processRestResponse(response);

        if(apiResponse!=null)
            return new RestResponse<>(apiResponse.getData());

        return handleErrorResponse(messageBucket, response.getError());
    }




}
