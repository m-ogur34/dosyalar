package tr.com.allianz.accounting_ui_backend.cyclic_postings.controller;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import tr.com.allianz.accounting_ui_backend.cyclic_postings.service.CyclicAccountMappingService;
import tr.com.allianz.accounting_ui_backend.request_response.RestResponse;
import tr.com.allianz.accounting_ui_backend.shared.constants.AccountingConstants;
import tr.com.allianz.pmc.client.model.*;

@RestController
@Slf4j
@RequiredArgsConstructor
@RequestMapping(value = AccountingConstants.API_ROOT + "/cyclic-account-mapping")
@CrossOrigin
public class CyclicAccountMappingController {

    private final CyclicAccountMappingService cyclicAccountMappingService;

    @GetMapping("/list")
    public ResponseEntity<RestResponse<AlzCyclicAccountMappingListResponse>>  getAlzCyclicMappingList()  {
        return ResponseEntity.ok(cyclicAccountMappingService.getAlzCyclicMappingList());
    }

    @PostMapping("/create")
    public ResponseEntity<RestResponse<CreateAlzCyclicAccountMappingResponse>>  createCyclicAccountMapping(@RequestBody CreateAlzCyclicAccountMappingRequest request)  {
        return ResponseEntity.ok(cyclicAccountMappingService.createAlzCyclicAccountMappingResponse(request));
    }

    @PostMapping("/remove")
    public ResponseEntity<RestResponse<RemoveAlzCyclicAccountMappingResponse>>  removeCyclicAccountMapping(@RequestBody RemoveAlzCyclicAccountMappingRequest request) {
        return ResponseEntity.ok(cyclicAccountMappingService.removeAlzCyclicAccountMappingResponse(request));
    }

}
