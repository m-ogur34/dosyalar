package tr.com.allianz.accounting_ui_backend.config.cas;

import com.allianz.auth.client.model.UserDetailsModel;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import tr.com.allianz.accounting_ui_backend.shared.constants.exception.AppException;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class ApplicationUserServiceTest {

    private ApplicationUserService applicationUserService;
    private SecurityContext securityContext;
    private Authentication authentication;
    private UserDetailsModel userDetailsModel;

    @BeforeEach
    void setUp() {
        applicationUserService = new ApplicationUserService();
        securityContext = mock(SecurityContext.class);
        authentication = mock(Authentication.class);
        userDetailsModel = mock(UserDetailsModel.class);

        SecurityContextHolder.setContext(securityContext);
        when(securityContext.getAuthentication()).thenReturn(authentication);
    }

    @AfterEach
    void tearDown() {
        SecurityContextHolder.clearContext();
    }

    @Test
    void testGetAuthenticatedUser_ShouldReturnUserDetailsModel_WhenPrincipalIsUserDetailsModel() {
        // Arrange
        when(authentication.getPrincipal()).thenReturn(userDetailsModel);

        // Act
        UserDetailsModel result = applicationUserService.getAuthenticatedUser();

        // Assert
        assertNotNull(result);
        assertEquals(userDetailsModel, result);
        verify(authentication, times(1)).getPrincipal();
    }

    @Test
    void testGetAuthenticatedUser_ShouldThrowAppException_WhenPrincipalIsNotUserDetailsModel() {
        // Arrange
        String invalidPrincipal = "NotAUserDetailsModel";
        when(authentication.getPrincipal()).thenReturn(invalidPrincipal);

        // Act & Assert
        AppException exception = assertThrows(AppException.class,
                () -> applicationUserService.getAuthenticatedUser());

        assertEquals("Get Authenticated User Error.", exception.getMessage());
        verify(authentication, times(1)).getPrincipal();
    }

    @Test
    void testGetAuthenticatedUser_ShouldThrowAppException_WhenPrincipalIsNull() {
        // Arrange
        when(authentication.getPrincipal()).thenReturn(null);

        // Act & Assert
        AppException exception = assertThrows(AppException.class,
                () -> applicationUserService.getAuthenticatedUser());

        assertEquals("Get Authenticated User Error.", exception.getMessage());
    }

    @Test
    void testGetUserName_ShouldReturnUserName() {
        // Arrange
        when(authentication.getPrincipal()).thenReturn(userDetailsModel);
        when(userDetailsModel.getUserName()).thenReturn("testUser");

        // Act
        String userName = applicationUserService.getUserName();

        // Assert
        assertEquals("testUser", userName);
        verify(userDetailsModel, times(1)).getUserName();
    }

    @Test
    void testGetUserName_ShouldReturnNull_WhenUserNameIsNull() {
        // Arrange
        when(authentication.getPrincipal()).thenReturn(userDetailsModel);
        when(userDetailsModel.getUserName()).thenReturn(null);

        // Act
        String userName = applicationUserService.getUserName();

        // Assert
        assertNull(userName);
    }

    @Test
    void testGetUserName_ShouldThrowAppException_WhenAuthenticationFails() {
        // Arrange
        when(authentication.getPrincipal()).thenReturn("InvalidPrincipal");

        // Act & Assert
        assertThrows(AppException.class, () -> applicationUserService.getUserName());
    }

    @Test
    void testGetChannel_ShouldReturnUserName() {
        // Arrange
        when(authentication.getPrincipal()).thenReturn(userDetailsModel);
        when(userDetailsModel.getUserName()).thenReturn("channelUser");

        // Act
        String channel = applicationUserService.getChannel();

        // Assert
        assertEquals("channelUser", channel);
        verify(userDetailsModel, times(1)).getUserName();
    }

    @Test
    void testGetChannel_ShouldReturnNull_WhenUserNameIsNull() {
        // Arrange
        when(authentication.getPrincipal()).thenReturn(userDetailsModel);
        when(userDetailsModel.getUserName()).thenReturn(null);

        // Act
        String channel = applicationUserService.getChannel();

        // Assert
        assertNull(channel);
    }

    @Test
    void testGetChannel_ShouldThrowAppException_WhenAuthenticationFails() {
        // Arrange
        when(authentication.getPrincipal()).thenReturn(123); // Invalid type

        // Act & Assert
        assertThrows(AppException.class, () -> applicationUserService.getChannel());
    }

    @Test
    void testGetAuthenticatedUser_WithDifferentUserNames() {
        // Arrange
        when(authentication.getPrincipal()).thenReturn(userDetailsModel);
        when(userDetailsModel.getUserName()).thenReturn("user1");

        // Act
        UserDetailsModel result1 = applicationUserService.getAuthenticatedUser();
        String userName1 = applicationUserService.getUserName();

        // Update mock
        when(userDetailsModel.getUserName()).thenReturn("user2");
        String userName2 = applicationUserService.getUserName();

        // Assert
        assertNotNull(result1);
        assertEquals("user1", userName1);
        assertEquals("user2", userName2);
    }

    @Test
    void testConstructor_ShouldCreateInstance() {
        // Act
        ApplicationUserService service = new ApplicationUserService();

        // Assert
        assertNotNull(service);
    }

    @Test
    void testGetUserName_WithEmptyString() {
        // Arrange
        when(authentication.getPrincipal()).thenReturn(userDetailsModel);
        when(userDetailsModel.getUserName()).thenReturn("");

        // Act
        String userName = applicationUserService.getUserName();

        // Assert
        assertEquals("", userName);
    }

    @Test
    void testGetChannel_WithEmptyString() {
        // Arrange
        when(authentication.getPrincipal()).thenReturn(userDetailsModel);
        when(userDetailsModel.getUserName()).thenReturn("");

        // Act
        String channel = applicationUserService.getChannel();

        // Assert
        assertEquals("", channel);
    }

    @Test
    void testGetAuthenticatedUser_WithDifferentPrincipalTypes() {
        // Test with String
        when(authentication.getPrincipal()).thenReturn("StringPrincipal");
        assertThrows(AppException.class, () -> applicationUserService.getAuthenticatedUser());

        // Test with Integer
        when(authentication.getPrincipal()).thenReturn(12345);
        assertThrows(AppException.class, () -> applicationUserService.getAuthenticatedUser());

        // Test with Object
        when(authentication.getPrincipal()).thenReturn(new Object());
        assertThrows(AppException.class, () -> applicationUserService.getAuthenticatedUser());
    }

    @Test
    void testGetUserName_WithLongUserName() {
        // Arrange
        String longUserName = "a".repeat(1000);
        when(authentication.getPrincipal()).thenReturn(userDetailsModel);
        when(userDetailsModel.getUserName()).thenReturn(longUserName);

        // Act
        String userName = applicationUserService.getUserName();

        // Assert
        assertEquals(longUserName, userName);
        assertEquals(1000, userName.length());
    }

    @Test
    void testGetChannel_WithSpecialCharacters() {
        // Arrange
        String specialUserName = "user@#$%^&*()_+-=[]{}|;':\",./<>?";
        when(authentication.getPrincipal()).thenReturn(userDetailsModel);
        when(userDetailsModel.getUserName()).thenReturn(specialUserName);

        // Act
        String channel = applicationUserService.getChannel();

        // Assert
        assertEquals(specialUserName, channel);
    }

    @Test
    void testMultipleMethodCalls_ShouldUseSameAuthentication() {
        // Arrange
        when(authentication.getPrincipal()).thenReturn(userDetailsModel);
        when(userDetailsModel.getUserName()).thenReturn("sameUser");

        // Act
        UserDetailsModel user = applicationUserService.getAuthenticatedUser();
        String userName = applicationUserService.getUserName();
        String channel = applicationUserService.getChannel();

        // Assert
        assertNotNull(user);
        assertEquals("sameUser", userName);
        assertEquals("sameUser", channel);
    }
}

