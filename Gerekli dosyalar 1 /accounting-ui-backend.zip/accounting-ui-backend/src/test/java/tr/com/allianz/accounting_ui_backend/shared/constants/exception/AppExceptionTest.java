package tr.com.allianz.accounting_ui_backend.shared.constants.exception;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class AppExceptionTest {

    @Test
    void constructor_WithMessage_ShouldCreateExceptionWithMessageAndDefaultCode() {
        // Arrange
        String message = "Test error message";

        // Act
        AppException exception = new AppException(message);

        // Assert
        assertNotNull(exception);
        assertEquals(message, exception.getMessage());
        assertNotNull(exception.getCode());
        assertEquals("0", exception.getCode().getCode());
    }

    @Test
    void constructor_WithErrorCode_ShouldCreateExceptionWithCode() {
        // Arrange
        ErrorCode code = new ErrorCode("ERR_001");

        // Act
        AppException exception = new AppException(code);

        // Assert
        assertNotNull(exception);
        assertEquals(code, exception.getCode());
    }

    @Test
    void constructor_WithCodeAndMessage_ShouldCreateExceptionWithBoth() {
        // Arrange
        String codeStr = "ERR_002";
        String message = "Error occurred";

        // Act
        AppException exception = new AppException(codeStr, message);

        // Assert
        assertNotNull(exception);
        assertEquals(message, exception.getMessage());
        assertNotNull(exception.getCode());
        assertEquals(codeStr, exception.getCode().getCode());
    }

    @Test
    void constructor_WithErrorCodeAndMessage_ShouldCreateExceptionWithBoth() {
        // Arrange
        ErrorCode code = new ErrorCode("ERR_003");
        String message = "Another error";

        // Act
        AppException exception = new AppException(code, message);

        // Assert
        assertNotNull(exception);
        assertEquals(message, exception.getMessage());
        assertEquals(code, exception.getCode());
    }

    @Test
    void constructor_WithErrorCodeMessageAndCause_ShouldCreateExceptionWithAll() {
        // Arrange
        ErrorCode code = new ErrorCode("ERR_004");
        String message = "Root cause error";
        Throwable cause = new IllegalArgumentException("Invalid argument");

        // Act
        AppException exception = new AppException(code, message, cause);

        // Assert
        assertNotNull(exception);
        assertEquals(message, exception.getMessage());
        assertEquals(code, exception.getCode());
        assertEquals(cause, exception.getCause());
    }

    @Test
    void getCode_ShouldReturnCorrectCode() {
        // Arrange
        ErrorCode code = new ErrorCode("ERR_005");
        AppException exception = new AppException(code);

        // Act
        ErrorCode retrievedCode = exception.getCode();

        // Assert
        assertNotNull(retrievedCode);
        assertEquals(code, retrievedCode);
    }

    @Test
    void shouldExtendRuntimeException() {
        // Arrange
        AppException exception = new AppException("Test");

        // Assert
        assertInstanceOf(RuntimeException.class, exception);
    }

    @Test
    void shouldImplementErrorCodeAware() {
        // Arrange
        AppException exception = new AppException(new ErrorCode("ERR_006"));

        // Assert
        assertInstanceOf(ErrorCodeAware.class, exception);
    }

    @Test
    void constructor_WithNullMessage_ShouldHandleGracefully() {
        // Act
        AppException exception = new AppException((String) null);

        // Assert
        assertNotNull(exception);
        assertNull(exception.getMessage());
    }

    @Test
    void constructor_WithNullCode_ShouldHandleGracefully() {
        // Act
        AppException exception = new AppException((ErrorCode) null);

        // Assert
        assertNotNull(exception);
        assertNull(exception.getCode());
    }

    @Test
    void constructor_WithEmptyMessage_ShouldCreateException() {
        // Arrange
        String message = "";

        // Act
        AppException exception = new AppException(message);

        // Assert
        assertNotNull(exception);
        assertEquals("", exception.getMessage());
    }

    @Test
    void constructor_WithNullCause_ShouldCreateException() {
        // Arrange
        ErrorCode code = new ErrorCode("ERR_007");
        String message = "Error with null cause";

        // Act
        AppException exception = new AppException(code, message, null);

        // Assert
        assertNotNull(exception);
        assertEquals(message, exception.getMessage());
        assertNull(exception.getCause());
    }


    @Test
    void throwAppException_ShouldBeCatchable() {
        // Act & Assert
        assertThrows(AppException.class, () -> {
            throw new AppException("Throwable error");
        });
    }

    @Test
    void throwAppException_ShouldBeCatchableAsRuntimeException() {
        // Act & Assert
        assertThrows(RuntimeException.class, () -> {
            throw new AppException("Runtime error");
        });
    }

    @Test
    void multipleConstructors_ShouldAllProduceValidExceptions() {
        // Arrange & Act
        AppException exception1 = new AppException("Message");
        AppException exception2 = new AppException(new ErrorCode("CODE"));
        AppException exception3 = new AppException("CODE", "Message");
        AppException exception4 = new AppException(new ErrorCode("CODE"), "Message");
        AppException exception5 = new AppException(new ErrorCode("CODE"), "Message", new Exception());

        // Assert
        assertNotNull(exception1);
        assertNotNull(exception2);
        assertNotNull(exception3);
        assertNotNull(exception4);
        assertNotNull(exception5);
    }

    @Test
    void getCode_WithStringConstructor_ShouldReturnDefaultCode() {
        // Arrange
        AppException exception = new AppException("Message");

        // Act
        ErrorCode code = exception.getCode();

        // Assert
        assertNotNull(code);
        assertEquals("0", code.getCode());
    }

    @Test
    void getMessage_ShouldPreserveExceptionMessage() {
        // Arrange
        String message = "Complex error message with special chars: @#$%^&*()";

        // Act
        AppException exception = new AppException(message);

        // Assert
        assertEquals(message, exception.getMessage());
    }

    @Test
    void getCause_ShouldReturnCorrectCause() {
        // Arrange
        ErrorCode code = new ErrorCode("ERR_008");
        Throwable cause = new IOException("IO error");
        AppException exception = new AppException(code, "Message", cause);

        // Act
        Throwable retrievedCause = exception.getCause();

        // Assert
        assertEquals(cause, retrievedCause);
    }

    @Test
    void stackTrace_ShouldBeAvailable() {
        // Arrange
        AppException exception = new AppException("Error");

        // Act
        StackTraceElement[] stackTrace = exception.getStackTrace();

        // Assert
        assertNotNull(stackTrace);
        assertTrue(stackTrace.length > 0);
    }
}

