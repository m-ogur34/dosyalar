package tr.com.allianz.accounting_ui_backend.config.cas;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.StaticApplicationContext;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.ObjectPostProcessor;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.DefaultSecurityFilterChain;
import org.springframework.security.web.access.intercept.AuthorizationFilter;
import org.springframework.security.web.header.HeaderWriterFilter;
import org.springframework.web.accept.HeaderContentNegotiationStrategy;
import org.springframework.web.accept.ContentNegotiationStrategy;
import org.springframework.web.filter.CorsFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;

@ExtendWith(MockitoExtension.class)
class WebSecurityConfigTest {

    @InjectMocks
    private WebSecurityConfig webSecurityConfig;

    private HttpSecurity createHttpSecurity() throws Exception {
        ObjectPostProcessor<Object> objectPostProcessor = new ObjectPostProcessor<>() {
            @Override
            public <O> O postProcess(O object) {
                return object;
            }
        };

        AuthenticationManagerBuilder authenticationBuilder = new AuthenticationManagerBuilder(objectPostProcessor);

        Map<Class<?>, Object> sharedObjects = new HashMap<>();
        ApplicationContext applicationContext = new StaticApplicationContext();
        sharedObjects.put(ApplicationContext.class, applicationContext);
        sharedObjects.put(ContentNegotiationStrategy.class, new HeaderContentNegotiationStrategy());
        sharedObjects.put(AuthenticationManager.class, mock(AuthenticationManager.class));

        return new HttpSecurity(objectPostProcessor, authenticationBuilder, sharedObjects);
    }

    private UrlBasedCorsConfigurationSource getCorsSource() {
        CorsConfigurationSource source = webSecurityConfig.corsConfigurationSource();
        assertInstanceOf(UrlBasedCorsConfigurationSource.class, source);
        return (UrlBasedCorsConfigurationSource) source;
    }

    private CorsConfiguration getCorsConfiguration() {
        CorsConfiguration config = getCorsSource().getCorsConfigurations().get("/**");
        assertNotNull(config);
        return config;
    }

    private List<String> getAllowedOriginPatterns() {
        List<String> patterns = getCorsConfiguration().getAllowedOriginPatterns();
        assertNotNull(patterns);
        return patterns;
    }

    private List<String> getAllowedMethods() {
        List<String> methods = getCorsConfiguration().getAllowedMethods();
        assertNotNull(methods);
        return methods;
    }

    private List<String> getAllowedHeaders() {
        List<String> headers = getCorsConfiguration().getAllowedHeaders();
        assertNotNull(headers);
        return headers;
    }


    @Test
    void constructor_ShouldCreateInstance() {
        // Arrange & Act
        WebSecurityConfig config = new WebSecurityConfig();

        // Assert
        assertNotNull(config);
    }

    @Test
    void securityFilterChain_ShouldBuildStatelessPermitAllChainWithCorsAndHeaders() throws Exception {
        DefaultSecurityFilterChain filterChain = (DefaultSecurityFilterChain) webSecurityConfig.securityFilterChain(createHttpSecurity());

        assertNotNull(filterChain);
        assertFalse(filterChain.getFilters().isEmpty());
        assertTrue(filterChain.getFilters().stream().anyMatch(CorsFilter.class::isInstance));
        assertTrue(filterChain.getFilters().stream().anyMatch(HeaderWriterFilter.class::isInstance));
        assertTrue(filterChain.getFilters().stream().anyMatch(AuthorizationFilter.class::isInstance));
    }

    @Test
    void corsConfigurationSource_ShouldNotBeNull() {
        // Act
        CorsConfigurationSource source = webSecurityConfig.corsConfigurationSource();

        // Assert
        assertNotNull(source);
    }

    @Test
    void corsConfigurationSource_ShouldReturnUrlBasedCorsConfigurationSource() {
        // Act
        CorsConfigurationSource source = webSecurityConfig.corsConfigurationSource();

        // Assert
        assertInstanceOf(UrlBasedCorsConfigurationSource.class, source);
    }

    @Test
    void corsConfigurationSource_ShouldHaveCorrectConfiguration() {
        CorsConfiguration config = getCorsConfiguration();

        // Assert
        assertEquals(Boolean.TRUE, config.getAllowCredentials());
    }

    @Test
    void corsConfigurationSource_ShouldAllowSpecificOrigins() {
        List<String> allowedOrigins = getAllowedOriginPatterns();

        assertTrue(allowedOrigins.contains("https://*.allianz.com.tr"));
        assertTrue(allowedOrigins.contains("http://*.allianz.com.tr"));
        assertTrue(allowedOrigins.contains("http://localhost:4200"));
        assertTrue(allowedOrigins.contains("http://localhost:8090"));
    }

    @Test
    void corsConfigurationSource_ShouldAllowAllMethods() {
        List<String> allowedMethods = getAllowedMethods();

        assertTrue(allowedMethods.contains("GET"));
        assertTrue(allowedMethods.contains("POST"));
        assertTrue(allowedMethods.contains("PUT"));
        assertTrue(allowedMethods.contains("PATCH"));
        assertTrue(allowedMethods.contains("DELETE"));
        assertTrue(allowedMethods.contains("OPTIONS"));
        assertTrue(allowedMethods.contains("HEAD"));
    }

    @Test
    void corsConfigurationSource_ShouldAllowAllHeaders() {
        List<String> allowedHeaders = getAllowedHeaders();

        assertTrue(allowedHeaders.contains("*"));
    }

    @Test
    void corsConfigurationSource_ShouldRegisterForAllPaths() {
        UrlBasedCorsConfigurationSource urlSource = getCorsSource();

        // Assert
        assertTrue(urlSource.getCorsConfigurations().containsKey("/**"));
    }

    @Test
    void corsConfigurationSource_ShouldEnableCredentials() {
        CorsConfiguration config = getCorsConfiguration();

        // Assert
        assertNotNull(config.getAllowCredentials());
        assertTrue(config.getAllowCredentials());
    }

    @Test
    void corsConfigurationSource_ShouldHaveCorrectNumberOfOrigins() {
        assertEquals(4, getAllowedOriginPatterns().size());
    }

    @Test
    void corsConfigurationSource_ShouldHaveCorrectNumberOfMethods() {
        assertEquals(7, getAllowedMethods().size());
    }

    @Test
    void corsConfigurationSource_ShouldAllowLocalhostOrigins() {
        List<String> patterns = getAllowedOriginPatterns();
        assertTrue(patterns.stream().anyMatch(p -> p.contains("localhost:4200")));
        assertTrue(patterns.stream().anyMatch(p -> p.contains("localhost:8090")));
    }

    @Test
    void corsConfigurationSource_ShouldAllowAllianzDomains() {
        List<String> patterns = getAllowedOriginPatterns();
        assertTrue(patterns.stream().anyMatch(p -> p.contains("allianz.com.tr")));
    }

    @Test
    void corsConfigurationSource_ShouldSupportHttpsAndHttp() {
        List<String> patterns = getAllowedOriginPatterns();
        assertTrue(patterns.stream().anyMatch(p -> p.startsWith("https://")));
        assertTrue(patterns.stream().anyMatch(p -> p.startsWith("http://")));
    }

    @Test
    void corsConfigurationSource_ShouldAllowDeleteMethod() {
        assertTrue(getAllowedMethods().contains("DELETE"));
    }

    @Test
    void corsConfigurationSource_ShouldAllowPatchMethod() {
        assertTrue(getAllowedMethods().contains("PATCH"));
    }

    @Test
    void corsConfigurationSource_ShouldAllowOptionsMethod() {
        assertTrue(getAllowedMethods().contains("OPTIONS"));
    }

    @Test
    void corsConfigurationSource_ShouldAllowHeadMethod() {
        assertTrue(getAllowedMethods().contains("HEAD"));
    }

    @Test
    void corsConfigurationSource_ShouldBeReusable() {
        // Act
        CorsConfigurationSource source1 = webSecurityConfig.corsConfigurationSource();
        CorsConfigurationSource source2 = webSecurityConfig.corsConfigurationSource();

        // Assert
        assertNotNull(source1);
        assertNotNull(source2);
        assertNotSame(source1, source2); // New instances each time
    }

    @Test
    void corsConfigurationSource_ConfigurationShouldBeImmutable() {
        CorsConfiguration config = getCorsConfiguration();

        // Assert
        assertNotNull(config.getAllowedOriginPatterns());
        assertNotNull(config.getAllowedMethods());
        assertNotNull(config.getAllowedHeaders());
    }

    @Test
    void corsConfigurationSource_ShouldHaveWildcardPathPattern() {
        UrlBasedCorsConfigurationSource urlSource = getCorsSource();

        // Assert
        assertTrue(urlSource.getCorsConfigurations().containsKey("/**"));
        assertEquals(1, urlSource.getCorsConfigurations().size());
    }

    @Test
    void webSecurityConfig_ShouldHaveNoArgsConstructor() {
        // Act & Assert
        assertDoesNotThrow(WebSecurityConfig::new);
    }

    @Test
    void corsConfiguration_OriginPatterns_ShouldNotBeEmpty() {
        assertFalse(getAllowedOriginPatterns().isEmpty());
    }

    @Test
    void corsConfiguration_Methods_ShouldNotBeEmpty() {
        assertFalse(getAllowedMethods().isEmpty());
    }

    @Test
    void corsConfiguration_Headers_ShouldNotBeEmpty() {
        assertFalse(getAllowedHeaders().isEmpty());
    }

    @Test
    void corsConfigurationSource_ShouldSupportRestfulOperations() {
        List<String> methods = getAllowedMethods();

        assertTrue(methods.contains("GET"));
        assertTrue(methods.contains("POST"));
        assertTrue(methods.contains("PUT"));
        assertTrue(methods.contains("DELETE"));
    }

    @Test
    void corsConfigurationSource_MultipleCallsShouldProduceDifferentInstances() {
        // Act
        CorsConfigurationSource source1 = webSecurityConfig.corsConfigurationSource();
        CorsConfigurationSource source2 = webSecurityConfig.corsConfigurationSource();
        CorsConfigurationSource source3 = webSecurityConfig.corsConfigurationSource();

        // Assert
        assertNotSame(source1, source2);
        assertNotSame(source2, source3);
        assertNotSame(source1, source3);
    }
}

