package tr.com.allianz.accounting_ui_backend.config.cas;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import tr.com.allianz.accounting_ui_backend.shared.constants.AccountingConstants;

import java.lang.reflect.Method;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mockStatic;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class AuthenticatedUserControllerTest {

    @InjectMocks
    private AuthenticatedUserController authenticatedUserController;


    @Test
    void constructor_ShouldCreateInstance() {
        // Arrange & Act
        AuthenticatedUserController authenticatedController = new AuthenticatedUserController();

        // Assert
        assertNotNull(authenticatedController);
    }

    @Test
    void classShouldHaveRestControllerAnnotation() {
        // Assert
        assertTrue(AuthenticatedUserController.class.isAnnotationPresent(RestController.class));
    }

    @Test
    void classShouldHaveCrossOriginAnnotation() {
        // Assert
        assertTrue(AuthenticatedUserController.class.isAnnotationPresent(CrossOrigin.class));
    }

    @Test
    void classShouldHaveRequestMappingAnnotation() {
        // Assert
        assertTrue(AuthenticatedUserController.class.isAnnotationPresent(RequestMapping.class));
    }

    @Test
    void requestMapping_ShouldHaveCorrectPath() {
        // Arrange
        RequestMapping annotation = AuthenticatedUserController.class.getAnnotation(RequestMapping.class);

        // Assert
        assertNotNull(annotation);
        assertEquals(1, annotation.value().length);
        assertEquals(AccountingConstants.API_ROOT + "/cas", annotation.value()[0]);
    }

    @Test
    void requestMapping_ShouldBeApiV1Cas() {
        // Arrange
        RequestMapping annotation = AuthenticatedUserController.class.getAnnotation(RequestMapping.class);

        // Assert
        assertTrue(annotation.value()[0].startsWith("/api/v1"));
        assertTrue(annotation.value()[0].endsWith("/cas"));
    }

    @Test
    void userProfile_MethodShouldExist() throws NoSuchMethodException {
        // Act
        Method method = AuthenticatedUserController.class.getMethod("userProfile");

        // Assert
        assertNotNull(method);
    }

    @Test
    void userProfile_MethodShouldHaveGetMappingAnnotation() throws NoSuchMethodException {
        // Arrange
        Method method = AuthenticatedUserController.class.getMethod("userProfile");

        // Assert
        assertTrue(method.isAnnotationPresent(GetMapping.class));
    }

    @Test
    void userProfile_GetMappingShouldHaveCorrectPath() throws NoSuchMethodException {
        // Arrange
        Method method = AuthenticatedUserController.class.getMethod("userProfile");
        GetMapping annotation = method.getAnnotation(GetMapping.class);

        // Assert
        assertNotNull(annotation);
        assertEquals(1, annotation.value().length);
        assertEquals("/user-profile", annotation.value()[0]);
    }


    @Test
    void userProfile_ShouldReturnUserProfileType() throws NoSuchMethodException {
        // Arrange
        Method method = AuthenticatedUserController.class.getMethod("userProfile");

        // Assert
        assertEquals(UserProfile.class, method.getReturnType());
    }

    @Test
    void userProfile_MethodShouldBePublic() throws NoSuchMethodException {
        // Arrange
        Method method = AuthenticatedUserController.class.getMethod("userProfile");

        // Assert
        assertTrue(java.lang.reflect.Modifier.isPublic(method.getModifiers()));
    }

    @Test
    void userProfile_MethodShouldHaveNoParameters() throws NoSuchMethodException {
        // Arrange
        Method method = AuthenticatedUserController.class.getMethod("userProfile");

        // Assert
        assertEquals(0, method.getParameterCount());
    }

    @Test
    void userProfile_ShouldDelegateToAuthenticatedUserService() {
        UserProfile expected = new UserProfile();
        expected.setUserName("test-user");

        try (MockedStatic<AuthenticatedUserService> authenticatedUserService = mockStatic(AuthenticatedUserService.class)) {
            authenticatedUserService.when(AuthenticatedUserService::getUserProfile).thenReturn(expected);

            UserProfile actual = authenticatedUserController.userProfile();

            assertSame(expected, actual);
            authenticatedUserService.verify(AuthenticatedUserService::getUserProfile);
        }
    }


    @Test
    void controllerShouldBePublic() {
        // Assert
        assertTrue(java.lang.reflect.Modifier.isPublic(
                AuthenticatedUserController.class.getModifiers()));
    }

    @Test
    void controllerShouldNotBeFinal() {
        // Assert
        assertFalse(java.lang.reflect.Modifier.isFinal(
                AuthenticatedUserController.class.getModifiers()));
    }

    @Test
    void controllerShouldNotBeAbstract() {
        // Assert
        assertFalse(java.lang.reflect.Modifier.isAbstract(
                AuthenticatedUserController.class.getModifiers()));
    }

    @Test
    void crossOrigin_ShouldBePresent() {
        // Arrange
        CrossOrigin annotation = AuthenticatedUserController.class.getAnnotation(CrossOrigin.class);

        // Assert
        assertNotNull(annotation);
    }


    @Test
    void fullEndpointPath_ShouldBeApiV1CasUserProfile() {
        // Arrange
        RequestMapping classMapping = AuthenticatedUserController.class.getAnnotation(RequestMapping.class);
        Method method = assertDoesNotThrow(() ->
                AuthenticatedUserController.class.getMethod("userProfile"));
        GetMapping methodMapping = method.getAnnotation(GetMapping.class);

        // Assert
        String fullPath = classMapping.value()[0] + methodMapping.value()[0];
        assertEquals("/api/v1/cas/user-profile", fullPath);
    }

    @Test
    void controller_ShouldHaveNoFields() {
        // Assert - Controller should be stateless
        assertEquals(0, AuthenticatedUserController.class.getDeclaredFields().length);
    }

    @Test
    void controller_ShouldBeStateless() {
        // Arrange & Act
        AuthenticatedUserController controller1 = new AuthenticatedUserController();
        AuthenticatedUserController controller2 = new AuthenticatedUserController();

        // Assert
        assertNotNull(controller1);
        assertNotNull(controller2);
        assertNotSame(controller1, controller2);
    }

}
