package tr.com.allianz.accounting_ui_backend.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import tr.com.allianz.accounting_ui_backend.request_response.RestResponse;
import tr.com.allianz.pmc.client.DispatcherClientResponse;
import tr.com.allianz.pmc.client.ErrorResponse;
import tr.com.allianz.pmc.commonmessageutils.MessageBucket;
import tr.com.allianz.pmc.commonmessageutils.Severity;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class RestClientConsumerServiceTest {

    @Mock
    private MessageBucket messageBucket;

    @Mock
    private ErrorResponse errorResponse;

    @Mock
    private DispatcherClientResponse<String> dispatcherClientResponse;

    private RestClientConsumerService restClientConsumerService;

    @BeforeEach
    void setUp() {
        // Create a concrete implementation of abstract class for testing
        restClientConsumerService = new RestClientConsumerService() {
        };
    }

    @Test
    void processRestResponse_ShouldReturnData_WhenResponseIsSuccessful() {
        // Arrange
        String expectedData = "test data";
        when(dispatcherClientResponse.isSuccess()).thenReturn(true);
        when(dispatcherClientResponse.getData()).thenReturn(expectedData);

        // Act
        String result = restClientConsumerService.processRestResponse(dispatcherClientResponse);

        // Assert
        assertNotNull(result);
        assertEquals(expectedData, result);
    }

    @Test
    void processRestResponse_ShouldReturnNull_WhenResponseIsNull() {
        // Act
        String result = restClientConsumerService.processRestResponse(null);

        // Assert
        assertNull(result);
    }

    @Test
    void processRestResponse_ShouldReturnNull_WhenResponseIsNotSuccess() {
        // Arrange
        when(dispatcherClientResponse.isSuccess()).thenReturn(false);
        // getData() is not called when isSuccess() returns false, so we don't stub it

        // Act
        String result = restClientConsumerService.processRestResponse(dispatcherClientResponse);

        // Assert
        assertNull(result);
    }

    @Test
    void processRestResponse_ShouldReturnNull_WhenResponseDataIsNull() {
        // Arrange
        when(dispatcherClientResponse.isSuccess()).thenReturn(true);
        when(dispatcherClientResponse.getData()).thenReturn(null);

        // Act
        String result = restClientConsumerService.processRestResponse(dispatcherClientResponse);

        // Assert
        assertNull(result);
    }

    @Test
    void processRestResponse_ShouldReturnNull_WhenResponseIsSuccessButDataNull() {
        // Arrange
        when(dispatcherClientResponse.isSuccess()).thenReturn(true);
        when(dispatcherClientResponse.getData()).thenReturn(null);

        // Act
        String result = restClientConsumerService.processRestResponse(dispatcherClientResponse);

        // Assert
        assertNull(result);
    }

    @Test
    void processRestResponse_ShouldReturnNull_WhenResponseIsNotSuccessButDataPresent() {
        // Arrange
        lenient().when(dispatcherClientResponse.isSuccess()).thenReturn(false);
        // getData() is not called when isSuccess() returns false, so we don't stub it

        // Act
        String result = restClientConsumerService.processRestResponse(dispatcherClientResponse);

        // Assert
        assertNull(result);
    }

    @Test
    void processRestResponse_ShouldHandleEmptyString() {
        // Arrange
        when(dispatcherClientResponse.isSuccess()).thenReturn(true);
        when(dispatcherClientResponse.getData()).thenReturn("");

        // Act
        String result = restClientConsumerService.processRestResponse(dispatcherClientResponse);

        // Assert
        assertNotNull(result);
        assertEquals("", result);
    }

    @Test
    void processRestResponse_ShouldHandleDifferentDataTypes() {
        // Arrange
        @SuppressWarnings("unchecked")
        DispatcherClientResponse<Integer> intResponse = mock(DispatcherClientResponse.class);
        when(intResponse.isSuccess()).thenReturn(true);
        when(intResponse.getData()).thenReturn(42);

        // Act
        Integer result = restClientConsumerService.processRestResponse(intResponse);

        // Assert
        assertNotNull(result);
        assertEquals(42, result);
    }

    @Test
    void handleErrorResponse_ShouldAddMessageAndReturnRestResponse_WhenErrorResponseIsNull() {
        // Act
        RestResponse<String> result = restClientConsumerService.handleErrorResponse(messageBucket, null);

        // Assert
        assertNotNull(result);
        verify(messageBucket).addExternalMessage(
                "UNKNOWN ERROR",
                "Muhasebe Servisinden Hata Mesajı Boş Geldi",
                Severity.ERROR
        );
        verify(messageBucket).getMessages();
    }

    @Test
    void handleErrorResponse_ShouldAddErrorMessageWithDetails_WhenErrorResponseIsNotNull() {
        // Arrange
        String errorCode = "SERVICE_ERROR";
        String errorMessage = "Service unavailable";
        when(errorResponse.getCode()).thenReturn(errorCode);
        when(errorResponse.getMessage()).thenReturn(errorMessage);

        // Act
        RestResponse<String> result = restClientConsumerService.handleErrorResponse(messageBucket, errorResponse);

        // Assert
        assertNotNull(result);
        verify(messageBucket).addExternalMessage(
                errorCode,
                errorMessage,
                Severity.ERROR
        );
        verify(messageBucket).getMessages();
    }

    @Test
    void handleErrorResponse_ShouldSetUiMessagesInRestResponse() {
        // Act
        RestResponse<String> result = restClientConsumerService.handleErrorResponse(messageBucket, null);

        // Assert
        assertNotNull(result);
        verify(messageBucket).getMessages();
    }

    @Test
    void handleErrorResponse_ShouldReturnEmptyRestResponse_WhenNoMessagesAdded() {
        // Act
        RestResponse<String> result = restClientConsumerService.handleErrorResponse(messageBucket, null);

        // Assert
        assertNotNull(result);
        assertNull(result.getData());
    }

    @Test
    void handleErrorResponse_ShouldHandleNullErrorCode() {
        // Arrange
        when(errorResponse.getCode()).thenReturn(null);
        when(errorResponse.getMessage()).thenReturn("Error message");

        // Act
        RestResponse<String> result = restClientConsumerService.handleErrorResponse(messageBucket, errorResponse);

        // Assert
        assertNotNull(result);
        verify(messageBucket).addExternalMessage(null, "Error message", Severity.ERROR);
    }

    @Test
    void handleErrorResponse_ShouldHandleNullErrorMessage() {
        // Arrange
        when(errorResponse.getCode()).thenReturn("ERROR_CODE");
        when(errorResponse.getMessage()).thenReturn(null);

        // Act
        RestResponse<String> result = restClientConsumerService.handleErrorResponse(messageBucket, errorResponse);

        // Assert
        assertNotNull(result);
        verify(messageBucket).addExternalMessage("ERROR_CODE", null, Severity.ERROR);
    }

    @Test
    void handleErrorResponse_ShouldHandleEmptyErrorCode() {
        // Arrange
        when(errorResponse.getCode()).thenReturn("");
        when(errorResponse.getMessage()).thenReturn("Message");

        // Act
        RestResponse<String> result = restClientConsumerService.handleErrorResponse(messageBucket, errorResponse);

        // Assert
        assertNotNull(result);
        verify(messageBucket).addExternalMessage("", "Message", Severity.ERROR);
    }

    @Test
    void handleErrorResponse_ShouldHandleEmptyErrorMessage() {
        // Arrange
        when(errorResponse.getCode()).thenReturn("CODE");
        when(errorResponse.getMessage()).thenReturn("");

        // Act
        RestResponse<String> result = restClientConsumerService.handleErrorResponse(messageBucket, errorResponse);

        // Assert
        assertNotNull(result);
        verify(messageBucket).addExternalMessage("CODE", "", Severity.ERROR);
    }

    @Test
    void handleErrorResponse_ShouldAlwaysUseSeverityError() {
        // Arrange
        when(errorResponse.getCode()).thenReturn("ERROR");
        when(errorResponse.getMessage()).thenReturn("Message");

        // Act
        restClientConsumerService.handleErrorResponse(messageBucket, errorResponse);

        // Assert
        verify(messageBucket).addExternalMessage(
                anyString(),
                anyString(),
                eq(Severity.ERROR)
        );
    }

    @Test
    void handleErrorResponse_ShouldHandleLongErrorMessages() {
        // Arrange
        String longCode = "CODE_".repeat(100);
        String longMessage = "MESSAGE_".repeat(100);
        when(errorResponse.getCode()).thenReturn(longCode);
        when(errorResponse.getMessage()).thenReturn(longMessage);

        // Act
        RestResponse<String> result = restClientConsumerService.handleErrorResponse(messageBucket, errorResponse);

        // Assert
        assertNotNull(result);
        verify(messageBucket).addExternalMessage(longCode, longMessage, Severity.ERROR);
    }

    @Test
    void processRestResponse_ShouldHandleAllConditionsFailing() {
        // Arrange
        lenient().when(dispatcherClientResponse.isSuccess()).thenReturn(false);
        // getData() is not called when isSuccess() returns false, so we don't stub it

        // Act
        String result = restClientConsumerService.processRestResponse(dispatcherClientResponse);

        // Assert
        assertNull(result);
    }

    @Test
    void handleErrorResponse_ShouldHandleMultipleCalls() {
        // Arrange
        when(errorResponse.getCode()).thenReturn("ERROR1");
        when(errorResponse.getMessage()).thenReturn("Message1");

        // Act
        RestResponse<String> result1 = restClientConsumerService.handleErrorResponse(messageBucket, errorResponse);

        when(errorResponse.getCode()).thenReturn("ERROR2");
        when(errorResponse.getMessage()).thenReturn("Message2");

        RestResponse<String> result2 = restClientConsumerService.handleErrorResponse(messageBucket, errorResponse);

        // Assert
        assertNotNull(result1);
        assertNotNull(result2);
        verify(messageBucket, times(2)).addExternalMessage(anyString(), anyString(), any(Severity.class));
        verify(messageBucket, times(2)).getMessages();
    }

    @Test
    void processRestResponse_ShouldReturnDataWhenAllConditionsAreMet() {
        // Arrange
        String data = "Success data";
        when(dispatcherClientResponse.isSuccess()).thenReturn(true);
        when(dispatcherClientResponse.getData()).thenReturn(data);

        // Act
        String result = restClientConsumerService.processRestResponse(dispatcherClientResponse);

        // Assert
        assertNotNull(result);
        assertEquals(data, result);
    }
}

