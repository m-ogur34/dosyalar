package tr.com.allianz.accounting_ui_backend.config.cas;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.context.MessageSource;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.Ordered;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.mock.web.MockServletContext;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class WebConfigTest {

    private WebConfig webConfig;

    @Mock
    private ViewControllerRegistry viewControllerRegistry;

    @BeforeEach
    void setUp() {
        webConfig = new WebConfig();
    }

    @Test
    void addResourceHandlers_ShouldRegisterSwaggerUIResources() {
        AnnotationConfigWebApplicationContext context = new AnnotationConfigWebApplicationContext();
        MockServletContext servletContext = new MockServletContext();
        context.setServletContext(servletContext);
        ResourceHandlerRegistry registry = new ResourceHandlerRegistry(context, servletContext);

        webConfig.addResourceHandlers(registry);

        assertTrue(registry.hasMappingForPattern("swagger-ui.html"));
    }

    @Test
    void addViewControllers_ShouldRegisterRedirectToSwaggerUI() {
        webConfig.addViewControllers(viewControllerRegistry);

        verify(viewControllerRegistry).addRedirectViewController("/", "swagger-ui.html");
        verify(viewControllerRegistry).setOrder(Ordered.HIGHEST_PRECEDENCE);
    }

    @Test
    void addViewControllers_ShouldSetHighestPrecedence() {
        webConfig.addViewControllers(viewControllerRegistry);

        ArgumentCaptor<Integer> orderCaptor = ArgumentCaptor.forClass(Integer.class);
        verify(viewControllerRegistry).setOrder(orderCaptor.capture());
        assertEquals(Ordered.HIGHEST_PRECEDENCE, orderCaptor.getValue());
    }

    @Test
    void extendMessageConverters_ShouldConfigureJacksonObjectMapper() {
        // Arrange
        ObjectMapper objectMapper = new ObjectMapper();
        MappingJackson2HttpMessageConverter jacksonConverter = new MappingJackson2HttpMessageConverter(objectMapper);
        List<HttpMessageConverter<?>> converters = new ArrayList<>();
        converters.add(jacksonConverter);

        // Act
        webConfig.extendMessageConverters(converters);

        // Assert
        assertFalse(objectMapper.isEnabled(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS),
                "WRITE_DATES_AS_TIMESTAMPS should be disabled");
        assertFalse(objectMapper.isEnabled(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES),
                "FAIL_ON_UNKNOWN_PROPERTIES should be disabled");
    }

    @Test
    void extendMessageConverters_ShouldOnlyModifyJacksonConverter() {
        // Arrange
        ObjectMapper objectMapper = new ObjectMapper();
        // Enable features to verify they are disabled
        objectMapper.enable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
        objectMapper.enable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);

        MappingJackson2HttpMessageConverter jacksonConverter = new MappingJackson2HttpMessageConverter(objectMapper);
        List<HttpMessageConverter<?>> converters = new ArrayList<>();
        converters.add(jacksonConverter);

        // Act
        webConfig.extendMessageConverters(converters);

        // Assert - Verify the first Jackson converter was modified
        MappingJackson2HttpMessageConverter modifiedConverter = (MappingJackson2HttpMessageConverter) converters.getFirst();
        ObjectMapper modifiedMapper = modifiedConverter.getObjectMapper();

        assertFalse(modifiedMapper.isEnabled(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS));
        assertFalse(modifiedMapper.isEnabled(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES));
    }

    @Test
    void extendMessageConverters_ShouldBreakAfterFirstJacksonConverter() {
        // Arrange
        ObjectMapper objectMapper1 = new ObjectMapper();
        ObjectMapper objectMapper2 = new ObjectMapper();

        objectMapper1.enable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
        objectMapper2.enable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);

        MappingJackson2HttpMessageConverter jacksonConverter1 = new MappingJackson2HttpMessageConverter(objectMapper1);
        MappingJackson2HttpMessageConverter jacksonConverter2 = new MappingJackson2HttpMessageConverter(objectMapper2);

        List<HttpMessageConverter<?>> converters = new ArrayList<>();
        converters.add(jacksonConverter1);
        converters.add(jacksonConverter2);

        // Act
        webConfig.extendMessageConverters(converters);

        // Assert - Only first converter should be modified
        assertFalse(objectMapper1.isEnabled(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS),
                "First Jackson converter should be modified");
        assertTrue(objectMapper2.isEnabled(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS),
                "Second Jackson converter should NOT be modified (loop breaks after first)");
    }

    @Test
    void ghpMessageSource_MethodShouldExist() {
        assertDoesNotThrow(() ->
                WebConfig.class.getDeclaredMethod("ghpMessageSource")
        );
    }

    @Test
    void ghpMessageSource_ShouldReturnUtf8ReloadableBundleMessageSource() {
        MessageSource messageSource = webConfig.ghpMessageSource();

        assertInstanceOf(ReloadableResourceBundleMessageSource.class, messageSource);

        ReloadableResourceBundleMessageSource reloadable = (ReloadableResourceBundleMessageSource) messageSource;
        assertEquals("UTF-8", ReflectionTestUtils.getField(reloadable, "defaultEncoding"));
        assertEquals("classpath:GroupHealthProductionMessages", reloadable.getBasenameSet().iterator().next());
    }

    @Test
    void extendMessageConverters_ShouldHandleEmptyConverterList() {
        // Arrange
        List<HttpMessageConverter<?>> converters = new ArrayList<>();

        // Act & Assert - Should not throw exception
        assertDoesNotThrow(() -> webConfig.extendMessageConverters(converters));
    }

    @Test
    void extendMessageConverters_ShouldHandleNonJacksonConverters() {
        // Arrange
        List<HttpMessageConverter<?>> converters = new ArrayList<>();
        HttpMessageConverter<?> nonJacksonConverter = mock(HttpMessageConverter.class);
        converters.add(nonJacksonConverter);

        // Act & Assert - Should not throw exception
        assertDoesNotThrow(() -> webConfig.extendMessageConverters(converters));
    }
}
