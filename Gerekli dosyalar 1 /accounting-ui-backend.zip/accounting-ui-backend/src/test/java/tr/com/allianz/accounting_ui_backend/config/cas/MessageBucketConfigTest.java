package tr.com.allianz.accounting_ui_backend.config.cas;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.web.context.annotation.RequestScope;
import tr.com.allianz.pmc.commonmessageutils.MessageBucket;

import java.lang.reflect.Method;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class MessageBucketConfigTest {

    @InjectMocks
    private MessageBucketConfig messageBucketConfig;

    @Test
    void constructor_ShouldCreateInstance() {
        // Arrange & Act
        MessageBucketConfig config = new MessageBucketConfig();

        // Assert
        assertNotNull(config);
    }

    @Test
    void messageBucket_ShouldReturnMessageBucketInstance() {
        // Act
        MessageBucket messageBucket = messageBucketConfig.messageBucket();

        // Assert
        assertNotNull(messageBucket);
    }

    @Test
    void messageBucket_ShouldReturnDefaultMessageBucket() {
        // Act
        MessageBucket messageBucket = messageBucketConfig.messageBucket();

        // Assert
        assertInstanceOf(DefaultMessageBucket.class, messageBucket);
    }

    @Test
    void messageBucket_ShouldReturnDifferentInstancesOnMultipleCalls() {
        // Act
        MessageBucket bucket1 = messageBucketConfig.messageBucket();
        MessageBucket bucket2 = messageBucketConfig.messageBucket();

        // Assert
        assertNotNull(bucket1);
        assertNotNull(bucket2);
        assertNotSame(bucket1, bucket2);
    }

    @Test
    void messageBucket_MethodShouldHaveBeanAnnotation() throws NoSuchMethodException {
        // Arrange
        Method method = MessageBucketConfig.class.getMethod("messageBucket");

        // Assert
        assertTrue(method.isAnnotationPresent(org.springframework.context.annotation.Bean.class));
    }

    @Test
    void messageBucket_MethodShouldHaveRequestScopeAnnotation() throws NoSuchMethodException {
        // Arrange
        Method method = MessageBucketConfig.class.getMethod("messageBucket");

        // Assert
        assertTrue(method.isAnnotationPresent(RequestScope.class));
    }

    @Test
    void classShouldHaveConfigurationAnnotation() {
        // Assert
        assertTrue(MessageBucketConfig.class.isAnnotationPresent(
                org.springframework.context.annotation.Configuration.class));
    }

    @Test
    void messageBucket_ShouldBePublicMethod() throws NoSuchMethodException {
        // Arrange
        Method method = MessageBucketConfig.class.getMethod("messageBucket");

        // Assert
        assertTrue(java.lang.reflect.Modifier.isPublic(method.getModifiers()));
    }

    @Test
    void messageBucket_ShouldReturnMessageBucketType() throws NoSuchMethodException {
        // Arrange
        Method method = MessageBucketConfig.class.getMethod("messageBucket");

        // Assert
        assertEquals(MessageBucket.class, method.getReturnType());
    }

    @Test
    void messageBucket_ShouldNotThrowException() {
        // Act & Assert
        assertDoesNotThrow(() -> messageBucketConfig.messageBucket());
    }


    @Test
    void messageBucket_MultipleInstancesShouldBeIndependent() {
        // Act
        MessageBucket bucket1 = messageBucketConfig.messageBucket();
        MessageBucket bucket2 = messageBucketConfig.messageBucket();

        // Assert - Each instance should be different
        assertNotSame(bucket1, bucket2);
    }

    @Test
    void messageBucket_ShouldCreateNewInstancePerRequest() {
        // Act
        MessageBucket bucket1 = messageBucketConfig.messageBucket();
        MessageBucket bucket2 = messageBucketConfig.messageBucket();
        MessageBucket bucket3 = messageBucketConfig.messageBucket();

        // Assert
        assertNotSame(bucket1, bucket2);
        assertNotSame(bucket2, bucket3);
        assertNotSame(bucket1, bucket3);
    }


    @Test
    void configClass_ShouldBePublic() {
        // Assert
        assertTrue(java.lang.reflect.Modifier.isPublic(
                MessageBucketConfig.class.getModifiers()));
    }

    @Test
    void configClass_ShouldNotBeFinal() {
        // Assert
        assertFalse(java.lang.reflect.Modifier.isFinal(
                MessageBucketConfig.class.getModifiers()));
    }

    @Test
    void configClass_ShouldNotBeAbstract() {
        // Assert
        assertFalse(java.lang.reflect.Modifier.isAbstract(
                MessageBucketConfig.class.getModifiers()));
    }

    @Test
    void messageBucket_MethodShouldHaveNoParameters() throws NoSuchMethodException {
        // Arrange
        Method method = MessageBucketConfig.class.getMethod("messageBucket");

        // Assert
        assertEquals(0, method.getParameterCount());
    }

    @Test
    void messageBucket_MethodShouldNotThrowAnyException() throws NoSuchMethodException {
        // Arrange
        Method method = MessageBucketConfig.class.getMethod("messageBucket");

        // Assert
        assertEquals(0, method.getExceptionTypes().length);
    }

    @Test
    void messageBucket_BeanShouldBeRequestScoped() throws NoSuchMethodException {
        // Arrange
        Method method = MessageBucketConfig.class.getMethod("messageBucket");
        RequestScope annotation = method.getAnnotation(RequestScope.class);

        // Assert
        assertNotNull(annotation);
    }


    @Test
    void messageBucket_InstancesShouldExtendMessageBucket() {
        // Act
        MessageBucket messageBucket = messageBucketConfig.messageBucket();

        // Assert
        assertInstanceOf(MessageBucket.class, messageBucket);
    }


    @Test
    void configClass_ShouldHaveNoArgsConstructor() {
        // Act & Assert
        assertDoesNotThrow(MessageBucketConfig::new);
    }

    @Test
    void messageBucket_ShouldBeSpringManagedBean() throws NoSuchMethodException {
        // Arrange
        Method method = MessageBucketConfig.class.getMethod("messageBucket");

        // Assert - Should have @Bean annotation
        assertTrue(method.isAnnotationPresent(
                org.springframework.context.annotation.Bean.class));
    }

    @Test
    void messageBucket_BeanNameShouldBeMethodName() throws NoSuchMethodException {
        // Arrange
        Method method = MessageBucketConfig.class.getMethod("messageBucket");

        // Assert
        assertEquals("messageBucket", method.getName());
    }

    @Test
    void configClass_ShouldBeInstantiable() {
        // Act
        MessageBucketConfig config1 = new MessageBucketConfig();
        MessageBucketConfig config2 = new MessageBucketConfig();

        // Assert
        assertNotNull(config1);
        assertNotNull(config2);
        assertNotSame(config1, config2);
    }
}

