package tr.com.allianz.accounting_ui_backend.service.config;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.util.AntPathMatcher;
import tr.com.allianz.accounting_ui_backend.service.config.client.CustomDispatcherClient;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class ServiceClientConfigTest {

    @InjectMocks
    private ServiceClientConfig serviceClientConfig;

    @BeforeEach
    void setUp() {
        ReflectionTestUtils.setField(serviceClientConfig, "accountingServiceUrl", "http://localhost:8080");
        ReflectionTestUtils.setField(serviceClientConfig, "accountingServiceTimeoutSec", 60L);
    }

    @Test
    void testDispatcherRestClient_ShouldCreateClientWithDefaultTimeout() {
        // Act
        CustomDispatcherClient client = serviceClientConfig.dispatcherRestClient();

        // Assert
        assertNotNull(client);
        assertNotNull(client.restAlzCyclicAccountMappingControllerApi);
        assertNotNull(client.restAlzCyclicPostingProcessControllerApi);
    }

    @Test
    void testDispatcherRestClient_ShouldUseConfiguredTimeout() {
        // Arrange
        ReflectionTestUtils.setField(serviceClientConfig, "accountingServiceTimeoutSec", 120L);

        // Act
        CustomDispatcherClient client = serviceClientConfig.dispatcherRestClient();

        // Assert
        assertNotNull(client);
        assertNotNull(client.restAlzCyclicAccountMappingControllerApi);
        assertNotNull(client.restAlzCyclicPostingProcessControllerApi);
    }

    @Test
    void testDispatcherRestClient_ShouldCreateOkHttpClientWithTimeouts() {
        // Act
        CustomDispatcherClient client = serviceClientConfig.dispatcherRestClient();

        // Assert
        assertNotNull(client);
    }

    @Test
    void testDispatcherRestClient_WithCustomUrl() {
        // Arrange
        ReflectionTestUtils.setField(serviceClientConfig, "accountingServiceUrl", "http://custom-url:9090");

        // Act
        CustomDispatcherClient client = serviceClientConfig.dispatcherRestClient();

        // Assert
        assertNotNull(client);
        assertNotNull(client.restAlzCyclicAccountMappingControllerApi);
    }

    @Test
    void testAntPathMatcher_ShouldReturnNewInstance() {
        // Act
        AntPathMatcher matcher = serviceClientConfig.antPathMatcher();

        // Assert
        assertNotNull(matcher);
        assertInstanceOf(AntPathMatcher.class, matcher);
    }

    @Test
    void testAntPathMatcher_ShouldWorkCorrectly() {
        // Act
        AntPathMatcher matcher = serviceClientConfig.antPathMatcher();

        // Assert
        assertTrue(matcher.match("/api/**", "/api/test"));
        assertTrue(matcher.match("/api/*", "/api/test"));
        assertFalse(matcher.match("/api/test", "/api/test/sub"));
    }

    @Test
    void testDispatcherRestClient_MultipleCalls_ShouldCreateDifferentInstances() {
        // Act
        CustomDispatcherClient client1 = serviceClientConfig.dispatcherRestClient();
        CustomDispatcherClient client2 = serviceClientConfig.dispatcherRestClient();

        // Assert
        assertNotNull(client1);
        assertNotNull(client2);
        assertNotSame(client1, client2);
    }

    @Test
    void testDispatcherRestClient_WithMinimalTimeout() {
        // Arrange
        ReflectionTestUtils.setField(serviceClientConfig, "accountingServiceTimeoutSec", 1L);

        // Act
        CustomDispatcherClient client = serviceClientConfig.dispatcherRestClient();

        // Assert
        assertNotNull(client);
    }

    @Test
    void testDispatcherRestClient_WithLargeTimeout() {
        // Arrange
        ReflectionTestUtils.setField(serviceClientConfig, "accountingServiceTimeoutSec", 300L);

        // Act
        CustomDispatcherClient client = serviceClientConfig.dispatcherRestClient();

        // Assert
        assertNotNull(client);
    }

    @Test
    void testDispatcherRestClient_ShouldInitializeAllEndpoints() {
        // Act
        CustomDispatcherClient client = serviceClientConfig.dispatcherRestClient();

        // Assert
        assertNotNull(client.restAlzCyclicAccountMappingControllerApi, "AlzCyclicAccountMappingControllerApi should be initialized");
        assertNotNull(client.restAlzCyclicPostingProcessControllerApi, "AlzCyclicPostingProcessControllerApi should be initialized");
    }
}

