package tr.com.allianz.accounting_ui_backend.cyclic_postings.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Answers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;
import tr.com.allianz.accounting_ui_backend.request_response.RestResponse;
import tr.com.allianz.accounting_ui_backend.service.config.client.CustomDispatcherClient;
import tr.com.allianz.pmc.client.DispatcherClientResponse;
import tr.com.allianz.pmc.client.endpoint.AlzCyclicAccountMappingControllerApiEndPoint;
import tr.com.allianz.pmc.client.model.*;
import tr.com.allianz.pmc.commonmessageutils.MessageBucket;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CyclicAccountMappingServiceTest {

    @Mock
    private CustomDispatcherClient pmcRestClientClient;

    @Mock
    private MessageBucket messageBucket;

    // Use DEEP_STUBS to mock the .getData().getData() chain automatically
    @Mock(answer = Answers.RETURNS_DEEP_STUBS)
    private AlzCyclicAccountMappingControllerApiEndPoint restAlzCyclicAccountMappingControllerApi;

    @InjectMocks
    private CyclicAccountMappingService cyclicAccountMappingService;

    @BeforeEach
    void setUp() {
        // The service accesses the public field 'restAlzCyclicAccountMappingControllerApi' directly.
        // We must manually set this field on the mock object to our mocked endpoint.
        ReflectionTestUtils.setField(pmcRestClientClient, "restAlzCyclicAccountMappingControllerApi", restAlzCyclicAccountMappingControllerApi);
    }

    @Test
    void getAlzCyclicMappingList_ShouldReturnListResponse() {
        // Arrange
        AlzCyclicAccountMappingListResponse expectedData = new AlzCyclicAccountMappingListResponse();
        ApiResponseAlzCyclicAccountMappingListResponse apiResponse = new ApiResponseAlzCyclicAccountMappingListResponse();
        apiResponse.setData(expectedData);

        DispatcherClientResponse<ApiResponseAlzCyclicAccountMappingListResponse> dispatcherResponse =
            new DispatcherClientResponse<>();
        dispatcherResponse.setData(apiResponse);
        dispatcherResponse.setSuccess(true);

        when(restAlzCyclicAccountMappingControllerApi
                .listCyclicAccountMapping())
                .thenReturn(dispatcherResponse);

        // Act
        RestResponse<AlzCyclicAccountMappingListResponse> result = cyclicAccountMappingService.getAlzCyclicMappingList();

        // Assert
        assertNotNull(result);
        assertNotNull(result.getData());
        assertEquals(expectedData, result.getData());
    }

    @Test
    void createAlzCyclicAccountMappingResponse_ShouldReturnCreateResponse() {
        // Arrange
        CreateAlzCyclicAccountMappingRequest request = new CreateAlzCyclicAccountMappingRequest();
        CreateAlzCyclicAccountMappingResponse expectedData = new CreateAlzCyclicAccountMappingResponse();
        ApiResponseCreateAlzCyclicAccountMappingResponse apiResponse = new ApiResponseCreateAlzCyclicAccountMappingResponse();
        apiResponse.setData(expectedData);

        DispatcherClientResponse<ApiResponseCreateAlzCyclicAccountMappingResponse> dispatcherResponse =
            new DispatcherClientResponse<>();
        dispatcherResponse.setData(apiResponse);
        dispatcherResponse.setSuccess(true);

        when(restAlzCyclicAccountMappingControllerApi
                .createCyclicAccountMapping(request))
                .thenReturn(dispatcherResponse);

        // Act
        RestResponse<CreateAlzCyclicAccountMappingResponse> result = cyclicAccountMappingService.createAlzCyclicAccountMappingResponse(request);

        // Assert
        assertNotNull(result);
        assertNotNull(result.getData());
        assertEquals(expectedData, result.getData());
    }

    @Test
    void createAlzCyclicAccountMappingResponse_ShouldReturnErrorResponse_WhenApiResponseFails() {
        // Arrange
        CreateAlzCyclicAccountMappingRequest request = new CreateAlzCyclicAccountMappingRequest();
        DispatcherClientResponse<ApiResponseCreateAlzCyclicAccountMappingResponse> dispatcherResponse =
                new DispatcherClientResponse<>();
        dispatcherResponse.setData(null);
        dispatcherResponse.setSuccess(false);

        when(restAlzCyclicAccountMappingControllerApi
                .createCyclicAccountMapping(request))
                .thenReturn(dispatcherResponse);

        // Act
        RestResponse<CreateAlzCyclicAccountMappingResponse> result =
                cyclicAccountMappingService.createAlzCyclicAccountMappingResponse(request);

        // Assert
        assertNotNull(result);
        assertNull(result.getData());
        // Verify handleErrorResponse logic was triggered (checking interactions with messageBucket)
        // Since verify calls are not strict, we assume base class logic works if result is not null (as handleErrorResponse returns a new RestResponse)
    }

    @Test
    void removeAlzCyclicAccountMappingResponse_ShouldReturnRemoveResponse() {
        // Arrange
        RemoveAlzCyclicAccountMappingRequest request = new RemoveAlzCyclicAccountMappingRequest();
        RemoveAlzCyclicAccountMappingResponse expectedData = new RemoveAlzCyclicAccountMappingResponse();
        ApiResponseRemoveAlzCyclicAccountMappingResponse apiResponse = new ApiResponseRemoveAlzCyclicAccountMappingResponse();
        apiResponse.setData(expectedData);

        DispatcherClientResponse<ApiResponseRemoveAlzCyclicAccountMappingResponse> dispatcherResponse =
            new DispatcherClientResponse<>();
        dispatcherResponse.setData(apiResponse);
        dispatcherResponse.setSuccess(true);

        when(restAlzCyclicAccountMappingControllerApi
                .removeCyclicAccountMapping(request))
                .thenReturn(dispatcherResponse);

        // Act
        RestResponse<RemoveAlzCyclicAccountMappingResponse> result = cyclicAccountMappingService.removeAlzCyclicAccountMappingResponse(request);

        // Assert
        assertNotNull(result);
        assertNotNull(result.getData());
        assertEquals(expectedData, result.getData());
    }

    @Test
    void removeAlzCyclicAccountMappingResponse_ShouldReturnErrorResponse_WhenApiResponseFails() {
        // Arrange
        RemoveAlzCyclicAccountMappingRequest request = new RemoveAlzCyclicAccountMappingRequest();
        DispatcherClientResponse<ApiResponseRemoveAlzCyclicAccountMappingResponse> dispatcherResponse =
                new DispatcherClientResponse<>();
        dispatcherResponse.setData(null);
        dispatcherResponse.setSuccess(false);

        when(restAlzCyclicAccountMappingControllerApi
                .removeCyclicAccountMapping(request))
                .thenReturn(dispatcherResponse);

        // Act
        RestResponse<RemoveAlzCyclicAccountMappingResponse> result =
                cyclicAccountMappingService.removeAlzCyclicAccountMappingResponse(request);

        // Assert
        assertNotNull(result);
        assertNull(result.getData());
    }

    @Test
    void getAlzCyclicMappingList_ShouldReturnErrorResponse_WhenApiResponseFails() {
        // Arrange
        DispatcherClientResponse<ApiResponseAlzCyclicAccountMappingListResponse> dispatcherResponse =
                new DispatcherClientResponse<>();
        dispatcherResponse.setData(null);
        dispatcherResponse.setSuccess(false);

        when(restAlzCyclicAccountMappingControllerApi
                .listCyclicAccountMapping())
                .thenReturn(dispatcherResponse);

        // Act
        RestResponse<AlzCyclicAccountMappingListResponse> result =
                cyclicAccountMappingService.getAlzCyclicMappingList();

        // Assert
        assertNotNull(result);
        assertNull(result.getData());
    }
}