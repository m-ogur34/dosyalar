package tr.com.allianz.accounting_ui_backend.request_response;

import org.junit.jupiter.api.Test;
import tr.com.allianz.pmc.commonmessageutils.UiMessages;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;

class RestResponseTest {

    @Test
    void of_ShouldCreateInstanceWithData() {
        // Arrange
        String expectedData = "test-data";

        // Act
        RestResponse<String> result = RestResponse.of(expectedData);

        // Assert
        assertNotNull(result);
        assertEquals(expectedData, result.getData());
    }

    @Test
    void of_WhenDataIsNull_ShouldCreateResponseWithNullData() {
        // Act
        RestResponse<String> result = RestResponse.of(null);

        // Assert
        assertNotNull(result);
        assertNull(result.getData());
    }

    @Test
    void empty_ShouldReturnSingletonEmptyResponse() {
        // Act
        RestResponse<Void> result1 = RestResponse.empty();
        RestResponse<Void> result2 = RestResponse.empty();

        // Assert
        assertNotNull(result1);
        assertNull(result1.getData());
        // Verify it returns the declared static constant instance
        assertSame(result1, result2, "empty() should return the same static instance");
    }

    @Test
    void constructor_WithResponseCodeAndObject_ShouldInitializeFields() {
        // Arrange
        int code = 200;
        String responseObject = "Success Meaning";

        // Act
        RestResponse<Void> result = new RestResponse<>(code, responseObject);

        // Assert
        assertEquals(code, result.getResponse_code());
        assertEquals(responseObject, result.getResponse());
        assertNotNull(result.getTimestamp(), "Timestamp should be initialized in constructor");
    }

    @Test
    void setUiMessages_WhenNotNull_ShouldSetField() {
        // Arrange
        RestResponse<String> restResponse = new RestResponse<>();
        UiMessages messages = mock(UiMessages.class);

        // Act
        restResponse.setUiMessages(messages);

        // Assert
        assertEquals(messages, restResponse.getUiMessages());
    }

    @Test
    void setUiMessages_WhenNull_ShouldKeepExistingOrNull() {
        // Arrange
        RestResponse<String> restResponse = new RestResponse<>();

        // Act
        restResponse.setUiMessages(null);

        // Assert
        assertNull(restResponse.getUiMessages());

        // Arrange - case where message was already set
        UiMessages messages = mock(UiMessages.class);
        restResponse.setUiMessages(messages);

        // Act - set null again
        restResponse.setUiMessages(null);

        // Assert - The logic `if (uiMessages != null)` prevents overwriting with null
        assertEquals(messages, restResponse.getUiMessages());
    }
}