package tr.com.allianz.accounting_ui_backend.assistance_accounting.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;
import tr.com.allianz.accounting_ui_backend.request_response.RestResponse;
import tr.com.allianz.accounting_ui_backend.service.config.client.CustomDispatcherClient;
import tr.com.allianz.pmc.client.DispatcherClientResponse;
import tr.com.allianz.pmc.client.endpoint.*;
import tr.com.allianz.pmc.client.model.*;
import tr.com.allianz.pmc.commonmessageutils.MessageBucket;

import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AssistanceAccountingServiceTest {

    @Mock
    private CustomDispatcherClient pmcRestClientClient;

    @Mock
    private MessageBucket messageBucket;

    @InjectMocks
    private AssistanceAccountingService assistanceAccountingService;

    @Mock
    private AccCoverCodeControllerApiEndPoint restAccCoverCodeControllerApi;
    @Mock
    private AssistanceCompanyControllerApiEndPoint restAssistanceCompanyControllerApi;
    @Mock
    private AssistanceProductControllerApiEndPoint restAssistanceProductControllerApi;
    @Mock
    private AssistancePartitionControllerApiEndPoint restAssistancePartitionControllerApi;
    @Mock
    private AssistanceQueryControllerApiEndPoint restAssistanceQueryControllerApi;
    @Mock
    private AssistancePostingControllerApiEndPoint restAssistancePostingControllerApi;

    @BeforeEach
    void setUp() {
        ReflectionTestUtils.setField(pmcRestClientClient, "restAccCoverCodeControllerApi", restAccCoverCodeControllerApi);
        ReflectionTestUtils.setField(pmcRestClientClient, "restAssistanceCompanyControllerApi", restAssistanceCompanyControllerApi);
        ReflectionTestUtils.setField(pmcRestClientClient, "restAssistanceProductControllerApi", restAssistanceProductControllerApi);
        ReflectionTestUtils.setField(pmcRestClientClient, "restAssistancePartitionControllerApi", restAssistancePartitionControllerApi);
        ReflectionTestUtils.setField(pmcRestClientClient, "restAssistanceQueryControllerApi", restAssistanceQueryControllerApi);
        ReflectionTestUtils.setField(pmcRestClientClient, "restAssistancePostingControllerApi", restAssistancePostingControllerApi);
    }

    @Test
    void testGetListAccCoverCode_Success() {
        ApiResponseListAccCoverCode apiResponse = new ApiResponseListAccCoverCode();
        apiResponse.setData(Collections.emptyList());
        
        DispatcherClientResponse<ApiResponseListAccCoverCode> clientResponse = mock(DispatcherClientResponse.class);
        when(clientResponse.isSuccess()).thenReturn(true);
        when(clientResponse.getData()).thenReturn(apiResponse);

        when(restAccCoverCodeControllerApi.listAccCoverCodes()).thenReturn(clientResponse);

        RestResponse<List<AccCoverCode>> result = assistanceAccountingService.getListAccCoverCode();

        assertNotNull(result);
        assertNotNull(result.getData());
    }

    @Test
    void testGetListAssistanceCompany_Success() {
        ApiResponseListAssistanceCompany apiResponse = new ApiResponseListAssistanceCompany();
        apiResponse.setData(Collections.emptyList());
        
        DispatcherClientResponse<ApiResponseListAssistanceCompany> clientResponse = mock(DispatcherClientResponse.class);
        when(clientResponse.isSuccess()).thenReturn(true);
        when(clientResponse.getData()).thenReturn(apiResponse);

        when(restAssistanceCompanyControllerApi.listAssistanceCompanies()).thenReturn(clientResponse);

        RestResponse<List<AssistanceCompany>> result = assistanceAccountingService.getListAssistanceCompany();

        assertNotNull(result);
        assertNotNull(result.getData());
    }

    @Test
    void testGetListAssistanceProduct_Success() {
        ApiResponseListAssistanceProduct apiResponse = new ApiResponseListAssistanceProduct();
        apiResponse.setData(Collections.emptyList());
        
        DispatcherClientResponse<ApiResponseListAssistanceProduct> clientResponse = mock(DispatcherClientResponse.class);
        when(clientResponse.isSuccess()).thenReturn(true);
        when(clientResponse.getData()).thenReturn(apiResponse);

        when(restAssistanceProductControllerApi.listAssistanceProducts("code")).thenReturn(clientResponse);

        RestResponse<List<AssistanceProduct>> result = assistanceAccountingService.getListAssistanceProduct("code");

        assertNotNull(result);
        assertNotNull(result.getData());
    }

    @Test
    void testGetListAssistancePartition_Success() {
        ApiResponseListAssistancePartition apiResponse = new ApiResponseListAssistancePartition();
        apiResponse.setData(Collections.emptyList());
        
        DispatcherClientResponse<ApiResponseListAssistancePartition> clientResponse = mock(DispatcherClientResponse.class);
        when(clientResponse.isSuccess()).thenReturn(true);
        when(clientResponse.getData()).thenReturn(apiResponse);

        when(restAssistancePartitionControllerApi.listAssistancePartitions(any())).thenReturn(clientResponse);

        RestResponse<List<AssistancePartition>> result = assistanceAccountingService.getListAssistancePartition(List.of(1L));

        assertNotNull(result);
        assertNotNull(result.getData());
    }

    @Test
    void testPostListAssistanceQuery_Success() {
        ApiResponseListAssistanceQueryResult apiResponse = new ApiResponseListAssistanceQueryResult();
        apiResponse.setData(Collections.emptyList());
        
        DispatcherClientResponse<ApiResponseListAssistanceQueryResult> clientResponse = mock(DispatcherClientResponse.class);
        when(clientResponse.isSuccess()).thenReturn(true);
        when(clientResponse.getData()).thenReturn(apiResponse);

        when(restAssistanceQueryControllerApi.listAssistanceQueryResults(any())).thenReturn(clientResponse);

        RestResponse<List<AssistanceQueryResult>> result = assistanceAccountingService.postListAssistanceQuery(new AssistanceQueryCriteria());

        assertNotNull(result);
        assertNotNull(result.getData());
    }

    @Test
    void testPostCreateAssistancePosting_Success() {
        ApiResponseLong apiResponse = new ApiResponseLong();
        apiResponse.setData(123L);

        DispatcherClientResponse<ApiResponseLong> clientResponse = mock(DispatcherClientResponse.class);
        when(clientResponse.isSuccess()).thenReturn(true);
        when(clientResponse.getData()).thenReturn(apiResponse);

        when(restAssistancePostingControllerApi.createAssistancePosting(any())).thenReturn(clientResponse);

        RestResponse<Long> result = assistanceAccountingService.postCreateAssistancePosting(new CreateAssistancePostingRequest());

        assertNotNull(result);
        assertEquals(123L, result.getData());
    }


    // Error scenario tests

    @Test
    void testGetListAccCoverCode_Error() {
        DispatcherClientResponse<ApiResponseListAccCoverCode> clientResponse = mock(DispatcherClientResponse.class);
        when(clientResponse.isSuccess()).thenReturn(false);
        when(clientResponse.getError()).thenReturn(null);
        when(restAccCoverCodeControllerApi.listAccCoverCodes()).thenReturn(clientResponse);

        RestResponse<List<AccCoverCode>> result = assistanceAccountingService.getListAccCoverCode();
        assertNotNull(result);
        assertNull(result.getData());
    }

    @Test
    void testGetListAssistanceCompany_Error() {
        DispatcherClientResponse<ApiResponseListAssistanceCompany> clientResponse = mock(DispatcherClientResponse.class);
        when(clientResponse.isSuccess()).thenReturn(false);
        when(clientResponse.getError()).thenReturn(null);
        when(restAssistanceCompanyControllerApi.listAssistanceCompanies()).thenReturn(clientResponse);

        RestResponse<List<AssistanceCompany>> result = assistanceAccountingService.getListAssistanceCompany();
        assertNotNull(result);
        assertNull(result.getData());
    }

    @Test
    void testGetListAssistanceProduct_Error() {
        DispatcherClientResponse<ApiResponseListAssistanceProduct> clientResponse = mock(DispatcherClientResponse.class);
        when(clientResponse.isSuccess()).thenReturn(false);
        when(clientResponse.getError()).thenReturn(null);
        when(restAssistanceProductControllerApi.listAssistanceProducts("code")).thenReturn(clientResponse);

        RestResponse<List<AssistanceProduct>> result = assistanceAccountingService.getListAssistanceProduct("code");
        assertNotNull(result);
        assertNull(result.getData());
    }

    @Test
    void testGetListAssistancePartition_Error() {
        DispatcherClientResponse<ApiResponseListAssistancePartition> clientResponse = mock(DispatcherClientResponse.class);
        when(clientResponse.isSuccess()).thenReturn(false);
        when(clientResponse.getError()).thenReturn(null);
        when(restAssistancePartitionControllerApi.listAssistancePartitions(any())).thenReturn(clientResponse);

        RestResponse<List<AssistancePartition>> result = assistanceAccountingService.getListAssistancePartition(List.of(1L));
        assertNotNull(result);
        assertNull(result.getData());
    }

    @Test
    void testPostListAssistanceQuery_Error() {
        DispatcherClientResponse<ApiResponseListAssistanceQueryResult> clientResponse = mock(DispatcherClientResponse.class);
        when(clientResponse.isSuccess()).thenReturn(false);
        when(clientResponse.getError()).thenReturn(null);
        when(restAssistanceQueryControllerApi.listAssistanceQueryResults(any())).thenReturn(clientResponse);

        RestResponse<List<AssistanceQueryResult>> result = assistanceAccountingService.postListAssistanceQuery(new AssistanceQueryCriteria());
        assertNotNull(result);
        assertNull(result.getData());
    }

    @Test
    void testPostCreateAssistancePosting_Error() {
        DispatcherClientResponse<ApiResponseLong> clientResponse = mock(DispatcherClientResponse.class);
        when(clientResponse.isSuccess()).thenReturn(false);
        when(clientResponse.getError()).thenReturn(null);
        when(restAssistancePostingControllerApi.createAssistancePosting(any())).thenReturn(clientResponse);

        RestResponse<Long> result = assistanceAccountingService.postCreateAssistancePosting(new CreateAssistancePostingRequest());
        assertNotNull(result);
        assertNull(result.getData());
    }

}
