package tr.com.allianz.accounting_ui_backend.service.config.client;

import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeParseException;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;

class CustomLocalDateAdapterTest {

    private CustomLocalDateAdapter adapter;
    private JsonSerializationContext serializationContext;
    private JsonDeserializationContext deserializationContext;

    @BeforeEach
    void setUp() {
        adapter = new CustomLocalDateAdapter();
        // Contexts are often not used inside simple adapters, but we mock them just in case signature requires non-null
        serializationContext = mock(JsonSerializationContext.class);
        deserializationContext = mock(JsonDeserializationContext.class);
    }

    @Test
    void serialize_ShouldReturnFormattedString() {
        // Arrange
        LocalDate date = LocalDate.of(2023, 10, 5);

        // Act
        JsonElement result = adapter.serialize(date, LocalDate.class, serializationContext);

        // Assert
        assertNotNull(result);
        assertTrue(result.isJsonPrimitive());
        assertEquals("2023-10-05", result.getAsString());
    }

    @Test
    void deserialize_WithIsoLocalDateString_ShouldReturnLocalDate() {
        // Arrange
        String jsonDate = "2023-10-05";
        JsonElement jsonElement = new JsonPrimitive(jsonDate);

        // Act
        LocalDate result = adapter.deserialize(jsonElement, LocalDate.class, deserializationContext);

        // Assert
        assertNotNull(result);
        assertEquals(LocalDate.of(2023, 10, 5), result);
    }

    @Test
    void deserialize_WithInstantString_ShouldReturnLocalDate() {
        // Arrange
        String jsonDate = "2023-10-05T10:00:00Z";
        JsonElement jsonElement = new JsonPrimitive(jsonDate);

        // The adapter uses ZoneId.systemDefault(), so we calculate the expected value dynamically based on environment
        LocalDate expectedDate = LocalDate.ofInstant(Instant.parse(jsonDate), ZoneId.systemDefault());

        // Act
        LocalDate result = adapter.deserialize(jsonElement, LocalDate.class, deserializationContext);

        // Assert
        assertNotNull(result);
        assertEquals(expectedDate, result);
    }

    @Test
    void deserialize_WithInvalidFormat_ShouldThrowException() {
        // Arrange
        String invalidDate = "invalid-date-format";
        JsonElement jsonElement = new JsonPrimitive(invalidDate);

        // Act & Assert
        assertThrows(DateTimeParseException.class, () ->
            adapter.deserialize(jsonElement, LocalDate.class, deserializationContext)
        );
    }
}