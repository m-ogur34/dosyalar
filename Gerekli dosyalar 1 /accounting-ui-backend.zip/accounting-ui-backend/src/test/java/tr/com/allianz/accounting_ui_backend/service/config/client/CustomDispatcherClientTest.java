package tr.com.allianz.accounting_ui_backend.service.config.client;

import okhttp3.OkHttpClient;
import org.junit.jupiter.api.Test;
import tr.com.allianz.pmc.client.extension.DispatcherMetaDataProvider;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;

class CustomDispatcherClientTest {

    @Test
    void constructor_WhenBaseUrlIsNull_ShouldThrowException() {
        // Arrange
        OkHttpClient client = mock(OkHttpClient.class);

        // Act & Assert
        assertThrows(IllegalArgumentException.class, () ->
            new CustomDispatcherClient(null, client)
        , "Should throw exception when baseUrl is null");
    }

    @Test
    void constructor_WhenClientAndMetaProviderAreNull_ShouldThrowException() {
        // Arrange
        String baseUrl = "http://localhost:8080/";

        // Act & Assert
        // The 3-arg constructor logic throws if client is null AND provider is null
        assertThrows(IllegalArgumentException.class, () ->
            new CustomDispatcherClient(baseUrl, null, null)
        , "Should throw exception when both client and metaDataProvider are null");
    }

    @Test
    void constructor_WhenClientProvided_ShouldInitializeServices() {
        // Arrange
        String baseUrl = "http://localhost:8080/";
        OkHttpClient client = mock(OkHttpClient.class);

        // Act
        CustomDispatcherClient instance = new CustomDispatcherClient(baseUrl, client);

        // Assert
        assertNotNull(instance.restAlzCyclicAccountMappingControllerApi, "Account Mapping API endpoint should be initialized");
        assertNotNull(instance.restAlzCyclicPostingProcessControllerApi, "Posting Process API endpoint should be initialized");
        assertNotNull(CustomDispatcherClient.gson, "Static GSON instance should be initialized");
    }

    @Test
    void constructor_WhenClientNullButMetaDataProvided_ShouldBuildClientAndInitialize() {
        // Arrange
        String baseUrl = "http://localhost:8080/";
        DispatcherMetaDataProvider metaDataProvider = mock(DispatcherMetaDataProvider.class);

        // Act
        // This path constructs a new OkHttpClient internally using DispatcherHeaderInjectionFilter
        CustomDispatcherClient instance = new CustomDispatcherClient(baseUrl, null, metaDataProvider);

        // Assert
        assertNotNull(instance.restAlzCyclicAccountMappingControllerApi);
        assertNotNull(instance.restAlzCyclicPostingProcessControllerApi);
        assertNotNull(CustomDispatcherClient.gson);
    }

    @Test
    void twoArgConstructor_ShouldDelegatesCorrectly() {
        // Arrange
        String baseUrl = "http://localhost:8080/";
        OkHttpClient client = mock(OkHttpClient.class);

        // Act
        CustomDispatcherClient instance = new CustomDispatcherClient(baseUrl, client);

        // Assert
        assertNotNull(instance.restAlzCyclicAccountMappingControllerApi);
    }
}