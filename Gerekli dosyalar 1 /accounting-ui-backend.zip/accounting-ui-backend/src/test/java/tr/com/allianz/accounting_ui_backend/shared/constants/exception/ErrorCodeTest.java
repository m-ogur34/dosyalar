package tr.com.allianz.accounting_ui_backend.shared.constants.exception;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.Serializable;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class ErrorCodeTest {

    @Test
    void constructor_WithCodeOnly_ShouldCreateErrorCode() {
        // Arrange
        String code = "ERR_001";

        // Act
        ErrorCode errorCode = new ErrorCode(code);

        // Assert
        assertNotNull(errorCode);
        assertEquals(code, errorCode.getCode());
        assertNull(errorCode.getMessage());
        assertNull(errorCode.getName());
    }

    @Test
    void constructor_WithCodeAndMessage_ShouldCreateErrorCodeWithBoth() {
        // Arrange
        String code = "ERR_002";
        String message = "Error message";

        // Act
        ErrorCode errorCode = new ErrorCode(code, message);

        // Assert
        assertNotNull(errorCode);
        assertEquals(code, errorCode.getCode());
        assertEquals(message, errorCode.getMessage());
        assertNull(errorCode.getName());
    }

    @Test
    void getCode_ShouldReturnCorrectCode() {
        // Arrange
        String code = "ERR_003";
        ErrorCode errorCode = new ErrorCode(code);

        // Act
        String retrievedCode = errorCode.getCode();

        // Assert
        assertNotNull(retrievedCode);
        assertEquals(code, retrievedCode);
    }

    @Test
    void getMessage_ShouldReturnCorrectMessage() {
        // Arrange
        String code = "ERR_004";
        String message = "Test error message";
        ErrorCode errorCode = new ErrorCode(code, message);

        // Act
        String retrievedMessage = errorCode.getMessage();

        // Assert
        assertNotNull(retrievedMessage);
        assertEquals(message, retrievedMessage);
    }

    @Test
    void getName_ShouldReturnNull_WhenNotSet() {
        // Arrange
        ErrorCode errorCode = new ErrorCode("ERR_005");

        // Act
        String name = errorCode.getName();

        // Assert
        assertNull(name);
    }

    @Test
    void shouldImplementSerializable() {
        // Arrange
        ErrorCode errorCode = new ErrorCode("ERR_006");

        // Assert
        assertInstanceOf(Serializable.class, errorCode);
    }

    @Test
    void constructor_WithNullCode_ShouldCreateErrorCode() {
        // Act
        ErrorCode errorCode = new ErrorCode(null);

        // Assert
        assertNotNull(errorCode);
        assertNull(errorCode.getCode());
        assertNull(errorCode.getMessage());
    }

    @Test
    void constructor_WithEmptyCode_ShouldCreateErrorCode() {
        // Arrange
        String code = "";

        // Act
        ErrorCode errorCode = new ErrorCode(code);

        // Assert
        assertNotNull(errorCode);
        assertEquals("", errorCode.getCode());
    }

    @Test
    void constructor_WithNullMessage_ShouldCreateErrorCode() {
        // Arrange
        String code = "ERR_007";

        // Act
        ErrorCode errorCode = new ErrorCode(code, null);

        // Assert
        assertNotNull(errorCode);
        assertEquals(code, errorCode.getCode());
        assertNull(errorCode.getMessage());
    }

    @Test
    void constructor_WithEmptyMessage_ShouldCreateErrorCode() {
        // Arrange
        String code = "ERR_008";
        String message = "";

        // Act
        ErrorCode errorCode = new ErrorCode(code, message);

        // Assert
        assertNotNull(errorCode);
        assertEquals(code, errorCode.getCode());
        assertEquals("", errorCode.getMessage());
    }

    @Test
    void constructor_WithSpecialCharactersInCode_ShouldCreateErrorCode() {
        // Arrange
        String code = "ERR_@#$%^&*()";

        // Act
        ErrorCode errorCode = new ErrorCode(code);

        // Assert
        assertNotNull(errorCode);
        assertEquals(code, errorCode.getCode());
    }

    @Test
    void constructor_WithSpecialCharactersInMessage_ShouldCreateErrorCode() {
        // Arrange
        String code = "ERR_009";
        String message = "Error: @#$%^&*()_+-=[]{}|;:',.<>?/~`";

        // Act
        ErrorCode errorCode = new ErrorCode(code, message);

        // Assert
        assertNotNull(errorCode);
        assertEquals(code, errorCode.getCode());
        assertEquals(message, errorCode.getMessage());
    }

    @Test
    void constructor_WithLongCode_ShouldCreateErrorCode() {
        // Arrange
        String code = "ERR_".repeat(100);

        // Act
        ErrorCode errorCode = new ErrorCode(code);

        // Assert
        assertNotNull(errorCode);
        assertEquals(code, errorCode.getCode());
    }

    @Test
    void constructor_WithLongMessage_ShouldCreateErrorCode() {
        // Arrange
        String code = "ERR_010";
        String message = "Message: ".repeat(100);

        // Act
        ErrorCode errorCode = new ErrorCode(code, message);

        // Assert
        assertNotNull(errorCode);
        assertEquals(code, errorCode.getCode());
        assertEquals(message, errorCode.getMessage());
    }

    @Test
    void multipleConstructors_ShouldProduceValidErrorCodes() {
        // Act
        ErrorCode errorCode1 = new ErrorCode("CODE1");
        ErrorCode errorCode2 = new ErrorCode("CODE2", "Message");

        // Assert
        assertNotNull(errorCode1);
        assertNotNull(errorCode2);
        assertEquals("CODE1", errorCode1.getCode());
        assertEquals("CODE2", errorCode2.getCode());
        assertEquals("Message", errorCode2.getMessage());
    }

    @Test
    void errorCode_ShouldStoreAndRetrieveValuesCorrectly() {
        // Arrange
        String code = "ERR_011";
        String message = "Validation failed";
        ErrorCode errorCode = new ErrorCode(code, message);

        // Act
        String retrievedCode = errorCode.getCode();
        String retrievedMessage = errorCode.getMessage();

        // Assert
        assertEquals(code, retrievedCode);
        assertEquals(message, retrievedMessage);
    }

    @Test
    void constructor_CodeOnlyThenMessage_ShouldHaveNullMessage() {
        // Arrange
        String code = "ERR_012";

        // Act
        ErrorCode errorCode = new ErrorCode(code);

        // Assert
        assertEquals(code, errorCode.getCode());
        assertNull(errorCode.getMessage());
    }

    @Test
    void serialVersionUID_ShouldBeOne() {
        // Assert - ErrorCode has serialVersionUID = 1L
        assertTrue(Serializable.class.isAssignableFrom(ErrorCode.class));
    }

    @Test
    void errorCode_WithUnicodeCharacters_ShouldCreateSuccessfully() {
        // Arrange
        String code = "ERR_错误_エラー_خطأ";
        String message = "Unicode message: 你好 こんにちは مرحبا";

        // Act
        ErrorCode errorCode = new ErrorCode(code, message);

        // Assert
        assertNotNull(errorCode);
        assertEquals(code, errorCode.getCode());
        assertEquals(message, errorCode.getMessage());
    }

    @Test
    void errorCode_WithNumericCode_ShouldCreateSuccessfully() {
        // Arrange
        String code = "001";
        String message = "Error";

        // Act
        ErrorCode errorCode = new ErrorCode(code, message);

        // Assert
        assertEquals(code, errorCode.getCode());
        assertEquals(message, errorCode.getMessage());
    }

    @Test
    void errorCode_WithHyphenatedCode_ShouldCreateSuccessfully() {
        // Arrange
        String code = "ERR-001-VALIDATION";
        String message = "Validation error";

        // Act
        ErrorCode errorCode = new ErrorCode(code, message);

        // Assert
        assertEquals(code, errorCode.getCode());
        assertEquals(message, errorCode.getMessage());
    }

    @Test
    void getName_ShouldAlwaysReturnNull() {
        // Arrange
        ErrorCode errorCode1 = new ErrorCode("ERR_013");
        ErrorCode errorCode2 = new ErrorCode("ERR_014", "Message");

        // Act
        String name1 = errorCode1.getName();
        String name2 = errorCode2.getName();

        // Assert
        assertNull(name1);
        assertNull(name2);
    }

    @Test
    void constructorSequence_ShouldMaintainStateCorrectly() {
        // Arrange
        String code1 = "ERR_015";
        String message1 = "First error";
        String code2 = "ERR_016";

        // Act
        ErrorCode errorCode1 = new ErrorCode(code1, message1);
        ErrorCode errorCode2 = new ErrorCode(code2);

        // Assert
        assertEquals(code1, errorCode1.getCode());
        assertEquals(message1, errorCode1.getMessage());
        assertEquals(code2, errorCode2.getCode());
        assertNull(errorCode2.getMessage());
    }

    @Test
    void errorCode_ShouldHandleWhitespaceInCode() {
        // Arrange
        String code = "  ERR 001  ";
        String message = "  Error message  ";

        // Act
        ErrorCode errorCode = new ErrorCode(code, message);

        // Assert
        assertEquals(code, errorCode.getCode());
        assertEquals(message, errorCode.getMessage());
    }

    @Test
    void errorCode_WithNewlinesInMessage_ShouldCreateSuccessfully() {
        // Arrange
        String code = "ERR_017";
        String message = "Line 1\nLine 2\nLine 3";

        // Act
        ErrorCode errorCode = new ErrorCode(code, message);

        // Assert
        assertEquals(code, errorCode.getCode());
        assertEquals(message, errorCode.getMessage());
    }

    @Test
    void errorCode_WithTabsInMessage_ShouldCreateSuccessfully() {
        // Arrange
        String code = "ERR_018";
        String message = "Error\t\tMessage\t\tWith\t\tTabs";

        // Act
        ErrorCode errorCode = new ErrorCode(code, message);

        // Assert
        assertEquals(code, errorCode.getCode());
        assertEquals(message, errorCode.getMessage());
    }

    @Test
    void constructor_TwoParameter_ShouldNotAffectName() {
        // Arrange
        String code = "ERR_019";
        String message = "Error message";

        // Act
        ErrorCode errorCode = new ErrorCode(code, message);
        String name = errorCode.getName();

        // Assert
        assertNull(name);
    }

    @Test
    void getters_ShouldReturnSameValuesAsConstructor() {
        // Arrange
        String code = "ERR_020";
        String message = "Test message";
        ErrorCode errorCode = new ErrorCode(code, message);

        // Act
        String retrievedCode = errorCode.getCode();
        String retrievedMessage = errorCode.getMessage();
        String retrievedName = errorCode.getName();

        // Assert
        assertEquals(code, retrievedCode);
        assertEquals(message, retrievedMessage);
        assertNull(retrievedName);
    }
}

