package tr.com.allianz.accounting_ui_backend.config.cas;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import tr.com.allianz.pmc.commonmessageutils.MessageBucket;
import tr.com.allianz.pmc.commonmessageutils.UiMessage;

import java.util.Collection;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;

@ExtendWith(MockitoExtension.class)
class DefaultMessageBucketTest {

    @Mock
    private UiMessage mockMessage;

    @Mock
    private UiMessage mockMessage1;

    @Mock
    private UiMessage mockMessage2;

    @Mock
    private UiMessage mockMessage3;

    private DefaultMessageBucket defaultMessageBucket;

    @BeforeEach
    void setUp() {
        defaultMessageBucket = new DefaultMessageBucket();
    }

    @Test
    void constructor_NoArgs_ShouldCreateInstance() {
        // Act
        DefaultMessageBucket bucket = new DefaultMessageBucket();


        // Assert
        assertNotNull(bucket);
        assertNotNull(bucket.getBucket());
    }

    @Test
    void constructor_WithNullMessageAccessor_ShouldCreateInstance() {
        // Act
        DefaultMessageBucket bucket = new DefaultMessageBucket(null);

        // Assert
        assertNotNull(bucket);
        assertNotNull(bucket.getBucket());
    }

    @Test
    void shouldExtendMessageBucket() {
        // Assert
        assertInstanceOf(MessageBucket.class, defaultMessageBucket);
    }

    @Test
    void getBucket_ShouldReturnEmptyCollectionInitially() {
        // Act
        Collection<UiMessage> bucket = defaultMessageBucket.getBucket();

        // Assert
        assertNotNull(bucket);
        assertTrue(bucket.isEmpty());
    }

    @Test
    void getBucket_ShouldReturnListType() {
        // Act
        Collection<UiMessage> bucket = defaultMessageBucket.getBucket();

        // Assert
        assertInstanceOf(List.class, bucket);
    }

    @Test
    void getBucket_ShouldReturnSameInstanceOnMultipleCalls() {
        // Act
        Collection<UiMessage> bucket1 = defaultMessageBucket.getBucket();
        Collection<UiMessage> bucket2 = defaultMessageBucket.getBucket();

        // Assert
        assertSame(bucket1, bucket2);
    }

    @Test
    void getBucket_ShouldAllowAddingMessages() {
        // Act
        Collection<UiMessage> bucket = defaultMessageBucket.getBucket();
        bucket.add(mockMessage);

        // Assert
        assertEquals(1, bucket.size());
        assertTrue(bucket.contains(mockMessage));
    }

    @Test
    void getBucket_ShouldMaintainMessagesAcrossCalls() {
        // Act
        Collection<UiMessage> bucket1 = defaultMessageBucket.getBucket();
        bucket1.add(mockMessage1);

        Collection<UiMessage> bucket2 = defaultMessageBucket.getBucket();
        bucket2.add(mockMessage2);

        // Assert
        assertEquals(2, bucket2.size());
        assertTrue(bucket2.contains(mockMessage1));
        assertTrue(bucket2.contains(mockMessage2));
    }

    @Test
    void getBucket_ShouldAllowRemovingMessages() {
        // Arrange
        Collection<UiMessage> bucket = defaultMessageBucket.getBucket();
        bucket.add(mockMessage);

        // Act
        bucket.remove(mockMessage);

        // Assert
        assertTrue(bucket.isEmpty());
    }

    @Test
    void getBucket_ShouldAllowClearingMessages() {
        // Arrange
        Collection<UiMessage> bucket = defaultMessageBucket.getBucket();
        bucket.add(mockMessage1);
        bucket.add(mockMessage2);

        // Act
        bucket.clear();

        // Assert
        assertTrue(bucket.isEmpty());
        assertEquals(0, bucket.size());
    }

    @Test
    void getBucket_ShouldPreserveMessageOrder() {
        // Act
        Collection<UiMessage> bucket = defaultMessageBucket.getBucket();
        bucket.add(mockMessage1);
        bucket.add(mockMessage2);
        bucket.add(mockMessage3);

        // Assert
        List<UiMessage> list = (List<UiMessage>) bucket;
        assertEquals(mockMessage1, list.get(0));
        assertEquals(mockMessage2, list.get(1));
        assertEquals(mockMessage3, list.get(2));
    }

    @Test
    void getBucket_ShouldAllowDuplicateMessages() {
        // Act
        Collection<UiMessage> bucket = defaultMessageBucket.getBucket();
        bucket.add(mockMessage);
        bucket.add(mockMessage);

        // Assert
        assertEquals(2, bucket.size());
    }

    @Test
    void multipleInstances_ShouldHaveIndependentBuckets() {
        // Arrange
        DefaultMessageBucket bucket1 = new DefaultMessageBucket();
        DefaultMessageBucket bucket2 = new DefaultMessageBucket();

        // Act
        bucket1.getBucket().add(mockMessage1);
        bucket2.getBucket().add(mockMessage2);

        // Assert
        assertEquals(1, bucket1.getBucket().size());
        assertEquals(1, bucket2.getBucket().size());
        assertTrue(bucket1.getBucket().contains(mockMessage1));
        assertFalse(bucket1.getBucket().contains(mockMessage2));
        assertTrue(bucket2.getBucket().contains(mockMessage2));
        assertFalse(bucket2.getBucket().contains(mockMessage1));
    }

    @Test
    void getBucket_ShouldReturnMutableCollection() {
        // Act
        Collection<UiMessage> bucket = defaultMessageBucket.getBucket();

        // Assert
        assertDoesNotThrow(() -> bucket.add(mockMessage));
        assertDoesNotThrow(bucket::clear);
    }


    @Test
    void getBucket_ShouldSupportIterating() {
        // Arrange
        Collection<UiMessage> bucket = defaultMessageBucket.getBucket();
        bucket.add(mockMessage1);
        bucket.add(mockMessage2);

        // Act
        int count = 0;
        for (UiMessage msg : bucket) {
            assertNotNull(msg);
            count++;
        }

        // Assert
        assertEquals(2, count);
    }

    @Test
    void getBucket_ShouldSupportStreamOperations() {
        // Arrange
        Collection<UiMessage> bucket = defaultMessageBucket.getBucket();
        bucket.add(mockMessage1);
        bucket.add(mockMessage2);

        // Act
        long count = bucket.stream().count();

        // Assert
        assertEquals(2, count);
    }

    @Test
    void getBucket_ShouldHandleLargeNumberOfMessages() {
        // Arrange
        Collection<UiMessage> bucket = defaultMessageBucket.getBucket();

        // Act
        for (int i = 0; i < 1000; i++) {
            bucket.add(mock(UiMessage.class));
        }

        // Assert
        assertEquals(1000, bucket.size());
    }

    @Test
    void getBucket_AfterClear_ShouldBeEmpty() {
        // Arrange
        Collection<UiMessage> bucket = defaultMessageBucket.getBucket();
        bucket.add(mockMessage);
        bucket.clear();

        // Act
        Collection<UiMessage> bucketAfterClear = defaultMessageBucket.getBucket();

        // Assert
        assertTrue(bucketAfterClear.isEmpty());
    }

    @Test
    void getBucket_ShouldBeThreadSafe_ForIndependentInstances() {
        // Arrange
        DefaultMessageBucket bucket1 = new DefaultMessageBucket();
        DefaultMessageBucket bucket2 = new DefaultMessageBucket();

        // Act
        bucket1.getBucket().add(mockMessage1);
        bucket2.getBucket().add(mockMessage2);

        // Assert
        assertEquals(1, bucket1.getBucket().size());
        assertEquals(1, bucket2.getBucket().size());
    }

    @Test
    void getBucket_ShouldNotReturnNull() {
        // Act
        Collection<UiMessage> bucket = defaultMessageBucket.getBucket();

        // Assert
        assertNotNull(bucket);
    }

    @Test
    void getBucket_EmptyBucket_ShouldHaveSizeZero() {
        // Act
        Collection<UiMessage> bucket = defaultMessageBucket.getBucket();

        // Assert
        assertEquals(0, bucket.size());
    }
}
