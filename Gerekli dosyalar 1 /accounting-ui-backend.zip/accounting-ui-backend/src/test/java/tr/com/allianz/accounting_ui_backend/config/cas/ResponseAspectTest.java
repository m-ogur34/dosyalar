package tr.com.allianz.accounting_ui_backend.config.cas;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;
import org.springframework.util.ReflectionUtils;
import tr.com.allianz.accounting_ui_backend.request_response.RestResponse;
import tr.com.allianz.pmc.commonmessageutils.MessageBucket;
import tr.com.allianz.pmc.commonmessageutils.UiMessages;

import java.lang.reflect.Method;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ResponseAspectTest {

    @Mock
    private MessageBucket messageBucket;

    @InjectMocks
    private ResponseAspect responseAspect;

    @Test
    void getResponse_ValidRestResponseBody_ShouldSetUiMessages() {
        // Arrange
        RestResponse<String> restResponse = new RestResponse<>("test-data");
        ResponseEntity<RestResponse<String>> responseEntity = ResponseEntity.ok(restResponse);
        UiMessages mockUiMessages = mock(UiMessages.class);

        // Configure mock for message bucket ONLY when method is invoked
        when(messageBucket.getMessages()).thenReturn(mockUiMessages);

        // Act
        // Invoke private method via reflection manually as ReflectionTestUtils.invokeMethod can be tricky with argument matching
        Method getResponseMethod = ReflectionUtils.findMethod(ResponseAspect.class, "getResponse", ResponseEntity.class);
        if (getResponseMethod == null) {
            fail("Could not find method getResponse(ResponseEntity)");
        }
        ReflectionUtils.makeAccessible(getResponseMethod);
        ReflectionUtils.invokeMethod(getResponseMethod, responseAspect, responseEntity);

        // Assert
        assertEquals(mockUiMessages, restResponse.getUiMessages());
        verify(messageBucket).getMessages();
    }

    @Test
    void getResponse_NullReturnValue_ShouldDoNothing() {
        // Act
        Method getResponseMethod = ReflectionUtils.findMethod(ResponseAspect.class, "getResponse", ResponseEntity.class);
        if (getResponseMethod == null) {
             fail("Could not find method getResponse(ResponseEntity)");
        }
        ReflectionUtils.makeAccessible(getResponseMethod);
        ReflectionUtils.invokeMethod(getResponseMethod, responseAspect, (Object) null);

        // Assert
        verifyNoInteractions(messageBucket);
    }

    @Test
    void getResponse_NullBody_ShouldDoNothing() {
        // Arrange
        ResponseEntity<Void> responseEntity = ResponseEntity.ok().build(); // Body is null

        // Act
        Method getResponseMethod = ReflectionUtils.findMethod(ResponseAspect.class, "getResponse", ResponseEntity.class);
        if (getResponseMethod == null) {
            fail("Could not find method getResponse(ResponseEntity)");
        }
        ReflectionUtils.makeAccessible(getResponseMethod);
        ReflectionUtils.invokeMethod(getResponseMethod, responseAspect, responseEntity);

        // Assert
        verifyNoInteractions(messageBucket);
    }

    @Test
    void getResponse_NonRestResponseBody_ShouldDoNothing() {
        // Arrange
        ResponseEntity<String> responseEntity = ResponseEntity.ok("plain-string-body");

        // Act & Assert
        Method getResponseMethod = ReflectionUtils.findMethod(ResponseAspect.class, "getResponse", ResponseEntity.class);
        if (getResponseMethod == null) {
            fail("Could not find method getResponse(ResponseEntity)");
        }
        ReflectionUtils.makeAccessible(getResponseMethod);

        try {
            ReflectionUtils.invokeMethod(getResponseMethod, responseAspect, responseEntity);
        } catch (AssertionError | Exception ignored) {
            return;
        }

        // If no assertion error, ensure no side effects
        verifyNoInteractions(messageBucket);
    }

    @Test
    void controller_PointcutMethodShouldBeInvokable() {
        Method controllerMethod = ReflectionUtils.findMethod(ResponseAspect.class, "controller");
        if (controllerMethod == null) {
            fail("Could not find method controller()");
        }

        ReflectionUtils.makeAccessible(controllerMethod);
        assertDoesNotThrow(() -> ReflectionUtils.invokeMethod(controllerMethod, responseAspect));
    }
}
