package tr.com.allianz.accounting_ui_backend.cyclic_postings.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import tr.com.allianz.accounting_ui_backend.service.PmcRestClientServiceImpl;
import tr.com.allianz.accounting_ui_backend.service.config.client.CustomDispatcherClient;
import tr.com.allianz.pmc.client.ErrorResponse;
import tr.com.allianz.pmc.commonmessageutils.MessageBucket;
import tr.com.allianz.pmc.commonmessageutils.Severity;


import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class PmcRestClientServiceImplTest {

    @Mock
    private MessageBucket messageBucket;

    @Mock
    private ErrorResponse errorResponse;

    private PmcRestClientServiceImpl pmcRestClientService;

    private static final String API_BASE_URL = "http://localhost:8080";
    private static final long READ_TIMEOUT = 5000L;

    @BeforeEach
    void setUp() {
        pmcRestClientService = new PmcRestClientServiceImpl(API_BASE_URL, READ_TIMEOUT, messageBucket);
    }

    @Test
    void constructor_ShouldInitializeServiceWithValidParameters() {
        // Act & Assert
        assertNotNull(pmcRestClientService);
        assertEquals(API_BASE_URL, pmcRestClientService.getApiBaseUrl());
        assertNotNull(pmcRestClientService.getPmcRestClient());
        assertNotNull(pmcRestClientService.getMessageBucket());
    }

    @Test
    void getApiBaseUrl_ShouldReturnCorrectUrl() {
        // Act
        String apiUrl = pmcRestClientService.getApiBaseUrl();

        // Assert
        assertNotNull(apiUrl);
        assertEquals(API_BASE_URL, apiUrl);
    }

    @Test
    void getPmcRestClient_ShouldReturnCustomDispatcherClientInstance() {
        // Act
        CustomDispatcherClient client = pmcRestClientService.getPmcRestClient();

        // Assert
        assertNotNull(client);
        assertInstanceOf(CustomDispatcherClient.class, client);
    }

    @Test
    void getMessageBucket_ShouldReturnMessageBucketInstance() {
        // Act
        MessageBucket bucket = pmcRestClientService.getMessageBucket();

        // Assert
        assertNotNull(bucket);
        assertEquals(messageBucket, bucket);
    }

    @Test
    void handleBackendResponse_ShouldAddErrorMessageWhenErrorResponseIsNull() {
        // Act
        pmcRestClientService.handleBackendResponse(null);

        // Assert
        verify(messageBucket).addExternalMessage(
                "UNKNOWN ERROR",
                "Muhasebe Servisinden Hata Mesajı Boş Geldi",
                Severity.ERROR
        );
    }

    @Test
    void handleBackendResponse_ShouldAddErrorMessageWithErrorDetails() {
        // Arrange
        String errorCode = "SERVICE_ERROR";
        String errorMessage = "Service is unavailable";
        when(errorResponse.getCode()).thenReturn(errorCode);
        when(errorResponse.getMessage()).thenReturn(errorMessage);

        // Act
        pmcRestClientService.handleBackendResponse(errorResponse);

        // Assert
        verify(messageBucket).addExternalMessage(
                errorCode,
                errorMessage,
                Severity.ERROR
        );
    }

    @Test
    void handleBackendResponse_ShouldHandleEmptyErrorCode() {
        // Arrange
        when(errorResponse.getCode()).thenReturn("");
        when(errorResponse.getMessage()).thenReturn("Error message");

        // Act
        pmcRestClientService.handleBackendResponse(errorResponse);

        // Assert
        verify(messageBucket).addExternalMessage(
                "",
                "Error message",
                Severity.ERROR
        );
    }

    @Test
    void handleBackendResponse_ShouldHandleNullErrorCode() {
        // Arrange
        when(errorResponse.getCode()).thenReturn(null);
        when(errorResponse.getMessage()).thenReturn("Error message");

        // Act
        pmcRestClientService.handleBackendResponse(errorResponse);

        // Assert
        verify(messageBucket).addExternalMessage(
                null,
                "Error message",
                Severity.ERROR
        );
    }

    @Test
    void handleBackendResponse_ShouldHandleEmptyErrorMessage() {
        // Arrange
        when(errorResponse.getCode()).thenReturn("ERROR_CODE");
        when(errorResponse.getMessage()).thenReturn("");

        // Act
        pmcRestClientService.handleBackendResponse(errorResponse);

        // Assert
        verify(messageBucket).addExternalMessage(
                "ERROR_CODE",
                "",
                Severity.ERROR
        );
    }

    @Test
    void handleBackendResponse_ShouldHandleNullErrorMessage() {
        // Arrange
        when(errorResponse.getCode()).thenReturn("ERROR_CODE");
        when(errorResponse.getMessage()).thenReturn(null);

        // Act
        pmcRestClientService.handleBackendResponse(errorResponse);

        // Assert
        verify(messageBucket).addExternalMessage(
                "ERROR_CODE",
                null,
                Severity.ERROR
        );
    }

    @Test
    void handleBackendResponse_ShouldHandleLongErrorMessages() {
        // Arrange
        String errorCode = "LONG_ERROR";
        String longMessage = "A".repeat(1000);
        when(errorResponse.getCode()).thenReturn(errorCode);
        when(errorResponse.getMessage()).thenReturn(longMessage);

        // Act
        pmcRestClientService.handleBackendResponse(errorResponse);

        // Assert
        verify(messageBucket).addExternalMessage(
                errorCode,
                longMessage,
                Severity.ERROR
        );
    }

    @Test
    void handleBackendResponse_ShouldHandleSpecialCharactersInErrorMessage() {
        // Arrange
        String errorCode = "SPECIAL_CHARS";
        String specialMessage = "Error: @#$%^&*()_+-=[]{}|;:',.<>?/~`";
        when(errorResponse.getCode()).thenReturn(errorCode);
        when(errorResponse.getMessage()).thenReturn(specialMessage);

        // Act
        pmcRestClientService.handleBackendResponse(errorResponse);

        // Assert
        verify(messageBucket).addExternalMessage(
                errorCode,
                specialMessage,
                Severity.ERROR
        );
    }

    @Test
    void handleBackendResponse_ShouldHandleMultipleCalls() {
        // Arrange
        when(errorResponse.getCode()).thenReturn("ERROR1");
        when(errorResponse.getMessage()).thenReturn("First error");

        // Act
        pmcRestClientService.handleBackendResponse(errorResponse);

        when(errorResponse.getCode()).thenReturn("ERROR2");
        when(errorResponse.getMessage()).thenReturn("Second error");

        pmcRestClientService.handleBackendResponse(errorResponse);

        // Assert
        verify(messageBucket, times(2)).addExternalMessage(anyString(), anyString(), any(Severity.class));
    }

    @Test
    void constructor_ShouldCreateOkHttpClientWithCorrectTimeout() {
        // Arrange
        long customTimeout = 3000L;

        // Act
        PmcRestClientServiceImpl service = new PmcRestClientServiceImpl(API_BASE_URL, customTimeout, messageBucket);

        // Assert
        assertNotNull(service);
        assertEquals(API_BASE_URL, service.getApiBaseUrl());
    }

    @Test
    void handleBackendResponse_ShouldAlwaysUseSeverityError() {
        // Arrange
        when(errorResponse.getCode()).thenReturn("ERROR");
        when(errorResponse.getMessage()).thenReturn("Message");

        // Act
        pmcRestClientService.handleBackendResponse(errorResponse);

        // Assert
        verify(messageBucket).addExternalMessage(
                anyString(),
                anyString(),
                eq(Severity.ERROR)
        );
    }

    @Test
    void handleBackendResponse_ShouldNotThrowExceptionWithNullErrorResponse() {
        // Act & Assert
        assertDoesNotThrow(() -> pmcRestClientService.handleBackendResponse(null));
    }

    @Test
    void handleBackendResponse_ShouldNotThrowExceptionWithValidErrorResponse() {
        // Arrange
        when(errorResponse.getCode()).thenReturn("CODE");
        when(errorResponse.getMessage()).thenReturn("Message");

        // Act & Assert
        assertDoesNotThrow(() -> pmcRestClientService.handleBackendResponse(errorResponse));
    }
}

