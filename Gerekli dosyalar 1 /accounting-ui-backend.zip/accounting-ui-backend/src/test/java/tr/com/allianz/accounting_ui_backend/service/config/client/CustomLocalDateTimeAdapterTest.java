package tr.com.allianz.accounting_ui_backend.service.config.client;

import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;

class CustomLocalDateTimeAdapterTest {

    private CustomLocalDateTimeAdapter adapter;
    private JsonSerializationContext serializationContext;
    private JsonDeserializationContext deserializationContext;

    @BeforeEach
    void setUp() {
        adapter = new CustomLocalDateTimeAdapter();
        serializationContext = mock(JsonSerializationContext.class);
        deserializationContext = mock(JsonDeserializationContext.class);
    }

    @Test
    void serialize_ShouldReturnIsoFormattedString() {
        // Arrange
        LocalDateTime dateTime = LocalDateTime.of(2023, 10, 5, 14, 30, 0);

        // Act
        JsonElement result = adapter.serialize(dateTime, LocalDateTime.class, serializationContext);

        // Assert
        assertNotNull(result);
        assertTrue(result.isJsonPrimitive());
        // ISO_LOCAL_DATE_TIME format example: '2023-10-05T14:30:00'
        assertEquals("2023-10-05T14:30:00", result.getAsString());
    }

    @Test
    void deserialize_WithInstantString_ShouldReturnLocalDateTime() {
        // Arrange
        String jsonDate = "2023-10-05T14:30:00Z";
        JsonElement jsonElement = new JsonPrimitive(jsonDate);

        // Logic relies on system default zone
        LocalDateTime expectedDateTime = LocalDateTime.ofInstant(Instant.parse(jsonDate), ZoneId.systemDefault());

        // Act
        LocalDateTime result = adapter.deserialize(jsonElement, LocalDateTime.class, deserializationContext);

        // Assert
        assertNotNull(result);
        assertEquals(expectedDateTime, result);
    }

    @Test
    void deserialize_WithIsoLocalDateTimeString_ShouldReturnLocalDateTime() {
        // Arrange
        String jsonDate = "2023-10-05T14:30:00";
        JsonElement jsonElement = new JsonPrimitive(jsonDate);

        LocalDateTime expectedDateTime = LocalDateTime.parse(jsonDate, DateTimeFormatter.ISO_LOCAL_DATE_TIME);

        // Act
        LocalDateTime result = adapter.deserialize(jsonElement, LocalDateTime.class, deserializationContext);

        // Assert
        assertNotNull(result);
        assertEquals(expectedDateTime, result);
    }

    @Test
    void deserialize_WithInvalidFormat_ShouldThrowException() {
        // Arrange
        String invalidDate = "invalid-datetime-format";
        JsonElement jsonElement = new JsonPrimitive(invalidDate);

        // Act & Assert
        assertThrows(DateTimeParseException.class, () ->
            adapter.deserialize(jsonElement, LocalDateTime.class, deserializationContext)
        );
    }
}