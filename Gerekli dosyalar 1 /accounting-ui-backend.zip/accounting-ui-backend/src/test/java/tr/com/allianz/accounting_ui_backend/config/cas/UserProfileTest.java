package tr.com.allianz.accounting_ui_backend.config.cas;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.Serializable;

import static org.junit.jupiter.api.Assertions.*;

class UserProfileTest {

    private UserProfile userProfile;
    private ObjectMapper objectMapper;

    @BeforeEach
    void setUp() {
        userProfile = new UserProfile();
        objectMapper = new ObjectMapper();
    }

    @Test
    void testNoArgsConstructor_ShouldCreateEmptyUserProfile() {
        // Act
        UserProfile profile = new UserProfile();

        // Assert
        assertNotNull(profile);
        assertNull(profile.getPartnerId());
        assertNull(profile.getUserName());
        assertNull(profile.getName());
        assertNull(profile.getEmail());
        assertNull(profile.getUserType());
        assertNull(profile.getAgenIntId());
        assertNull(profile.getAgencyTitle());
        assertNull(profile.getAgencyCode());
        assertNull(profile.getSubAgenIntId());
        assertNull(profile.getSubAgencyTitle());
        assertNull(profile.getSubAgencyCode());
        assertNull(profile.getIdentityNo());
        assertNull(profile.getMaskedIdentityNo());
        assertNull(profile.getTaxNumber());
        assertNull(profile.getMaskedTaxNumber());
        assertFalse(profile.isActive());
        assertFalse(profile.isPasswordExpired());
        assertNull(profile.getGsmNo());
        assertNull(profile.getMaskedGsmNo());
        assertNull(profile.getVipGsmNo());
        assertNull(profile.getMaskedVipGsmNo());
        assertFalse(profile.isLoginWidthSMS());
        assertFalse(profile.isSmsLoginOpen());
        assertFalse(profile.isBgdUser());
        assertFalse(profile.isCallCenterUser());
        assertNull(profile.getSubUserType());
        assertNull(profile.getReferenceOpusUser());
        assertNull(profile.getMfaType());
    }

    @Test
    void testSettersAndGetters_PartnerId() {
        // Arrange
        String partnerId = "P12345";

        // Act
        userProfile.setPartnerId(partnerId);

        // Assert
        assertEquals(partnerId, userProfile.getPartnerId());
    }

    @Test
    void testSettersAndGetters_UserName() {
        // Arrange
        String userName = "testUser";

        // Act
        userProfile.setUserName(userName);

        // Assert
        assertEquals(userName, userProfile.getUserName());
    }

    @Test
    void testSettersAndGetters_Name() {
        // Arrange
        String name = "John Doe";

        // Act
        userProfile.setName(name);

        // Assert
        assertEquals(name, userProfile.getName());
    }

    @Test
    void testSettersAndGetters_Email() {
        // Arrange
        String email = "test@example.com";

        // Act
        userProfile.setEmail(email);

        // Assert
        assertEquals(email, userProfile.getEmail());
    }

    @Test
    void testSettersAndGetters_UserType() {
        // Arrange
        String userType = "0";

        // Act
        userProfile.setUserType(userType);

        // Assert
        assertEquals(userType, userProfile.getUserType());
    }

    @Test
    void testSettersAndGetters_AgenIntId() {
        // Arrange
        Long agenIntId = 12345L;

        // Act
        userProfile.setAgenIntId(agenIntId);

        // Assert
        assertEquals(agenIntId, userProfile.getAgenIntId());
    }

    @Test
    void testSettersAndGetters_AgencyTitle() {
        // Arrange
        String agencyTitle = "Test Agency";

        // Act
        userProfile.setAgencyTitle(agencyTitle);

        // Assert
        assertEquals(agencyTitle, userProfile.getAgencyTitle());
    }

    @Test
    void testSettersAndGetters_AgencyCode() {
        // Arrange
        String agencyCode = "AG001";

        // Act
        userProfile.setAgencyCode(agencyCode);

        // Assert
        assertEquals(agencyCode, userProfile.getAgencyCode());
    }

    @Test
    void testSettersAndGetters_SubAgenIntId() {
        // Arrange
        Long subAgenIntId = 67890L;

        // Act
        userProfile.setSubAgenIntId(subAgenIntId);

        // Assert
        assertEquals(subAgenIntId, userProfile.getSubAgenIntId());
    }

    @Test
    void testSettersAndGetters_SubAgencyTitle() {
        // Arrange
        String subAgencyTitle = "Sub Agency Title";

        // Act
        userProfile.setSubAgencyTitle(subAgencyTitle);

        // Assert
        assertEquals(subAgencyTitle, userProfile.getSubAgencyTitle());
    }

    @Test
    void testSettersAndGetters_SubAgencyCode() {
        // Arrange
        String subAgencyCode = "SUB001";

        // Act
        userProfile.setSubAgencyCode(subAgencyCode);

        // Assert
        assertEquals(subAgencyCode, userProfile.getSubAgencyCode());
    }

    @Test
    void testSettersAndGetters_IdentityNo() {
        // Arrange
        String identityNo = "12345678901";

        // Act
        userProfile.setIdentityNo(identityNo);

        // Assert
        assertEquals(identityNo, userProfile.getIdentityNo());
    }

    @Test
    void testSettersAndGetters_MaskedIdentityNo() {
        // Arrange
        String maskedIdentityNo = "*******8901";

        // Act
        userProfile.setMaskedIdentityNo(maskedIdentityNo);

        // Assert
        assertEquals(maskedIdentityNo, userProfile.getMaskedIdentityNo());
    }

    @Test
    void testSettersAndGetters_TaxNumber() {
        // Arrange
        String taxNumber = "1234567890";

        // Act
        userProfile.setTaxNumber(taxNumber);

        // Assert
        assertEquals(taxNumber, userProfile.getTaxNumber());
    }

    @Test
    void testSettersAndGetters_MaskedTaxNumber() {
        // Arrange
        String maskedTaxNumber = "******7890";

        // Act
        userProfile.setMaskedTaxNumber(maskedTaxNumber);

        // Assert
        assertEquals(maskedTaxNumber, userProfile.getMaskedTaxNumber());
    }

    @Test
    void testSettersAndGetters_Active() {
        // Act
        userProfile.setActive(true);

        // Assert
        assertTrue(userProfile.isActive());

        // Act
        userProfile.setActive(false);

        // Assert
        assertFalse(userProfile.isActive());
    }

    @Test
    void testSettersAndGetters_PasswordExpired() {
        // Act
        userProfile.setPasswordExpired(true);

        // Assert
        assertTrue(userProfile.isPasswordExpired());

        // Act
        userProfile.setPasswordExpired(false);

        // Assert
        assertFalse(userProfile.isPasswordExpired());
    }

    @Test
    void testSettersAndGetters_GsmNo() {
        // Arrange
        String gsmNo = "05551234567";

        // Act
        userProfile.setGsmNo(gsmNo);

        // Assert
        assertEquals(gsmNo, userProfile.getGsmNo());
    }

    @Test
    void testSettersAndGetters_MaskedGsmNo() {
        // Arrange
        String maskedGsmNo = "*****34567";

        // Act
        userProfile.setMaskedGsmNo(maskedGsmNo);

        // Assert
        assertEquals(maskedGsmNo, userProfile.getMaskedGsmNo());
    }

    @Test
    void testSettersAndGetters_VipGsmNo() {
        // Arrange
        String vipGsmNo = "05559876543";

        // Act
        userProfile.setVipGsmNo(vipGsmNo);

        // Assert
        assertEquals(vipGsmNo, userProfile.getVipGsmNo());
    }

    @Test
    void testSettersAndGetters_MaskedVipGsmNo() {
        // Arrange
        String maskedVipGsmNo = "*****76543";

        // Act
        userProfile.setMaskedVipGsmNo(maskedVipGsmNo);

        // Assert
        assertEquals(maskedVipGsmNo, userProfile.getMaskedVipGsmNo());
    }

    @Test
    void testSettersAndGetters_LoginWidthSMS() {
        // Act
        userProfile.setLoginWidthSMS(true);

        // Assert
        assertTrue(userProfile.isLoginWidthSMS());

        // Act
        userProfile.setLoginWidthSMS(false);

        // Assert
        assertFalse(userProfile.isLoginWidthSMS());
    }

    @Test
    void testSettersAndGetters_SmsLoginOpen() {
        // Act
        userProfile.setSmsLoginOpen(true);

        // Assert
        assertTrue(userProfile.isSmsLoginOpen());

        // Act
        userProfile.setSmsLoginOpen(false);

        // Assert
        assertFalse(userProfile.isSmsLoginOpen());
    }

    @Test
    void testSettersAndGetters_BgdUser() {
        // Act
        userProfile.setBgdUser(true);

        // Assert
        assertTrue(userProfile.isBgdUser());

        // Act
        userProfile.setBgdUser(false);

        // Assert
        assertFalse(userProfile.isBgdUser());
    }

    @Test
    void testSettersAndGetters_CallCenterUser() {
        // Act
        userProfile.setCallCenterUser(true);

        // Assert
        assertTrue(userProfile.isCallCenterUser());

        // Act
        userProfile.setCallCenterUser(false);

        // Assert
        assertFalse(userProfile.isCallCenterUser());
    }

    @Test
    void testSettersAndGetters_SubUserType() {
        // Arrange
        String subUserType = "1";

        // Act
        userProfile.setSubUserType(subUserType);

        // Assert
        assertEquals(subUserType, userProfile.getSubUserType());
    }

    @Test
    void testSettersAndGetters_ReferenceOpusUser() {
        // Arrange
        String referenceOpusUser = "OPUS_USER_123";

        // Act
        userProfile.setReferenceOpusUser(referenceOpusUser);

        // Assert
        assertEquals(referenceOpusUser, userProfile.getReferenceOpusUser());
    }

    @Test
    void testSettersAndGetters_MfaType() {
        // Arrange
        String mfaType = "SMS";

        // Act
        userProfile.setMfaType(mfaType);

        // Assert
        assertEquals(mfaType, userProfile.getMfaType());
    }

    @Test
    void testCompleteUserProfile_WithAllFields() {
        // Arrange & Act
        userProfile.setPartnerId("P001");
        userProfile.setUserName("jdoe");
        userProfile.setName("John Doe");
        userProfile.setEmail("jdoe@example.com");
        userProfile.setUserType("1");
        userProfile.setAgenIntId(100L);
        userProfile.setAgencyTitle("Main Agency");
        userProfile.setAgencyCode("AG100");
        userProfile.setSubAgenIntId(200L);
        userProfile.setSubAgencyTitle("Sub Agency");
        userProfile.setSubAgencyCode("SUB200");
        userProfile.setIdentityNo("12345678901");
        userProfile.setMaskedIdentityNo("*******8901");
        userProfile.setTaxNumber("9876543210");
        userProfile.setMaskedTaxNumber("******3210");
        userProfile.setActive(true);
        userProfile.setPasswordExpired(false);
        userProfile.setGsmNo("05551234567");
        userProfile.setMaskedGsmNo("*****34567");
        userProfile.setVipGsmNo("05559876543");
        userProfile.setMaskedVipGsmNo("*****76543");
        userProfile.setLoginWidthSMS(true);
        userProfile.setSmsLoginOpen(true);
        userProfile.setBgdUser(false);
        userProfile.setCallCenterUser(false);
        userProfile.setSubUserType("0");
        userProfile.setReferenceOpusUser("OPUS123");
        userProfile.setMfaType("SMS");

        // Assert
        assertEquals("P001", userProfile.getPartnerId());
        assertEquals("jdoe", userProfile.getUserName());
        assertEquals("John Doe", userProfile.getName());
        assertEquals("jdoe@example.com", userProfile.getEmail());
        assertEquals("1", userProfile.getUserType());
        assertEquals(100L, userProfile.getAgenIntId());
        assertEquals("Main Agency", userProfile.getAgencyTitle());
        assertEquals("AG100", userProfile.getAgencyCode());
        assertEquals(200L, userProfile.getSubAgenIntId());
        assertEquals("Sub Agency", userProfile.getSubAgencyTitle());
        assertEquals("SUB200", userProfile.getSubAgencyCode());
        assertEquals("12345678901", userProfile.getIdentityNo());
        assertEquals("*******8901", userProfile.getMaskedIdentityNo());
        assertEquals("9876543210", userProfile.getTaxNumber());
        assertEquals("******3210", userProfile.getMaskedTaxNumber());
        assertTrue(userProfile.isActive());
        assertFalse(userProfile.isPasswordExpired());
        assertEquals("05551234567", userProfile.getGsmNo());
        assertEquals("*****34567", userProfile.getMaskedGsmNo());
        assertEquals("05559876543", userProfile.getVipGsmNo());
        assertEquals("*****76543", userProfile.getMaskedVipGsmNo());
        assertTrue(userProfile.isLoginWidthSMS());
        assertTrue(userProfile.isSmsLoginOpen());
        assertFalse(userProfile.isBgdUser());
        assertFalse(userProfile.isCallCenterUser());
        assertEquals("0", userProfile.getSubUserType());
        assertEquals("OPUS123", userProfile.getReferenceOpusUser());
        assertEquals("SMS", userProfile.getMfaType());
    }

    @Test
    void testJsonSerialization_ShouldSerializeAllFields() throws Exception {
        // Arrange
        userProfile.setPartnerId("P001");
        userProfile.setUserName("testUser");
        userProfile.setName("Test User");
        userProfile.setEmail("test@example.com");
        userProfile.setUserType("1");
        userProfile.setAgenIntId(100L);
        userProfile.setActive(true);
        userProfile.setMfaType("SMS");

        // Act
        String json = objectMapper.writeValueAsString(userProfile);

        // Assert
        assertNotNull(json);
        assertTrue(json.contains("\"partnerId\":\"P001\""));
        assertTrue(json.contains("\"userName\":\"testUser\""));
        assertTrue(json.contains("\"name\":\"Test User\""));
        assertTrue(json.contains("\"email\":\"test@example.com\""));
        assertTrue(json.contains("\"userType\":\"1\""));
        assertTrue(json.contains("\"agenIntId\":100"));
        assertTrue(json.contains("\"active\":true"));
        assertTrue(json.contains("\"mfaType\":\"SMS\""));
    }

    @Test
    void testJsonDeserialization_ShouldDeserializeAllFields() throws Exception {
        // Arrange
        String json = "{\"partnerId\":\"P001\",\"userName\":\"testUser\",\"name\":\"Test User\"," +
                "\"email\":\"test@example.com\",\"userType\":\"1\",\"agenIntId\":100," +
                "\"active\":true,\"mfaType\":\"SMS\"}";

        // Act
        UserProfile profile = objectMapper.readValue(json, UserProfile.class);

        // Assert
        assertNotNull(profile);
        assertEquals("P001", profile.getPartnerId());
        assertEquals("testUser", profile.getUserName());
        assertEquals("Test User", profile.getName());
        assertEquals("test@example.com", profile.getEmail());
        assertEquals("1", profile.getUserType());
        assertEquals(100L, profile.getAgenIntId());
        assertTrue(profile.isActive());
        assertEquals("SMS", profile.getMfaType());
    }

    @Test
    void testJsonIgnore_IdentityNo_ShouldNotSerialize() throws Exception {
        // Arrange
        userProfile.setIdentityNo("12345678901");
        userProfile.setMaskedIdentityNo("*******8901");

        // Act
        String json = objectMapper.writeValueAsString(userProfile);

        // Assert
        assertFalse(json.contains("\"identityNo\":\"12345678901\""));
        assertTrue(json.contains("\"identityNo\":\"*******8901\""));
    }

    @Test
    void testJsonIgnore_TaxNumber_ShouldNotSerialize() throws Exception {
        // Arrange
        userProfile.setTaxNumber("9876543210");
        userProfile.setMaskedTaxNumber("******3210");

        // Act
        String json = objectMapper.writeValueAsString(userProfile);

        // Assert
        assertFalse(json.contains("\"taxNumber\":\"9876543210\""));
        assertTrue(json.contains("\"taxNumber\":\"******3210\""));
    }

    @Test
    void testJsonIgnore_GsmNo_ShouldNotSerialize() throws Exception {
        // Arrange
        userProfile.setGsmNo("05551234567");
        userProfile.setMaskedGsmNo("*****34567");

        // Act
        String json = objectMapper.writeValueAsString(userProfile);

        // Assert
        assertFalse(json.contains("\"gsmNo\":\"05551234567\""));
        assertTrue(json.contains("\"gsmNo\":\"*****34567\""));
    }

    @Test
    void testJsonIgnore_VipGsmNo_ShouldNotSerialize() throws Exception {
        // Arrange
        userProfile.setVipGsmNo("05559876543");
        userProfile.setMaskedVipGsmNo("*****76543");

        // Act
        String json = objectMapper.writeValueAsString(userProfile);

        // Assert
        assertFalse(json.contains("\"vipGsmNo\":\"05559876543\""));
        assertTrue(json.contains("\"vipGsmNo\":\"*****76543\""));
    }

    @Test
    void testJsonIgnoreProperties_UnknownProperties_ShouldBeIgnored() throws Exception {
        // Arrange
        String json = "{\"partnerId\":\"P001\",\"unknownField\":\"unknownValue\"}";

        // Act
        UserProfile profile = objectMapper.readValue(json, UserProfile.class);

        // Assert
        assertNotNull(profile);
        assertEquals("P001", profile.getPartnerId());
    }

    @Test
    void testSerializable_ShouldImplementSerializable() {
        // Assert
        assertInstanceOf(Serializable.class, userProfile);
    }

    @Test
    void testNullValues_ShouldAcceptNullForAllReferenceTypes() {
        // Act & Assert
        userProfile.setPartnerId(null);
        assertNull(userProfile.getPartnerId());

        userProfile.setUserName(null);
        assertNull(userProfile.getUserName());

        userProfile.setName(null);
        assertNull(userProfile.getName());

        userProfile.setEmail(null);
        assertNull(userProfile.getEmail());

        userProfile.setUserType(null);
        assertNull(userProfile.getUserType());

        userProfile.setAgenIntId(null);
        assertNull(userProfile.getAgenIntId());

        userProfile.setAgencyTitle(null);
        assertNull(userProfile.getAgencyTitle());

        userProfile.setAgencyCode(null);
        assertNull(userProfile.getAgencyCode());

        userProfile.setSubAgenIntId(null);
        assertNull(userProfile.getSubAgenIntId());

        userProfile.setSubAgencyTitle(null);
        assertNull(userProfile.getSubAgencyTitle());

        userProfile.setSubAgencyCode(null);
        assertNull(userProfile.getSubAgencyCode());

        userProfile.setMfaType(null);
        assertNull(userProfile.getMfaType());
    }

    @Test
    void testEmptyStrings_ShouldAcceptEmptyStrings() {
        // Act
        userProfile.setPartnerId("");
        userProfile.setUserName("");
        userProfile.setName("");
        userProfile.setEmail("");

        // Assert
        assertEquals("", userProfile.getPartnerId());
        assertEquals("", userProfile.getUserName());
        assertEquals("", userProfile.getName());
        assertEquals("", userProfile.getEmail());
    }

    @Test
    void testLongValues_ShouldHandleLargeNumbers() {
        // Arrange
        Long maxValue = Long.MAX_VALUE;
        Long minValue = Long.MIN_VALUE;

        // Act
        userProfile.setAgenIntId(maxValue);
        assertEquals(maxValue, userProfile.getAgenIntId());

        userProfile.setSubAgenIntId(minValue);
        assertEquals(minValue, userProfile.getSubAgenIntId());
    }

    @Test
    void testSpecialCharacters_InStringFields() {
        // Arrange
        String specialChars = "!@#$%^&*()_+-=[]{}|;':\",./<>?";

        // Act
        userProfile.setName(specialChars);
        userProfile.setEmail(specialChars);
        userProfile.setUserName(specialChars);

        // Assert
        assertEquals(specialChars, userProfile.getName());
        assertEquals(specialChars, userProfile.getEmail());
        assertEquals(specialChars, userProfile.getUserName());
    }

    @Test
    void testBooleanDefaultValues_ShouldBeFalse() {
        // Arrange
        UserProfile newProfile = new UserProfile();

        // Assert
        assertFalse(newProfile.isActive());
        assertFalse(newProfile.isPasswordExpired());
        assertFalse(newProfile.isLoginWidthSMS());
        assertFalse(newProfile.isSmsLoginOpen());
        assertFalse(newProfile.isBgdUser());
        assertFalse(newProfile.isCallCenterUser());
    }

    @Test
    void testMaskedFieldsIndependence_ShouldBeIndependent() {
        // Act
        userProfile.setIdentityNo("12345678901");
        userProfile.setMaskedIdentityNo("*******8901");

        // Assert
        assertEquals("12345678901", userProfile.getIdentityNo());
        assertEquals("*******8901", userProfile.getMaskedIdentityNo());
        assertNotEquals(userProfile.getIdentityNo(), userProfile.getMaskedIdentityNo());
    }
}

