package tr.com.allianz.accounting_ui_backend;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import javax.management.MBeanServer;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(MockitoExtension.class)
class JmxConfigTest {

    @InjectMocks
    private JmxConfig jmxConfig;

    @Test
    void mBeanServer_ShouldReturnInstance() {
        // Act
        MBeanServer result = jmxConfig.mBeanServer();

        // Assert
        assertNotNull(result, "MBeanServer instance should not be null");
        // Verify it is a valid MBeanServer implementation (usually part of JMX implementation)
        assertTrue(result.getDefaultDomain() != null || !result.getDomains().getClass().isArray());
    }
}