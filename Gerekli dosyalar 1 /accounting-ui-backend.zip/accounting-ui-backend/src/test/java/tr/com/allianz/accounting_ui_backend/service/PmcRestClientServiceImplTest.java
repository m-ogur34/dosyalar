package tr.com.allianz.accounting_ui_backend.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import tr.com.allianz.pmc.client.ErrorResponse;
import tr.com.allianz.pmc.commonmessageutils.MessageBucket;
import tr.com.allianz.pmc.commonmessageutils.Severity;

import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class PmcRestClientServiceImplTest {

    @Mock
    private MessageBucket messageBucket;

    private PmcRestClientServiceImpl pmcRestClientService;

    @BeforeEach
    void setUp() {
        // Initialize with dummy values as custom dispatcher client init logic is in constructor
        pmcRestClientService = new PmcRestClientServiceImpl("http://localhost", 60, messageBucket);
    }

    @Test
    void handleBackendResponse_WhenErrorIsNull_ShouldAddUnknownMessage() {
        // Act
        pmcRestClientService.handleBackendResponse(null);

        // Assert
        verify(messageBucket).addExternalMessage(
                eq("UNKNOWN ERROR"),
                eq("Muhasebe Servisinden Hata Mesajı Boş Geldi"),
                eq(Severity.ERROR)
        );
    }

    @Test
    void handleBackendResponse_WhenErrorIsNotNull_ShouldAddSpecificMessage() {
        // Arrange
        ErrorResponse errorResponse = new ErrorResponse();
        errorResponse.setCode("ERR-101");
        errorResponse.setMessage("Something went wrong");

        // Act
        pmcRestClientService.handleBackendResponse(errorResponse);

        // Assert
        verify(messageBucket).addExternalMessage(
                eq("ERR-101"),
                eq("Something went wrong"),
                eq(Severity.ERROR)
        );
    }
}

