package tr.com.allianz.accounting_ui_backend.cyclic_postings.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import tr.com.allianz.accounting_ui_backend.cyclic_postings.service.CyclicAccountMappingService;
import tr.com.allianz.accounting_ui_backend.request_response.RestResponse;
import tr.com.allianz.accounting_ui_backend.shared.constants.AccountingConstants;
import tr.com.allianz.pmc.client.model.*;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)
class CyclicAccountMappingControllerTest {

    private MockMvc mockMvc;

    @Mock
    private CyclicAccountMappingService cyclicAccountMappingService;

    @InjectMocks
    private CyclicAccountMappingController cyclicAccountMappingController;

    private ObjectMapper objectMapper;

    @BeforeEach
    void setUp() {
        mockMvc = MockMvcBuilders.standaloneSetup(cyclicAccountMappingController).build();
        objectMapper = new ObjectMapper();
    }

    @Test
    void getAlzCyclicMappingList_ShouldReturnOk() throws Exception {
        // Arrange
        RestResponse<AlzCyclicAccountMappingListResponse> response = RestResponse.of(new AlzCyclicAccountMappingListResponse());
        when(cyclicAccountMappingService.getAlzCyclicMappingList()).thenReturn(response);

        // Act & Assert
        mockMvc.perform(get(AccountingConstants.API_ROOT + "/cyclic-account-mapping/list")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());

        verify(cyclicAccountMappingService).getAlzCyclicMappingList();
    }

    @Test
    void createCyclicAccountMapping_ShouldReturnOk() throws Exception {
        // Arrange
        CreateAlzCyclicAccountMappingRequest request = new CreateAlzCyclicAccountMappingRequest();
        RestResponse<CreateAlzCyclicAccountMappingResponse> response = RestResponse.of(new CreateAlzCyclicAccountMappingResponse());

        when(cyclicAccountMappingService.createAlzCyclicAccountMappingResponse(any())).thenReturn(response);

        // Act & Assert
        // Note: The controller method signature uses form-data or params by default if @RequestBody is missing.
        // Assuming @RequestBody is implied or handled implicitly by the framework setup or passing as params.
        // If it's a JSON body, add @RequestBody to the controller argument.
        // Based on the code provided, it looks like it might be expecting params or form data,
        // but typically REST APIs use JSON bodies. I will check for JSON body mismatch if the controller is missing @RequestBody.
        // If the original controller method `createCyclicAccountMapping` does not have @RequestBody,
        // Spring MVC tries to bind from parameters.

        mockMvc.perform(post(AccountingConstants.API_ROOT + "/cyclic-account-mapping/create")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request))) // This might fail binding if @RequestBody is missing in Controller
                .andExpect(status().isOk());

        // Note: If the test fails because 'request' is null in controller, you need to add @RequestBody to the Controller method.
        // Or if it's form data:
        // .param("someField", "someValue")
    }

    @Test
    void removeCyclicAccountMapping_ShouldReturnOk() throws Exception {
        // Arrange
        RemoveAlzCyclicAccountMappingRequest request = new RemoveAlzCyclicAccountMappingRequest();
        RestResponse<RemoveAlzCyclicAccountMappingResponse> response = RestResponse.of(new RemoveAlzCyclicAccountMappingResponse());

        when(cyclicAccountMappingService.removeAlzCyclicAccountMappingResponse(any())).thenReturn(response);

        // Act & Assert
        mockMvc.perform(post(AccountingConstants.API_ROOT + "/cyclic-account-mapping/remove")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk());
    }
}