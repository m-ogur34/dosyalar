package tr.com.allianz.accounting_ui_backend.config.cas;

import com.allianz.auth.client.model.UserDetailsModel;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class AuthenticatedUserServiceTest {

    private SecurityContext securityContext;
    private Authentication authentication;
    private UserDetailsModel userDetailsModel;

    @BeforeEach
    void setUp() {
        securityContext = mock(SecurityContext.class);
        authentication = mock(Authentication.class);
        userDetailsModel = mock(UserDetailsModel.class);

        SecurityContextHolder.setContext(securityContext);
        when(securityContext.getAuthentication()).thenReturn(authentication);
        when(authentication.getPrincipal()).thenReturn(userDetailsModel);
    }

    @AfterEach
    void tearDown() {
        SecurityContextHolder.clearContext();
    }

    @Test
    void testGetUserName_ShouldReturnUserName() {
        // Arrange
        when(userDetailsModel.getAgenIntId()).thenReturn(100L);
        when(userDetailsModel.getAgencyCode()).thenReturn("AG001");
        when(userDetailsModel.getUserType()).thenReturn("0");
        when(userDetailsModel.getSubUserType()).thenReturn("0");
        when(userDetailsModel.getUserName()).thenReturn("testUser");
        when(userDetailsModel.getSubAgencyCode()).thenReturn("SUB001");
        when(userDetailsModel.getTaxNumber()).thenReturn("1234567890");

        // Act
        String userName = AuthenticatedUserService.getUserName();

        // Assert
        assertEquals("testUser", userName);
    }

    @Test
    void testGetTaxNumber_ShouldReturnTaxNumber() {
        // Arrange
        when(userDetailsModel.getAgenIntId()).thenReturn(100L);
        when(userDetailsModel.getAgencyCode()).thenReturn("AG001");
        when(userDetailsModel.getUserType()).thenReturn("0");
        when(userDetailsModel.getSubUserType()).thenReturn("0");
        when(userDetailsModel.getUserName()).thenReturn("testUser");
        when(userDetailsModel.getSubAgencyCode()).thenReturn("SUB001");
        when(userDetailsModel.getTaxNumber()).thenReturn("1234567890");

        // Act
        String taxNumber = AuthenticatedUserService.getTaxNumber();

        // Assert
        assertEquals("1234567890", taxNumber);
    }

    @Test
    void testGetUserType_ShouldReturnUserType() {
        // Arrange
        when(userDetailsModel.getAgenIntId()).thenReturn(100L);
        when(userDetailsModel.getAgencyCode()).thenReturn("AG001");
        when(userDetailsModel.getUserType()).thenReturn("0");
        when(userDetailsModel.getSubUserType()).thenReturn("0");
        when(userDetailsModel.getUserName()).thenReturn("testUser");
        when(userDetailsModel.getSubAgencyCode()).thenReturn("SUB001");
        when(userDetailsModel.getTaxNumber()).thenReturn("1234567890");

        // Act
        String userType = AuthenticatedUserService.getUserType();

        // Assert
        assertEquals("0", userType);
    }

    @Test
    void testGetSubUserType_ShouldReturnSubUserType() {
        // Arrange
        when(userDetailsModel.getAgenIntId()).thenReturn(100L);
        when(userDetailsModel.getAgencyCode()).thenReturn("AG001");
        when(userDetailsModel.getUserType()).thenReturn("0");
        when(userDetailsModel.getSubUserType()).thenReturn("0");
        when(userDetailsModel.getUserName()).thenReturn("testUser");
        when(userDetailsModel.getSubAgencyCode()).thenReturn("SUB001");
        when(userDetailsModel.getTaxNumber()).thenReturn("1234567890");

        // Act
        String subUserType = AuthenticatedUserService.getSubUserType();

        // Assert
        assertEquals("0", subUserType);
    }

    @Test
    void testGetAgentIntId_ShouldReturnAgentIntId() {
        // Arrange
        when(userDetailsModel.getAgenIntId()).thenReturn(12345L);
        when(userDetailsModel.getAgencyCode()).thenReturn("AG001");
        when(userDetailsModel.getUserType()).thenReturn("0");
        when(userDetailsModel.getSubUserType()).thenReturn("0");
        when(userDetailsModel.getUserName()).thenReturn("testUser");
        when(userDetailsModel.getSubAgencyCode()).thenReturn("SUB001");
        when(userDetailsModel.getTaxNumber()).thenReturn("1234567890");

        // Act
        Integer agentIntId = AuthenticatedUserService.getAgentIntId();

        // Assert
        assertEquals(12345, agentIntId);
    }

    @Test
    void testGetSubAgentCode_ShouldReturnSubAgentCode() {
        // Arrange
        when(userDetailsModel.getAgenIntId()).thenReturn(100L);
        when(userDetailsModel.getAgencyCode()).thenReturn("AG001");
        when(userDetailsModel.getUserType()).thenReturn("0");
        when(userDetailsModel.getSubUserType()).thenReturn("0");
        when(userDetailsModel.getUserName()).thenReturn("testUser");
        when(userDetailsModel.getSubAgencyCode()).thenReturn("SUB001");
        when(userDetailsModel.getTaxNumber()).thenReturn("1234567890");

        // Act
        String subAgentCode = AuthenticatedUserService.getSubAgentCode();

        // Assert
        assertEquals("SUB001", subAgentCode);
    }

    @Test
    void testGetCompanyCode_ShouldReturnAZS() {
        // Act
        String companyCode = AuthenticatedUserService.getCompanyCode();

        // Assert
        assertEquals("AZS", companyCode);
    }

    @Test
    void testGetUserProfile_ShouldReturnUserProfile() {
        // Arrange
        when(userDetailsModel.getAgenIntId()).thenReturn(100L);
        when(userDetailsModel.getAgencyCode()).thenReturn("AG001");
        when(userDetailsModel.getUserType()).thenReturn("1");
        when(userDetailsModel.getSubUserType()).thenReturn("0");
        when(userDetailsModel.getUserName()).thenReturn("agentUser");
        when(userDetailsModel.getSubAgencyCode()).thenReturn("SUB100");
        when(userDetailsModel.getTaxNumber()).thenReturn("9876543210");

        // Act
        UserProfile userProfile = AuthenticatedUserService.getUserProfile();

        // Assert
        assertNotNull(userProfile);
        assertEquals(100L, userProfile.getAgenIntId());
        assertEquals("AG001", userProfile.getAgencyCode());
        assertEquals("1", userProfile.getUserType());
        assertEquals("0", userProfile.getSubUserType());
        assertEquals("agentUser", userProfile.getUserName());
        assertEquals("SUB100", userProfile.getSubAgencyCode());
        assertEquals("9876543210", userProfile.getTaxNumber());
    }

    @Test
    void testIsAlzUser_ShouldReturnTrue_WhenUserTypeIsZero() {
        // Arrange
        when(userDetailsModel.getAgenIntId()).thenReturn(100L);
        when(userDetailsModel.getAgencyCode()).thenReturn("AG001");
        when(userDetailsModel.getUserType()).thenReturn("0");
        when(userDetailsModel.getSubUserType()).thenReturn("0");
        when(userDetailsModel.getUserName()).thenReturn("testUser");
        when(userDetailsModel.getSubAgencyCode()).thenReturn("SUB001");
        when(userDetailsModel.getTaxNumber()).thenReturn("1234567890");

        // Act
        boolean isAlzUser = AuthenticatedUserService.isAlzUser();

        // Assert
        assertTrue(isAlzUser);
    }

    @Test
    void testIsAlzUser_ShouldReturnFalse_WhenUserTypeIsNotZero() {
        // Arrange
        when(userDetailsModel.getAgenIntId()).thenReturn(100L);
        when(userDetailsModel.getAgencyCode()).thenReturn("AG001");
        when(userDetailsModel.getUserType()).thenReturn("1");
        when(userDetailsModel.getSubUserType()).thenReturn("0");
        when(userDetailsModel.getUserName()).thenReturn("testUser");
        when(userDetailsModel.getSubAgencyCode()).thenReturn("SUB001");
        when(userDetailsModel.getTaxNumber()).thenReturn("1234567890");

        // Act
        boolean isAlzUser = AuthenticatedUserService.isAlzUser();

        // Assert
        assertFalse(isAlzUser);
    }

    @Test
    void testIsAgency_ShouldReturnTrue_WhenUserTypeIsOne() {
        // Arrange
        when(userDetailsModel.getAgenIntId()).thenReturn(100L);
        when(userDetailsModel.getAgencyCode()).thenReturn("AG001");
        when(userDetailsModel.getUserType()).thenReturn("1");
        when(userDetailsModel.getSubUserType()).thenReturn("0");
        when(userDetailsModel.getUserName()).thenReturn("testUser");
        when(userDetailsModel.getSubAgencyCode()).thenReturn("SUB001");
        when(userDetailsModel.getTaxNumber()).thenReturn("1234567890");

        // Act
        boolean isAgency = AuthenticatedUserService.isAgency();

        // Assert
        assertTrue(isAgency);
    }

    @Test
    void testIsAgency_ShouldReturnFalse_WhenUserTypeIsNotOne() {
        // Arrange
        when(userDetailsModel.getAgenIntId()).thenReturn(100L);
        when(userDetailsModel.getAgencyCode()).thenReturn("AG001");
        when(userDetailsModel.getUserType()).thenReturn("0");
        when(userDetailsModel.getSubUserType()).thenReturn("0");
        when(userDetailsModel.getUserName()).thenReturn("testUser");
        when(userDetailsModel.getSubAgencyCode()).thenReturn("SUB001");
        when(userDetailsModel.getTaxNumber()).thenReturn("1234567890");

        // Act
        boolean isAgency = AuthenticatedUserService.isAgency();

        // Assert
        assertFalse(isAgency);
    }

    @Test
    void testIsCustomer_ShouldReturnTrue_WhenSubUserTypeIsOne() {
        // Arrange
        when(userDetailsModel.getAgenIntId()).thenReturn(100L);
        when(userDetailsModel.getAgencyCode()).thenReturn("AG001");
        when(userDetailsModel.getUserType()).thenReturn("0");
        when(userDetailsModel.getSubUserType()).thenReturn("1");
        when(userDetailsModel.getUserName()).thenReturn("testUser");
        when(userDetailsModel.getSubAgencyCode()).thenReturn("SUB001");
        when(userDetailsModel.getTaxNumber()).thenReturn("1234567890");

        // Act
        boolean isCustomer = AuthenticatedUserService.isCustomer();

        // Assert
        assertTrue(isCustomer);
    }

    @Test
    void testIsCustomer_ShouldReturnFalse_WhenSubUserTypeIsNotOne() {
        // Arrange
        when(userDetailsModel.getAgenIntId()).thenReturn(100L);
        when(userDetailsModel.getAgencyCode()).thenReturn("AG001");
        when(userDetailsModel.getUserType()).thenReturn("0");
        when(userDetailsModel.getSubUserType()).thenReturn("0");
        when(userDetailsModel.getUserName()).thenReturn("testUser");
        when(userDetailsModel.getSubAgencyCode()).thenReturn("SUB001");
        when(userDetailsModel.getTaxNumber()).thenReturn("1234567890");

        // Act
        boolean isCustomer = AuthenticatedUserService.isCustomer();

        // Assert
        assertFalse(isCustomer);
    }

    @Test
    void testGetUserTypeName_ShouldReturnCentral_WhenUserTypeIsZero() {
        // Arrange
        when(userDetailsModel.getAgenIntId()).thenReturn(100L);
        when(userDetailsModel.getAgencyCode()).thenReturn("AG001");
        when(userDetailsModel.getUserType()).thenReturn("0");
        when(userDetailsModel.getSubUserType()).thenReturn("0");
        when(userDetailsModel.getUserName()).thenReturn("testUser");
        when(userDetailsModel.getSubAgencyCode()).thenReturn("SUB001");
        when(userDetailsModel.getTaxNumber()).thenReturn("1234567890");

        // Act
        String userTypeName = AuthenticatedUserService.getUserTypeName();

        // Assert
        assertEquals("CENTRAL", userTypeName);
    }

    @Test
    void testGetUserTypeName_ShouldReturnAgency_WhenUserTypeIsOne() {
        // Arrange
        when(userDetailsModel.getAgenIntId()).thenReturn(100L);
        when(userDetailsModel.getAgencyCode()).thenReturn("AG001");
        when(userDetailsModel.getUserType()).thenReturn("1");
        when(userDetailsModel.getSubUserType()).thenReturn("0");
        when(userDetailsModel.getUserName()).thenReturn("testUser");
        when(userDetailsModel.getSubAgencyCode()).thenReturn("SUB001");
        when(userDetailsModel.getTaxNumber()).thenReturn("1234567890");

        // Act
        String userTypeName = AuthenticatedUserService.getUserTypeName();

        // Assert
        assertEquals("AGENCY", userTypeName);
    }

    @Test
    void testGetUserTypeName_ShouldReturnCustomer_WhenSubUserTypeIsOne() {
        // Arrange
        when(userDetailsModel.getAgenIntId()).thenReturn(100L);
        when(userDetailsModel.getAgencyCode()).thenReturn("AG001");
        when(userDetailsModel.getUserType()).thenReturn("2");
        when(userDetailsModel.getSubUserType()).thenReturn("1");
        when(userDetailsModel.getUserName()).thenReturn("testUser");
        when(userDetailsModel.getSubAgencyCode()).thenReturn("SUB001");
        when(userDetailsModel.getTaxNumber()).thenReturn("1234567890");

        // Act
        String userTypeName = AuthenticatedUserService.getUserTypeName();

        // Assert
        assertEquals("CUSTOMER", userTypeName);
    }

    @Test
    void testGetUserTypeName_ShouldReturnEmpty_WhenNoConditionMatches() {
        // Arrange
        when(userDetailsModel.getAgenIntId()).thenReturn(100L);
        when(userDetailsModel.getAgencyCode()).thenReturn("AG001");
        when(userDetailsModel.getUserType()).thenReturn("3");
        when(userDetailsModel.getSubUserType()).thenReturn("0");
        when(userDetailsModel.getUserName()).thenReturn("testUser");
        when(userDetailsModel.getSubAgencyCode()).thenReturn("SUB001");
        when(userDetailsModel.getTaxNumber()).thenReturn("1234567890");

        // Act
        String userTypeName = AuthenticatedUserService.getUserTypeName();

        // Assert
        assertEquals("", userTypeName);
    }

    @Test
    void testGetAgentRole_ShouldReturnAgentIntId() {
        // Arrange
        when(userDetailsModel.getAgenIntId()).thenReturn(999L);
        when(userDetailsModel.getAgencyCode()).thenReturn("AG001");
        when(userDetailsModel.getUserType()).thenReturn("0");
        when(userDetailsModel.getSubUserType()).thenReturn("0");
        when(userDetailsModel.getUserName()).thenReturn("testUser");
        when(userDetailsModel.getSubAgencyCode()).thenReturn("SUB001");
        when(userDetailsModel.getTaxNumber()).thenReturn("1234567890");

        // Act
        int agentRole = AuthenticatedUserService.getAgentRole();

        // Assert
        assertEquals(999, agentRole);
    }

    @Test
    void testConstructor_ShouldThrowException() {
        // Act & Assert - Constructor should throw exception when called via reflection
        assertThrows(Exception.class, () -> {
            java.lang.reflect.Constructor<AuthenticatedUserService> constructor =
                AuthenticatedUserService.class.getDeclaredConstructor();
            constructor.setAccessible(true);
            constructor.newInstance();
        });
    }


    @Test
    void testGetAgentIntId_WithLargeValue() {
        // Arrange
        when(userDetailsModel.getAgenIntId()).thenReturn(2147483647L);
        when(userDetailsModel.getAgencyCode()).thenReturn("AG001");
        when(userDetailsModel.getUserType()).thenReturn("0");
        when(userDetailsModel.getSubUserType()).thenReturn("0");
        when(userDetailsModel.getUserName()).thenReturn("testUser");
        when(userDetailsModel.getSubAgencyCode()).thenReturn("SUB001");
        when(userDetailsModel.getTaxNumber()).thenReturn("1234567890");

        // Act
        Integer agentIntId = AuthenticatedUserService.getAgentIntId();

        // Assert
        assertEquals(2147483647, agentIntId);
    }

    @Test
    void testGetUserProfile_MultipleFieldsSet() {
        // Arrange
        when(userDetailsModel.getAgenIntId()).thenReturn(555L);
        when(userDetailsModel.getAgencyCode()).thenReturn("AGENCY999");
        when(userDetailsModel.getUserType()).thenReturn("0");
        when(userDetailsModel.getSubUserType()).thenReturn("0");
        when(userDetailsModel.getUserName()).thenReturn("centralUser");
        when(userDetailsModel.getSubAgencyCode()).thenReturn("SUBAGENCY999");
        when(userDetailsModel.getTaxNumber()).thenReturn("5555555555");

        // Act
        UserProfile profile = AuthenticatedUserService.getUserProfile();

        // Assert
        assertEquals(555L, profile.getAgenIntId());
        assertEquals("AGENCY999", profile.getAgencyCode());
        assertEquals("0", profile.getUserType());
        assertEquals("0", profile.getSubUserType());
        assertEquals("centralUser", profile.getUserName());
        assertEquals("SUBAGENCY999", profile.getSubAgencyCode());
        assertEquals("5555555555", profile.getTaxNumber());
    }
}

