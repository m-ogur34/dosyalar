package tr.com.allianz.accounting_ui_backend;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockedStatic;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mockStatic;

@ExtendWith(SpringExtension.class)
class AccountingUiBackendApplicationTests {

	@Test
	void contextLoads() {
		// Simple test to verify test infrastructure works
		assertTrue(true);
	}

	@Test
	void applicationClassShouldBeAnnotatedWithSpringBootApplication() {
		assertTrue(AccountingUiBackendApplication.class.isAnnotationPresent(
				org.springframework.boot.autoconfigure.SpringBootApplication.class));
	}

	@Test
	void applicationClassShouldImportJmxConfig() {
		assertTrue(AccountingUiBackendApplication.class.isAnnotationPresent(
				org.springframework.context.annotation.Import.class));
	}

	@Test
	void main_ShouldDelegateToSpringApplicationRun() {
		String[] args = {"--spring.profiles.active=test"};

		try (MockedStatic<org.springframework.boot.SpringApplication> springApplication = mockStatic(org.springframework.boot.SpringApplication.class)) {
			springApplication.when(() -> org.springframework.boot.SpringApplication.run(AccountingUiBackendApplication.class, args))
					.thenReturn(null);

			AccountingUiBackendApplication.main(args);

			springApplication.verify(() -> org.springframework.boot.SpringApplication.run(AccountingUiBackendApplication.class, args));
		}
	}

	@Test
	void springBootApplication_ShouldDeclareExpectedScanBasePackagesAndExcludes() {
		org.springframework.boot.autoconfigure.SpringBootApplication annotation =
				AccountingUiBackendApplication.class.getAnnotation(org.springframework.boot.autoconfigure.SpringBootApplication.class);

		assertArrayEquals(new String[]{"com.allianz.auth.client", "tr.com.allianz.accounting_ui_backend"}, annotation.scanBasePackages());
		assertEquals(3, annotation.exclude().length);
	}

	@Test
	void constructor_ShouldCreateApplicationInstance() {
		AccountingUiBackendApplication application = new AccountingUiBackendApplication();

		assertTrue(application instanceof AccountingUiBackendApplication);
	}

}
