package tr.com.allianz.accounting_ui_backend.shared.constants.exception;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class ErrorCodeAwareTest {

    @Mock
    private ErrorCode mockErrorCode;

    @Test
    void shouldBeInterface() {
        // Assert
        assertTrue(ErrorCodeAware.class.isInterface());
    }

    @Test
    void shouldBePublic() {
        // Assert
        assertTrue(Modifier.isPublic(ErrorCodeAware.class.getModifiers()));
    }

    @Test
    void getCodeMethodShouldExist() {
        // Assert
        try {
            ErrorCodeAware.class.getMethod("getCode");
            assertTrue(true);
        } catch (NoSuchMethodException e) {
            fail("getCode method should exist");
        }
    }

    @Test
    void getCodeShouldReturnErrorCode() {
        // Arrange
        ErrorCodeAware implementation = () -> mockErrorCode;

        // Act
        ErrorCode result = implementation.getCode();

        // Assert
        assertNotNull(result);
        assertEquals(mockErrorCode, result);
    }

    @Test
    void getCodeShouldNotHaveParameters() throws NoSuchMethodException {
        // Arrange
        Method method = ErrorCodeAware.class.getMethod("getCode");

        // Assert
        assertEquals(0, method.getParameterCount());
    }

    @Test
    void getCodeShouldReturnErrorCodeType() throws NoSuchMethodException {
        // Arrange
        Method method = ErrorCodeAware.class.getMethod("getCode");

        // Assert
        assertEquals(ErrorCode.class, method.getReturnType());
    }


    @Test
    void shouldBeImplementableByAppException() {
        // Arrange
        AppException appException = new AppException("Error");

        // Assert
        assertInstanceOf(ErrorCodeAware.class, appException);
    }

    @Test
    void implementationCanReturnNull() {
        // Arrange
        ErrorCodeAware implementation = () -> null;

        // Act
        ErrorCode result = implementation.getCode();

        // Assert
        assertNull(result);
    }

    @Test
    void implementationCanReturnErrorCodeInstance() {
        // Arrange
        ErrorCode errorCode = new ErrorCode("IMPL_TEST", "Implementation test");
        ErrorCodeAware implementation = () -> errorCode;

        // Act
        ErrorCode result = implementation.getCode();

        // Assert
        assertNotNull(result);
        assertEquals("IMPL_TEST", result.getCode());
        assertEquals("Implementation test", result.getMessage());
    }

    @Test
    void multipleImplementationsCanCoexist() {
        // Arrange
        ErrorCode code1 = new ErrorCode("CODE1");
        ErrorCode code2 = new ErrorCode("CODE2");

        ErrorCodeAware impl1 = () -> code1;
        ErrorCodeAware impl2 = () -> code2;

        // Act
        ErrorCode result1 = impl1.getCode();
        ErrorCode result2 = impl2.getCode();

        // Assert
        assertEquals(code1, result1);
        assertEquals(code2, result2);
        assertNotEquals(result1, result2);
    }

    @Test
    void getCodeMethodShouldBePublic() throws NoSuchMethodException {
        // Arrange
        Method method = ErrorCodeAware.class.getMethod("getCode");

        // Assert
        assertTrue(Modifier.isPublic(method.getModifiers()));
    }

    @Test
    void getCodeMethodShouldBeAbstract() throws NoSuchMethodException {
        // Arrange
        Method method = ErrorCodeAware.class.getMethod("getCode");

        // Assert
        assertTrue(Modifier.isAbstract(method.getModifiers()));
    }

    @Test
    void interfaceCanBeUsedAsType() {
        // Arrange
        ErrorCodeAware implementation = () -> new ErrorCode("TYPE_TEST");

        // Assert
        assertInstanceOf(ErrorCodeAware.class, implementation);
    }

    @Test
    void getCodeReturnValueCanBeCheckedForNull() {
        // Arrange
        ErrorCodeAware nullReturning = () -> null;
        ErrorCodeAware valueReturning = () -> new ErrorCode("VALUE");

        // Act & Assert
        assertNull(nullReturning.getCode());
        assertNotNull(valueReturning.getCode());
    }

    @Test
    void implementationCanCacheErrorCode() {
        // Arrange
        ErrorCode cachedCode = new ErrorCode("CACHED");
        ErrorCodeAware implementation = new ErrorCodeAware() {
            private final ErrorCode code = cachedCode;

            @Override
            public ErrorCode getCode() {
                return code;
            }
        };

        // Act
        ErrorCode result1 = implementation.getCode();
        ErrorCode result2 = implementation.getCode();

        // Assert
        assertSame(result1, result2);
        assertEquals(cachedCode, result1);
    }

    @Test
    void implementationCanComputeErrorCodeDynamically() {
        // Arrange
        ErrorCodeAware dynamicImpl = new ErrorCodeAware() {
            private int callCount = 0;

            @Override
            public ErrorCode getCode() {
                callCount++;
                return new ErrorCode("DYNAMIC_" + callCount);
            }
        };

        // Act
        ErrorCode result1 = dynamicImpl.getCode();
        ErrorCode result2 = dynamicImpl.getCode();

        // Assert
        assertNotEquals(result1.getCode(), result2.getCode());
        assertEquals("DYNAMIC_1", result1.getCode());
        assertEquals("DYNAMIC_2", result2.getCode());
    }

    @Test
    void errorCodeAwareCanBeUsedInCollections() {
        // Arrange
        ErrorCodeAware impl1 = () -> new ErrorCode("ERR1");
        ErrorCodeAware impl2 = () -> new ErrorCode("ERR2");

        java.util.List<ErrorCodeAware> implementations = java.util.Arrays.asList(impl1, impl2);

        // Act
        java.util.List<ErrorCode> codes = new java.util.ArrayList<>();
        for (ErrorCodeAware impl : implementations) {
            codes.add(impl.getCode());
        }

        // Assert
        assertEquals(2, codes.size());
        assertEquals("ERR1", codes.get(0).getCode());
        assertEquals("ERR2", codes.get(1).getCode());
    }

    @Test
    void errorCodeAwareIsCompatibleWithLambda() {
        // Arrange & Act
        ErrorCodeAware lambda = () -> new ErrorCode("LAMBDA");

        // Assert
        assertNotNull(lambda);
        assertEquals("LAMBDA", lambda.getCode().getCode());
    }

    @Test
    void methodSignatureIsConsistent() throws NoSuchMethodException {
        // Arrange
        Method method = ErrorCodeAware.class.getMethod("getCode");

        // Assert
        assertEquals("getCode", method.getName());
        assertEquals(ErrorCode.class, method.getReturnType());
        assertEquals(0, method.getParameterCount());
    }
}

