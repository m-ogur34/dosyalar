package tr.com.allianz.accounting_ui_backend.assistance_accounting.controller;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;
import tr.com.allianz.accounting_ui_backend.assistance_accounting.service.AssistanceAccountingService;
import tr.com.allianz.accounting_ui_backend.request_response.RestResponse;
import tr.com.allianz.pmc.client.model.*;

import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AssistanceAccountingControllerTest {

    @Mock
    private AssistanceAccountingService assistanceAccountingService;

    @InjectMocks
    private AssistanceAccountingController controller;

    @Test
    void testListAccCoverCodes() {
        RestResponse<List<AccCoverCode>> expected = RestResponse.of(Collections.emptyList());
        when(assistanceAccountingService.getListAccCoverCode()).thenReturn(expected);

        ResponseEntity<RestResponse<List<AccCoverCode>>> response = controller.listAccCoverCodes();
        assertNotNull(response);
        assertEquals(expected, response.getBody());
    }

    @Test
    void testListAssistanceCompanies() {
        RestResponse<List<AssistanceCompany>> expected = RestResponse.of(Collections.emptyList());
        when(assistanceAccountingService.getListAssistanceCompany()).thenReturn(expected);

        ResponseEntity<RestResponse<List<AssistanceCompany>>> response = controller.listAssistanceCompanies();
        assertNotNull(response);
        assertEquals(expected, response.getBody());
    }

    @Test
    void testListAssistanceProducts() {
        RestResponse<List<AssistanceProduct>> expected = RestResponse.of(Collections.emptyList());
        when(assistanceAccountingService.getListAssistanceProduct("code")).thenReturn(expected);

        ResponseEntity<RestResponse<List<AssistanceProduct>>> response = controller.listAssistanceProducts("code");
        assertNotNull(response);
        assertEquals(expected, response.getBody());
    }

    @Test
    void testListAssistancePartitions() {
        RestResponse<List<AssistancePartition>> expected = RestResponse.of(Collections.emptyList());
        List<Long> productIds = List.of(1L, 2L);
        when(assistanceAccountingService.getListAssistancePartition(productIds)).thenReturn(expected);

        ResponseEntity<RestResponse<List<AssistancePartition>>> response = controller.listAssistancePartitions(productIds);
        assertNotNull(response);
        assertEquals(expected, response.getBody());
    }

    @Test
    void testCreateAssistanceAccountingEntry() {
        RestResponse<List<AssistanceQueryResult>> expected = RestResponse.of(Collections.emptyList());
        AssistanceQueryCriteria criteria = new AssistanceQueryCriteria();
        when(assistanceAccountingService.postListAssistanceQuery(criteria)).thenReturn(expected);

        ResponseEntity<RestResponse<List<AssistanceQueryResult>>> response = controller.createAssistanceAccountingEntry(criteria);
        assertNotNull(response);
        assertEquals(expected, response.getBody());
    }

    @Test
    void testCreatePosting() {
        RestResponse<Long> expected = RestResponse.of(1L);
        CreateAssistancePostingRequest request = new CreateAssistancePostingRequest();
        when(assistanceAccountingService.postCreateAssistancePosting(request)).thenReturn(expected);

        ResponseEntity<RestResponse<Long>> response = controller.createPosting(request);
        assertNotNull(response);
        assertEquals(expected, response.getBody());
    }
}

