package tr.com.allianz.accounting_ui_backend.shared.constants.exception;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ErrorCodesTest {

    @Test
    void undefinedError_ShouldHaveCorrectCodeAndMessage() {
        ErrorCode errorCode = ErrorCodes.Exception.UNDEFINED_ERROR;
        assertNotNull(errorCode);
        assertEquals("0", errorCode.getCode());
        assertEquals("UNDEFINED ERROR", errorCode.getMessage());
    }

    @Test
    void internalServerError_ShouldHaveCorrectCodeAndMessage() {
        ErrorCode errorCode = ErrorCodes.Exception.INTERNAL_SERVER_ERROR;
        assertNotNull(errorCode);
        assertEquals("10", errorCode.getCode());
        assertEquals("INTERNAL SERVER ERROR", errorCode.getMessage());
    }

    @Test
    void unprocessableInputData_ShouldHaveCorrectCodeAndMessage() {
        ErrorCode errorCode = ErrorCodes.Exception.UNPROCESSABLE_INPUT_DATA;
        assertNotNull(errorCode);
        assertEquals("20", errorCode.getCode());
        assertEquals("UNPROCESSABLE INPUT DATA", errorCode.getMessage());
    }

    @Test
    void badRequest_ShouldHaveCorrectCodeAndMessage() {
        ErrorCode errorCode = ErrorCodes.Exception.BAD_REQUEST;
        assertNotNull(errorCode);
        assertEquals("30", errorCode.getCode());
        assertEquals("BAD REQUEST", errorCode.getMessage());
    }

    @Test
    void digitalPos_ShouldHaveCorrectCodeAndMessage() {
        ErrorCode errorCode = ErrorCodes.Exception.DIGITAL_POS;
        assertNotNull(errorCode);
        assertEquals("40", errorCode.getCode());
        assertEquals("DIGITAL POS", errorCode.getMessage());
    }

    @Test
    void errorCodesInterface_ShouldBeInterface() {
        assertTrue(ErrorCodes.class.isInterface());
    }

    @Test
    void securityInterface_ShouldBeInterface() {
        assertTrue(ErrorCodes.Security.class.isInterface());
    }

    @Test
    void exceptionInterface_ShouldBeInterface() {
        assertTrue(ErrorCodes.Exception.class.isInterface());
    }
}

