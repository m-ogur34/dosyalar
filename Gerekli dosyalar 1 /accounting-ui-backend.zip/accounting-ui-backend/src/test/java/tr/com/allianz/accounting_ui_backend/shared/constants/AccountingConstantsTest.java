package tr.com.allianz.accounting_ui_backend.shared.constants;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.lang.reflect.Modifier;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class AccountingConstantsTest {

    @Test
    void API_ROOT_HasCorrectValue() {
        assertEquals("/api/v1", AccountingConstants.API_ROOT);
    }

    @Test
    void API_ROOT_IsNotNull() {
        assertNotNull(AccountingConstants.API_ROOT);
    }

    @Test
    void classShouldBeFinal() {
        assertTrue(Modifier.isFinal(AccountingConstants.class.getModifiers()));
    }

    @Test
    void API_ROOT_FollowsRestfulPattern() {
        assertTrue(AccountingConstants.API_ROOT.matches("^/api/v\\d+$"));
    }

    @Test
    void API_ROOT_HasExpectedLength() {
        assertEquals(7, AccountingConstants.API_ROOT.length());
    }

    @Test
    void API_ROOT_CanConcatenateWithEndpoints() {
        String endpoint = AccountingConstants.API_ROOT + "/list";
        assertEquals("/api/v1/list", endpoint);
    }

    @Test
    void classIsPublic() {
        assertTrue(Modifier.isPublic(AccountingConstants.class.getModifiers()));
    }

    @Test
    void API_ROOT_MultipleReferencesAreEqual() {
        String ref1 = AccountingConstants.API_ROOT;
        String ref2 = AccountingConstants.API_ROOT;
        assertEquals(ref1, ref2);
    }

    @Test
    void API_ROOT_CanCreateMultipleEndpoints() {
        assertEquals("/api/v1/list", AccountingConstants.API_ROOT + "/list");
        assertEquals("/api/v1/create", AccountingConstants.API_ROOT + "/create");
        assertEquals("/api/v1/update", AccountingConstants.API_ROOT + "/update");
    }

    @Test
    void API_ROOT_StringImmutability() {
        String original = AccountingConstants.API_ROOT;
        @SuppressWarnings("unused")
        String modified = original + "/test";
        assertEquals("/api/v1", AccountingConstants.API_ROOT);
    }

    @Test
    void constructor_ShouldBeInvokableReflectively() throws Exception {
        var constructor = AccountingConstants.class.getDeclaredConstructor();
        constructor.setAccessible(true);

        Object instance = constructor.newInstance();

        assertNotNull(instance);
        assertInstanceOf(AccountingConstants.class, instance);
    }
}



