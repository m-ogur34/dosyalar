package tr.com.allianz.accounting_ui_backend.cyclic_postings.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import tr.com.allianz.accounting_ui_backend.cyclic_postings.service.CyclicPostingProcessService;
import tr.com.allianz.accounting_ui_backend.request_response.RestResponse;
import tr.com.allianz.accounting_ui_backend.shared.constants.AccountingConstants;
import tr.com.allianz.pmc.client.model.*;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)
class CyclicPostingProcessControllerTest {

    private MockMvc mockMvc;

    @Mock
    private CyclicPostingProcessService cyclicPostingProcessService;

    @InjectMocks
    private CyclicPostingProcessController cyclicPostingProcessController;

    private ObjectMapper objectMapper;

    @BeforeEach
    void setUp() {
        mockMvc = MockMvcBuilders.standaloneSetup(cyclicPostingProcessController).build();
        objectMapper = new ObjectMapper();
    }

    @Test
    void getAlzCyclicMappingList_ShouldReturnOk() throws Exception {
        // Arrange
        RestResponse<AlzCyclicPostingProcessListResponse> response = RestResponse.of(new AlzCyclicPostingProcessListResponse());
        when(cyclicPostingProcessService.getAlzCyclicMappingList(
                0, 2000, null, null, null
        )).thenReturn(response);

        // Act & Assert
        mockMvc.perform(get(AccountingConstants.API_ROOT + "/cyclic-posting-process/list")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());

        verify(cyclicPostingProcessService).getAlzCyclicMappingList(
                0, 2000, null, null, null
        );
    }

    @Test
    void createCyclicAccountMapping_ShouldReturnOk() throws Exception {
        // Arrange
        CreateCyclicPostingRequest request = new CreateCyclicPostingRequest();
        RestResponse<CreateCyclicPostingResponse> response = RestResponse.of(new CreateCyclicPostingResponse());

        when(cyclicPostingProcessService.createAlzCyclicPostingProcess(any()))
                .thenReturn(response);

        // Act & Assert
        // Logic note: Ensure the controller method has @RequestBody if using JSON content mapping.
        mockMvc.perform(post(AccountingConstants.API_ROOT + "/cyclic-posting-process/create")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk());
    }

    @Test
    void removeUnprocessedCyclicPostings_ShouldReturnOk() throws Exception {
        // Arrange
        RemoveCyclicPostingProcessRequest request = new RemoveCyclicPostingProcessRequest();
        RestResponse<RemoveCyclicPostingProcessResponse> response = RestResponse.of(new RemoveCyclicPostingProcessResponse());

        when(cyclicPostingProcessService.removeUnprocessedCyclicPosting(any())).thenReturn(response);

        // Act & Assert
        mockMvc.perform(post(AccountingConstants.API_ROOT + "/cyclic-posting-process/remove-unprocessed")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk());
    }

    @Test
    void processCyclicPostings_ShouldReturnOk() throws Exception {
        // Arrange
        ProcessCyclicPostingRequest request = new ProcessCyclicPostingRequest();
        RestResponse<ProcessCyclicPostingResponse> response = RestResponse.of(new ProcessCyclicPostingResponse());

        when(cyclicPostingProcessService.processCyclicPosting(any())).thenReturn(response);

        // Act & Assert
        mockMvc.perform(post(AccountingConstants.API_ROOT + "/cyclic-posting-process/process")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk());
    }
}