package tr.com.allianz.accounting_ui_backend.cyclic_postings.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import tr.com.allianz.accounting_ui_backend.request_response.RestResponse;
import tr.com.allianz.accounting_ui_backend.service.RestClientConsumerService;
import tr.com.allianz.accounting_ui_backend.service.config.client.CustomDispatcherClient;
import tr.com.allianz.pmc.client.DispatcherClientResponse;
import tr.com.allianz.pmc.client.endpoint.AlzCyclicPostingProcessControllerApiEndPoint;
import tr.com.allianz.pmc.client.model.*;
import tr.com.allianz.pmc.commonmessageutils.MessageBucket;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class CyclicPostingProcessServiceTest {

    @Mock
    private CustomDispatcherClient pmcRestClientClient;

    @Mock
    private MessageBucket messageBucket;

    @Mock
    private AlzCyclicPostingProcessControllerApiEndPoint restAlzCyclicPostingProcessControllerApi;

    @InjectMocks
    private CyclicPostingProcessService cyclicPostingProcessService;

    @BeforeEach
    void setUp() {
        // Set the mock endpoint on the CustomDispatcherClient
        org.springframework.test.util.ReflectionTestUtils.setField(
            pmcRestClientClient,
            "restAlzCyclicPostingProcessControllerApi",
            restAlzCyclicPostingProcessControllerApi
        );
    }

    // ===================== Success Tests =====================

    @Test
    void getAlzCyclicMappingList_ShouldReturnListResponse() {
        // Arrange
        AlzCyclicPostingProcessListResponse expectedData = new AlzCyclicPostingProcessListResponse();
        ApiResponseAlzCyclicPostingProcessListResponse apiResponse = new ApiResponseAlzCyclicPostingProcessListResponse();
        apiResponse.setData(expectedData);

        DispatcherClientResponse<ApiResponseAlzCyclicPostingProcessListResponse> dispatcherResponse =
            new DispatcherClientResponse<>();
        dispatcherResponse.setData(apiResponse);
        dispatcherResponse.setSuccess(true);

        doReturn(dispatcherResponse)
            .when(restAlzCyclicPostingProcessControllerApi)
            .listAlzCyclicPostingProcess(0, 2000, null, null, null);

        // Act
        RestResponse<AlzCyclicPostingProcessListResponse> result = cyclicPostingProcessService.getAlzCyclicMappingList(0, 2000, null, null, null);

        // Assert
        assertNotNull(result);
        assertNotNull(result.getData());
        assertEquals(expectedData, result.getData());
    }

    @Test
    void createAlzCyclicPostingProcess_ShouldReturnCreateResponse() {
        // Arrange
        CreateCyclicPostingRequest request = new CreateCyclicPostingRequest();
        CreateCyclicPostingResponse expectedData = new CreateCyclicPostingResponse();
        ApiResponseCreateCyclicPostingResponse apiResponse = new ApiResponseCreateCyclicPostingResponse();
        apiResponse.setData(expectedData);

        DispatcherClientResponse<ApiResponseCreateCyclicPostingResponse> dispatcherResponse =
            new DispatcherClientResponse<>();
        dispatcherResponse.setData(apiResponse);
        dispatcherResponse.setSuccess(true);

        when(restAlzCyclicPostingProcessControllerApi
                .createCyclicPostings(request))
                .thenReturn(dispatcherResponse);

        // Act
        RestResponse<CreateCyclicPostingResponse> result = cyclicPostingProcessService.createAlzCyclicPostingProcess(request);

        // Assert
        assertNotNull(result);
        assertNotNull(result.getData());
        assertEquals(expectedData, result.getData());
    }

    @Test
    void removeUnprocessedCyclicPosting_ShouldReturnRemoveResponse() {
        // Arrange
        RemoveCyclicPostingProcessRequest request = new RemoveCyclicPostingProcessRequest();
        RemoveCyclicPostingProcessResponse expectedData = new RemoveCyclicPostingProcessResponse();
        ApiResponseRemoveCyclicPostingProcessResponse apiResponse = new ApiResponseRemoveCyclicPostingProcessResponse();
        apiResponse.setData(expectedData);

        DispatcherClientResponse<ApiResponseRemoveCyclicPostingProcessResponse> dispatcherResponse =
            new DispatcherClientResponse<>();
        dispatcherResponse.setData(apiResponse);
        dispatcherResponse.setSuccess(true);

        when(restAlzCyclicPostingProcessControllerApi
                .removeUnprocessedCyclicPostings(request))
                .thenReturn(dispatcherResponse);

        // Act
        RestResponse<RemoveCyclicPostingProcessResponse> result = cyclicPostingProcessService.removeUnprocessedCyclicPosting(request);

        // Assert
        assertNotNull(result);
        assertNotNull(result.getData());
        assertEquals(expectedData, result.getData());
    }

    @Test
    void processCyclicPosting_ShouldReturnProcessResponse() {
        // Arrange
        ProcessCyclicPostingRequest request = new ProcessCyclicPostingRequest();
        ProcessCyclicPostingResponse expectedData = new ProcessCyclicPostingResponse();
        ApiResponseProcessCyclicPostingResponse apiResponse = new ApiResponseProcessCyclicPostingResponse();
        apiResponse.setData(expectedData);

        DispatcherClientResponse<ApiResponseProcessCyclicPostingResponse> dispatcherResponse =
            new DispatcherClientResponse<>();
        dispatcherResponse.setData(apiResponse);
        dispatcherResponse.setSuccess(true);

        when(restAlzCyclicPostingProcessControllerApi
                .processCyclicPostings(request))
                .thenReturn(dispatcherResponse);

        // Act
        RestResponse<ProcessCyclicPostingResponse> result = cyclicPostingProcessService.processCyclicPosting(request);

        // Assert
        assertNotNull(result);
        assertNotNull(result.getData());
        assertEquals(expectedData, result.getData());
    }

    // ===================== Error Scenario Tests =====================

    @Test
    void getAlzCyclicMappingList_ShouldReturnErrorResponse_WhenApiResponseFails() {
        // Arrange
        DispatcherClientResponse<ApiResponseAlzCyclicPostingProcessListResponse> dispatcherResponse =
            new DispatcherClientResponse<>();
        dispatcherResponse.setData(null);
        dispatcherResponse.setSuccess(false);

        doReturn(dispatcherResponse)
            .when(restAlzCyclicPostingProcessControllerApi)
            .listAlzCyclicPostingProcess(anyInt(), anyInt(), any(), any(), any());

        // Act
        RestResponse<AlzCyclicPostingProcessListResponse> result =
            cyclicPostingProcessService.getAlzCyclicMappingList(0, 2000, null, null, null);

        // Assert
        assertNotNull(result);
        assertNull(result.getData());
        verify(messageBucket).addExternalMessage(anyString(), anyString(), any());
    }

    @Test
    void createAlzCyclicPostingProcess_ShouldReturnErrorResponse_WhenApiResponseFails() {
        // Arrange
        CreateCyclicPostingRequest request = new CreateCyclicPostingRequest();
        DispatcherClientResponse<ApiResponseCreateCyclicPostingResponse> dispatcherResponse =
            new DispatcherClientResponse<>();
        dispatcherResponse.setData(null);
        dispatcherResponse.setSuccess(false);

        when(restAlzCyclicPostingProcessControllerApi
                .createCyclicPostings(request))
                .thenReturn(dispatcherResponse);

        // Act
        RestResponse<CreateCyclicPostingResponse> result =
            cyclicPostingProcessService.createAlzCyclicPostingProcess(request);

        // Assert
        assertNotNull(result);
        assertNull(result.getData());
        verify(messageBucket).addExternalMessage(anyString(), anyString(), any());
    }

    @Test
    void processCyclicPosting_ShouldReturnErrorResponse_WhenApiResponseFails() {
        // Arrange
        ProcessCyclicPostingRequest request = new ProcessCyclicPostingRequest();
        DispatcherClientResponse<ApiResponseProcessCyclicPostingResponse> dispatcherResponse =
                new DispatcherClientResponse<>();
        dispatcherResponse.setData(null);
        dispatcherResponse.setSuccess(false);

        when(restAlzCyclicPostingProcessControllerApi
                .processCyclicPostings(request))
                .thenReturn(dispatcherResponse);

        // Act
        RestResponse<ProcessCyclicPostingResponse> result =
                cyclicPostingProcessService.processCyclicPosting(request);

        // Assert
        assertNotNull(result);
        assertNull(result.getData());
        verify(messageBucket).addExternalMessage(anyString(), anyString(), any());
    }

    @Test
    void removeUnprocessedCyclicPosting_ShouldReturnErrorResponse_WhenApiResponseFails() {
        // Arrange
        RemoveCyclicPostingProcessRequest request = new RemoveCyclicPostingProcessRequest();
        DispatcherClientResponse<ApiResponseRemoveCyclicPostingProcessResponse> dispatcherResponse =
                new DispatcherClientResponse<>();
        dispatcherResponse.setData(null);
        dispatcherResponse.setSuccess(false);

        when(restAlzCyclicPostingProcessControllerApi
                .removeUnprocessedCyclicPostings(request))
                .thenReturn(dispatcherResponse);

        // Act
        RestResponse<RemoveCyclicPostingProcessResponse> result =
                cyclicPostingProcessService.removeUnprocessedCyclicPosting(request);

        // Assert
        assertNotNull(result);
        assertNull(result.getData());
        verify(messageBucket).addExternalMessage(anyString(), anyString(), any());
    }

    // ===================== Null/Empty Parameter Tests =====================

    @Test
    void getAlzCyclicMappingList_ShouldHandleAllParameters() {
        // Arrange
        AlzCyclicPostingProcessListResponse expectedData = new AlzCyclicPostingProcessListResponse();
        ApiResponseAlzCyclicPostingProcessListResponse apiResponse = new ApiResponseAlzCyclicPostingProcessListResponse();
        apiResponse.setData(expectedData);

        DispatcherClientResponse<ApiResponseAlzCyclicPostingProcessListResponse> dispatcherResponse =
            new DispatcherClientResponse<>();
        dispatcherResponse.setData(apiResponse);
        dispatcherResponse.setSuccess(true);

        Integer page = 1;
        Integer size = 100;
        Long batchId = 123L;
        Long cyclicBatchId = 456L;
        String status = "PENDING";

        doReturn(dispatcherResponse)
            .when(restAlzCyclicPostingProcessControllerApi)
            .listAlzCyclicPostingProcess(page, size, batchId, cyclicBatchId, status);

        // Act
        RestResponse<AlzCyclicPostingProcessListResponse> result =
            cyclicPostingProcessService.getAlzCyclicMappingList(page, size, batchId, cyclicBatchId, status);

        // Assert
        assertNotNull(result);
        assertEquals(expectedData, result.getData());
    }

    @Test
    void createAlzCyclicPostingProcess_ShouldHandleNullRequest() {
        // Arrange
        CreateCyclicPostingResponse expectedData = new CreateCyclicPostingResponse();
        ApiResponseCreateCyclicPostingResponse apiResponse = new ApiResponseCreateCyclicPostingResponse();
        apiResponse.setData(expectedData);

        DispatcherClientResponse<ApiResponseCreateCyclicPostingResponse> dispatcherResponse =
            new DispatcherClientResponse<>();
        dispatcherResponse.setData(apiResponse);
        dispatcherResponse.setSuccess(true);

        when(restAlzCyclicPostingProcessControllerApi
                .createCyclicPostings(null))
                .thenReturn(dispatcherResponse);

        // Act
        RestResponse<CreateCyclicPostingResponse> result =
            cyclicPostingProcessService.createAlzCyclicPostingProcess(null);

        // Assert
        assertNotNull(result);
        assertEquals(expectedData, result.getData());
    }

    @Test
    void removeUnprocessedCyclicPosting_ShouldHandleNullRequest() {
        // Arrange
        RemoveCyclicPostingProcessResponse expectedData = new RemoveCyclicPostingProcessResponse();
        ApiResponseRemoveCyclicPostingProcessResponse apiResponse = new ApiResponseRemoveCyclicPostingProcessResponse();
        apiResponse.setData(expectedData);

        DispatcherClientResponse<ApiResponseRemoveCyclicPostingProcessResponse> dispatcherResponse =
            new DispatcherClientResponse<>();
        dispatcherResponse.setData(apiResponse);
        dispatcherResponse.setSuccess(true);

        when(restAlzCyclicPostingProcessControllerApi
                .removeUnprocessedCyclicPostings(null))
                .thenReturn(dispatcherResponse);

        // Act
        RestResponse<RemoveCyclicPostingProcessResponse> result =
            cyclicPostingProcessService.removeUnprocessedCyclicPosting(null);

        // Assert
        assertNotNull(result);
        assertEquals(expectedData, result.getData());
    }

    @Test
    void processCyclicPosting_ShouldHandleNullRequest() {
        // Arrange
        ProcessCyclicPostingResponse expectedData = new ProcessCyclicPostingResponse();
        ApiResponseProcessCyclicPostingResponse apiResponse = new ApiResponseProcessCyclicPostingResponse();
        apiResponse.setData(expectedData);

        DispatcherClientResponse<ApiResponseProcessCyclicPostingResponse> dispatcherResponse =
            new DispatcherClientResponse<>();
        dispatcherResponse.setData(apiResponse);
        dispatcherResponse.setSuccess(true);

        when(restAlzCyclicPostingProcessControllerApi
                .processCyclicPostings(null))
                .thenReturn(dispatcherResponse);

        // Act
        RestResponse<ProcessCyclicPostingResponse> result =
            cyclicPostingProcessService.processCyclicPosting(null);

        // Assert
        assertNotNull(result);
        assertEquals(expectedData, result.getData());
    }

    // ===================== Integration Tests =====================

    @Test
    void service_ShouldExtendRestClientConsumerService() {
        // Assert
        assertInstanceOf(RestClientConsumerService.class, cyclicPostingProcessService);
    }

    @Test
    void getAlzCyclicMappingList_ShouldCallCorrectApiMethod() {
        // Arrange
        AlzCyclicPostingProcessListResponse expectedData = new AlzCyclicPostingProcessListResponse();
        ApiResponseAlzCyclicPostingProcessListResponse apiResponse = new ApiResponseAlzCyclicPostingProcessListResponse();
        apiResponse.setData(expectedData);

        DispatcherClientResponse<ApiResponseAlzCyclicPostingProcessListResponse> dispatcherResponse =
            new DispatcherClientResponse<>();
        dispatcherResponse.setData(apiResponse);
        dispatcherResponse.setSuccess(true);

        Integer page = 0;
        Integer size = 2000;

        doReturn(dispatcherResponse)
            .when(restAlzCyclicPostingProcessControllerApi)
            .listAlzCyclicPostingProcess(page, size, null, null, null);

        // Act
        cyclicPostingProcessService.getAlzCyclicMappingList(page, size, null, null, null);

        // Assert
        verify(restAlzCyclicPostingProcessControllerApi).listAlzCyclicPostingProcess(page, size, null, null, null);
    }

    @Test
    void createAlzCyclicPostingProcess_ShouldCallCorrectApiMethod() {
        // Arrange
        CreateCyclicPostingRequest request = new CreateCyclicPostingRequest();
        CreateCyclicPostingResponse expectedData = new CreateCyclicPostingResponse();
        ApiResponseCreateCyclicPostingResponse apiResponse = new ApiResponseCreateCyclicPostingResponse();
        apiResponse.setData(expectedData);

        DispatcherClientResponse<ApiResponseCreateCyclicPostingResponse> dispatcherResponse =
            new DispatcherClientResponse<>();
        dispatcherResponse.setData(apiResponse);
        dispatcherResponse.setSuccess(true);

        when(restAlzCyclicPostingProcessControllerApi
                .createCyclicPostings(request))
                .thenReturn(dispatcherResponse);

        // Act
        cyclicPostingProcessService.createAlzCyclicPostingProcess(request);

        // Assert
        verify(restAlzCyclicPostingProcessControllerApi).createCyclicPostings(request);
    }

    @Test
    void removeUnprocessedCyclicPosting_ShouldCallCorrectApiMethod() {
        // Arrange
        RemoveCyclicPostingProcessRequest request = new RemoveCyclicPostingProcessRequest();
        RemoveCyclicPostingProcessResponse expectedData = new RemoveCyclicPostingProcessResponse();
        ApiResponseRemoveCyclicPostingProcessResponse apiResponse = new ApiResponseRemoveCyclicPostingProcessResponse();
        apiResponse.setData(expectedData);

        DispatcherClientResponse<ApiResponseRemoveCyclicPostingProcessResponse> dispatcherResponse =
            new DispatcherClientResponse<>();
        dispatcherResponse.setData(apiResponse);
        dispatcherResponse.setSuccess(true);

        when(restAlzCyclicPostingProcessControllerApi
                .removeUnprocessedCyclicPostings(request))
                .thenReturn(dispatcherResponse);

        // Act
        cyclicPostingProcessService.removeUnprocessedCyclicPosting(request);

        // Assert
        verify(restAlzCyclicPostingProcessControllerApi).removeUnprocessedCyclicPostings(request);
    }

    @Test
    void processCyclicPosting_ShouldCallCorrectApiMethod() {
        // Arrange
        ProcessCyclicPostingRequest request = new ProcessCyclicPostingRequest();
        ProcessCyclicPostingResponse expectedData = new ProcessCyclicPostingResponse();
        ApiResponseProcessCyclicPostingResponse apiResponse = new ApiResponseProcessCyclicPostingResponse();
        apiResponse.setData(expectedData);

        DispatcherClientResponse<ApiResponseProcessCyclicPostingResponse> dispatcherResponse =
            new DispatcherClientResponse<>();
        dispatcherResponse.setData(apiResponse);
        dispatcherResponse.setSuccess(true);

        when(restAlzCyclicPostingProcessControllerApi
                .processCyclicPostings(request))
                .thenReturn(dispatcherResponse);

        // Act
        cyclicPostingProcessService.processCyclicPosting(request);

        // Assert
        verify(restAlzCyclicPostingProcessControllerApi).processCyclicPostings(request);
    }
}
