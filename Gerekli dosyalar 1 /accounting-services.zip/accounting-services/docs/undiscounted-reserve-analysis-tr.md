# Undiscounted Reserve Dağıtım Analizi

**Doküman tarihi:** 04.08.2026  
**Proje:** `accounting-services`  
**Durum:** Analiz ve geliştirme öncesi karar dokümanı

---

## 1. Amaç

IBNR ve ULAE dağıtımları tamamlandıktan sonra tüm DC/Partajlar için bilanço rezervi formatında CY/PY kırılımlı
`Undiscounted Reserve` oluşturulması; ayrıca yüklenen `Current Rate Discounted Reserve` ve 
`Locked-in Rate Discounted Reserve` tutarlarının IBNR kural seti ve Undiscounted Reserve ağırlıkları kullanılarak
dağıtılması amaçlanmaktadır.

Bu doküman:

- mevcut kodun davranışını,
- beklenen iş kuralını,
- hesaplama sırasını,
- CY/PY ağırlık formüllerini,
- veri modeli ve persistence ihtiyaçlarını,
- sınır durumlarını,
- geliştirme öncesi netleştirilmesi gereken kararları

ortaya koyar.

---

## 2. Kapsam

### Kapsama dahil

- DC/Partaj bazında `Undiscounted Reserve` üretimi
- CY ve PY kırılımı
- Bilanço rezervi yaklaşımı
- `Current Rate Discounted Reserve` dağıtımı
- `Locked-in Rate Discounted Reserve` dağıtımı
- IBNR kural seti ile uygun DC/Partajların belirlenmesi
- Devreden kayıtların kapsamdan çıkarılması
- `IBNR + ULAE + Case Reserve - SS Receivables` toplamının oluşturulması

### Kapsam dışı veya henüz tanımlanmamış konular

Aşağıdaki konular mevcut kodda veya verilen gereksinimde kesin olarak tanımlı değildir:

- DC/Partaj anahtarının kaynak tablosu ve kolonları
- `Case Reserve` ve `SS Receivables` veri kaynakları
- Devreden kaydı gösteren kolon
- Rezervlerin Gross/RE/Net kırılımının gerekip gerekmediği
- Toplam satırının veritabanına kaydedilip kaydedilmeyeceği
- Negatif rezervlerin ağırlık hesabında nasıl ele alınacağı
- Yuvarlama farkının hangi DC/Partaja verileceği

Bu maddeler geliştirme başlamadan önce iş birimi ve veri sahibi tarafından karara bağlanmalıdır.

---

## 3. Terimler

| Terim | Açıklama |
|---|---|
| CY | Current Year, cari yıl |
| PY | Previous Year, önceki yıl |
| IBNR | Incurred But Not Reported rezervi |
| ULAE | Unallocated Loss Adjustment Expense |
| Case Reserve | Dosya/hasar bazlı mevcut karşılık |
| SS Receivables | Gereksinimde belirtilen SS alacakları |
| DC/Partaj | Dağıtımın yapılacağı iş/portföy kırılımı |
| Undiscounted Reserve | İskonto edilmemiş bilanço rezervi |
| Current Rate Discounted Reserve | Cari oranla iskonto edilmiş rezerv |
| Locked-in Rate Discounted Reserve | Kilitlenmiş oranla iskonto edilmiş rezerv |
| Devreden | Önceki dönemden devreden ve bu hesaplamada kapsam dışı bırakılması istenen kayıt |

---

## 4. İş Gereksinimi

İstenen rezerv görünümü üç ana kalemden oluşmaktadır:

| Rezerv kalemi | Kırılım | Dağıtım mantığı |
|---|---|---|
| Undiscounted Reserve | CY/PY, bilanço rezervi | DC/Partajların Undiscounted Reserve ağırlığına göre |
| Current Rate Discounted Reserve | CY/PY, bilanço rezervi | Önce IBNR kriteri, sonra Undiscounted ağırlığı |
| Locked-in Rate Discounted Reserve | CY/PY, bilanço rezervi | Önce IBNR kriteri, sonra Undiscounted ağırlığı |

IBNR ve ULAE dağıtımları tamamlandıktan sonra tüm DC/Partajlar için devreden olmayan kayıtlar üzerinden Undiscounted Reserve oluşturulmalıdır.

Current Rate ve Locked-in Rate tutarları tüm DC/Partajlara doğrudan oranlanmayacaktır. Her iki tutar için aşağıdaki iki aşamalı süreç uygulanacaktır:

1. IBNR kural setini sağlayan DC/Partajlar seçilecektir.
2. Seçilen DC/Partajlar, CY ve PY için ayrı ayrı Undiscounted Reserve ağırlıklarıyla dağıtılacaktır.

Örnek IBNR kriteri:

```sql

ruleText

```

---

## 5. Mevcut Kodun Durumu

### 5.1 `ExecuteDistributionUseCase`

`ExecuteDistributionUseCase` mevcut durumda:

1. `ActuaryQueryCriteria` ile süreç, yıl ve ay bazında sonuçları yükler.
2. `ruleId` ve en az bir amount alanı bulunan kayıtları dağıtılabilir kabul eder.
3. Dağıtılabilir kuralların toplamlarını hesaplar.
4. TRFS ve IFRS kural bazlı toplamlarını yükler.
5. Kural bazında tutar ve oranları `ActuaryProcessAmount` içine kaydeder.

Mevcut `isDistributable` kontrolü yalnızca mevcut amount ve IFRS alanlarını kontrol eder. Rezerv alanları bu kontrolde bulunmamaktadır.

### 5.2 Mevcut domain modeli

`ActuaryProcessAmount` ve `ActuaryProcessRuleAmount` içinde mevcut alanlar şunlardır:

- TRFS/GROSS CY ve PY
- TRFS/RE CY ve PY
- TRFS/NET CY ve PY
- IFRS/GROSS CY ve PY
- IFRS/RE CY ve PY
- IFRS/NET CY ve PY
- Bu alanların oranları

Aşağıdaki rezerv alanları mevcut değildir:

- Undiscounted Reserve CY/PY
- Current Rate Discounted Reserve CY/PY
- Locked-in Rate Discounted Reserve CY/PY
- IBNR, ULAE, Case Reserve ve SS Receivables bileşenleri
- DC/Partaj kimliği
- Devreden bilgisi

### 5.3 Mevcut persistence yapısı

`AlzActProcessAmountsRepository` mevcut tutar ve oran alanlarını `ALZ_ACT_PROCESS_AMOUNTS` tablosundan okur. Sorgu kural, süreç, yıl ve ay seviyesinde çalışır; DC/Partaj seviyesinde rezerv dağıtımı yapacak alanları taşımamaktadır.

Mevcut yapıda `ALZ_ACT_PROCESS_RULES.RULE_TEXT` kural koşulunu taşır. Kural metinleri SQL'e uygulanmadan önce `SqlRulePredicateSupport` tarafından güvenlik ve sözdizimi açısından doğrulanmaktadır.

### 5.4 Sonuç

Yeni gereksinim mevcut akışa doğrudan birkaç kolon eklemekten daha geniştir. DC/Partaj seviyesinde rezerv hesabı için yeni veri sorguları, yeni bir sonuç modeli veya mevcut modelin DC/Partaj alanlarıyla genişletilmesi ve ayrı bir rezerv dağıtım aşaması gerekmektedir.

---

## 6. Önerilen Hesaplama Akışı

### Aşama 1 — Rezerv bileşenlerini yükleme

Her devreden olmayan DC/Partaj için aşağıdaki CY/PY bileşenleri hazırlanmalıdır:

```text
IBNR_CY, IBNR_PY
ULAE_CY, ULAE_PY
CASE_RESERVE_CY, CASE_RESERVE_PY
SS_RECEIVABLES_CY, SS_RECEIVABLES_PY
```

### Aşama 2 — Undiscounted Reserve hesaplama

DC/Partaj bazında önerilen bilanço rezervi formülü:

```text
UNDISCOUNTED_CY_i =
    IBNR_CY_i
  + ULAE_CY_i
  + CASE_RESERVE_CY_i
  - SS_RECEIVABLES_CY_i
```

```text
UNDISCOUNTED_PY_i =
    IBNR_PY_i
  + ULAE_PY_i
  + CASE_RESERVE_PY_i
  - SS_RECEIVABLES_PY_i
```

Bu formül, gereksinimde belirtilen toplam formülünün DC/Partaj seviyesine uygulanmış halidir. İş birimi, Case Reserve ve SS Receivables bileşenlerinin Undiscounted Reserve detayına da dahil edilmesini teyit etmelidir.

### Aşama 3 — IBNR kapsamını belirleme

Current Rate ve Locked-in Rate dağıtımında kullanılacak DC/Partaj kümesi:

- IBNR kural setini karşılayan,
- devreden olmayan,
- dağıtıma esas Undiscounted Reserve değeri bulunan

kayıtlardan oluşmalıdır.

```text
S_IBNR = IBNR kriterini sağlayan ve devreden olmayan DC/Partajlar
```

IBNR kriterini karşılamayan kayıtlar Undiscounted Reserve detayında yer alabilir; ancak Current Rate veya Locked-in Rate dağıtımından pay almamalıdır.

### Aşama 4 — CY/PY ağırlıklarını hesaplama

CY ağırlığı:

```text
W_CY_i =
    UNDISCOUNTED_CY_i
    / Σ(UNDISCOUNTED_CY_j), j ∈ S_IBNR
```

PY ağırlığı:

```text
W_PY_i =
    UNDISCOUNTED_PY_i
    / Σ(UNDISCOUNTED_PY_j), j ∈ S_IBNR
```

CY ve PY paydaları birbirinden bağımsızdır. CY ağırlığı PY toplamından, PY ağırlığı CY toplamından hesaplanmamalıdır.

### Aşama 5 — Current Rate dağıtımı

```text
CURRENT_CY_i = CURRENT_CY_INPUT × W_CY_i
```

```text
CURRENT_PY_i = CURRENT_PY_INPUT × W_PY_i
```

### Aşama 6 — Locked-in Rate dağıtımı

```text
LOCKED_IN_CY_i = LOCKED_IN_CY_INPUT × W_CY_i
```

```text
LOCKED_IN_PY_i = LOCKED_IN_PY_INPUT × W_PY_i
```

Current Rate ve Locked-in Rate aynı uygun DC/Partaj kümesini ve aynı Undiscounted ağırlıklarını kullanabilir; ancak input ve output tutarları ayrı hesaplanıp saklanmalıdır.

---

## 7. Örnek Hesaplama

IBNR kriterini sağlayan üç DC/Partaj olduğu varsayılsın:

| DC/Partaj | Undiscounted CY | Undiscounted PY |
|---|---:|---:|
| A | 600 | 200 |
| B | 300 | 300 |
| C | 100 | 500 |
| **Toplam** | **1.000** | **1.000** |

Ağırlıklar:

| DC/Partaj | CY ağırlığı | PY ağırlığı |
|---|---:|---:|
| A | %60 | %20 |
| B | %30 | %30 |
| C | %10 | %50 |

Current Rate input değerleri:

```text
CURRENT_CY_INPUT = 800
CURRENT_PY_INPUT = 400
```

Dağıtım:

| DC/Partaj | Current CY | Current PY |
|---|---:|---:|
| A | 480 | 80 |
| B | 240 | 120 |
| C | 80 | 200 |
| **Toplam** | **800** | **400** |

Locked-in Rate input değerleri de aynı yöntemle, ancak ayrı input tutarlarıyla dağıtılır.

---

## 8. Devreden Kayıt Kuralı

“Devreden olmayacak” kuralı yalnızca sonuç satırının gizlenmesi olarak uygulanmamalıdır. Devreden kayıtlar aşağıdaki tüm hesaplardan çıkarılmalıdır:

- Undiscounted Reserve toplamı
- CY ağırlık paydası
- PY ağırlık paydası
- Current Rate uygun DC/Partaj kümesi
- Locked-in Rate uygun DC/Partaj kümesi
- Toplam satırı

Devreden kayıtların ağırlık paydasına dahil edilmesi, kayıt daha sonra sonuçtan çıkarılsa dahi diğer DC/Partajların paylarını hatalı biçimde azaltır.

Devreden filtresi için gerçek kolon ve değer, kaynak tablo incelenerek kesinleştirilmelidir.

---

## 9. Toplam Satırı

Toplam satırı CY ve PY için ayrı üretilmelidir.

```text
TOTAL_CY =
    Σ IBNR_CY
  + Σ ULAE_CY
  + Σ CASE_RESERVE_CY
  - Σ SS_RECEIVABLES_CY
```

```text
TOTAL_PY =
    Σ IBNR_PY
  + Σ ULAE_PY
  + Σ CASE_RESERVE_PY
  - Σ SS_RECEIVABLES_PY
```

Toplamlar yalnızca devreden olmayan kayıtlar üzerinden hesaplanmalıdır.

Toplam satırının:

- özel bir `ruleId` ile `ALZ_ACT_PROCESS_AMOUNTS` tablosuna yazılması,
- ayrı aggregate olarak API/raporda üretilmesi,
- veya yalnızca Excel çıktısında gösterilmesi

karar gerektirmektedir.

---

## 10. Önerilen Veri Modeli

Rezerv sonucu DC/Partaj seviyesinde tutulacaksa en az aşağıdaki kimlik ve filtre alanları taşınmalıdır:

```text
dcPartajId
dcPartajCode
isCarriedForward
isIndustrial
accCoverCode
productId
```

Rezerv tutarları:

```text
undiscountedCy
undiscountedPy
currentRateDiscountedCy
currentRateDiscountedPy
lockedInRateDiscountedCy
lockedInRateDiscountedPy
```

İzlenebilirlik ve kontrol amacıyla bileşenlerin ayrıca tutulması önerilir:

```text
ibnrCy
ibnrPy
ulaeCy
ulaePy
caseReserveCy
caseReservePy
ssReceivablesCy
ssReceivablesPy
```

Rezerv hesaplamasını mevcut `ExecuteDistributionUseCase` içine tamamen gömmek yerine ayrı bir `ReserveDistribution` domain modeli ve ayrı bir use case ile uygulamak daha düşük risklidir.

Önerilen akış:

```text
ExecuteDistributionUseCase
    → mevcut IBNR / ULAE dağıtımları

ExecuteReserveDistributionUseCase
    → Undiscounted Reserve
    → Current Rate dağıtımı
    → Locked-in Rate dağıtımı
    → toplam satırı
```

---

## 11. Teknik Değişiklik Alanları

### Domain

Değişmesi veya genişletilmesi muhtemel sınıflar:

- `ActuaryProcessAmount`
- `ActuaryProcessRuleAmount`
- Yeni `ReserveDistributionAmount` veya eşdeğer value object

### Application

- Rezerv kaynaklarının yüklenmesi
- Devreden filtresinin uygulanması
- IBNR kriteriyle uygun DC/Partaj kümesinin oluşturulması
- CY/PY ağırlıklarının ayrı hesaplanması
- İki discounted reserve türünün dağıtılması
- Toplamların oluşturulması

### Persistence

Yeni sorguların aşağıdaki bilgileri sağlaması gerekir:

- DC/Partaj kimliği
- CY/PY rezerv bileşenleri
- devreden bilgisi
- `is_industrial`
- `acc_cover_code`
- `product_id`
- Current Rate input tutarı
- Locked-in Rate input tutarı

`ALZ_ACT_PROCESS_RULES.RULE_TEXT` ile gelen koşullar mevcut güvenlik/doğrulama mekanizması korunarak uygulanmalıdır.

### API ve Excel

Manuel giriş veya çıktı gerekiyorsa aşağıdaki kolonlar tanımlanmalıdır:

```text
Undiscounted Reserve CY
Undiscounted Reserve PY
Current Rate Discounted Reserve CY
Current Rate Discounted Reserve PY
Locked-in Rate Discounted Reserve CY
Locked-in Rate Discounted Reserve PY
```

Bu alanların kullanıcı tarafından yüklenip yüklenmeyeceği veya sistem tarafından hesaplanacağı netleştirilmelidir.

---

## 12. Sınır Durumları

### 12.1 Sıfır payda

```text
Σ UNDISCOUNTED_CY = 0
```

veya

```text
Σ UNDISCOUNTED_PY = 0
```

ise ilgili dönem için ağırlık hesaplanamaz.

Önerilen davranış:

- dağıtım yapılmaması,
- sonuç değerinin `null` veya iş kuralına göre `0` olması,
- anlaşılır bir log/iş hatası üretilmesi,
- sessizce eşit dağıtım yapılmaması.

### 12.2 Negatif Undiscounted Reserve

`Case Reserve - SS Receivables` sonucu negatif olabilir. Negatif tutarların ağırlığa dahil edilmesi negatif veya anlamsız paylar üretebilir.

Olası seçenekler:

1. Negatif değerleri ağırlığa dahil etmek
2. Negatif değerleri sıfıra çekmek
3. Negatif değer bulunan dağıtımı durdurmak
4. Pozitif ve negatif rezervleri ayrı dağıtmak

Bu karar iş birimi tarafından verilmelidir. Kodda varsayılan olarak negatifleri sıfıra çekmek, finansal kural onayı olmadan uygulanmamalıdır.

### 12.3 Null tutarlar

Null bileşenlerin `0` kabul edilip edilmeyeceği hesaplama bazında standartlaştırılmalıdır. Bir bileşen mevcut değilse toplam formülünde genellikle `0` kabul edilmesi beklenir; ancak eksik kaynak verisi ile gerçek sıfır birbirinden ayrılabiliyorsa bu ayrım korunmalıdır.

### 12.4 Yuvarlama

CY ve PY ayrı yuvarlanmalıdır. Detay toplamı input tutarından kuruş seviyesinde farklılaşırsa fark için açık bir dağıtım kuralı belirlenmelidir.

Önerilen kontrol:

```text
Σ dağıtılan Current CY = Current CY input
Σ dağıtılan Current PY = Current PY input
Σ dağıtılan Locked-in CY = Locked-in CY input
Σ dağıtılan Locked-in PY = Locked-in PY input
```

### 12.5 IBNR kriterini karşılamayan kayıtlar

Bu kayıtlar:

- Undiscounted Reserve detayında bulunabilir,
- Current Rate dağıtımından pay alamaz,
- Locked-in Rate dağıtımından pay alamaz,
- ilgili discounted ağırlık paydasına giremez.

---

## 13. Test Senaryoları

En az aşağıdaki testler eklenmelidir:

1. CY ağırlığı doğru hesaplanıyor mu?
2. PY ağırlığı CY’den bağımsız hesaplanıyor mu?
3. IBNR kriterini karşılamayan kayıt discounted reserve almıyor mu?
4. Devreden kayıt weight paydasından çıkarılıyor mu?
5. Devreden kayıt toplam satırından çıkarılıyor mu?
6. Current Rate ve Locked-in Rate ayrı inputlarla doğru dağılıyor mu?
7. CY paydası sıfır olduğunda beklenen davranış oluşuyor mu?
8. PY paydası sıfır olduğunda beklenen davranış oluşuyor mu?
9. Negatif Undiscounted Reserve için seçilen politika uygulanıyor mu?
10. Yuvarlama sonrası detay toplamı input toplamına eşitleniyor mu?
11. `IBNR + ULAE + Case Reserve - SS Receivables` toplamı doğru mu?
12. `ruleId` eksik veya kural sonucu boş olduğunda gereksiz kayıt oluşuyor mu?
13. Güvensiz veya geçersiz `RULE_TEXT` reddediliyor mu?
14. Aynı DC/Partaj için mükerrer sonuç oluşuyor mu?
15. CY ve PY verilerinden biri eksik olduğunda diğer dönem doğru hesaplanıyor mu?

---

## 14. Açık Sorular ve Karar Gerektiren Konular

| No | Konu | Karar ihtiyacı |
|---:|---|---|
| 1 | DC/Partaj anahtarı | Kaynak tablo ve kolon nedir? |
| 2 | Devreden göstergesi | Hangi alan ve hangi değerler devredeni ifade eder? |
| 3 | Case Reserve kaynağı | Tablo, kolon ve CY/PY ayrımı nedir? |
| 4 | SS Receivables kaynağı | Tablo, kolon ve işareti nedir? |
| 5 | Undiscounted hesabı | Sistem hesaplayacak mı, kullanıcı mı yükleyecek? |
| 6 | Kural kapsamı | IBNR kriteri tüm ürünlerde aynı mı? |
| 7 | Rezerv kırılımı | Gross/RE/Net gerekli mi? |
| 8 | Toplam satırı | Veritabanına mı, yalnızca rapora mı yazılacak? |
| 9 | Sıfır payda | `0`, `null` veya hata mı üretilecek? |
| 10 | Negatif rezerv | Ağırlık hesabında nasıl ele alınacak? |
| 11 | Yuvarlama farkı | Hangi DC/Partaja düzeltme yapılacak? |
| 12 | Current/Locked input seviyesi | VTPL Corporate veya başka bir üst seviyeden mi yükleniyor? |

---

## 15. Kabul Kriterleri

Geliştirme tamamlandığında aşağıdaki koşullar sağlanmalıdır:

- Tüm devreden olmayan DC/Partajlar için CY ve PY Undiscounted Reserve üretilebilmelidir.
- Devreden kayıtlar tüm ilgili toplam ve ağırlık hesaplarından dışlanmalıdır.
- Current Rate yalnızca IBNR kriterini sağlayan DC/Partajlara dağıtılmalıdır.
- Locked-in Rate yalnızca IBNR kriterini sağlayan DC/Partajlara dağıtılmalıdır.
- Current Rate ve Locked-in Rate için CY ve PY paydaları ayrı hesaplanmalıdır.
- Dağıtım ağırlığı Undiscounted Reserve olmalıdır; mevcut amount oranlarıyla karıştırılmamalıdır.
- Detay toplamları input tutarlarıyla mutabık olmalıdır.
- Bilanço toplamı `IBNR + ULAE + Case Reserve - SS Receivables` formülüne uygun olmalıdır.
- Sıfır payda, negatif rezerv, null veri ve yuvarlama farkı için belirlenmiş davranış uygulanmalıdır.
- Yeni alanlar persistence, API/Excel ve test katmanlarında tutarlı biçimde taşınmalıdır.

---

## 16. Sonuç

İş gereksiniminin teknik karşılığı aşağıdaki sıradır:

```text
IBNR ve ULAE dağıtımlarını tamamla
→ devreden olmayan DC/Partajları belirle
→ CY/PY Undiscounted Reserve hesapla
→ IBNR kriterini sağlayan alt kümeyi seç
→ CY Undiscounted ağırlığıyla Current Rate dağıt
→ PY Undiscounted ağırlığıyla Current Rate dağıt
→ CY Undiscounted ağırlığıyla Locked-in Rate dağıt
→ PY Undiscounted ağırlığıyla Locked-in Rate dağıt
→ IBNR + ULAE + Case Reserve - SS Receivables toplamlarını üret
```

Mevcut proje yapısında en düşük riskli çözüm, rezerv hesabını mevcut `ExecuteDistributionUseCase` içine tamamen gömmek yerine ayrı bir rezerv dağıtım use case’i, ayrı bir domain sonucu ve ayrı persistence sorgu seti olarak tasarlamaktır.

İş birimi kararları tamamlanmadan tablo/kolon isimleri ve nihai SQL sorguları kesinleştirilmemelidir.

