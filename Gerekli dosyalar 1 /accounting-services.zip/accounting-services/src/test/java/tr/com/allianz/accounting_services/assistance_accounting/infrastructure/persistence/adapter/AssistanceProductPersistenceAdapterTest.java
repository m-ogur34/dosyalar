package tr.com.allianz.accounting_services.assistance_accounting.infrastructure.persistence.adapter;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import tr.com.allianz.accounting_services.assistance_accounting.domain.valueobject.AssistanceProduct;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AssistanceProductPersistenceAdapterTest {

    @Mock
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @InjectMocks
    private AssistanceProductPersistenceAdapter adapter;

    @Test
    void loadAssistanceProducts_ShouldReturnMappedProducts_WhenNoFilter() {
        // Given
        AssistanceProduct product = new AssistanceProduct(101L, "REF-101", "Test Product");
        when(namedParameterJdbcTemplate.query(anyString(), any(SqlParameterSource.class), any(RowMapper.class))).thenReturn(List.of(product));

        // When
        List<AssistanceProduct> result = adapter.loadAssistanceProducts(null);

        // Then
        assertThat(result).hasSize(1);
        assertThat(result.getFirst()).isEqualTo(product);

        verify(namedParameterJdbcTemplate).query(anyString(), any(SqlParameterSource.class), any(RowMapper.class));
    }

    @Test
    void loadAssistanceProducts_ShouldFilter_WhenAccCoverCodeProvided() {
        // Given
        String accCode = "ACC";
        AssistanceProduct product = new AssistanceProduct(101L, "REF", "Test Product");
        when(namedParameterJdbcTemplate.query(anyString(), any(SqlParameterSource.class), any(RowMapper.class))).thenReturn(List.of(product));

        // When
        List<AssistanceProduct> result = adapter.loadAssistanceProducts(accCode);

        // Then
        assertThat(result).hasSize(1);

        verify(namedParameterJdbcTemplate).query(anyString(), any(SqlParameterSource.class), any(RowMapper.class));
    }
}


