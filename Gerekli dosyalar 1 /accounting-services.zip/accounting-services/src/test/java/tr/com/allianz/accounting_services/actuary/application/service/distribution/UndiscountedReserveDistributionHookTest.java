package tr.com.allianz.accounting_services.actuary.application.service.distribution;

import org.junit.jupiter.api.Test;
import tr.com.allianz.accounting_services.actuary.application.port.out.CleanupUndiscountedReserveReportsPort;
import tr.com.allianz.accounting_services.actuary.application.port.out.SaveActuaryPeriodStatusPort;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.ActuaryPeriodStatus;

import java.time.LocalDate;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

class UndiscountedReserveDistributionHookTest {

    @Test
    void supports_ShouldOnlyMatchUndiscountedReserveProcess() {
        UndiscountedReserveDistributionHook hook = hook();

        assertThat(hook.supports("UNDISCRES")).isTrue();
        assertThat(hook.supports("IBNR")).isFalse();
        assertThat(hook.supports(null)).isFalse();
    }

    @Test
    void beforeExecute_ShouldCleanupReportsAtEndOfPeriod() {
        CleanupUndiscountedReserveReportsPort cleanupPort = mock(CleanupUndiscountedReserveReportsPort.class);
        UndiscountedReserveDistributionHook hook = new UndiscountedReserveDistributionHook(
                cleanupPort, mock(SaveActuaryPeriodStatusPort.class));
        DistributionProcessContext context = new DistributionProcessContext("UNDISCRES", 2026, 6, "tester");

        hook.beforeExecute(context);

        verify(cleanupPort).cleanup(LocalDate.of(2026, 6, 30));
    }

    @Test
    void afterExecute_ShouldMarkPeriodAsApproved() {
        SaveActuaryPeriodStatusPort savePeriodStatusPort = mock(SaveActuaryPeriodStatusPort.class);
        UndiscountedReserveDistributionHook hook = new UndiscountedReserveDistributionHook(
                mock(CleanupUndiscountedReserveReportsPort.class), savePeriodStatusPort);
        DistributionProcessContext context = new DistributionProcessContext("UNDISCRES", 2026, 6, "tester");

        hook.afterExecute(context);

        verify(savePeriodStatusPort).upsertStatus(
                "UNDISCRES", 2026, 6, ActuaryPeriodStatus.APPROVED);
    }

    private UndiscountedReserveDistributionHook hook() {
        return new UndiscountedReserveDistributionHook(
                mock(CleanupUndiscountedReserveReportsPort.class),
                mock(SaveActuaryPeriodStatusPort.class));
    }
}
