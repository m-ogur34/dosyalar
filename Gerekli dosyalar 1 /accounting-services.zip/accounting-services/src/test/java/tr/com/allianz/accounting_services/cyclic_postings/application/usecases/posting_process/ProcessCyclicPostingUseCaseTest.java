package tr.com.allianz.accounting_services.cyclic_postings.application.usecases.posting_process;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import tr.com.allianz.accounting_services.cyclic_postings.application.exception.CyclicPostingProcessNotFoundException;
import tr.com.allianz.accounting_services.cyclic_postings.application.port.out.CyclicPostingProcessPort;
import tr.com.allianz.accounting_services.cyclic_postings.domain.valueobject.ProcessStatus;
import tr.com.allianz.accounting_services.cyclic_postings.infrastructure.persistence.entity.AlzCyclicPostingProcess;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ProcessCyclicPostingUseCaseTest {

    @Mock
    private CyclicPostingProcessPort cyclicPostingProcessPort;

    private ProcessCyclicPostingUseCase useCase;

    @BeforeEach
    void setUp() {
        useCase = new ProcessCyclicPostingUseCase(cyclicPostingProcessPort);
    }

    @Test
    void shouldProcessMultipleCyclicPostingsSuccessfully() {
        // Given
        ProcessCyclicPostingUseCase.ProcessCyclicPostingCommand command1 =
            new ProcessCyclicPostingUseCase.ProcessCyclicPostingCommand(1L);
        ProcessCyclicPostingUseCase.ProcessCyclicPostingCommand command2 =
            new ProcessCyclicPostingUseCase.ProcessCyclicPostingCommand(2L);
        List<ProcessCyclicPostingUseCase.ProcessCyclicPostingCommand> commands = Arrays.asList(command1, command2);

        AlzCyclicPostingProcess process1 = createProcess(1L, "CREATED");
        AlzCyclicPostingProcess process2 = createProcess(2L, "CREATED");
        AlzCyclicPostingProcess processedProcess1 = createProcess(1L, "PROCESSED");
        AlzCyclicPostingProcess processedProcess2 = createProcess(2L, "PROCESSED");

        when(cyclicPostingProcessPort.findById(1L)).thenReturn(process1).thenReturn(processedProcess1);
        when(cyclicPostingProcessPort.findById(2L)).thenReturn(process2).thenReturn(processedProcess2);
        when(cyclicPostingProcessPort.saveAll(anyList())).thenAnswer(invocation -> invocation.getArgument(0));

        // When
        List<AlzCyclicPostingProcess> result = useCase.handle(commands);

        // Then
        assertThat(result).hasSize(2);
        verify(cyclicPostingProcessPort, times(2)).callCyclicPostingProcedure(anyLong());
        verify(cyclicPostingProcessPort).callCyclicPostingProcedure(1L);
        verify(cyclicPostingProcessPort).callCyclicPostingProcedure(2L);
        verify(cyclicPostingProcessPort).saveAll(anyList());
    }

    @Test
    void shouldHandleProcedureErrorGracefully() {
        // Given
        ProcessCyclicPostingUseCase.ProcessCyclicPostingCommand command =
            new ProcessCyclicPostingUseCase.ProcessCyclicPostingCommand(1L);
        List<ProcessCyclicPostingUseCase.ProcessCyclicPostingCommand> commands = List.of(command);

        AlzCyclicPostingProcess process = createProcess(1L, "CREATED");

        // İşlem veritabanından bulunur
        when(cyclicPostingProcessPort.findById(1L)).thenReturn(process);

        // Prosedür çağrısı hata fırlatır
        doThrow(new RuntimeException("Procedure error"))
            .when(cyclicPostingProcessPort).callCyclicPostingProcedure(1L);

        // When & Then
        // Exception fırlatılması beklenir, liste dönmez
        assertThatThrownBy(() -> useCase.handle(commands))
            .isInstanceOf(tr.com.allianz.accounting_services.cyclic_postings.application.exception.CyclicPostingProcessFailedException.class);

        // Verifications
        verify(cyclicPostingProcessPort).callCyclicPostingProcedure(1L);
        verify(cyclicPostingProcessPort).findById(1L); // Sadece ilk okuma yapılır
        verify(cyclicPostingProcessPort, never()).saveAll(anyList()); // Hata olduğu için kaydetme adımı çalışmaz
    }

    @Test
    void shouldProcessSingleCyclicPosting() {
        // Given
        Long batchId = 1L;
        AlzCyclicPostingProcess initialProcess = createProcess(batchId, "CREATED");
        AlzCyclicPostingProcess processedProcess = createProcess(batchId, "PROCESSED");

        when(cyclicPostingProcessPort.findById(batchId)).thenReturn(initialProcess).thenReturn(processedProcess);

        // When
        AlzCyclicPostingProcess result = useCase.processAccountingCyclicPosting(batchId);

        // Then
        assertThat(result).isNotNull();
        assertThat(result.getBatchId()).isEqualTo(batchId);
        assertThat(result.getProcessStatusEnum()).isEqualTo(ProcessStatus.PROCESSED);
        verify(cyclicPostingProcessPort).callCyclicPostingProcedure(batchId);
        verify(cyclicPostingProcessPort, times(2)).findById(batchId);
    }

    @Test
    void shouldHandleEmptyCommandList() {
        // Given
        List<ProcessCyclicPostingUseCase.ProcessCyclicPostingCommand> commands = Collections.emptyList();
        when(cyclicPostingProcessPort.saveAll(anyList())).thenAnswer(invocation -> invocation.getArgument(0));

        // When
        List<AlzCyclicPostingProcess> result = useCase.handle(commands);

        // Then
        assertThat(result).isEmpty();
        verify(cyclicPostingProcessPort).saveAll(Collections.emptyList());
        verify(cyclicPostingProcessPort, never()).callCyclicPostingProcedure(anyLong());
    }

    @Test
    void shouldProcessAccountingCyclicPostingWithDifferentBatchId() {
        // Given
        Long batchId = 999L;
        AlzCyclicPostingProcess initialProcess = createProcess(batchId, "CREATED");
        AlzCyclicPostingProcess processedProcess = createProcess(batchId, "PROCESSED");

        when(cyclicPostingProcessPort.findById(batchId)).thenReturn(initialProcess).thenReturn(processedProcess);
        doNothing().when(cyclicPostingProcessPort).callCyclicPostingProcedure(batchId);

        // When
        AlzCyclicPostingProcess result = useCase.processAccountingCyclicPosting(batchId);

        // Then
        assertThat(result).isNotNull();
        assertThat(result.getBatchId()).isEqualTo(batchId);
        verify(cyclicPostingProcessPort).callCyclicPostingProcedure(batchId);
    }

    @Test
    void shouldLogErrorWhenProcedureFails() {
        // Given
        Long batchId = 1L;
        AlzCyclicPostingProcess process = createProcess(batchId, "CREATED");

        // İşlem başlamadan önce kayıt bulunur
        when(cyclicPostingProcessPort.findById(batchId))
            .thenReturn(process);

        // Prosedür hata fırlatır
        doThrow(new RuntimeException("Database error"))
            .when(cyclicPostingProcessPort).callCyclicPostingProcedure(batchId);

        // When & Then
        // Artık sonuç dönmesi değil, exception fırlatılması bekleniyor
        assertThatThrownBy(() -> useCase.processAccountingCyclicPosting(batchId))
            .isInstanceOf(tr.com.allianz.accounting_services.cyclic_postings.application.exception.CyclicPostingProcessFailedException.class);

        verify(cyclicPostingProcessPort).callCyclicPostingProcedure(batchId);

        // Hata alındığı için akış durur, findById sadece ilk kontrol için 1 kez çağrılmış olur
        verify(cyclicPostingProcessPort).findById(batchId);
    }

    @Test
    void shouldProcessMixedSuccessAndFailureScenarios() {
        // Given
        ProcessCyclicPostingUseCase.ProcessCyclicPostingCommand command1 =
            new ProcessCyclicPostingUseCase.ProcessCyclicPostingCommand(1L);
        ProcessCyclicPostingUseCase.ProcessCyclicPostingCommand command2 =
            new ProcessCyclicPostingUseCase.ProcessCyclicPostingCommand(2L);
        List<ProcessCyclicPostingUseCase.ProcessCyclicPostingCommand> commands = Arrays.asList(command1, command2);

        AlzCyclicPostingProcess process1 = createProcess(1L, "CREATED");
        AlzCyclicPostingProcess process2 = createProcess(2L, "CREATED");
        AlzCyclicPostingProcess successProcess = createProcess(1L, "PROCESSED");

        when(cyclicPostingProcessPort.findById(1L)).thenReturn(process1).thenReturn(successProcess);
        when(cyclicPostingProcessPort.findById(2L)).thenReturn(process2);

        doNothing().when(cyclicPostingProcessPort).callCyclicPostingProcedure(1L);
        doThrow(new RuntimeException("Error")).when(cyclicPostingProcessPort).callCyclicPostingProcedure(2L);
        // saveAll mock'lamaya gerek yok çünkü exception fırlatılınca kod oraya ulaşmayacak

        // When & Then
        // İlk işlem başarılı olsa da ikinci işlem hata fırlattığı için tüm handle metodu fail eder
        assertThatThrownBy(() -> useCase.handle(commands))
            .isInstanceOf(tr.com.allianz.accounting_services.cyclic_postings.application.exception.CyclicPostingProcessFailedException.class);

        // Verifications
        verify(cyclicPostingProcessPort).callCyclicPostingProcedure(1L);
        verify(cyclicPostingProcessPort).callCyclicPostingProcedure(2L);

        // Akış kesildiği için kaydetme işlemi çağrılmamalıdır
        verify(cyclicPostingProcessPort, never()).saveAll(anyList());
    }

    @Test
    void shouldCreateProcessCyclicPostingCommandWithCorrectBatchId() {
        // Given & When
        ProcessCyclicPostingUseCase.ProcessCyclicPostingCommand command =
            new ProcessCyclicPostingUseCase.ProcessCyclicPostingCommand(12345L);

        // Then
        assertThat(command.batchId()).isEqualTo(12345L);
    }

 @Test
 void shouldThrowExceptionWhenProcessNotFound() {
     // Given
     Long batchId = 1L;
     when(cyclicPostingProcessPort.findById(batchId)).thenReturn(null);

     // When & Then
     assertThatThrownBy(() -> useCase.processAccountingCyclicPosting(batchId))
         .isInstanceOf(CyclicPostingProcessNotFoundException.class);

     verify(cyclicPostingProcessPort).findById(batchId);
     verify(cyclicPostingProcessPort, never()).callCyclicPostingProcedure(anyLong());
 }

    @Test
    void shouldHandleMultipleCallsToProcessAccountingCyclicPosting() {
        // Given
        Long batchId1 = 1L;
        Long batchId2 = 2L;

        AlzCyclicPostingProcess process1 = createProcess(batchId1, "CREATED");
        AlzCyclicPostingProcess process2 = createProcess(batchId2, "CREATED");
        AlzCyclicPostingProcess processedProcess1 = createProcess(batchId1, "PROCESSED");
        AlzCyclicPostingProcess processedProcess2 = createProcess(batchId2, "PROCESSED");

        when(cyclicPostingProcessPort.findById(batchId1))
            .thenReturn(process1).thenReturn(processedProcess1);
        when(cyclicPostingProcessPort.findById(batchId2))
            .thenReturn(process2).thenReturn(processedProcess2);

        // When
        AlzCyclicPostingProcess result1 = useCase.processAccountingCyclicPosting(batchId1);
        AlzCyclicPostingProcess result2 = useCase.processAccountingCyclicPosting(batchId2);

        // Then
        assertThat(result1.getBatchId()).isEqualTo(batchId1);
        assertThat(result2.getBatchId()).isEqualTo(batchId2);
        verify(cyclicPostingProcessPort).callCyclicPostingProcedure(batchId1);
        verify(cyclicPostingProcessPort).callCyclicPostingProcedure(batchId2);
    }

    @Test
    void shouldHandleAllProcessesFailingInHandleMethod() {
        // Given
        ProcessCyclicPostingUseCase.ProcessCyclicPostingCommand command1 =
            new ProcessCyclicPostingUseCase.ProcessCyclicPostingCommand(1L);
        ProcessCyclicPostingUseCase.ProcessCyclicPostingCommand command2 =
            new ProcessCyclicPostingUseCase.ProcessCyclicPostingCommand(2L);
        List<ProcessCyclicPostingUseCase.ProcessCyclicPostingCommand> commands = Arrays.asList(command1, command2);

        AlzCyclicPostingProcess process1 = createProcess(1L, "CREATED");

        // İlk işlem çağrıldığında process bulunur
        when(cyclicPostingProcessPort.findById(1L)).thenReturn(process1);

        // İlk işlem prosedürde hata fırlatır
        doThrow(new RuntimeException("Error 1")).when(cyclicPostingProcessPort).callCyclicPostingProcedure(1L);

        // When & Then
        // İlk hatada exception fırlatılır, diğer işlemlere geçilmez
        assertThatThrownBy(() -> useCase.handle(commands))
            .isInstanceOf(tr.com.allianz.accounting_services.cyclic_postings.application.exception.CyclicPostingProcessFailedException.class);

        // Verifications
        verify(cyclicPostingProcessPort).callCyclicPostingProcedure(1L);
        // İlk işlemde hata alındığı için 2. işleme hiç geçilmez
        verify(cyclicPostingProcessPort, never()).callCyclicPostingProcedure(2L);
        // Kaydetme işlemi yapılmaz
        verify(cyclicPostingProcessPort, never()).saveAll(anyList());
    }

    @Test
    void shouldVerifyProcessStatusAfterSuccessfulProcessing() {
        // Given
        ProcessCyclicPostingUseCase.ProcessCyclicPostingCommand command =
            new ProcessCyclicPostingUseCase.ProcessCyclicPostingCommand(1L);
        List<ProcessCyclicPostingUseCase.ProcessCyclicPostingCommand> commands = List.of(command);

        AlzCyclicPostingProcess initialProcess = createProcess(1L, "CREATED");
        AlzCyclicPostingProcess processedProcess = createProcess(1L, "PROCESSED");

        when(cyclicPostingProcessPort.findById(1L)).thenReturn(initialProcess).thenReturn(processedProcess);
        when(cyclicPostingProcessPort.saveAll(anyList())).thenAnswer(invocation -> invocation.getArgument(0));

        // When
        List<AlzCyclicPostingProcess> result = useCase.handle(commands);

        // Then
        assertThat(result).hasSize(1);
        assertThat(result.getFirst().getProcessStatusEnum()).isEqualTo(ProcessStatus.PROCESSED);
        verify(cyclicPostingProcessPort).callCyclicPostingProcedure(1L);
    }

    @Test
    void shouldHandleLargeNumberOfCommands() {
        // Given
        List<ProcessCyclicPostingUseCase.ProcessCyclicPostingCommand> commands =
            Arrays.asList(
                new ProcessCyclicPostingUseCase.ProcessCyclicPostingCommand(1L),
                new ProcessCyclicPostingUseCase.ProcessCyclicPostingCommand(2L),
                new ProcessCyclicPostingUseCase.ProcessCyclicPostingCommand(3L),
                new ProcessCyclicPostingUseCase.ProcessCyclicPostingCommand(4L),
                new ProcessCyclicPostingUseCase.ProcessCyclicPostingCommand(5L)
            );

        for (long i = 1; i <= 5; i++) {
            AlzCyclicPostingProcess process = createProcess(i, "CREATED");
            AlzCyclicPostingProcess processedProcess = createProcess(i, "PROCESSED");
            when(cyclicPostingProcessPort.findById(i)).thenReturn(process).thenReturn(processedProcess);
        }
        when(cyclicPostingProcessPort.saveAll(anyList())).thenAnswer(invocation -> invocation.getArgument(0));

        // When
        List<AlzCyclicPostingProcess> result = useCase.handle(commands);

        // Then
        assertThat(result).hasSize(5);
        verify(cyclicPostingProcessPort, times(5)).callCyclicPostingProcedure(anyLong());
    }

    private AlzCyclicPostingProcess createProcess(Long batchId, String status) {
        AlzCyclicPostingProcess process = new AlzCyclicPostingProcess();
        process.setBatchId(batchId);
        process.setProcessStatusEnum(ProcessStatus.valueOf(status));
        process.setPostingDate(LocalDate.now());
        process.setCreatedDate(LocalDateTime.now());
        process.setUpdatedDate(LocalDateTime.now());
        return process;
    }
}