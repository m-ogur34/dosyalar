package tr.com.allianz.accounting_services.actuary.application.usecases;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import tr.com.allianz.accounting_services.actuary.application.port.out.SaveActuaryProcessAmountPort;
import tr.com.allianz.accounting_services.actuary.application.service.ActuaryLogService;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.ActuaryProcessAmount;

import java.math.BigDecimal;

import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class SaveActuaryProcessAmountUseCaseTest {

    @Mock
    private SaveActuaryProcessAmountPort saveActuaryProcessAmountPort;

    @Mock
    private ActuaryLogService actuaryLogService;

    @Test
    void handle_ShouldCallSavePortAndWriteAmountUpdateLog() {
        ActuaryProcessAmount amount = new ActuaryProcessAmount(
                2024,
                6,
                "P1001",
                100,
                new BigDecimal("1000"),
                new BigDecimal("100"),
                new BigDecimal("900"),
                new BigDecimal("950"),
                new BigDecimal("95"),
                new BigDecimal("855"),
                new BigDecimal("1100"),
                new BigDecimal("110"),
                new BigDecimal("990"),
                new BigDecimal("1050"),
                new BigDecimal("105"),
                new BigDecimal("945"),
                new BigDecimal("1.0000"),
                new BigDecimal("0.1000"),
                new BigDecimal("0.9000"),
                new BigDecimal("0.9500"),
                new BigDecimal("0.0950"),
                new BigDecimal("0.8550"),
                new BigDecimal("1.1000"),
                new BigDecimal("0.1100"),
                new BigDecimal("0.9900"),
                new BigDecimal("1.0500"),
                new BigDecimal("0.1050"),
                new BigDecimal("0.9450")
        );

        SaveActuaryProcessAmountUseCase useCase = new SaveActuaryProcessAmountUseCase(
                saveActuaryProcessAmountPort,
                actuaryLogService
        );
        useCase.handle(amount, "tester");

        verify(saveActuaryProcessAmountPort).save(amount);
        verify(actuaryLogService).logAmountUpdate(
                "P1001",
                2024,
                6,
                100,
                "Amount updated for rule ID: 100",
                "tester"
        );
    }

    @Test
    void handle_WithoutUser_ShouldUseSystemUser() {
        ActuaryProcessAmount amount = new ActuaryProcessAmount(
                2024,
                6,
                "P1001",
                101,
                BigDecimal.ONE,
                BigDecimal.ZERO,
                BigDecimal.ONE,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null
        );

        SaveActuaryProcessAmountUseCase useCase = new SaveActuaryProcessAmountUseCase(
                saveActuaryProcessAmountPort,
                actuaryLogService
        );

        useCase.handle(amount);

        verify(saveActuaryProcessAmountPort).save(amount);
        verify(actuaryLogService).logAmountUpdate(
                "P1001",
                2024,
                6,
                101,
                "Amount updated for rule ID: 101",
                "SYSTEM"
        );
    }
}

