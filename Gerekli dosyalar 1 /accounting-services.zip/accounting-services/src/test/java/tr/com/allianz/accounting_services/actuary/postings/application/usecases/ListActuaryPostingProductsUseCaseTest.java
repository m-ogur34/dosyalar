package tr.com.allianz.accounting_services.actuary.postings.application.usecases;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import tr.com.allianz.accounting_services.actuary.postings.application.port.out.LoadActuaryPostingProductsPort;
import tr.com.allianz.accounting_services.actuary.postings.domain.model.ActuaryPostingProduct;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ListActuaryPostingProductsUseCaseTest {

    @Mock
    private LoadActuaryPostingProductsPort loadActuaryPostingProductsPort;

    @Test
    void handle_ShouldReturnProductsFromPort() {
        List<ActuaryPostingProduct> expected = List.of(
                new ActuaryPostingProduct(10L, "1001", "Kasko")
        );
        when(loadActuaryPostingProductsPort.loadByBranchId("34")).thenReturn(expected);

        ListActuaryPostingProductsUseCase useCase =
                new ListActuaryPostingProductsUseCase(loadActuaryPostingProductsPort);

        List<ActuaryPostingProduct> result = useCase.handle("34");

        assertThat(result).isEqualTo(expected);
        verify(loadActuaryPostingProductsPort).loadByBranchId("34");
    }
}

