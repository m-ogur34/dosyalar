package tr.com.allianz.accounting_services.cyclic_postings.application.usecases.posting_process;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import tr.com.allianz.accounting_services.cyclic_postings.application.exception.CyclicPostingProcessAlreadyExistsException;
import tr.com.allianz.accounting_services.cyclic_postings.application.exception.CyclicPostingProcessNotFoundException;
import tr.com.allianz.accounting_services.cyclic_postings.application.port.out.CyclicPostingCheckPort;
import tr.com.allianz.accounting_services.cyclic_postings.application.port.out.CyclicPostingProcessPort;
import tr.com.allianz.accounting_services.cyclic_postings.domain.valueobject.ProcessStatus;
import tr.com.allianz.accounting_services.cyclic_postings.infrastructure.persistence.entity.AlzCyclicPostingProcess;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CreateCyclicPostingUseCaseTest {

    @Mock
    private CyclicPostingProcessPort cyclicPostingProcessPort;

    @Mock
    private CyclicPostingCheckPort cyclicPostingCheckPort;

    private CreateCyclicPostingUseCase useCase;

    @BeforeEach
    void setUp() {
        useCase = new CreateCyclicPostingUseCase(cyclicPostingProcessPort, cyclicPostingCheckPort);
    }

    @Test
    void shouldCreateCyclicPostingProcessSuccessfully() {
        // Given
        Long batchId = 12345L;
        LocalDate postingDate = LocalDate.of(2024, 1, 15);

        CreateCyclicPostingUseCase.CreateCyclicPostingCommand command =
            new CreateCyclicPostingUseCase.CreateCyclicPostingCommand(batchId, postingDate);

        when(cyclicPostingProcessPort.findById(batchId)).thenReturn(null);
        when(cyclicPostingCheckPort.findBatchCount(batchId)).thenReturn(1);
        when(cyclicPostingCheckPort.findNotMappedCyclicAccountNo(batchId)).thenReturn(null);
        when(cyclicPostingProcessPort.saveAll(anyList())).thenAnswer(invocation -> invocation.getArgument(0));

        // When
        List<AlzCyclicPostingProcess> result = useCase.handle(List.of(command));

        // Then
        assertThat(result).hasSize(1);
        AlzCyclicPostingProcess process = result.getFirst();
        assertThat(process.getBatchId()).isEqualTo(batchId);
        assertThat(process.getPostingDate()).isEqualTo(postingDate);
        assertThat(process.getCyclicBatchId()).isNull();
        assertThat(process.getProcessStatusEnum()).isEqualTo(ProcessStatus.CREATED);
        assertThat(process.getCreatedDate()).isNotNull();
        assertThat(process.getUpdatedDate()).isNotNull();
        assertThat(process.getErrText()).isNull();

        verify(cyclicPostingProcessPort).findById(batchId);
        verify(cyclicPostingCheckPort).findBatchCount(batchId);
        verify(cyclicPostingCheckPort).findNotMappedCyclicAccountNo(batchId);
        verify(cyclicPostingProcessPort).saveAll(anyList());
    }

    @Test
    void shouldThrowExceptionWhenProcessAlreadyExists() {
        // Given
        Long batchId = 12345L;
        LocalDate postingDate = LocalDate.of(2024, 1, 15);

        CreateCyclicPostingUseCase.CreateCyclicPostingCommand command =
            new CreateCyclicPostingUseCase.CreateCyclicPostingCommand(batchId, postingDate);

        AlzCyclicPostingProcess existingProcess = new AlzCyclicPostingProcess();
        when(cyclicPostingProcessPort.findById(batchId)).thenReturn(existingProcess);

        // When & Then
        assertThatThrownBy(() -> useCase.handle(List.of(command)))
            .isInstanceOf(CyclicPostingProcessAlreadyExistsException.class)
            .hasFieldOrPropertyWithValue("batchId", batchId);

        verify(cyclicPostingProcessPort).findById(batchId);
        verify(cyclicPostingCheckPort, never()).findBatchCount(anyLong());
        verify(cyclicPostingProcessPort, never()).saveAll(anyList());
    }

    @Test
    void shouldThrowExceptionWhenPostingNotFound() {
        // Given
        Long batchId = 12345L;
        LocalDate postingDate = LocalDate.of(2024, 1, 15);

        CreateCyclicPostingUseCase.CreateCyclicPostingCommand command =
            new CreateCyclicPostingUseCase.CreateCyclicPostingCommand(batchId, postingDate);

        when(cyclicPostingProcessPort.findById(batchId)).thenReturn(null);
        when(cyclicPostingCheckPort.findBatchCount(batchId)).thenReturn(0);

        // When & Then
        assertThatThrownBy(() -> useCase.handle(List.of(command)))
            .isInstanceOf(CyclicPostingProcessNotFoundException.class)
            .hasFieldOrPropertyWithValue("batchId", batchId);

        verify(cyclicPostingProcessPort).findById(batchId);
        verify(cyclicPostingCheckPort).findBatchCount(batchId);
        verify(cyclicPostingCheckPort, never()).findNotMappedCyclicAccountNo(anyLong());
        verify(cyclicPostingProcessPort, never()).saveAll(anyList());
    }

    @Test
    void shouldSetErrorStatusWhenUnmappedAccountsExist() {
        // Given
        Long batchId = 12345L;
        LocalDate postingDate = LocalDate.of(2024, 1, 15);
        String unmappedAccounts = "6001, 7002";

        CreateCyclicPostingUseCase.CreateCyclicPostingCommand command =
            new CreateCyclicPostingUseCase.CreateCyclicPostingCommand(batchId, postingDate);

        when(cyclicPostingProcessPort.findById(batchId)).thenReturn(null);
        when(cyclicPostingCheckPort.findBatchCount(batchId)).thenReturn(1);
        when(cyclicPostingCheckPort.findNotMappedCyclicAccountNo(batchId)).thenReturn(unmappedAccounts);
        when(cyclicPostingProcessPort.saveAll(anyList())).thenAnswer(invocation -> invocation.getArgument(0));

        // When
        List<AlzCyclicPostingProcess> result = useCase.handle(List.of(command));

        // Then
        assertThat(result).hasSize(1);
        AlzCyclicPostingProcess process = result.getFirst();
        assertThat(process.getProcessStatusEnum()).isEqualTo(ProcessStatus.ERROR_OCCURRED);
        assertThat(process.getErrText()).contains("Bazı devir hesapları eşleştirilmemiş");
        assertThat(process.getErrText()).contains(unmappedAccounts);

        verify(cyclicPostingCheckPort).findNotMappedCyclicAccountNo(batchId);
    }

    @Test
    void shouldHandleEmptyUnmappedAccounts() {
        // Given
        Long batchId = 12345L;
        LocalDate postingDate = LocalDate.of(2024, 1, 15);

        CreateCyclicPostingUseCase.CreateCyclicPostingCommand command =
            new CreateCyclicPostingUseCase.CreateCyclicPostingCommand(batchId, postingDate);

        when(cyclicPostingProcessPort.findById(batchId)).thenReturn(null);
        when(cyclicPostingCheckPort.findBatchCount(batchId)).thenReturn(1);
        when(cyclicPostingCheckPort.findNotMappedCyclicAccountNo(batchId)).thenReturn("");
        when(cyclicPostingProcessPort.saveAll(anyList())).thenAnswer(invocation -> invocation.getArgument(0));

        // When
        List<AlzCyclicPostingProcess> result = useCase.handle(List.of(command));

        // Then
        assertThat(result).hasSize(1);
        AlzCyclicPostingProcess process = result.getFirst();
        assertThat(process.getProcessStatusEnum()).isEqualTo(ProcessStatus.CREATED);
        assertThat(process.getErrText()).isNull();
    }

    @Test
    void shouldHandleMultipleCommands() {
        // Given
        CreateCyclicPostingUseCase.CreateCyclicPostingCommand command1 =
            new CreateCyclicPostingUseCase.CreateCyclicPostingCommand(1L, LocalDate.now());
        CreateCyclicPostingUseCase.CreateCyclicPostingCommand command2 =
            new CreateCyclicPostingUseCase.CreateCyclicPostingCommand(2L, LocalDate.now());

        when(cyclicPostingProcessPort.findById(anyLong())).thenReturn(null);
        when(cyclicPostingCheckPort.findBatchCount(anyLong())).thenReturn(1);
        when(cyclicPostingCheckPort.findNotMappedCyclicAccountNo(anyLong())).thenReturn(null);
        when(cyclicPostingProcessPort.saveAll(anyList())).thenAnswer(invocation -> invocation.getArgument(0));

        // When
        List<AlzCyclicPostingProcess> result = useCase.handle(Arrays.asList(command1, command2));

        // Then
        assertThat(result).hasSize(2);
        verify(cyclicPostingProcessPort, times(2)).findById(anyLong());
        verify(cyclicPostingCheckPort, times(2)).findBatchCount(anyLong());
        verify(cyclicPostingCheckPort, times(2)).findNotMappedCyclicAccountNo(anyLong());
        verify(cyclicPostingProcessPort).saveAll(anyList());
    }
}