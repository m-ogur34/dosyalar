package tr.com.allianz.accounting_services.actuary.postings.infrastructure.persistence.adapter;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import tr.com.allianz.accounting_services.actuary.postings.domain.model.ActuaryPostingProduct;

import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ActuaryPostingProductPersistenceAdapterTest {

    @Mock
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @Test
    void loadByBranchId_ShouldBindBranchIdAndMapRows() {
        when(namedParameterJdbcTemplate.queryForList(anyString(), any(MapSqlParameterSource.class)))
                .thenReturn(List.of(
                        Map.of("product_id", 101L, "ext_reference", " 1001 ", "long_name", " Kasko "),
                        Map.of("product_id", 202, "ext_reference", "", "long_name", " Trafik ")
                ));

        ActuaryPostingProductPersistenceAdapter adapter =
                new ActuaryPostingProductPersistenceAdapter(namedParameterJdbcTemplate);

        List<ActuaryPostingProduct> result = adapter.loadByBranchId("34");

        assertThat(result).hasSize(2);
        assertThat(result.getFirst().getProductId()).isEqualTo(101L);
        assertThat(result.getFirst().getExtReference()).isEqualTo("1001");
        assertThat(result.getFirst().getLongName()).isEqualTo("Kasko");

        assertThat(result.get(1).getProductId()).isEqualTo(202L);
        assertThat(result.get(1).getExtReference()).isEqualTo("");
        assertThat(result.get(1).getLongName()).isEqualTo("Trafik");

        ArgumentCaptor<MapSqlParameterSource> captor = ArgumentCaptor.forClass(MapSqlParameterSource.class);
        verify(namedParameterJdbcTemplate).queryForList(anyString(), captor.capture());
        assertThat(captor.getValue().getValue("branch_id")).isEqualTo("34");
    }

    @Test
    void loadByBranchId_ShouldReturnEmptyList_WhenNoRowExists() {
        when(namedParameterJdbcTemplate.queryForList(anyString(), any(MapSqlParameterSource.class)))
                .thenReturn(List.of());

        ActuaryPostingProductPersistenceAdapter adapter =
                new ActuaryPostingProductPersistenceAdapter(namedParameterJdbcTemplate);

        List<ActuaryPostingProduct> result = adapter.loadByBranchId("06");

        assertThat(result).isEmpty();
    }
}

