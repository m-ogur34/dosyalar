package tr.com.allianz.accounting_services.actuary.infrastructure.persistence.entity;

import org.junit.jupiter.api.Test;

import java.lang.reflect.Method;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatCode;

class AlzActProcessRulesTest {

    @Test
    void setProcessId_ShouldInitializeEmbeddedIdAndKeepFieldsInSync() {
        AlzActProcessRules entity = new AlzActProcessRules();

        entity.setProcessId("P1001");

        assertThat(entity.getProcessId()).isEqualTo("P1001");
        assertThat(entity.getId()).isNotNull();
        assertThat(entity.getId().getProcessId()).isEqualTo("P1001");
    }

    @Test
    void setRuleId_ShouldInitializeEmbeddedIdAndKeepFieldsInSync() {
        AlzActProcessRules entity = new AlzActProcessRules();

        entity.setRuleId(123);

        assertThat(entity.getRuleId()).isEqualTo(123);
        assertThat(entity.getId()).isNotNull();
        assertThat(entity.getId().getRuleId()).isEqualTo(123);
    }

    @Test
    void syncIdFields_ShouldCopyValuesFromEmbeddedId() throws Exception {
        AlzActProcessRules entity = new AlzActProcessRules();
        entity.setId(new AlzActProcessRulesId("P2002", 77));

        Method syncMethod = AlzActProcessRules.class.getDeclaredMethod("syncIdFields");
        syncMethod.setAccessible(true);
        syncMethod.invoke(entity);

        assertThat(entity.getProcessId()).isEqualTo("P2002");
        assertThat(entity.getRuleId()).isEqualTo(77);
    }

    @Test
    void syncIdFields_ShouldDoNothingWhenIdIsNull() throws Exception {
        AlzActProcessRules entity = new AlzActProcessRules();

        Method syncMethod = AlzActProcessRules.class.getDeclaredMethod("syncIdFields");
        syncMethod.setAccessible(true);

        assertThatCode(() -> syncMethod.invoke(entity)).doesNotThrowAnyException();
        assertThat(entity.getProcessId()).isNull();
        assertThat(entity.getRuleId()).isNull();
    }
}

