package tr.com.allianz.accounting_services.cyclic_postings.application.usecases.posting_process;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import tr.com.allianz.accounting_services.cyclic_postings.application.port.out.CyclicPostingProcessPort;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ListCyclicPostingProcessUseCaseTest {

    @Mock
    private CyclicPostingProcessPort cyclicPostingProcessPort;

    private ListCyclicPostingProcessUseCase useCase;

    private final Pageable pageable = PageRequest.of(0, 10);

    private final Long batchId = null;
    private final Long cyclicBatchId = null;
    private final String status = null;

    @BeforeEach
    void setUp() {
        useCase = new ListCyclicPostingProcessUseCase(cyclicPostingProcessPort);
    }

    @Test
    void shouldReturnAllCyclicPostingProcesses() {
        // Given
        AlzCyclicPostingProcessReadModel process1 = createReadModel(1L, "CREATED");
        AlzCyclicPostingProcessReadModel process2 = createReadModel(2L, "PROCESSED");

        List<AlzCyclicPostingProcessReadModel> expectedProcesses = Arrays.asList(process1, process2);
        when(cyclicPostingProcessPort.listAllCyclicPostingProcesses(pageable, batchId, cyclicBatchId, status)).thenReturn(expectedProcesses);

        // When
        List<AlzCyclicPostingProcessReadModel> result = useCase.handle(pageable, batchId, cyclicBatchId, status);

        // Then
        assertThat(result).hasSize(2);
        assertThat(result).containsExactlyInAnyOrder(process1, process2);
        verify(cyclicPostingProcessPort).listAllCyclicPostingProcesses(pageable, batchId, cyclicBatchId, status);
    }

    @Test
    void shouldReturnEmptyListWhenNoProcessesExist() {

        // Given
        when(cyclicPostingProcessPort.listAllCyclicPostingProcesses(pageable, batchId, cyclicBatchId, status)).thenReturn(Collections.emptyList());

        // When
        List<AlzCyclicPostingProcessReadModel> result = useCase.handle(pageable, batchId, cyclicBatchId, status);

        // Then
        assertThat(result).isEmpty();
        verify(cyclicPostingProcessPort).listAllCyclicPostingProcesses(pageable, batchId, cyclicBatchId, status);
    }

    @Test
    void shouldCallPortExactlyOnce() {
        // Given
        when(cyclicPostingProcessPort.listAllCyclicPostingProcesses(pageable, batchId, cyclicBatchId, status)).thenReturn(Collections.emptyList());

        // When
        useCase.handle(pageable, batchId, cyclicBatchId, status);

        // Then
        verify(cyclicPostingProcessPort, times(1)).listAllCyclicPostingProcesses(pageable, batchId, cyclicBatchId, status);
    }

    private AlzCyclicPostingProcessReadModel createReadModel(Long batchId, String status) {
        return new AlzCyclicPostingProcessReadModel(
                batchId, LocalDate.now(),null,status,null,LocalDateTime.now(),LocalDateTime.now()
        );
    }
}