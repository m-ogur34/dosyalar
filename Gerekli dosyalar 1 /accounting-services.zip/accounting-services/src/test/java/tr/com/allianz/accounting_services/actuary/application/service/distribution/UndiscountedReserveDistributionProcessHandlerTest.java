package tr.com.allianz.accounting_services.actuary.application.service.distribution;

import org.junit.jupiter.api.Test;
import tr.com.allianz.accounting_services.actuary.application.port.out.CreateUndiscountedReserveDataPort;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

class UndiscountedReserveDistributionProcessHandlerTest {

    @Test
    void supports_ShouldOnlyMatchUndiscountedReserveProcess() {
        UndiscountedReserveDistributionProcessHandler handler =
                new UndiscountedReserveDistributionProcessHandler(mock(CreateUndiscountedReserveDataPort.class));

        assertThat(handler.supports("UNDISCRES")).isTrue();
        assertThat(handler.supports("IBNR")).isFalse();
        assertThat(handler.supports(null)).isFalse();
    }

    @Test
    void execute_ShouldCreateUndiscountedReserveDataWithYearAndMonth() {
        CreateUndiscountedReserveDataPort port = mock(CreateUndiscountedReserveDataPort.class);
        UndiscountedReserveDistributionProcessHandler handler =
                new UndiscountedReserveDistributionProcessHandler(port);

        handler.execute("UNDISCRES", 2026, 6);

        verify(port).create(2026, 6);
    }
}
