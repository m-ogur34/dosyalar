package tr.com.allianz.accounting_services.cyclic_postings.infrastructure.config;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import tr.com.allianz.accounting_services.cyclic_postings.application.port.out.CyclicPostingMappingPort;
import tr.com.allianz.accounting_services.cyclic_postings.application.usecases.CreateCyclicMappingUseCase;
import tr.com.allianz.accounting_services.cyclic_postings.application.usecases.ListAlzCyclicAccountMappingUseCase;

@ExtendWith(MockitoExtension.class)
class CyclicAccountMappingConfigTest {


    @Mock
    CyclicPostingMappingPort cyclicPostingMappingPort;

    private final CyclicAccountMappingConfig config = new CyclicAccountMappingConfig();

    @Test
    void createAlzCyclicAccountMappingUseCase() {
        CreateCyclicMappingUseCase bean = config.createCyclicMappingUseCase(cyclicPostingMappingPort);
        Assertions.assertNotNull(bean);
    }

    @Test
    void listAlzCyclicAccountMappingUseCase() {
        ListAlzCyclicAccountMappingUseCase bean = config.listAlzCyclingAccountMappingUseCase(cyclicPostingMappingPort);
        Assertions.assertNotNull(bean);
    }

    @Test
    void removeAlzCyclicAccountMappingUseCase() {
        var bean = config.removeAlzCyclicAccountMappingUseCase(cyclicPostingMappingPort);
        Assertions.assertNotNull(bean);
    }

}