package tr.com.allianz.accounting_services.actuary.application.service.distribution;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class UlaeDistributionProcessHandlerTest {

    @Test
    void supports_ShouldOnlyMatchUlae() {
        UlaeDistributionProcessHandler handler = new UlaeDistributionProcessHandler();

        assertThat(handler.supports("ULAE")).isTrue();
        assertThat(handler.supports("IBNR")).isFalse();
        assertThat(handler.supports(null)).isFalse();
    }

    @Test
    void execute_ShouldDoNothing() {
        UlaeDistributionProcessHandler handler = new UlaeDistributionProcessHandler();

        handler.execute("ULAE", 2026, 6);
    }
}

