package tr.com.allianz.accounting_services.assistance_accounting.application.usecases;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import tr.com.allianz.accounting_services.assistance_accounting.application.port.out.AssistancePartitionLoaderPort;
import tr.com.allianz.accounting_services.assistance_accounting.domain.valueobject.AssistancePartition;

import java.util.Collections;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ListAssistancePartitionUseCaseTest {

    @Mock
    private AssistancePartitionLoaderPort assistancePartitionLoaderPort;

    @InjectMocks
    private ListAssistancePartitionUseCase listAssistancePartitionUseCase;

    @Test
    void handle_ShouldReturnListFromPort() {
        // Given
        List<Long> productIds = List.of(100L);
        AssistancePartition partition = new AssistancePartition("TypeA", "Desc");
        List<AssistancePartition> expectedList = List.of(partition);
        when(assistancePartitionLoaderPort.loadAssistancePartitions(productIds)).thenReturn(expectedList);

        // When
        List<AssistancePartition> result = listAssistancePartitionUseCase.handle(productIds);

        // Then
        assertThat(result).hasSize(1);
        assertThat(result).isEqualTo(expectedList);
        verify(assistancePartitionLoaderPort).loadAssistancePartitions(productIds);
    }

    @Test
    void handle_ShouldReturnEmptyList_WhenPortReturnsEmpty() {
        // Given
        List<Long> productIds = List.of(100L);
        when(assistancePartitionLoaderPort.loadAssistancePartitions(productIds)).thenReturn(Collections.emptyList());

        // When
        List<AssistancePartition> result = listAssistancePartitionUseCase.handle(productIds);

        // Then
        assertThat(result).isEmpty();
        verify(assistancePartitionLoaderPort).loadAssistancePartitions(productIds);
    }
}

