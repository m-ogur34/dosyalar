package tr.com.allianz.accounting_services.actuary.postings.infrastructure.persistence.adapter;

import org.junit.jupiter.api.Test;
import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import tr.com.allianz.accounting_services.actuary.postings.application.usecases.GetActuaryPostingBatchInfoCommand;
import tr.com.allianz.accounting_services.actuary.postings.domain.model.ActuaryPostingBatchInfoLine;
import tr.com.allianz.accounting_services.actuary.postings.application.exception.ActuaryPostingBatchInfoFailedException;

import java.math.BigDecimal;
import java.sql.Date;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class ActuaryPostingBatchInfoPersistenceAdapterTest {

    @Test
    void loadBatchInfo_ShouldMapRefCursorRows() {
        SimpleJdbcCall simpleJdbcCall = mock(SimpleJdbcCall.class, org.mockito.Mockito.RETURNS_SELF);
        when(simpleJdbcCall.execute(any(org.springframework.jdbc.core.namedparam.MapSqlParameterSource.class)))
                .thenReturn(Map.of(
                        "v_refcur",
                        List.of(
                                new ActuaryPostingBatchInfoLine("100", "Cash", "Explanation 1", BigDecimal.TEN, BigDecimal.ZERO),
                                new ActuaryPostingBatchInfoLine("200", "Revenue", "Explanation 2", BigDecimal.ZERO, new BigDecimal("25"))
                        )
                ));

        ActuaryPostingBatchInfoPersistenceAdapter adapter = new ActuaryPostingBatchInfoPersistenceAdapter(mock(JdbcTemplate.class)) {
            @Override
            protected SimpleJdbcCall createSimpleJdbcCall() {
                return simpleJdbcCall;
            }
        };

        List<ActuaryPostingBatchInfoLine> result = adapter.loadBatchInfo(new GetActuaryPostingBatchInfoCommand(
                10L,
                LocalDate.of(2026, 7, 15),
                "3401",
                60L,
                "PARTITION",
                1
        ));

        assertThat(result).hasSize(2);
        assertThat(result.getFirst().getAccountNo()).isEqualTo("100");
        assertThat(result.getFirst().getAccountExp()).isEqualTo("Cash");
        assertThat(result.getFirst().getExplanation()).isEqualTo("Explanation 1");
        assertThat(result.getFirst().getBorc()).isEqualByComparingTo("10");
        assertThat(result.getFirst().getAlacak()).isEqualByComparingTo("0");
    }

    @Test
    void loadBatchInfo_ShouldReturnEmptyList_WhenCursorIsNull() {
        SimpleJdbcCall simpleJdbcCall = mock(SimpleJdbcCall.class, org.mockito.Mockito.RETURNS_SELF);
        Map<String, Object> out = new java.util.HashMap<>();
        out.put("v_refcur", null);
        when(simpleJdbcCall.execute(any(org.springframework.jdbc.core.namedparam.MapSqlParameterSource.class)))
                .thenReturn(out);

        ActuaryPostingBatchInfoPersistenceAdapter adapter = new ActuaryPostingBatchInfoPersistenceAdapter(mock(JdbcTemplate.class)) {
            @Override
            protected SimpleJdbcCall createSimpleJdbcCall() {
                return simpleJdbcCall;
            }
        };

        List<ActuaryPostingBatchInfoLine> result = adapter.loadBatchInfo(new GetActuaryPostingBatchInfoCommand(
                10L,
                LocalDate.of(2026, 7, 15),
                "3401",
                60L,
                "PARTITION",
                1
        ));

        assertThat(result).isEmpty();
    }

    @Test
    void loadBatchInfo_ShouldConvertPostingDateToMonthEnd() {
        org.springframework.jdbc.core.namedparam.MapSqlParameterSource[] captured = new org.springframework.jdbc.core.namedparam.MapSqlParameterSource[1];
        SimpleJdbcCall simpleJdbcCall = mock(SimpleJdbcCall.class, org.mockito.Mockito.RETURNS_SELF);
        when(simpleJdbcCall.execute(any(org.springframework.jdbc.core.namedparam.MapSqlParameterSource.class)))
                .thenAnswer(invocation -> {
                    captured[0] = invocation.getArgument(0);
                    return Map.of("v_refcur", List.of());
                });

        ActuaryPostingBatchInfoPersistenceAdapter adapter = new ActuaryPostingBatchInfoPersistenceAdapter(mock(JdbcTemplate.class)) {
            @Override
            protected SimpleJdbcCall createSimpleJdbcCall() {
                return simpleJdbcCall;
            }
        };

        adapter.loadBatchInfo(new GetActuaryPostingBatchInfoCommand(
                10L,
                LocalDate.of(2026, 2, 10),
                "3401",
                60L,
                "PARTITION",
                1
        ));

        assertThat(captured[0]).isNotNull();
        assertThat(captured[0].getValue("p_date")).isEqualTo(Date.valueOf(LocalDate.of(2026, 2, 28)));
    }

    @Test
    void loadBatchInfo_ShouldWrapDataAccessException() {
        SimpleJdbcCall simpleJdbcCall = mock(SimpleJdbcCall.class, org.mockito.Mockito.RETURNS_SELF);
        when(simpleJdbcCall.execute(any(org.springframework.jdbc.core.namedparam.MapSqlParameterSource.class)))
                .thenThrow(new DataAccessResourceFailureException("db failed", new RuntimeException("ORA-12345")));

        ActuaryPostingBatchInfoPersistenceAdapter adapter = new ActuaryPostingBatchInfoPersistenceAdapter(mock(JdbcTemplate.class)) {
            @Override
            protected SimpleJdbcCall createSimpleJdbcCall() {
                return simpleJdbcCall;
            }
        };

        assertThatThrownBy(() -> adapter.loadBatchInfo(new GetActuaryPostingBatchInfoCommand(
                10L,
                LocalDate.of(2026, 7, 15),
                "3401",
                60L,
                "PARTITION",
                1
        )))
                .isInstanceOf(ActuaryPostingBatchInfoFailedException.class)
                .satisfies(ex -> assertThat(((ActuaryPostingBatchInfoFailedException) ex).getDetail())
                        .contains("ORA-12345"));
    }
}

