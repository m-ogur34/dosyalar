package tr.com.allianz.accounting_services.assistance_accounting.interfaces.web;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import tr.com.allianz.accounting_services.assistance_accounting.application.usecases.ListAssistancePartitionUseCase;
import tr.com.allianz.accounting_services.assistance_accounting.domain.valueobject.AssistancePartition;

import java.util.Collections;
import java.util.List;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)
class AssistancePartitionControllerTest {

    private MockMvc mockMvc;

    @Mock
    private ListAssistancePartitionUseCase listAssistancePartitionUseCase;

    @BeforeEach
    void setUp() {
        AssistancePartitionController controller = new AssistancePartitionController(listAssistancePartitionUseCase);
        mockMvc = MockMvcBuilders.standaloneSetup(controller).build();
    }

    @Test
    void listAssistancePartitions_ShouldReturnListOfPartitions() throws Exception {
        AssistancePartition partition = new AssistancePartition("TypeA", "Desc");
        List<Long> productIds = List.of(100L);
        when(listAssistancePartitionUseCase.handle(productIds)).thenReturn(List.of(partition));

        mockMvc.perform(post("/api/v1/assistance-partition")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("[100]"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data[0].partitionType").value("TypeA"))
                .andExpect(jsonPath("$.data[0].longName").value("Desc"));
    }

    @Test
    void listAssistancePartitions_ShouldReturnEmptyList_WhenNoPartitionsFound() throws Exception {
        List<Long> productIds = List.of(100L);
        when(listAssistancePartitionUseCase.handle(productIds)).thenReturn(Collections.emptyList());

        mockMvc.perform(post("/api/v1/assistance-partition")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("[100]"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data").isEmpty());
    }
}

