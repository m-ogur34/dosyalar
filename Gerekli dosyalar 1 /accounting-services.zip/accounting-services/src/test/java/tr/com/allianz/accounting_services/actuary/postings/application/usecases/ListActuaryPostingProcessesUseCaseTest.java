package tr.com.allianz.accounting_services.actuary.postings.application.usecases;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import tr.com.allianz.accounting_services.actuary.postings.application.port.out.LoadActuaryPostingProcessesPort;
import tr.com.allianz.accounting_services.actuary.postings.domain.model.ActuaryPostingProcess;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ListActuaryPostingProcessesUseCaseTest {

    @Mock
    private LoadActuaryPostingProcessesPort loadActuaryPostingProcessesPort;

    @Test
    void handle_ShouldReturnProcessesFromPort() {
        List<ActuaryPostingProcess> expected = List.of(
                new ActuaryPostingProcess("P1", "Alpha"),
                new ActuaryPostingProcess("P2", "Beta")
        );
        when(loadActuaryPostingProcessesPort.loadAll()).thenReturn(expected);

        ListActuaryPostingProcessesUseCase useCase =
                new ListActuaryPostingProcessesUseCase(loadActuaryPostingProcessesPort);

        List<ActuaryPostingProcess> result = useCase.handle();

        assertThat(result).isEqualTo(expected);
        verify(loadActuaryPostingProcessesPort, times(1)).loadAll();
    }
}

