package tr.com.allianz.accounting_services;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class AccountingServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
