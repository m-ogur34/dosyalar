package tr.com.allianz.accounting_services.shared.api;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ErrorDetailTest {

    @Test
    void testConstructorAndAccessors() {
        ErrorDetail errorDetail = new ErrorDetail("fieldName", "must not be null");

        assertEquals("fieldName", errorDetail.field());
        assertEquals("must not be null", errorDetail.message());
    }

    @Test
    void testEqualsAndHashCode() {
        ErrorDetail e1 = new ErrorDetail("field", "error");
        ErrorDetail e2 = new ErrorDetail("field", "error");

        assertEquals(e1, e2);
        assertEquals(e1.hashCode(), e2.hashCode());
    }

    @Test
    void testNotEquals() {
        ErrorDetail e1 = new ErrorDetail("field", "error");
        ErrorDetail e2 = new ErrorDetail("field", "different error");

        assertNotEquals(e1, e2);
    }

    @Test
    void testToString() {
        ErrorDetail errorDetail = new ErrorDetail("field", "message");

        String result = errorDetail.toString();

        assertTrue(result.contains("field"));
        assertTrue(result.contains("message"));
    }
}
