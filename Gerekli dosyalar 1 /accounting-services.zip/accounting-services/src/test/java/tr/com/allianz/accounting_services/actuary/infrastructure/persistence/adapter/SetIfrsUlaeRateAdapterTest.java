package tr.com.allianz.accounting_services.actuary.infrastructure.persistence.adapter;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jdbc.core.PreparedStatementCallback;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.ActuaryProcessRuleAmount;
import tr.com.allianz.accounting_services.actuary.infrastructure.persistence.entity.AlzActProcessRules;
import tr.com.allianz.accounting_services.actuary.infrastructure.persistence.repository.AlzActProcessRulesRepository;

import java.math.BigDecimal;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicInteger;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.doAnswer;

@ExtendWith(MockitoExtension.class)
class SetIfrsUlaeRateAdapterTest {

    @Mock
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @Mock
    private AlzActProcessRulesRepository rulesRepository;

    @Test
    void setRate_ShouldUseAmountQueryAndUpdateActuaryProcessAmountRates() {
        ActuaryProcessRuleAmount row = Mockito.mock(ActuaryProcessRuleAmount.class);
        when(row.ruleId()).thenReturn(7);
        when(row.ifrsCyGross()).thenReturn(new BigDecimal("25"));
        when(row.ifrsPyGross()).thenReturn(new BigDecimal("50"));

        AlzActProcessRules rule = new AlzActProcessRules();
        rule.setProcessId("ULAE");
        rule.setRuleId(7);
        rule.setRuleText("branch_code = '01'");
        when(rulesRepository.findByProcessIdAndRuleId("ULAE", 7)).thenReturn(Optional.of(rule));
        doAnswer(invocation -> {
            String sql = invocation.getArgument(0);
            assertThat(sql).doesNotContain("{RULE_CONDITION}").doesNotContain("branch_code = '01'");
            if (sql.contains("koc_clm_bordro_rep")) {
                return invokeWithRows(invocation, List.of(row(
                        "BRANCH_CODE", "01",
                        "amount_component", new BigDecimal("30")
                )));
            }
            if (sql.contains("ticket_date = :end_date")) {
                return invokeWithRows(invocation, List.of(row(
                        "BRANCH_CODE", "01",
                        "amount_component", new BigDecimal("50")
                )));
            }
            return invokeWithRows(invocation, List.of(row(
                    "BRANCH_CODE", "01",
                    "amount_component", new BigDecimal("20")
            )));
        }).when(namedParameterJdbcTemplate).execute(anyString(), any(MapSqlParameterSource.class), any());
        when(namedParameterJdbcTemplate.update(anyString(), any(MapSqlParameterSource.class)))
                .thenReturn(1);

        SetIfrsUlaeRateAdapter adapter = new SetIfrsUlaeRateAdapter(
                namedParameterJdbcTemplate, rulesRepository);

        adapter.setRate("ULAE", LocalDate.of(2026, 7, 1), List.of(row));

        ArgumentCaptor<String> sqlCaptor = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<MapSqlParameterSource> parametersCaptor =
                ArgumentCaptor.forClass(MapSqlParameterSource.class);
        verify(namedParameterJdbcTemplate).update(sqlCaptor.capture(), parametersCaptor.capture());

        assertThat(sqlCaptor.getValue())
                .contains("UPDATE alz_act_process_amounts")
                .contains("ifrs_cy_gross_rate")
                .contains("ifrs_py_gross_rate")
                .contains("process_id = :process_id")
                .doesNotContain("MERGE INTO alz_ulae_amounts");
        assertThat(parametersCaptor.getValue().getValue("year")).isEqualTo(2026);
        assertThat(parametersCaptor.getValue().getValue("month")).isEqualTo(6);
        assertThat(parametersCaptor.getValue().getValue("process_id")).isEqualTo("ULAE");
        assertThat(parametersCaptor.getValue().getValue("rule_id")).isEqualTo(7);
        assertThat((BigDecimal) parametersCaptor.getValue().getValue("ifrs_cy_gross_rate"))
                .isEqualByComparingTo("0.2500000000000000");
        assertThat((BigDecimal) parametersCaptor.getValue().getValue("ifrs_py_gross_rate"))
                .isEqualByComparingTo("0.5000000000000000");
        verify(namedParameterJdbcTemplate, times(3))
                .execute(anyString(), any(MapSqlParameterSource.class), any());
    }

    @Test
    void setRate_ShouldKeepRatesGreaterThanOneAndNegative() {
        ActuaryProcessRuleAmount row = Mockito.mock(ActuaryProcessRuleAmount.class);
        when(row.ruleId()).thenReturn(7);
        when(row.ifrsCyGross()).thenReturn(new BigDecimal("150"));
        when(row.ifrsPyGross()).thenReturn(new BigDecimal("-150"));

        AlzActProcessRules rule = new AlzActProcessRules();
        rule.setProcessId("ULAE");
        rule.setRuleId(7);
        rule.setRuleText("branch_code = '01'");
        when(rulesRepository.findByProcessIdAndRuleId("ULAE", 7)).thenReturn(Optional.of(rule));
        doAnswer(invocation -> {
            String sql = invocation.getArgument(0);
            if (sql.contains("koc_clm_bordro_rep")) {
                return invokeWithRows(invocation, List.of(row(
                        "BRANCH_CODE", "01",
                        "amount_component", new BigDecimal("30")
                )));
            }
            if (sql.contains("ticket_date = :end_date")) {
                return invokeWithRows(invocation, List.of(row(
                        "BRANCH_CODE", "01",
                        "amount_component", new BigDecimal("50")
                )));
            }
            return invokeWithRows(invocation, List.of(row(
                    "BRANCH_CODE", "01",
                    "amount_component", new BigDecimal("20")
            )));
        }).when(namedParameterJdbcTemplate).execute(anyString(), any(MapSqlParameterSource.class), any());
        when(namedParameterJdbcTemplate.update(anyString(), any(MapSqlParameterSource.class)))
                .thenReturn(1);

        SetIfrsUlaeRateAdapter adapter = new SetIfrsUlaeRateAdapter(
                namedParameterJdbcTemplate, rulesRepository);

        adapter.setRate("ULAE", LocalDate.of(2026, 7, 1), List.of(row));

        ArgumentCaptor<MapSqlParameterSource> parametersCaptor =
                ArgumentCaptor.forClass(MapSqlParameterSource.class);
        verify(namedParameterJdbcTemplate, times(1))
                .update(anyString(), parametersCaptor.capture());

        assertThat((BigDecimal) parametersCaptor.getValue().getValue("ifrs_cy_gross_rate"))
                .isEqualByComparingTo("1.500000000000000000000000000000000");
        assertThat((BigDecimal) parametersCaptor.getValue().getValue("ifrs_py_gross_rate"))
                .isEqualByComparingTo("-1.500000000000000000000000000000000");
    }

    private Object invokeWithRows(InvocationOnMock invocation,
                                  List<Map<String, Object>> rows) throws Throwable {
        PreparedStatementCallback<?> callback = invocation.getArgument(2);
        return callback.doInPreparedStatement(preparedStatement(rows));
    }

    private java.sql.PreparedStatement preparedStatement(List<Map<String, Object>> rows) throws SQLException {
        java.sql.PreparedStatement ps = Mockito.mock(java.sql.PreparedStatement.class);
        java.sql.ResultSet rs = Mockito.mock(java.sql.ResultSet.class);
        ResultSetMetaData metaData = Mockito.mock(ResultSetMetaData.class);
        when(ps.executeQuery()).thenReturn(rs);
        when(rs.getMetaData()).thenReturn(metaData);

        List<String> columns = rows.isEmpty() ? List.of() : new ArrayList<>(rows.getFirst().keySet());
        AtomicInteger index = new AtomicInteger(-1);
        when(rs.next()).thenAnswer(invocation -> index.incrementAndGet() < rows.size());
        when(metaData.getColumnCount()).thenReturn(columns.size());
        when(metaData.getColumnLabel(any(Integer.class))).thenAnswer(invocation -> columns.get(invocation.getArgument(0, Integer.class) - 1));
        when(rs.getObject(any(Integer.class))).thenAnswer(invocation -> {
            int currentIndex = index.get();
            if (currentIndex < 0 || currentIndex >= rows.size()) {
                return null;
            }
            return rows.get(currentIndex).get(columns.get(invocation.getArgument(0, Integer.class) - 1));
        });
        when(rs.getBigDecimal(anyString())).thenAnswer(invocation -> {
            int currentIndex = index.get();
            if (currentIndex < 0 || currentIndex >= rows.size()) {
                return null;
            }
            Object value = lookup(rows.get(currentIndex), invocation.getArgument(0, String.class));
            return value instanceof BigDecimal bigDecimal ? bigDecimal : null;
        });
        return ps;
    }

    private Object lookup(Map<String, Object> row, String key) {
        if (row.containsKey(key)) {
            return row.get(key);
        }
        for (Map.Entry<String, Object> entry : row.entrySet()) {
            if (entry.getKey().equalsIgnoreCase(key)) {
                return entry.getValue();
            }
        }
        return null;
    }

    private Map<String, Object> row(Object... keyValues) {
        Map<String, Object> row = new LinkedHashMap<>();
        for (int i = 0; i < keyValues.length; i += 2) {
            row.put((String) keyValues[i], keyValues[i + 1]);
        }
        return row;
    }
}
