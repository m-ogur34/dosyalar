package tr.com.allianz.accounting_services.actuary.postings.infrastructure.persistence.adapter;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import tr.com.allianz.accounting_services.actuary.postings.domain.model.ActuaryPostingProcess;
import tr.com.allianz.accounting_services.actuary.postings.infrastructure.persistence.entity.AlzRciProcessEntity;
import tr.com.allianz.accounting_services.actuary.postings.infrastructure.persistence.repository.AlzRciProcessRepository;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ActuaryPostingProcessPersistenceAdapterTest {

    @Mock
    private AlzRciProcessRepository repository;

    @Test
    void loadAll_ShouldTrimDescription_HandleNull_AndSortAscending() {
        when(repository.findAll()).thenReturn(List.of(
                new AlzRciProcessEntity("P2", "  Beta  "),
                new AlzRciProcessEntity("P3", null),
                new AlzRciProcessEntity("P1", "  Alpha")
        ));

        ActuaryPostingProcessPersistenceAdapter adapter =
                new ActuaryPostingProcessPersistenceAdapter(repository);

        List<ActuaryPostingProcess> result = adapter.loadAll();

        verify(repository, times(1)).findAll();
        assertThat(result).hasSize(3);

        assertThat(result.get(0).getProcessId()).isEqualTo("P3");
        assertThat(result.get(0).getDescription()).isEqualTo("");

        assertThat(result.get(1).getProcessId()).isEqualTo("P1");
        assertThat(result.get(1).getDescription()).isEqualTo("Alpha");

        assertThat(result.get(2).getProcessId()).isEqualTo("P2");
        assertThat(result.get(2).getDescription()).isEqualTo("Beta");
    }
}

