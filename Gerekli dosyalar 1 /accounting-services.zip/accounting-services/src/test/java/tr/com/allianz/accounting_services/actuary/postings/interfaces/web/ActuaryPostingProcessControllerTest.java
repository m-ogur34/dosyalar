package tr.com.allianz.accounting_services.actuary.postings.interfaces.web;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import tr.com.allianz.accounting_services.actuary.application.usecases.ListActuaryProcessesUseCase;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.ActuaryProcess;
import tr.com.allianz.accounting_services.actuary.postings.application.usecases.ListActuaryPostingProcessesUseCase;
import tr.com.allianz.accounting_services.actuary.postings.domain.model.ActuaryPostingProcess;
import tr.com.allianz.accounting_services.actuary.postings.interfaces.web.dto.ActuaryPostingProcessResponse;

import java.time.LocalDate;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ActuaryPostingProcessControllerTest {

    @Mock
    private ListActuaryPostingProcessesUseCase listActuaryPostingProcessesUseCase;

    @Mock
    private ListActuaryProcessesUseCase listActuaryProcessesUseCase;

    @Test
    void getAllProcesses_ShouldReturnOnlyProcessesWhoseDescriptionContainsActiveProcessName() {
        // Aktif süreçler: processName "Alpha" ve "Gamma"
        when(listActuaryProcessesUseCase.handle()).thenReturn(List.of(
                new ActuaryProcess("1", "Alpha", "Alpha explanation", LocalDate.now().minusDays(1), LocalDate.now().plusDays(1)),
                new ActuaryProcess("3", "Gamma", "Gamma explanation", LocalDate.now().minusDays(1), LocalDate.now().plusDays(1))
        ));

        // Tüm posting process'ler: description'ı "Alpha" içeren geçmeli,
        // "Beta" içeren eşleşmemeli, "Gamma Process" içeren geçmeli
        when(listActuaryPostingProcessesUseCase.handle()).thenReturn(List.of(
                new ActuaryPostingProcess("P1", "Alpha Batch"),
                new ActuaryPostingProcess("P2", "Beta Batch"),
                new ActuaryPostingProcess("P3", "Gamma Process Batch")
        ));

        ActuaryPostingProcessController controller =
                new ActuaryPostingProcessController(listActuaryPostingProcessesUseCase, listActuaryProcessesUseCase);

        ResponseEntity<List<ActuaryPostingProcessResponse>> response = controller.getAllProcesses();

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody()).hasSize(2);
        assertThat(response.getBody()).extracting(ActuaryPostingProcessResponse::getProcessId)
                .containsExactlyInAnyOrder("P1", "P3");
    }

    @Test
    void getAllProcesses_ShouldReturnEmpty_WhenNoActiveProcesses() {
        when(listActuaryProcessesUseCase.handle()).thenReturn(List.of());
        when(listActuaryPostingProcessesUseCase.handle()).thenReturn(List.of(
                new ActuaryPostingProcess("P1", "Alpha Batch")
        ));

        ActuaryPostingProcessController controller =
                new ActuaryPostingProcessController(listActuaryPostingProcessesUseCase, listActuaryProcessesUseCase);

        ResponseEntity<List<ActuaryPostingProcessResponse>> response = controller.getAllProcesses();

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody()).isEmpty();
    }

    @Test
    void getAllProcesses_ShouldMatchCaseInsensitively() {
        when(listActuaryProcessesUseCase.handle()).thenReturn(List.of(
                new ActuaryProcess("1", "alpha", "alpha explanation", LocalDate.now().minusDays(1), LocalDate.now().plusDays(1))
        ));
        when(listActuaryPostingProcessesUseCase.handle()).thenReturn(List.of(
                new ActuaryPostingProcess("P1", "ALPHA Batch"),
                new ActuaryPostingProcess("P2", "Beta Batch")
        ));

        ActuaryPostingProcessController controller =
                new ActuaryPostingProcessController(listActuaryPostingProcessesUseCase, listActuaryProcessesUseCase);

        ResponseEntity<List<ActuaryPostingProcessResponse>> response = controller.getAllProcesses();

        assertThat(response.getBody()).hasSize(1);
        assertThat(response.getBody().getFirst().getProcessId()).isEqualTo("P1");
    }
}

