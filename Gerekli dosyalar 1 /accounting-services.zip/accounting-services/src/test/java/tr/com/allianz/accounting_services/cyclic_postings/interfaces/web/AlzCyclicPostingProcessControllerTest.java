package tr.com.allianz.accounting_services.cyclic_postings.interfaces.web;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import tr.com.allianz.accounting_services.cyclic_postings.application.usecases.posting_process.*;
import tr.com.allianz.accounting_services.cyclic_postings.infrastructure.persistence.entity.AlzCyclicPostingProcess;
import tr.com.allianz.accounting_services.cyclic_postings.interfaces.web.dto.CreateCyclicPostingRequest;
import tr.com.allianz.accounting_services.cyclic_postings.interfaces.web.dto.ProcessCyclicPostingRequest;
import tr.com.allianz.accounting_services.cyclic_postings.interfaces.web.dto.RemoveCyclicPostingProcessRequest;

import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static tr.com.allianz.accounting_services.BaseUnitTestConfig.asJsonString;

@ExtendWith(MockitoExtension.class)
class AlzCyclicPostingProcessControllerTest {

    private MockMvc mockMvc;

    @Mock
    private ProcessCyclicPostingUseCase processCyclicPostingUseCase;
    @Mock
    private CreateCyclicPostingUseCase createCyclicPostingUseCase;
    @Mock
    private ListCyclicPostingProcessUseCase listCyclicPostingProcessUseCase;
    @Mock
    private RemoveCyclicPostingProcessUseCase removeCyclicPostingProcessUseCase;

    private final Long batchId = null;
    private final Long cyclicBatchId = null;
    private final String status = null;

    @BeforeEach
    public void setup() {
        AlzCyclicPostingProcessController controller = new AlzCyclicPostingProcessController(
                processCyclicPostingUseCase,
                createCyclicPostingUseCase,
                listCyclicPostingProcessUseCase,
                removeCyclicPostingProcessUseCase
        );
        mockMvc = MockMvcBuilders.standaloneSetup(controller).build();
    }

    @Test
    void createCyclicPostings() throws Exception {
        CreateCyclicPostingRequest request = new CreateCyclicPostingRequest();
        request.setItems(List.of());

        List<AlzCyclicPostingProcess> resultList = List.of();

        when(createCyclicPostingUseCase.handle(any())).thenReturn(resultList);

        mockMvc.perform(post("/api/v1/cyclic-accounting-process/create")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(request)))
                .andExpect(status().isOk());
    }

    @Test
    void processCyclicPostingUseCaseTest() throws Exception {

        ProcessCyclicPostingRequest request = new ProcessCyclicPostingRequest();
        request.setItems(List.of());

        List<AlzCyclicPostingProcess> processList = List.of();

        when(processCyclicPostingUseCase.handle(any()))
                .thenReturn(processList);

        mockMvc.perform(post("/api/v1/cyclic-accounting-process/process")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(request)))
                .andExpect(status().isOk());
    }

    @Test
    void listAlzCyclicPostingProcess() throws Exception {

        Page<AlzCyclicPostingProcessReadModel> postingProcessReadModelList = Page.empty();

        when(listCyclicPostingProcessUseCase.handle(any(Pageable.class), eq(batchId), eq(cyclicBatchId),
                eq(status)))
                .thenReturn(postingProcessReadModelList.stream().toList());

        mockMvc.perform(get("/api/v1/cyclic-accounting-process/list"))
                .andExpect(status().isOk());
    }

    @Test
    void removeUnprocessedCyclicPostings() throws Exception {
        RemoveCyclicPostingProcessRequest request = new RemoveCyclicPostingProcessRequest(1L);

        doNothing().when(removeCyclicPostingProcessUseCase).handle(request.batchId());

        mockMvc.perform(post("/api/v1/cyclic-accounting-process/remove-unprocessed")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(request)))
                .andExpect(status().isOk());
    }

    @Test
    void processCyclicPostings() throws Exception {
        ProcessCyclicPostingRequest request = new ProcessCyclicPostingRequest();
        request.setItems(List.of());

        when(processCyclicPostingUseCase.handle(any())).thenReturn(List.of());

        mockMvc.perform(post("/api/v1/cyclic-accounting-process/process")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(request)))
                .andExpect(status().isOk());
    }
}

