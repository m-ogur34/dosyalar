package tr.com.allianz.accounting_services.cyclic_postings.infrastructure.config;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import tr.com.allianz.accounting_services.cyclic_postings.application.port.out.CyclicPostingCheckPort;
import tr.com.allianz.accounting_services.cyclic_postings.application.port.out.CyclicPostingProcessPort;
import tr.com.allianz.accounting_services.cyclic_postings.application.usecases.posting_process.CreateCyclicPostingUseCase;
import tr.com.allianz.accounting_services.cyclic_postings.application.usecases.posting_process.ListCyclicPostingProcessUseCase;
import tr.com.allianz.accounting_services.cyclic_postings.application.usecases.posting_process.ProcessCyclicPostingUseCase;
import tr.com.allianz.accounting_services.cyclic_postings.application.usecases.posting_process.RemoveCyclicPostingProcessUseCase;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
class CyclicAccountingProcessConfigTest {

    @Mock
    private CyclicPostingProcessPort cyclicPostingProcessPort;

    @Mock
    private CyclicPostingCheckPort cyclicPostingCheckPort;

    private final CyclicAccountingProcessConfig config = new CyclicAccountingProcessConfig();

    @Test
    void shouldCreateProcessCyclicPostingUseCaseBean() {
        // When
        ProcessCyclicPostingUseCase useCase = config.processCyclicPostingUseCase(cyclicPostingProcessPort);

        // Then
        assertNotNull(useCase);
        assertThat(useCase).isInstanceOf(ProcessCyclicPostingUseCase.class);
    }

    @Test
    void shouldCreateCreateCyclicPostingUseCaseBean() {
        // When
        CreateCyclicPostingUseCase useCase = config.createCyclicPostingUseCase(cyclicPostingProcessPort, cyclicPostingCheckPort);

        // Then
        assertNotNull(useCase);
        assertThat(useCase).isInstanceOf(CreateCyclicPostingUseCase.class);
    }

    @Test
    void shouldCreateListCyclicPostingProcessUseCaseBean() {
        // When
        ListCyclicPostingProcessUseCase useCase = config.listCyclicPostingUseCase(cyclicPostingProcessPort);

        // Then
        assertNotNull(useCase);
        assertThat(useCase).isInstanceOf(ListCyclicPostingProcessUseCase.class);
    }

    @Test
    void shouldCreateRemoveCyclicPostingProcessUseCaseBean() {
        // When
        RemoveCyclicPostingProcessUseCase useCase = config.removeCyclicPostingProcessUseCase(cyclicPostingProcessPort);

        // Then
        assertNotNull(useCase);
        assertThat(useCase).isInstanceOf(RemoveCyclicPostingProcessUseCase.class);
    }

    @Test
    void shouldCreateAllBeansWithNonNullPorts() {
        // When
        ProcessCyclicPostingUseCase processUseCase = config.processCyclicPostingUseCase(cyclicPostingProcessPort);
        CreateCyclicPostingUseCase createUseCase = config.createCyclicPostingUseCase(cyclicPostingProcessPort, cyclicPostingCheckPort);
        ListCyclicPostingProcessUseCase listUseCase = config.listCyclicPostingUseCase(cyclicPostingProcessPort);
        RemoveCyclicPostingProcessUseCase removeUseCase = config.removeCyclicPostingProcessUseCase(cyclicPostingProcessPort);

        // Then
        assertThat(processUseCase).isNotNull();
        assertThat(createUseCase).isNotNull();
        assertThat(listUseCase).isNotNull();
        assertThat(removeUseCase).isNotNull();
    }

    @Test
    void shouldCreateDifferentInstancesForEachBeanCall() {
        // When
        ProcessCyclicPostingUseCase useCase1 = config.processCyclicPostingUseCase(cyclicPostingProcessPort);
        ProcessCyclicPostingUseCase useCase2 = config.processCyclicPostingUseCase(cyclicPostingProcessPort);

        // Then
        assertThat(useCase1).isNotSameAs(useCase2);
    }

    @Test
    void configurationShouldBeAnnotatedWithConfiguration() {
        // When & Then
        assertThat(CyclicAccountingProcessConfig.class.isAnnotationPresent(org.springframework.context.annotation.Configuration.class))
            .isTrue();
    }
}