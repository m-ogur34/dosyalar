package tr.com.allianz.accounting_services.actuary.infrastructure.persistence.adapter;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class SqlRulePredicateSupportTest {

    @ParameterizedTest
    @ValueSource(strings = {
            "branch_code = '01'",
            "product_id >= 10 AND amount < 20",
            "code IN ('W','WCRI')",
            "NOT code LIKE 'X%'",
            "pool IS NULL OR pool IS NOT NULL",
            "nvl(is_pool,0) = 0"
    })
    void compile_ShouldAcceptSupportedGrammar(String ruleText) {
        SqlRulePredicateSupport.RulePredicate predicate = SqlRulePredicateSupport.compile(ruleText, 1);

        assertThat(predicate).isNotNull();
    }

    @Test
    void toSqlCondition_ShouldBindStringAndNumericLiterals() {
        SqlRulePredicateSupport.SqlCondition condition = SqlRulePredicateSupport.toSqlCondition(
                "branch_code = '01' AND product_id >= 10", "P1001", 1, "Rule text");

        assertThat(condition.sql()).isEqualTo("branch_code = :rule_param_0 AND product_id >= :rule_param_1");
        assertThat(condition.parameters().getValue("rule_param_0")).isEqualTo("01");
        assertThat((BigDecimal) condition.parameters().getValue("rule_param_1")).isEqualByComparingTo("10");
        assertThat(condition.sql()).doesNotContain("'01'").doesNotContain("10");
    }

    @ParameterizedTest
    @ValueSource(strings = {
            "1=1; drop table x",
            "branch_code = '01' OR 1=1",
            "branch_code = '01",
            "branch_code + '01' = 'X'",
            "code IN ()"
    })
    void compile_ShouldRejectUnsafeOrMalformedRules(String ruleText) {
        assertThatThrownBy(() -> SqlRulePredicateSupport.compile(ruleText, 2))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("Rule text güvenli değil")
                .hasMessageContaining("processId=NEW_PROCESS_2026");
    }

    @Test
    void matches_ShouldResolveCaseInsensitiveColumnsAndStringEquality() {
        SqlRulePredicateSupport.RulePredicate predicate = SqlRulePredicateSupport.compile(
                "branch_code = '01'", 3
        );

        assertThat(predicate.matches(Map.of("BRANCH_CODE", "01"))).isTrue();
        assertThat(predicate.matches(Map.of("branch_code", "02"))).isFalse();
    }

    @Test
    void matches_ShouldNormalizeNumbersForComparisons() {
        SqlRulePredicateSupport.RulePredicate predicate = SqlRulePredicateSupport.compile(
                "product_id >= 10 AND product_id < 11", 4
        );

        assertThat(predicate.matches(Map.of("product_id", 10))).isTrue();
        assertThat(predicate.matches(Map.of("product_id", new BigDecimal("10.5")))).isTrue();
        assertThat(predicate.matches(Map.of("product_id", 11))).isFalse();
    }

    @Test
    void matches_ShouldHonorAndOrPrecedenceAndParentheses() {
        SqlRulePredicateSupport.RulePredicate withoutParentheses = SqlRulePredicateSupport.compile(
                "branch_code = '01' OR branch_code = '02' AND product_id = 10", 5
        );
        SqlRulePredicateSupport.RulePredicate withParentheses = SqlRulePredicateSupport.compile(
                "(branch_code = '01' OR branch_code = '02') AND product_id = 10", 6
        );

        Map<String, Object> row = Map.of("branch_code", "01", "product_id", 9);
        assertThat(withoutParentheses.matches(row)).isTrue();
        assertThat(withParentheses.matches(row)).isFalse();
    }

    @Test
    void matches_ShouldSupportInNotLikeAndIsNull() {
        SqlRulePredicateSupport.RulePredicate predicate = SqlRulePredicateSupport.compile(
                "code IN ('W','WCRI') AND NOT branch_code LIKE '9%' AND cancel_date IS NULL",
                7
        );

        Map<String, Object> matchingRow = new HashMap<>();
        matchingRow.put("code", "W");
        matchingRow.put("branch_code", "01");
        matchingRow.put("cancel_date", null);

        Map<String, Object> nonMatchingRow = new HashMap<>();
        nonMatchingRow.put("code", "W");
        nonMatchingRow.put("branch_code", "91");
        nonMatchingRow.put("cancel_date", null);

        assertThat(predicate.matches(matchingRow)).isTrue();
        assertThat(predicate.matches(nonMatchingRow)).isFalse();
    }

    @Test
    void matches_ShouldSupportNvlFunctionInPredicate() {
        SqlRulePredicateSupport.RulePredicate predicate = SqlRulePredicateSupport.compile(
                "is_industrial = 1 and acc_cover_code = '15' and product_id <> 68 and nvl(is_pool,0) = 0",
                15
        );

        Map<String, Object> matchingRow = new HashMap<>();
        matchingRow.put("is_industrial", 1);
        matchingRow.put("acc_cover_code", "15");
        matchingRow.put("product_id", 10);
        matchingRow.put("is_pool", null);

        Map<String, Object> nonMatchingRow = new HashMap<>();
        nonMatchingRow.put("is_industrial", 1);
        nonMatchingRow.put("acc_cover_code", "15");
        nonMatchingRow.put("product_id", 10);
        nonMatchingRow.put("is_pool", 1);

        assertThat(predicate.matches(matchingRow)).isTrue();
        assertThat(predicate.matches(nonMatchingRow)).isFalse();
    }
}

