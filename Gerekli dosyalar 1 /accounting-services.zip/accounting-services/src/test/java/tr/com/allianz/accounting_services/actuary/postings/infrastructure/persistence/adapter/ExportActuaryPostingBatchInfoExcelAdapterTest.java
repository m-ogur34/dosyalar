package tr.com.allianz.accounting_services.actuary.postings.infrastructure.persistence.adapter;

import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.junit.jupiter.api.Test;
import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import tr.com.allianz.accounting_services.actuary.postings.application.usecases.GetActuaryPostingBatchInfoCommand;
import tr.com.allianz.accounting_services.actuary.postings.domain.model.ActuaryPostingBatchInfoExcelFile;
import tr.com.allianz.accounting_services.actuary.postings.domain.model.ActuaryPostingBatchInfoExcelRow;

import java.io.ByteArrayInputStream;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class ExportActuaryPostingBatchInfoExcelAdapterTest {

    private static final class TestableExportAdapter extends ExportActuaryPostingBatchInfoExcelAdapter {
        TestableExportAdapter(JdbcTemplate jdbcTemplate) {
            super(jdbcTemplate);
        }

        String exposeFindBatchName(Long batchType) {
            return findBatchName(batchType);
        }
    }

    @Test
    void exportToExcel_ShouldCreateWorkbookMatchingOracleColumnOrder() throws Exception {
        SimpleJdbcCall simpleJdbcCall = mock(SimpleJdbcCall.class, org.mockito.Mockito.RETURNS_SELF);
        when(simpleJdbcCall.execute(any(org.springframework.jdbc.core.namedparam.MapSqlParameterSource.class)))
                .thenReturn(Map.of(
                        "v_refcur",
                        List.of(
                                new ActuaryPostingBatchInfoExcelRow(
                                        "100",
                                        "Cash",
                                        "Test explanation",
                                        new java.math.BigDecimal("25"),
                                        LocalDate.of(2026, 7, 31),
                                        "USD",
                                        new java.math.BigDecimal("2.5"),
                                        "Motor",
                                        "Retail",
                                        "3401",
                                        "Istanbul",
                                        "1",
                                        "0",
                                        "AC01",
                                        "Acc Cover",
                                        "AR01",
                                        "Arrangement",
                                        "TC01",
                                        "Company",
                                        "Agency",
                                        "Layer A",
                                        "CLM-01",
                                        "MUALLAK",
                                        LocalDate.of(2026, 6, 15)
                                )
                        )
                ));

        ExportActuaryPostingBatchInfoExcelAdapter adapter = new ExportActuaryPostingBatchInfoExcelAdapter(mock(JdbcTemplate.class)) {
            @Override
            protected SimpleJdbcCall createSimpleJdbcCall() {
                return simpleJdbcCall;
            }

            @Override
            protected String findBatchName(Long batchType) {
                return "Aylik Batch";
            }

            @Override
            protected LocalDateTime currentTimestamp() {
                return LocalDateTime.of(2026, 7, 20, 14, 30);
            }
        };

        ActuaryPostingBatchInfoExcelFile result = adapter.exportToExcel(new GetActuaryPostingBatchInfoCommand(
                10L,
                LocalDate.of(2026, 7, 15),
                "3401",
                60L,
                "PARTITION",
                1
        ));

        assertThat(result.fileName()).isEqualTo("Aylik Batch_Fisi_202607201430.xlsx");
        assertThat(result.content()).isNotEmpty();

        try (var workbook = WorkbookFactory.create(new ByteArrayInputStream(result.content()))) {
            var sheet = workbook.getSheetAt(0);
            assertThat(sheet.getRow(0).getCell(0).getStringCellValue()).isEqualTo("HESAP NO");
            assertThat(sheet.getRow(0).getCell(28).getStringCellValue()).isEqualTo("HASAR TARIHI");

            var row = sheet.getRow(1);
            assertThat(row.getCell(0).getStringCellValue()).isEqualTo("100");
            assertThat(row.getCell(1).getStringCellValue()).isEqualTo("Cash");
            assertThat(row.getCell(2).getStringCellValue()).isEqualTo("Test explanation");
            assertThat(row.getCell(3).getNumericCellValue()).isEqualTo(0d);
            assertThat(row.getCell(4).getNumericCellValue()).isEqualTo(25d);
            assertThat(row.getCell(5).getNumericCellValue()).isEqualTo(-25d);
            assertThat(row.getCell(7).getNumericCellValue()).isEqualTo(10d);
            assertThat(row.getCell(8).getNumericCellValue()).isEqualTo(-10d);
            assertThat(row.getCell(10).getStringCellValue()).isEqualTo("USD");
            assertThat(row.getCell(12).getStringCellValue()).isEqualTo("Motor");
            assertThat(row.getCell(24).getStringCellValue()).isEqualTo("Agency");
            assertThat(row.getCell(27).getStringCellValue()).isEqualTo("MUALLAK");
            assertThat(row.getCell(28).getLocalDateTimeCellValue().toLocalDate()).isEqualTo(LocalDate.of(2026, 6, 15));
        }
    }

    @Test
    void exportToExcel_ShouldCreateHeaderOnlyWorkbook_WhenCursorIsNull() throws Exception {
        SimpleJdbcCall simpleJdbcCall = mock(SimpleJdbcCall.class, org.mockito.Mockito.RETURNS_SELF);
        Map<String, Object> out = new java.util.HashMap<>();
        out.put("v_refcur", null);
        when(simpleJdbcCall.execute(any(org.springframework.jdbc.core.namedparam.MapSqlParameterSource.class)))
                .thenReturn(out);

        ExportActuaryPostingBatchInfoExcelAdapter adapter = new ExportActuaryPostingBatchInfoExcelAdapter(mock(JdbcTemplate.class)) {
            @Override
            protected SimpleJdbcCall createSimpleJdbcCall() {
                return simpleJdbcCall;
            }

            @Override
            protected String findBatchName(Long batchType) {
                return "A/B:C*D?E\"F<G>H|";
            }

            @Override
            protected LocalDateTime currentTimestamp() {
                return LocalDateTime.of(2026, 7, 20, 14, 30);
            }
        };

        ActuaryPostingBatchInfoExcelFile result = adapter.exportToExcel(new GetActuaryPostingBatchInfoCommand(
                10L,
                LocalDate.of(2026, 7, 15),
                "3401",
                60L,
                "PARTITION",
                1
        ));

        assertThat(result.fileName()).isEqualTo("A_B_C_D_E_F_G_H__Fisi_202607201430.xlsx");
        try (var workbook = WorkbookFactory.create(new ByteArrayInputStream(result.content()))) {
            var sheet = workbook.getSheetAt(0);
            assertThat(sheet.getPhysicalNumberOfRows()).isEqualTo(1);
            assertThat(sheet.getRow(0).getCell(0).getStringCellValue()).isEqualTo("HESAP NO");
            assertThat(sheet.getRow(0).getCell(28).getStringCellValue()).isEqualTo("HASAR TARIHI");
        }
    }

    @Test
    void findBatchName_ShouldReturnDefault_WhenBlankOrError() {
        JdbcTemplate jdbcTemplate = mock(JdbcTemplate.class);
        TestableExportAdapter adapter = new TestableExportAdapter(jdbcTemplate);

        when(jdbcTemplate.query(any(String.class), any(org.springframework.jdbc.core.RowMapper.class), anyLong()))
                .thenReturn(new ArrayList<>(List.of("   ")))
                .thenThrow(new DataAccessResourceFailureException("db down"));

        String fallbackFromBlank = adapter.exposeFindBatchName(10L);
        String fallbackFromError = adapter.exposeFindBatchName(10L);

        assertThat(fallbackFromBlank).isEqualTo("BatchInfo");
        assertThat(fallbackFromError).isEqualTo("BatchInfo");
    }
}

