package tr.com.allianz.accounting_services.cyclic_postings.infrastructure.persistence.adapter;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import tr.com.allianz.accounting_services.cyclic_postings.infrastructure.persistence.repository.AlzCyclicAccountMappingRepository;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CyclicPostingCheckAdapterTest {

    @Mock
    private AlzCyclicAccountMappingRepository mappingRepository;

    @InjectMocks
    private CyclicPostingCheckAdapter adapter;

    @Test
    void shouldReturnBatchCountWhenBatchIdExists() {
        // Given
        Long batchId = 1L;
        int expectedCount = 5;
        when(mappingRepository.findPostingCountByBatchId(batchId)).thenReturn(expectedCount);

        // When
        int result = adapter.findBatchCount(batchId);

        // Then
        assertThat(result).isEqualTo(expectedCount);
        verify(mappingRepository).findPostingCountByBatchId(batchId);
    }

    @Test
    void shouldReturnZeroWhenNoBatchFound() {
        // Given
        Long batchId = 999L;
        when(mappingRepository.findPostingCountByBatchId(batchId)).thenReturn(0);

        // When
        int result = adapter.findBatchCount(batchId);

        // Then
        assertThat(result).isZero();
        verify(mappingRepository).findPostingCountByBatchId(batchId);
    }

    @Test
    void shouldReturnNotMappedAccountNoWhenExists() {
        // Given
        Long batchId = 1L;
        String expectedAccountNo = "123456";
        when(mappingRepository.findNotMappedAccountsByBatchId(batchId)).thenReturn(expectedAccountNo);

        // When
        String result = adapter.findNotMappedCyclicAccountNo(batchId);

        // Then
        assertThat(result).isEqualTo(expectedAccountNo);
        verify(mappingRepository).findNotMappedAccountsByBatchId(batchId);
    }

    @Test
    void shouldReturnNullWhenNoNotMappedAccountFound() {
        // Given
        Long batchId = 999L;
        when(mappingRepository.findNotMappedAccountsByBatchId(batchId)).thenReturn(null);

        // When
        String result = adapter.findNotMappedCyclicAccountNo(batchId);

        // Then
        assertThat(result).isNull();
        verify(mappingRepository).findNotMappedAccountsByBatchId(batchId);
    }

    @Test
    void shouldReturnEmptyStringWhenAllAccountsMapped() {
        // Given
        Long batchId = 1L;
        when(mappingRepository.findNotMappedAccountsByBatchId(batchId)).thenReturn("");

        // When
        String result = adapter.findNotMappedCyclicAccountNo(batchId);

        // Then
        assertThat(result).isEmpty();
        verify(mappingRepository).findNotMappedAccountsByBatchId(batchId);
    }

    @Test
    void shouldHandleMultipleBatchIdCalls() {
        // Given
        Long batchId1 = 1L;
        Long batchId2 = 2L;
        when(mappingRepository.findPostingCountByBatchId(batchId1)).thenReturn(3);
        when(mappingRepository.findPostingCountByBatchId(batchId2)).thenReturn(7);

        // When
        int result1 = adapter.findBatchCount(batchId1);
        int result2 = adapter.findBatchCount(batchId2);

        // Then
        assertThat(result1).isEqualTo(3);
        assertThat(result2).isEqualTo(7);
        verify(mappingRepository).findPostingCountByBatchId(batchId1);
        verify(mappingRepository).findPostingCountByBatchId(batchId2);
    }

    @Test
    void shouldHandleMultipleNotMappedAccountCalls() {
        // Given
        Long batchId1 = 1L;
        Long batchId2 = 2L;
        when(mappingRepository.findNotMappedAccountsByBatchId(batchId1)).thenReturn("ACC001");
        when(mappingRepository.findNotMappedAccountsByBatchId(batchId2)).thenReturn("ACC002");

        // When
        String result1 = adapter.findNotMappedCyclicAccountNo(batchId1);
        String result2 = adapter.findNotMappedCyclicAccountNo(batchId2);

        // Then
        assertThat(result1).isEqualTo("ACC001");
        assertThat(result2).isEqualTo("ACC002");
        verify(mappingRepository).findNotMappedAccountsByBatchId(batchId1);
        verify(mappingRepository).findNotMappedAccountsByBatchId(batchId2);
    }

    @Test
    void shouldVerifyRepositoryInteractionForBatchCount() {
        // Given
        Long batchId = 100L;
        when(mappingRepository.findPostingCountByBatchId(batchId)).thenReturn(10);

        // When
        adapter.findBatchCount(batchId);

        // Then
        verify(mappingRepository, times(1)).findPostingCountByBatchId(batchId);
        verifyNoMoreInteractions(mappingRepository);
    }

    @Test
    void shouldVerifyRepositoryInteractionForNotMappedAccount() {
        // Given
        Long batchId = 200L;
        when(mappingRepository.findNotMappedAccountsByBatchId(batchId)).thenReturn("ACC999");

        // When
        adapter.findNotMappedCyclicAccountNo(batchId);

        // Then
        verify(mappingRepository, times(1)).findNotMappedAccountsByBatchId(batchId);
        verifyNoMoreInteractions(mappingRepository);
    }
}