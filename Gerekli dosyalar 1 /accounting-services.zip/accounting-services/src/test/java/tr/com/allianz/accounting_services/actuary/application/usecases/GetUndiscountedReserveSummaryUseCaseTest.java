package tr.com.allianz.accounting_services.actuary.application.usecases;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import tr.com.allianz.accounting_services.actuary.application.port.out.LoadUndiscountedReserveSummaryPort;
import tr.com.allianz.accounting_services.actuary.application.port.out.SaveActuaryPeriodStatusPort;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.ActuaryQueryCriteria;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.UndiscountedReserveSummary;
import tr.com.allianz.accounting_services.actuary.infrastructure.persistence.entity.AlzActPeriods;

import java.math.BigDecimal;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class GetUndiscountedReserveSummaryUseCaseTest {

    @Mock
    private LoadUndiscountedReserveSummaryPort loadPort;

    @Mock
    private SaveActuaryPeriodStatusPort savePeriodStatusPort;

    @Test
    void handle_ShouldReturnSummaryForUndiscresProcess() {
        ActuaryQueryCriteria criteria = new ActuaryQueryCriteria("undiscres", 2026, 6);
        UndiscountedReserveSummary expected = new UndiscountedReserveSummary(
                new BigDecimal("100"), new BigDecimal("40"),
                new BigDecimal("80"), new BigDecimal("30")
        );
        when(loadPort.load(2026, 6)).thenReturn(expected);
        AlzActPeriods period = new AlzActPeriods("UNDISCRES", 2026, 6, "Approved");
        when(savePeriodStatusPort.getOrCreateInProgress("UNDISCRES", 2026, 6)).thenReturn(period);

        GetUndiscountedReserveSummaryResponse result =
                new GetUndiscountedReserveSummaryUseCase(loadPort, savePeriodStatusPort).handle(criteria);

        assertThat(result.summary()).isEqualTo(expected);
        assertThat(result.period()).isEqualTo(period);
        verify(loadPort).load(2026, 6);
        verify(savePeriodStatusPort).getOrCreateInProgress("UNDISCRES", 2026, 6);
    }

    @Test
    void handle_ShouldRejectOtherProcess() {
        ActuaryQueryCriteria criteria = new ActuaryQueryCriteria("IBNR", 2026, 6);

        assertThatThrownBy(() -> new GetUndiscountedReserveSummaryUseCase(loadPort, savePeriodStatusPort).handle(criteria))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("This query only supports processId: UNDISCRES");

        verifyNoInteractions(loadPort);
    }
}
