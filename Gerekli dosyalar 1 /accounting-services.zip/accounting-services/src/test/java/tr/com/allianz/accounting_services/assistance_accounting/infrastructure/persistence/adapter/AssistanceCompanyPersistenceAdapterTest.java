package tr.com.allianz.accounting_services.assistance_accounting.infrastructure.persistence.adapter;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import tr.com.allianz.accounting_services.assistance_accounting.domain.valueobject.AssistanceCompany;
import tr.com.allianz.accounting_services.assistance_accounting.infrastructure.persistence.entity.KocAcGenAccountRefs;
import tr.com.allianz.accounting_services.assistance_accounting.infrastructure.persistence.repository.KocAcGenAccountRefsRepository;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AssistanceCompanyPersistenceAdapterTest {

    @Mock
    private KocAcGenAccountRefsRepository repository;

    @InjectMocks
    private AssistanceCompanyPersistenceAdapter adapter;

    @Test
    void loadAssistanceCompanies_ShouldReturnMappedCompanies() {
        KocAcGenAccountRefs entity = new KocAcGenAccountRefs();
        entity.setIntId(1L);
        entity.setExtReference("REF");
        entity.setAccountCode("ACC");
        entity.setName("Agency");
        entity.setIsAssistanceCompany(1);

        when(repository.findByIsAssistanceCompany(1)).thenReturn(List.of(entity));

        List<AssistanceCompany> result = adapter.loadAssistanceCompanies();

        assertThat(result).hasSize(1);
        AssistanceCompany company = result.getFirst();
        assertThat(company.getIntId()).isEqualTo(1L);
        assertThat(company.getExtReference()).isEqualTo("REF");
        assertThat(company.getAccountCode()).isEqualTo("ACC");
        assertThat(company.getAgencyName()).isEqualTo("Agency");

        verify(repository).findByIsAssistanceCompany(1);
    }
}

