package tr.com.allianz.accounting_services.actuary.application.usecases;

import org.junit.jupiter.api.Test;
import tr.com.allianz.accounting_services.actuary.application.service.distribution.DistributionProcessHandlerResolver;
import tr.com.allianz.accounting_services.actuary.application.service.distribution.IbnrDistributionProcessHandler;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThatCode;

class ExecuteDistributionUseCaseTest {

    @Test
    void handle_ShouldExecuteNoOpIbnrHandlerWithoutExtraBeans() {
        ExecuteDistributionUseCase useCase = new ExecuteDistributionUseCase(
                new DistributionProcessHandlerResolver(List.of(new IbnrDistributionProcessHandler()))
        );

        assertThatCode(() -> useCase.handle("IBNR", 2026, 6, "tester"))
                .doesNotThrowAnyException();
    }
}
