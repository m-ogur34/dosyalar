package tr.com.allianz.accounting_services.assistance_accounting.domain.valueobject;

import org.junit.jupiter.api.Test;
import static org.assertj.core.api.Assertions.assertThat;

class AssistancePartitionTest {

    @Test
    void shouldCreateAssistancePartition() {
        String partitionType = "TypeA";
        String longName = "Description";

        AssistancePartition partition = new AssistancePartition(partitionType, longName);

        assertThat(partition.partitionType()).isEqualTo(partitionType);
        assertThat(partition.longName()).isEqualTo(longName);
    }
}

