package tr.com.allianz.accounting_services.actuary.postings.infrastructure.persistence.adapter;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import tr.com.allianz.accounting_services.actuary.postings.domain.model.ActuaryPostingBranch;

import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ActuaryPostingBranchPersistenceAdapterTest {

    @Mock
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @Test
    void loadAll_ShouldMapAndTrimValues() {
        when(namedParameterJdbcTemplate.queryForList(anyString(), any(MapSqlParameterSource.class)))
                .thenReturn(List.of(
                        Map.of("branch_id", " 34 ", "branch_name", " Istanbul ", "ext_reference", " 3401 "),
                        Map.of("branch_id", " 06 ", "branch_name", " Ankara ", "ext_reference", "")
                ));

        ActuaryPostingBranchPersistenceAdapter adapter =
                new ActuaryPostingBranchPersistenceAdapter(namedParameterJdbcTemplate);

        List<ActuaryPostingBranch> result = adapter.loadAll();

        assertThat(result).hasSize(2);
        assertThat(result.getFirst().getBranchId()).isEqualTo("34");
        assertThat(result.getFirst().getBranchName()).isEqualTo("Istanbul");
        assertThat(result.getFirst().getExtReference()).isEqualTo("3401");

        assertThat(result.get(1).getBranchId()).isEqualTo("06");
        assertThat(result.get(1).getBranchName()).isEqualTo("Ankara");
        assertThat(result.get(1).getExtReference()).isEqualTo("");
    }
}

