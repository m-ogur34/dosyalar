package tr.com.allianz.accounting_services.accounting_postings.application.usecases;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import tr.com.allianz.accounting_services.accounting_postings.application.port.out.ReversePostingPort;
import tr.com.allianz.accounting_services.accounting_postings.interfaces.web.dto.ReversePostingRequest;
import tr.com.allianz.accounting_services.accounting_postings.interfaces.web.dto.ReversePostingResponse;

import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ReversePostingUseCaseTest {

    @Mock
    private ReversePostingPort reversePostingPort;

    @InjectMocks
    private ReversePostingUseCase reversePostingUseCase;

    @Test
    void testHandle() {
        ReversePostingRequest request = new ReversePostingRequest();
        request.setBatchId(1L);

        ReversePostingResponse response = new ReversePostingResponse();
        response.setBatchId(1L);
        response.setReverseBatchId(2L);

        List<ReversePostingRequest> requests = Collections.singletonList(request);
        List<ReversePostingResponse> responses = Collections.singletonList(response);

        when(reversePostingPort.reversePosting(requests)).thenReturn(responses);
        
        List<ReversePostingResponse> result = reversePostingUseCase.handle(requests);
        
        assertEquals(1, result.size());
        assertEquals(1L, result.get(0).getBatchId());
        assertEquals(2L, result.get(0).getReverseBatchId());
    }
}
