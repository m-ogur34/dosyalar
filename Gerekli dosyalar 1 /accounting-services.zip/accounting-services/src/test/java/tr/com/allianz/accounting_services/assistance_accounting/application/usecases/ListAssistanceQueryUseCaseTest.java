package tr.com.allianz.accounting_services.assistance_accounting.application.usecases;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import tr.com.allianz.accounting_services.assistance_accounting.application.port.out.LoadAssistanceQueryPort;
import tr.com.allianz.accounting_services.assistance_accounting.domain.valueobject.AssistanceQueryCriteria;
import tr.com.allianz.accounting_services.assistance_accounting.domain.valueobject.AssistanceQueryResult;

import java.math.BigDecimal;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ListAssistanceQueryUseCaseTest {

    @Mock
    private LoadAssistanceQueryPort loadAssistanceQueryPort;

    @InjectMocks
    private ListAssistanceQueryUseCase listAssistanceQueryUseCase;

    @Test
    void handle_ShouldReturnListFromPort() {
        // Given
        AssistanceQueryCriteria criteria = new AssistanceQueryCriteria(
                BigDecimal.TEN, "ACC_CODE", 2023, 10, 1, "100", "PART", 5L
        );
        AssistanceQueryResult result = new AssistanceQueryResult(
                12345L, "Acc Exp", "LOB", "Dist Exp", 1, BigDecimal.TEN, null
        );
        List<AssistanceQueryResult> expectedList = List.of(result);

        when(loadAssistanceQueryPort.loadAssistanceQueryResults(criteria)).thenReturn(expectedList);

        // When
        List<AssistanceQueryResult> actualList = listAssistanceQueryUseCase.handle(criteria);

        // Then
        assertThat(actualList).hasSize(1);
        assertThat(actualList).isEqualTo(expectedList);
        verify(loadAssistanceQueryPort).loadAssistanceQueryResults(criteria);
    }
}
