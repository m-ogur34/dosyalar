package tr.com.allianz.accounting_services.assistance_accounting.application.usecases;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import tr.com.allianz.accounting_services.assistance_accounting.application.port.out.LoadAssistanceProductPort;
import tr.com.allianz.accounting_services.assistance_accounting.domain.valueobject.AssistanceProduct;

import java.util.Collections;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ListAssistanceProductUseCaseTest {

    @Mock
    private LoadAssistanceProductPort loadAssistanceProductPort;

    @InjectMocks
    private ListAssistanceProductUseCase listAssistanceProductUseCase;

    @Test
    void handle_ShouldReturnListFromPort() {
        // Given
        AssistanceProduct product = new AssistanceProduct(101L, "REF-101", "Test Product");
        List<AssistanceProduct> expectedList = List.of(product);
        when(loadAssistanceProductPort.loadAssistanceProducts(null)).thenReturn(expectedList);

        // When
        List<AssistanceProduct> result = listAssistanceProductUseCase.handle(null);

        // Then
        assertThat(result).hasSize(1);
        assertThat(result).isEqualTo(expectedList);
        verify(loadAssistanceProductPort).loadAssistanceProducts(null);
    }

    @Test
    void handle_ShouldReturnEmptyList_WhenPortReturnsEmpty() {
        // Given
        when(loadAssistanceProductPort.loadAssistanceProducts(null)).thenReturn(Collections.emptyList());

        // When
        List<AssistanceProduct> result = listAssistanceProductUseCase.handle(null);

        // Then
        assertThat(result).isEmpty();
        verify(loadAssistanceProductPort).loadAssistanceProducts(null);
    }
}

