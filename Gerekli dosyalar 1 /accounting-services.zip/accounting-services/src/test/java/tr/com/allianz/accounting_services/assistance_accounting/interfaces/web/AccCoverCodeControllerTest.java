package tr.com.allianz.accounting_services.assistance_accounting.interfaces.web;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import tr.com.allianz.accounting_services.assistance_accounting.application.usecases.ListAccCoverCodeUseCase;
import tr.com.allianz.accounting_services.assistance_accounting.domain.valueobject.AccCoverCode;

import java.util.Collections;
import java.util.List;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)
class AccCoverCodeControllerTest {

    private MockMvc mockMvc;

    @Mock
    private ListAccCoverCodeUseCase listAccCoverCodeUseCase;

    @BeforeEach
    void setUp() {
        AccCoverCodeController controller = new AccCoverCodeController(listAccCoverCodeUseCase);
        mockMvc = MockMvcBuilders.standaloneSetup(controller).build();
    }

    @Test
    void listAccCoverCodes_ShouldReturnList() throws Exception {
        AccCoverCode code = new AccCoverCode("CODE1", "Description");
        when(listAccCoverCodeUseCase.handle()).thenReturn(List.of(code));

        mockMvc.perform(get("/api/v1/acc-cover-code")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data[0].accCoverCode").value("CODE1"))
                .andExpect(jsonPath("$.data[0].explanation").value("Description"));
    }

    @Test
    void listAccCoverCodes_ShouldReturnEmptyList_WhenNoData() throws Exception {
        when(listAccCoverCodeUseCase.handle()).thenReturn(Collections.emptyList());

        mockMvc.perform(get("/api/v1/acc-cover-code")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data").isEmpty());
    }
}

