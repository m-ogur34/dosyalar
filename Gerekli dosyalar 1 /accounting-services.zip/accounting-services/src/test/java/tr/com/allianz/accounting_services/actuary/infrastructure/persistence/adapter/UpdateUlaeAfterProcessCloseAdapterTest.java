package tr.com.allianz.accounting_services.actuary.infrastructure.persistence.adapter;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import java.time.LocalDate;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class UpdateUlaeAfterProcessCloseAdapterTest {

    @Mock
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @Test
    void update_ShouldSetIStatusCodeForEligibleUlaeClose() {
        when(namedParameterJdbcTemplate.update(anyString(), any(MapSqlParameterSource.class))).thenReturn(1);
        UpdateUlaeAfterProcessCloseAdapter adapter =
                new UpdateUlaeAfterProcessCloseAdapter(namedParameterJdbcTemplate);

        adapter.update(LocalDate.of(2026, 6, 30), LocalDate.of(2026, 6, 1));

        ArgumentCaptor<String> sqlCaptor = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<MapSqlParameterSource> parametersCaptor = ArgumentCaptor.forClass(MapSqlParameterSource.class);
        verify(namedParameterJdbcTemplate).update(sqlCaptor.capture(), parametersCaptor.capture());

        String sql = sqlCaptor.getValue().toLowerCase();
        assertThat(sql).contains("set i_status_code = 2")
                .contains("agent_int_id = 12354")
                .contains("process_type = 'ulae'")
                .contains("branch_id = 1")
                .contains("close_date = :close_date")
                .contains("process_date = :process_date")
                .contains("status_code = 2")
                .contains("i_status_code is null");

        MapSqlParameterSource parameters = parametersCaptor.getValue();
        assertThat(parameters.getValue("close_date"))
                .isEqualTo(java.sql.Date.valueOf("2026-06-30"));
        assertThat(parameters.getValue("process_date"))
                .isEqualTo(java.sql.Date.valueOf("2026-06-01"));
    }
}

