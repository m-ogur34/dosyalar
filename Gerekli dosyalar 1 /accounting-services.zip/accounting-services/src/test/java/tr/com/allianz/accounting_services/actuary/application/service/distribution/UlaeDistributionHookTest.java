package tr.com.allianz.accounting_services.actuary.application.service.distribution;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import tr.com.allianz.accounting_services.actuary.application.port.out.SaveActuaryPeriodStatusPort;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.ActuaryPeriodStatus;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class UlaeDistributionHookTest {

    @Mock
    private SaveActuaryPeriodStatusPort saveActuaryPeriodStatusPort;

    @Test
    void supports_ShouldOnlyMatchUlaeProcessId() {
        UlaeDistributionHook hook = hook();

        assertThat(hook.supports("ULAE")).isTrue();
        assertThat(hook.supports("IBNR")).isFalse();
        assertThat(hook.supports(null)).isFalse();
    }

    @Test
    void afterExecute_ShouldMarkPeriodAsToBeReported() {
        UlaeDistributionHook hook = hook();
        DistributionProcessContext context = new DistributionProcessContext("ULAE", 2026, 6, "tester");

        hook.afterExecute(context);

        verify(saveActuaryPeriodStatusPort).upsertStatus(
                "ULAE",
                2026,
                6,
                ActuaryPeriodStatus.TO_BE_REPORTED
        );
    }

    private UlaeDistributionHook hook() {
        return new UlaeDistributionHook(saveActuaryPeriodStatusPort);
    }
}
