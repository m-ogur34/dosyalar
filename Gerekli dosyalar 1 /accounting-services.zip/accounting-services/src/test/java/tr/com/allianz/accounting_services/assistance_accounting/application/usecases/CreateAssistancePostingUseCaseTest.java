package tr.com.allianz.accounting_services.assistance_accounting.application.usecases;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import tr.com.allianz.accounting_services.assistance_accounting.application.port.out.CreateAssistancePostingPort;

import java.math.BigDecimal;
import java.time.LocalDate;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CreateAssistancePostingUseCaseTest {

    @Mock
    private CreateAssistancePostingPort createAssistancePostingPort;

    @InjectMocks
    private CreateAssistancePostingUseCase createAssistancePostingUseCase;

    @Test
    void handle_ShouldCallPort() {
        CreateAssistancePostingCommand command = new CreateAssistancePostingCommand(
                "INV123",
                LocalDate.now(),
                "Desc",
                LocalDate.now(),
                1L,
                2023,
                10,
                "ACC",
                BigDecimal.TEN,
                "EB",
                "100",
                "PART"
        );

        when(createAssistancePostingPort.createAssistancePosting(command)).thenReturn(12345L);

        Long result = createAssistancePostingUseCase.handle(command);

        assertThat(result).isEqualTo(12345L);
        verify(createAssistancePostingPort).createAssistancePosting(command);
    }
}
