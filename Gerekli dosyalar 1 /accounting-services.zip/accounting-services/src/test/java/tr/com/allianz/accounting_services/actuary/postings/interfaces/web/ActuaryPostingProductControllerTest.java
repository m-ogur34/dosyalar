package tr.com.allianz.accounting_services.actuary.postings.interfaces.web;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import tr.com.allianz.accounting_services.actuary.postings.application.usecases.ListActuaryPostingProductsUseCase;
import tr.com.allianz.accounting_services.actuary.postings.domain.model.ActuaryPostingProduct;
import tr.com.allianz.accounting_services.actuary.postings.interfaces.web.dto.ActuaryPostingProductResponse;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ActuaryPostingProductControllerTest {

    @Mock
    private ListActuaryPostingProductsUseCase listActuaryPostingProductsUseCase;

    @Test
    void getProductsByBranchId_ShouldReturnMappedResponse() {
        when(listActuaryPostingProductsUseCase.handle("34")).thenReturn(List.of(
                new ActuaryPostingProduct(101L, "1001", "Kasko"),
                new ActuaryPostingProduct(202L, "2002", "Trafik")
        ));

        ActuaryPostingProductController controller =
                new ActuaryPostingProductController(listActuaryPostingProductsUseCase);

        ResponseEntity<List<ActuaryPostingProductResponse>> response = controller.getProductsByBranchId("34");

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody()).hasSize(2);
        assertThat(response.getBody().getFirst().getProductId()).isEqualTo(101L);
        assertThat(response.getBody().getFirst().getExtReference()).isEqualTo("1001");
        assertThat(response.getBody().getFirst().getLongName()).isEqualTo("Kasko");
    }

    @Test
    void getProductsByBranchId_ShouldReturnEmptyList_WhenNoProductExists() {
        when(listActuaryPostingProductsUseCase.handle("06")).thenReturn(List.of());

        ActuaryPostingProductController controller =
                new ActuaryPostingProductController(listActuaryPostingProductsUseCase);

        ResponseEntity<List<ActuaryPostingProductResponse>> response = controller.getProductsByBranchId("06");

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody()).isEmpty();
    }
}

