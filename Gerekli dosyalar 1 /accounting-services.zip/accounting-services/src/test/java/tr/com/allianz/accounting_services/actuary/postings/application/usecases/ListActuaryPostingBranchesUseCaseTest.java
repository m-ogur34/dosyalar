package tr.com.allianz.accounting_services.actuary.postings.application.usecases;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import tr.com.allianz.accounting_services.actuary.postings.application.port.out.LoadActuaryPostingBranchesPort;
import tr.com.allianz.accounting_services.actuary.postings.domain.model.ActuaryPostingBranch;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ListActuaryPostingBranchesUseCaseTest {

    @Mock
    private LoadActuaryPostingBranchesPort loadActuaryPostingBranchesPort;

    @Test
    void handle_ShouldReturnBranchesFromPort() {
        List<ActuaryPostingBranch> expected = List.of(
                new ActuaryPostingBranch("34", "Istanbul", "3401")
        );
        when(loadActuaryPostingBranchesPort.loadAll()).thenReturn(expected);

        ListActuaryPostingBranchesUseCase useCase =
                new ListActuaryPostingBranchesUseCase(loadActuaryPostingBranchesPort);

        List<ActuaryPostingBranch> result = useCase.handle();

        assertThat(result).isEqualTo(expected);
        verify(loadActuaryPostingBranchesPort, times(1)).loadAll();
    }
}

