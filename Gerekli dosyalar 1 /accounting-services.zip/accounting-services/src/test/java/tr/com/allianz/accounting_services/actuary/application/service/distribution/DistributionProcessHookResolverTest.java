package tr.com.allianz.accounting_services.actuary.application.service.distribution;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class DistributionProcessHookResolverTest {

    @Mock
    private DistributionProcessHook matchingHook;

    @Mock
    private DistributionProcessHook otherHook;

    @Test
    void resolve_ShouldReturnHooksSupportingProcessIdInProvidedOrder() {
        when(matchingHook.supports("IBNR")).thenReturn(true);
        when(otherHook.supports("IBNR")).thenReturn(false);
        DistributionProcessHookResolver resolver =
                new DistributionProcessHookResolver(List.of(matchingHook, otherHook));

        assertThat(resolver.resolve("IBNR")).containsExactly(matchingHook);
        verify(matchingHook).supports("IBNR");
        verify(otherHook).supports("IBNR");
    }

    @Test
    void resolve_ShouldReturnEmptyListWhenNoHookSupportsProcessId() {
        when(matchingHook.supports("UNKNOWN")).thenReturn(false);
        when(otherHook.supports("UNKNOWN")).thenReturn(false);
        DistributionProcessHookResolver resolver =
                new DistributionProcessHookResolver(List.of(matchingHook, otherHook));

        assertThat(resolver.resolve("UNKNOWN")).isEmpty();
    }
}

