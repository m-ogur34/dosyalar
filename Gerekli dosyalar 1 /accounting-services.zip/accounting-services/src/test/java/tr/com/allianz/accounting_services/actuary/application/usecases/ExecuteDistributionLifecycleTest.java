package tr.com.allianz.accounting_services.actuary.application.usecases;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InOrder;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import tr.com.allianz.accounting_services.actuary.application.service.distribution.DistributionProcessContext;
import tr.com.allianz.accounting_services.actuary.application.service.distribution.DistributionProcessHandler;
import tr.com.allianz.accounting_services.actuary.application.service.distribution.DistributionProcessHandlerResolver;
import tr.com.allianz.accounting_services.actuary.application.service.distribution.DistributionProcessHook;
import tr.com.allianz.accounting_services.actuary.application.service.distribution.DistributionProcessHookResolver;
import tr.com.allianz.accounting_services.actuary.application.port.out.LoadActuaryPeriodStatusPort;
import tr.com.allianz.accounting_services.actuary.application.port.out.SaveActuaryPeriodStatusPort;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.ActuaryPeriodStatus;

import java.util.List;

import static org.mockito.Mockito.inOrder;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ExecuteDistributionLifecycleTest {

    @Mock
    private DistributionProcessHandlerResolver handlerResolver;

    @Mock
    private DistributionProcessHookResolver hookResolver;

    @Mock
    private DistributionProcessHandler handler;

    @Mock
    private DistributionProcessHook firstHook;

    @Mock
    private DistributionProcessHook secondHook;

    @Mock
    private LoadActuaryPeriodStatusPort loadActuaryPeriodStatusPort;

    @Mock
    private SaveActuaryPeriodStatusPort saveActuaryPeriodStatusPort;

    @Test
    void handle_ShouldRunMatchingHooksAroundExecutionWithContext() {
        ExecuteDistributionUseCase useCase = new ExecuteDistributionUseCase(handlerResolver, hookResolver);
        DistributionProcessContext expectedContext =
                new DistributionProcessContext("IBNR", 2026, 6, "tester");

        when(handlerResolver.resolve("IBNR")).thenReturn(handler);
        when(hookResolver.resolve("IBNR")).thenReturn(List.of(firstHook, secondHook));

        useCase.handle("IBNR", 2026, 6, "tester");

        InOrder inOrder = inOrder(firstHook, secondHook, handler);
        inOrder.verify(firstHook).beforeExecute(expectedContext);
        inOrder.verify(secondHook).beforeExecute(expectedContext);
        inOrder.verify(handler).execute("IBNR", 2026, 6);
        inOrder.verify(firstHook).afterExecute(expectedContext);
        inOrder.verify(secondHook).afterExecute(expectedContext);
    }

    @Test
    void handle_ShouldNotRunAfterHooksWhenBeforeHookFails() {
        ExecuteDistributionUseCase useCase = new ExecuteDistributionUseCase(handlerResolver, hookResolver);
        RuntimeException failure = new RuntimeException("before failed");

        when(handlerResolver.resolve("ULAE")).thenReturn(handler);
        when(hookResolver.resolve("ULAE")).thenReturn(List.of(firstHook));
        org.mockito.Mockito.doThrow(failure).when(firstHook)
                .beforeExecute(new DistributionProcessContext("ULAE", 2026, 6, "tester"));

        org.assertj.core.api.Assertions.assertThatThrownBy(() -> useCase.handle("ULAE", 2026, 6, "tester"))
                .isSameAs(failure);

        verify(handler, never()).execute("ULAE", 2026, 6);
        verify(firstHook, never()).afterExecute(new DistributionProcessContext("ULAE", 2026, 6, "tester"));
    }

    @Test
    void handle_ShouldWorkWithoutHooks() {
        ExecuteDistributionUseCase useCase = new ExecuteDistributionUseCase(handlerResolver, hookResolver);

        when(handlerResolver.resolve("GENERIC")).thenReturn(handler);
        when(hookResolver.resolve("GENERIC")).thenReturn(List.of());

        useCase.handle("GENERIC", 2026, 6, null);

        verify(handler).execute("GENERIC", 2026, 6);
    }

    @Test
    void handle_ShouldExecuteWhenPeriodStatusIsErrorOccurred() {
        ExecuteDistributionUseCase useCase = new ExecuteDistributionUseCase(
                handlerResolver,
                hookResolver,
                saveActuaryPeriodStatusPort,
                loadActuaryPeriodStatusPort
        );

        when(loadActuaryPeriodStatusPort.getStatus("UNDISCRES", 2026, 6))
                .thenReturn(ActuaryPeriodStatus.ERROR_OCCURRED);
        when(handlerResolver.resolve("UNDISCRES")).thenReturn(handler);
        when(hookResolver.resolve("UNDISCRES")).thenReturn(List.of());

        useCase.handle("UNDISCRES", 2026, 6, "tester");

        verify(handler).execute("UNDISCRES", 2026, 6);
    }
}


