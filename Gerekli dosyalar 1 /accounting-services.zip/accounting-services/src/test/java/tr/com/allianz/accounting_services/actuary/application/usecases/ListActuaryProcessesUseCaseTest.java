package tr.com.allianz.accounting_services.actuary.application.usecases;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import tr.com.allianz.accounting_services.actuary.application.port.out.LoadActuaryProcessesPort;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.ActuaryProcess;
import java.time.LocalDate;
import java.util.List;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
@ExtendWith(MockitoExtension.class)
class ListActuaryProcessesUseCaseTest {
    @Mock
    private LoadActuaryProcessesPort loadActuaryProcessesPort;
    @Test
    void handle_ShouldReturnActiveProcesses() {
        ActuaryProcess process = new ActuaryProcess("P1001", "Process 1", "Desc", LocalDate.now().minusDays(1), LocalDate.now().plusDays(1));
        when(loadActuaryProcessesPort.loadActiveProcesses(any(LocalDate.class))).thenReturn(List.of(process));
        ListActuaryProcessesUseCase useCase = new ListActuaryProcessesUseCase(loadActuaryProcessesPort);
        List<ActuaryProcess> result = useCase.handle();
        assertThat(result).hasSize(1);
        assertThat(result.get(0).processId()).isEqualTo("P1001");
        verify(loadActuaryProcessesPort).loadActiveProcesses(any(LocalDate.class));
    }
}
