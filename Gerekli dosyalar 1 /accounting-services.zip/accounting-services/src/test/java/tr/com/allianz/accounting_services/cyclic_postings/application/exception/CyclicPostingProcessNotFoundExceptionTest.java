package tr.com.allianz.accounting_services.cyclic_postings.application.exception;


import tr.com.allianz.accounting_services.shared.exception.BaseApplicationException;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class CyclicPostingProcessNotFoundExceptionTest {

    @Test
    void shouldCreateExceptionWithCorrectValues() {
        // Given
        Long batchId = 12345L;

        // When
        CyclicPostingProcessNotFoundException exception = new CyclicPostingProcessNotFoundException(batchId);

        // Then
        assertThat(exception.getBatchId()).isEqualTo(batchId);
        assertThat(exception.getErrorCode()).isEqualTo("CYCLIC_POSTING_PROCESS_NOT_FOUND");
        assertThat(exception.getMessage()).isEqualTo("Devreden fiş işleme kaydı bulunamadı");
        assertThat(exception.getBatchId()).isEqualTo(12345L);
    }

    @Test
    void shouldInheritFromBaseApplicationException() {
        // Given
        Long batchId = 12345L;

        // When
        CyclicPostingProcessNotFoundException exception = new CyclicPostingProcessNotFoundException(batchId);

        // Then
        assertThat(exception).isInstanceOf(BaseApplicationException.class);
    }

}