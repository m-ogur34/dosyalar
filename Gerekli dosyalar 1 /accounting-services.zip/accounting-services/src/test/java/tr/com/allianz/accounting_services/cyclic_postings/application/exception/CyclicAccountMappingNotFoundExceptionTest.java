package tr.com.allianz.accounting_services.cyclic_postings.application.exception;


import tr.com.allianz.accounting_services.shared.exception.BaseApplicationException;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class CyclicAccountMappingNotFoundExceptionTest {


    @Test
    void testAlzCyclicAccountMappingNotFoundException() {
        String accountNo = "testAccountNo";
        CyclicAccountMappingNotFoundException ex =
                new CyclicAccountMappingNotFoundException(accountNo);

        assertThat(ex.getErrorCode()).isEqualTo("CYCLIC_ACCOUNT_MAPPING_NOT_FOUND");
        assertThat(ex.getMessage()).isEqualTo("Cyclic account mapping not found");
        assertThat(ex.getDetail()).isEqualTo("Account with no "+accountNo+" mapping not exists.");
        assertThat(ex.getAccountNo()).isEqualTo(accountNo);
    }

    @Test
    void shouldInheritFromBaseApplicationException() {
        String accountNo = "testAccountNo";
        CyclicAccountMappingNotFoundException ex =
                new CyclicAccountMappingNotFoundException(accountNo);

        assertThat(ex).isInstanceOf(BaseApplicationException.class);
    }

}