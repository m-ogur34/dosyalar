package tr.com.allianz.accounting_services.actuary.interfaces.web;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;
import tr.com.allianz.accounting_services.actuary.application.usecases.ListActuaryQueryResponse;
import tr.com.allianz.accounting_services.actuary.application.usecases.ListActuaryQueryUseCase;
import tr.com.allianz.accounting_services.actuary.application.usecases.GetUndiscountedReserveSummaryUseCase;
import tr.com.allianz.accounting_services.actuary.application.usecases.GetUndiscountedReserveSummaryResponse;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.ActuaryProcessRuleAmount;
import tr.com.allianz.accounting_services.actuary.infrastructure.persistence.entity.AlzActPeriods;
import tr.com.allianz.accounting_services.actuary.interfaces.web.dto.ActuaryQueryRequestDto;
import tr.com.allianz.accounting_services.actuary.interfaces.web.dto.ActuaryQuerySearchResponseDto;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.UndiscountedReserveSummary;
import tr.com.allianz.accounting_services.shared.api.ApiResponse;

import java.math.BigDecimal;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ActuaryQueryControllerTest {

    @Mock
    private ListActuaryQueryUseCase listActuaryQueryUseCase;

    @Mock
    private GetUndiscountedReserveSummaryUseCase getUndiscountedReserveSummaryUseCase;

    @InjectMocks
    private ActuaryQueryController controller;

    @Test
    void listActuaryQueryResults_ShouldReturnResults() {
        // Given
        ActuaryQueryRequestDto request = new ActuaryQueryRequestDto("P1001", 2024, 6);

        ActuaryProcessRuleAmount mockResult = new ActuaryProcessRuleAmount(
                "RULE_1",
                2024,
                6,
                "P1001",
                100,
                new BigDecimal("1000"),
                new BigDecimal("100"),
                new BigDecimal("900"),
                new BigDecimal("950"),
                new BigDecimal("95"),
                new BigDecimal("855"),
                new BigDecimal("1100"),
                new BigDecimal("110"),
                new BigDecimal("990"),
                new BigDecimal("1050"),
                new BigDecimal("105"),
                new BigDecimal("945"),
                new BigDecimal("1.0"),
                new BigDecimal("0.1"),
                new BigDecimal("0.9"),
                new BigDecimal("0.95"),
                new BigDecimal("0.095"),
                new BigDecimal("0.855"),
                new BigDecimal("1.1"),
                new BigDecimal("0.11"),
                new BigDecimal("0.99"),
                new BigDecimal("1.05"),
                new BigDecimal("0.105"),
                new BigDecimal("0.945")
        );

        AlzActPeriods alzActPeriods = new AlzActPeriods(
                "test",2026,4,"In Progress"
        );

        ListActuaryQueryResponse responseDto  = new ListActuaryQueryResponse(
                List.of(mockResult), alzActPeriods
        );

        when(listActuaryQueryUseCase.handle(any()))
                .thenReturn(responseDto);

        // When
        ResponseEntity<ApiResponse<ActuaryQuerySearchResponseDto>> response =
                controller.listActuaryQueryResults(request);

        // Then
        assertThat(response.getStatusCode().value()).isEqualTo(200);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().success()).isTrue();
        assertThat(response.getBody().code()).isEqualTo("SUCCESS");
        assertThat(response.getBody().data()).isNotNull();
        
        verify(listActuaryQueryUseCase).handle(any());
    }

    @Test
    void listActuaryQueryResults_ShouldReturnEmptyListWhenNoResults() {
        // Given
        ActuaryQueryRequestDto request = new ActuaryQueryRequestDto("P9999", 2024, 6);

        ListActuaryQueryResponse responseDto  = new ListActuaryQueryResponse(
                List.of(), null
        );

        when(listActuaryQueryUseCase.handle(any()))
                .thenReturn(responseDto);

        // When
        ResponseEntity<ApiResponse<ActuaryQuerySearchResponseDto>> response =
                controller.listActuaryQueryResults(request);

        // Then
        assertThat(response.getStatusCode().value()).isEqualTo(200);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().data()).isNotNull();
        
        verify(listActuaryQueryUseCase).handle(any());
    }

    @Test
    void getUndiscountedReserveSummary_ShouldReturnSummary() {
        ActuaryQueryRequestDto request = new ActuaryQueryRequestDto("UNDISCRES", 2026, 6);
        UndiscountedReserveSummary summary = new UndiscountedReserveSummary(
                new BigDecimal("100"), new BigDecimal("40"),
                new BigDecimal("80"), new BigDecimal("30")
        );
        AlzActPeriods period = new AlzActPeriods("UNDISCRES", 2026, 6, "Approved");
        GetUndiscountedReserveSummaryResponse useCaseResponse =
                new GetUndiscountedReserveSummaryResponse(summary, period);
        when(getUndiscountedReserveSummaryUseCase.handle(any())).thenReturn(useCaseResponse);

        ResponseEntity<ApiResponse<GetUndiscountedReserveSummaryResponse>> response =
                controller.getUndiscountedReserveSummary(request);

        assertThat(response.getStatusCode().value()).isEqualTo(200);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().data().summary()).isEqualTo(summary);
        assertThat(response.getBody().data().period()).isEqualTo(period);
        verify(getUndiscountedReserveSummaryUseCase).handle(any());
    }
}

