package tr.com.allianz.accounting_services.assistance_accounting.infrastructure.persistence.adapter;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Answers;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import tr.com.allianz.accounting_services.assistance_accounting.application.usecases.CreateAssistancePostingCommand;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AssistancePostingPersistenceAdapterTest {

    @Mock
    private JdbcTemplate jdbcTemplate;

    @Mock(answer = Answers.RETURNS_SELF)
    private SimpleJdbcCall simpleJdbcCall;

    @Captor
    private ArgumentCaptor<SqlParameterSource> paramCaptor;

    private AssistancePostingPersistenceAdapter adapter;

    @BeforeEach
    void setUp() {
        adapter = new AssistancePostingPersistenceAdapter(jdbcTemplate) {
            @Override
            protected SimpleJdbcCall createSimpleJdbcCall() {
                return simpleJdbcCall;
            }
        };
    }

    @Test
    void createAssistancePosting_ShouldCallProcedure() {
        when(simpleJdbcCall.execute(any(SqlParameterSource.class))).thenReturn(Map.of("p_batch_id", 12345L));

        CreateAssistancePostingCommand command = new CreateAssistancePostingCommand(
                "INV123",
                LocalDate.of(2023, 10, 25),
                "Batch Desc",
                LocalDate.of(2023, 11, 1),
                1L,
                2023,
                10,
                "ACC_COVER",
                BigDecimal.TEN,
                "EB",
                "100",
                "PART"
        );

        Long batchId = adapter.createAssistancePosting(command);

        assertThat(batchId).isEqualTo(12345L);
        verify(simpleJdbcCall).withProcedureName("create_assistance_posting_batch");
        verify(simpleJdbcCall).withCatalogName("ALZ_ACC_POSTING_UTILS");
        verify(simpleJdbcCall).withSchemaName("CUSTOMER");
        verify(simpleJdbcCall).withoutProcedureColumnMetaDataAccess();
        verify(simpleJdbcCall).execute(paramCaptor.capture());

        SqlParameterSource params = paramCaptor.getValue();
        assertThat(params.getValue("p_invoice_no")).isEqualTo("INV123");
        assertThat(params.getValue("p_payable_amount")).isEqualTo(BigDecimal.TEN);
        assertThat(params.getValue("p_invoice_date")).isEqualTo(java.sql.Date.valueOf(LocalDate.of(2023, 10, 25)));
        assertThat(params.getValue("p_batch_description")).isEqualTo("Batch Desc");
        assertThat(params.getValue("p_accounting_date")).isEqualTo(java.sql.Date.valueOf(LocalDate.of(2023, 11, 1)));
        assertThat(params.getValue("p_agency_id")).isEqualTo(1L);
        assertThat(params.getValue("p_year")).isEqualTo(2023);
        assertThat(params.getValue("p_month")).isEqualTo(10);
        assertThat(params.getValue("p_acc_cover_code")).isEqualTo("ACC_COVER");
        assertThat(params.getValue("p_payable_amount")).isEqualTo(BigDecimal.TEN);
        assertThat(params.getValue("p_eb_type")).isNull(); // 'EB' is not a number, so it will be caught and yield null
        assertThat(params.getValue("p_product_id")).isEqualTo("100");
        assertThat(params.getValue("p_partition_type")).isEqualTo("PART");
    }
}
