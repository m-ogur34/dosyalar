package tr.com.allianz.accounting_services.actuary.infrastructure.persistence.adapter;

import org.junit.jupiter.api.Test;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class CreateUndiscountedReserveDataAdapterTest {

    @Test
    void create_ShouldCallUndiscountedReserveProcedureWithYearAndMonth() {
        SimpleJdbcCall call = mock(SimpleJdbcCall.class);
        when(call.withSchemaName("CUSTOMER")).thenReturn(call);
        when(call.withCatalogName("ALZ_ACT_PROCESS_UTILS")).thenReturn(call);
        when(call.withProcedureName("CREATE_UNDISCOUNTED_RESERVE_DATA")).thenReturn(call);
        when(call.withoutProcedureColumnMetaDataAccess()).thenReturn(call);
        when(call.declareParameters(any(SqlParameter[].class))).thenReturn(call);
        when(call.execute(any(MapSqlParameterSource.class))).thenReturn(Map.of());

        CreateUndiscountedReserveDataAdapter adapter = new TestSubject(call);

        adapter.create(2026, 6);

        var parameters = org.mockito.ArgumentCaptor.forClass(MapSqlParameterSource.class);
        verify(call).execute(parameters.capture());

        assertEquals(2026, parameters.getValue().getValue("p_year"));
        assertEquals(6, parameters.getValue().getValue("p_month"));
    }

    private static class TestSubject extends CreateUndiscountedReserveDataAdapter {

        private final SimpleJdbcCall call;

        private TestSubject(SimpleJdbcCall call) {
            super(mock(JdbcTemplate.class));
            this.call = call;
        }

        @Override
        protected SimpleJdbcCall createSimpleJdbcCall() {
            return call;
        }
    }
}
