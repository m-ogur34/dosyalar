package tr.com.allianz.accounting_services.actuary.infrastructure.persistence.adapter;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.UndiscountedReserveSummary;

import java.math.BigDecimal;
import java.sql.ResultSet;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class UndiscountedReserveSummaryAdapterTest {

    @Mock
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @Mock
    private ResultSet resultSet;

    @Test
    void load_ShouldMapCurrentAndPriorRows() throws Exception {
        when(resultSet.getString("period_type")).thenReturn("CURRENT", "PRIOR");
        when(resultSet.getBigDecimal("gross_amount"))
                .thenReturn(new BigDecimal("100"), new BigDecimal("40"));
        when(resultSet.getBigDecimal("net_amount"))
                .thenReturn(new BigDecimal("80"), new BigDecimal("30"));

        doAnswer(invocation -> {
            RowCallbackHandler handler = invocation.getArgument(2);
            handler.processRow(resultSet);
            handler.processRow(resultSet);
            return null;
        }).when(namedParameterJdbcTemplate).query(anyString(), any(SqlParameterSource.class), any(RowCallbackHandler.class));

        UndiscountedReserveSummary result =
                new UndiscountedReserveSummaryAdapter(namedParameterJdbcTemplate).load(2026, 6);

        assertThat(result.currentYearGrossAmount()).isEqualByComparingTo("100");
        assertThat(result.priorYearGrossAmount()).isEqualByComparingTo("40");
        assertThat(result.currentYearNetAmount()).isEqualByComparingTo("80");
        assertThat(result.priorYearNetAmount()).isEqualByComparingTo("30");

        ArgumentCaptor<String> queryCaptor = ArgumentCaptor.forClass(String.class);
        verify(namedParameterJdbcTemplate).query(queryCaptor.capture(), any(SqlParameterSource.class), any(RowCallbackHandler.class));
        assertThat(queryCaptor.getValue()).contains("from alz_hp_data h");
        assertThat(queryCaptor.getValue()).contains("'IFCY', 'OCY', 'ULCY', 'RCCY'");
        assertThat(queryCaptor.getValue()).contains("'IFPY', 'OPY', 'ULPY', 'RCPY'");
    }
}
