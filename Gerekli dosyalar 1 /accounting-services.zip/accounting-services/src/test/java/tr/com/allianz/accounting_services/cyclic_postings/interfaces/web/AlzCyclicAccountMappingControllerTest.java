package tr.com.allianz.accounting_services.cyclic_postings.interfaces.web;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import tr.com.allianz.accounting_services.BaseUnitTestConfig;
import tr.com.allianz.accounting_services.cyclic_postings.application.usecases.AlzCyclicAccountMappingReadModel;
import tr.com.allianz.accounting_services.cyclic_postings.application.usecases.CreateCyclicMappingUseCase;
import tr.com.allianz.accounting_services.cyclic_postings.application.usecases.ListAlzCyclicAccountMappingUseCase;
import tr.com.allianz.accounting_services.cyclic_postings.application.usecases.RemoveAlzCyclicAccountMappingUseCase;
import tr.com.allianz.accounting_services.cyclic_postings.infrastructure.persistence.entity.AlzCyclicAccountMapping;
import tr.com.allianz.accounting_services.cyclic_postings.interfaces.web.dto.CreateAlzCyclicAccountMappingRequest;
import tr.com.allianz.accounting_services.cyclic_postings.interfaces.web.dto.RemoveAlzCyclicAccountMappingRequest;

import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)
class AlzCyclicAccountMappingControllerTest extends BaseUnitTestConfig {

    private MockMvc mockMvc;

    @Mock
    private CreateCyclicMappingUseCase createCyclicMappingUseCase;

    @Mock
    private ListAlzCyclicAccountMappingUseCase listAlzCyclicAccountMappingUseCase;

    @Mock
    private RemoveAlzCyclicAccountMappingUseCase removeAlzCyclicAccountMappingUseCase;


    @BeforeEach
    public void setup() {
        AlzCyclicAccountMappingController controller = new AlzCyclicAccountMappingController(
                createCyclicMappingUseCase,
                listAlzCyclicAccountMappingUseCase,
                removeAlzCyclicAccountMappingUseCase
        );
        mockMvc = MockMvcBuilders.standaloneSetup(controller).build();
    }

    @Test
    void createCyclicAccountMapping() throws Exception {

        String testAccountNo  ="testAcc";
        String testCyclicAccountNo = "testCyclicAcc";
        CreateAlzCyclicAccountMappingRequest createUserRequest = new CreateAlzCyclicAccountMappingRequest(
                testAccountNo,testCyclicAccountNo
        );
        AlzCyclicAccountMapping entity = new AlzCyclicAccountMapping(testAccountNo,testCyclicAccountNo);

        when(createCyclicMappingUseCase.handle(any()))
                .thenReturn(entity);

        mockMvc.perform(post("/api/v1/cyclic-account-mapping/create")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(createUserRequest)))
                .andExpect(status().isOk());
    }

    @Test
    void listAlzCyclicAccountMapping() throws Exception {
        String testAccountNo  ="testAcc";
        String testCyclicAccountNo = "testCyclicAcc";

        when(listAlzCyclicAccountMappingUseCase.handle())
                .thenReturn(List.of(new AlzCyclicAccountMappingReadModel(testAccountNo,testCyclicAccountNo))
        );

        mockMvc.perform(get("/api/v1/cyclic-account-mapping/list")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());


    }
    @Test
    void removeAlzCyclicAccountMapping() throws Exception {
        String testAccountNo  ="testAcc";

        RemoveAlzCyclicAccountMappingRequest removeAlzCyclicAccountMappingRequest  =new RemoveAlzCyclicAccountMappingRequest(testAccountNo);

        doNothing().when(removeAlzCyclicAccountMappingUseCase).handle(any());

        mockMvc.perform(post("/api/v1/cyclic-account-mapping/remove")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(removeAlzCyclicAccountMappingRequest))
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }
}