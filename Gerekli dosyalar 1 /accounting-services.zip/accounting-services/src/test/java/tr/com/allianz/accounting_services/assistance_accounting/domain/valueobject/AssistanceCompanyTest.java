package tr.com.allianz.accounting_services.assistance_accounting.domain.valueobject;

import org.junit.jupiter.api.Test;
import static org.assertj.core.api.Assertions.assertThat;

class AssistanceCompanyTest {

    @Test
    void shouldCreateAssistanceCompany() {
        Long intId = 1L;
        String extReference = "REF";
        String accountCode = "ACC";
        String agencyName = "Agency";

        AssistanceCompany company = new AssistanceCompany(intId, extReference, accountCode, agencyName);

        assertThat(company.getIntId()).isEqualTo(intId);
        assertThat(company.getExtReference()).isEqualTo(extReference);
        assertThat(company.getAccountCode()).isEqualTo(accountCode);
        assertThat(company.getAgencyName()).isEqualTo(agencyName);
    }
}

