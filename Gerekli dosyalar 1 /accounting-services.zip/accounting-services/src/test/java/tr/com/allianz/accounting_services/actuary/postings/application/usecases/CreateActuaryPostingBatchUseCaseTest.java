package tr.com.allianz.accounting_services.actuary.postings.application.usecases;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import tr.com.allianz.accounting_services.actuary.postings.application.port.out.CreateActuaryPostingBatchPort;
import tr.com.allianz.accounting_services.actuary.postings.domain.model.CreateActuaryPostingBatchResult;
import java.time.LocalDate;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
@ExtendWith(MockitoExtension.class)
class CreateActuaryPostingBatchUseCaseTest {
    @Mock
    private CreateActuaryPostingBatchPort createActuaryPostingBatchPort;
    @Test
    void handle_ShouldReturnCreatedResult_WhenBatchDoesNotExist() {
        CreateActuaryPostingBatchCommand command = new CreateActuaryPostingBatchCommand(10L, LocalDate.of(2026, 7, 15), "3401", 1);
        CreateActuaryPostingBatchResult expected = CreateActuaryPostingBatchResult.created(9001L);
        when(createActuaryPostingBatchPort.createBatch(command)).thenReturn(expected);
        CreateActuaryPostingBatchUseCase useCase = new CreateActuaryPostingBatchUseCase(createActuaryPostingBatchPort);
        CreateActuaryPostingBatchResult result = useCase.handle(command);
        assertThat(result.batchId()).isEqualTo(9001L);
        assertThat(result.batchAlreadyExists()).isFalse();
        verify(createActuaryPostingBatchPort).createBatch(command);
    }
    @Test
    void handle_ShouldReturnExistingResult_WhenBatchAlreadyExists() {
        CreateActuaryPostingBatchCommand command = new CreateActuaryPostingBatchCommand(10L, LocalDate.of(2026, 7, 15), "3401", 1);
        CreateActuaryPostingBatchResult expected = CreateActuaryPostingBatchResult.existing(5500L);
        when(createActuaryPostingBatchPort.createBatch(command)).thenReturn(expected);
        CreateActuaryPostingBatchUseCase useCase = new CreateActuaryPostingBatchUseCase(createActuaryPostingBatchPort);
        CreateActuaryPostingBatchResult result = useCase.handle(command);
        assertThat(result.batchId()).isEqualTo(5500L);
        assertThat(result.batchAlreadyExists()).isTrue();
        verify(createActuaryPostingBatchPort).createBatch(command);
    }
}