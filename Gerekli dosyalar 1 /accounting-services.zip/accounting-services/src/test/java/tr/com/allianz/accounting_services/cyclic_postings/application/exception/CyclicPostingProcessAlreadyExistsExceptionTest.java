package tr.com.allianz.accounting_services.cyclic_postings.application.exception;


import tr.com.allianz.accounting_services.shared.exception.BaseApplicationException;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class CyclicPostingProcessAlreadyExistsExceptionTest {

    @Test
    void shouldCreateExceptionWithCorrectValues() {
        // Given
        Long batchId = 12345L;

        // When
        CyclicPostingProcessAlreadyExistsException exception =
            new CyclicPostingProcessAlreadyExistsException(batchId);

        // Then
        assertThat(exception.getBatchId()).isEqualTo(batchId);
        assertThat(exception.getErrorCode()).isEqualTo("CYCLIC_POSTING_PROCESS_ALREADY_EXISTS");
        assertThat(exception.getMessage()).isEqualTo("Cyclic posting process is already exists.");
        assertThat(exception.getBatchId()).isEqualTo(12345L);
    }

    @Test
    void shouldInheritFromBaseApplicationException() {
        // Given
        Long batchId = 12345L;

        // When
        CyclicPostingProcessAlreadyExistsException exception =
            new CyclicPostingProcessAlreadyExistsException(batchId);

        // Then
        assertThat(exception).isInstanceOf(BaseApplicationException.class);
    }
}