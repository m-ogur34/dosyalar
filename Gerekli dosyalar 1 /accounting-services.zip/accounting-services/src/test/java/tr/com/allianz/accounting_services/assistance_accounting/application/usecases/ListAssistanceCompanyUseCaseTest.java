package tr.com.allianz.accounting_services.assistance_accounting.application.usecases;

import org.junit.jupiter.api.Test;
import tr.com.allianz.accounting_services.assistance_accounting.application.port.out.LoadAssistanceCompanyPort;
import tr.com.allianz.accounting_services.assistance_accounting.domain.valueobject.AssistanceCompany;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

class ListAssistanceCompanyUseCaseTest {

    @Test
    void shouldReturnAssistanceCompanies() {
        LoadAssistanceCompanyPort loadAssistanceCompanyPort = mock(LoadAssistanceCompanyPort.class);
        ListAssistanceCompanyUseCase useCase = new ListAssistanceCompanyUseCase(loadAssistanceCompanyPort);
        AssistanceCompany company = new AssistanceCompany(1L, "REF1", "ACC1", "Agency1");

        when(loadAssistanceCompanyPort.loadAssistanceCompanies()).thenReturn(List.of(company));

        List<AssistanceCompany> result = useCase.handle();

        assertThat(result).hasSize(1);
        assertThat(result.getFirst()).isEqualTo(company);
        verify(loadAssistanceCompanyPort).loadAssistanceCompanies();
    }
}

