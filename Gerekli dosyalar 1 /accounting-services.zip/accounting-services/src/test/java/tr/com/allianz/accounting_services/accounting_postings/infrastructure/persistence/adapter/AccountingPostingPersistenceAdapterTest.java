package tr.com.allianz.accounting_services.accounting_postings.infrastructure.persistence.adapter;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Answers;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.DataRetrievalFailureException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import tr.com.allianz.accounting_services.accounting_postings.application.exception.CreatePostingFailedException;
import tr.com.allianz.accounting_services.accounting_postings.infrastructure.persistence.dto.CreatePostingOracleResponseDataDto;
import tr.com.allianz.accounting_services.accounting_postings.infrastructure.persistence.dto.CreatePostingOracleResponseDto;
import tr.com.allianz.accounting_services.accounting_postings.interfaces.web.dto.CreatePostingRequest;
import tr.com.allianz.accounting_services.accounting_postings.interfaces.web.dto.ReversePostingRequest;
import tr.com.allianz.accounting_services.accounting_postings.interfaces.web.dto.ReversePostingResponse;
import tr.com.allianz.accounting_services.accounting_postings.infrastructure.persistence.dto.ReversePostingOracleResponseDto;

import java.sql.Clob;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AccountingPostingPersistenceAdapterTest {

    @Mock
    private JdbcTemplate jdbcTemplate;

    @Mock
    private ObjectMapper objectMapper;

    @Mock(answer = Answers.RETURNS_SELF)
    private SimpleJdbcCall simpleJdbcCall;

    private AccountingPostingPersistenceAdapter adapter;

    @BeforeEach
    void setUp() {
        adapter = new AccountingPostingPersistenceAdapter(jdbcTemplate, objectMapper) {
            @Override
            protected SimpleJdbcCall createSimpleJdbcCall() {
                return simpleJdbcCall;
            }
        };
    }

    @Test
    void testCreatePosting_SuccessWithStringResponse() throws Exception {
        CreatePostingRequest request = new CreatePostingRequest();
        when(objectMapper.writeValueAsString(any())).thenReturn("{}");

        Map<String, Object> outMap = new HashMap<>();
        String jsonResponse = "{\"succeeded\":true,\"data\":{\"batchId\":123}}";
        outMap.put("p_response", jsonResponse);
        when(simpleJdbcCall.execute(any(MapSqlParameterSource.class))).thenReturn(outMap);

        CreatePostingOracleResponseDto responseDto = new CreatePostingOracleResponseDto();
        responseDto.setSuccess(true);
        CreatePostingOracleResponseDataDto dataDto = new CreatePostingOracleResponseDataDto();
        dataDto.setBatchId(123L);
        responseDto.setData(dataDto);

        when(objectMapper.readValue(eq(jsonResponse), eq(CreatePostingOracleResponseDto.class))).thenReturn(responseDto);

        Long batchId = adapter.createPosting(request);
        assertEquals(123L, batchId);
    }

    @Test
    void testCreatePosting_SuccessWithClobResponse() throws Exception {
        CreatePostingRequest request = new CreatePostingRequest();
        when(objectMapper.writeValueAsString(any())).thenReturn("{}");

        Map<String, Object> outMap = new HashMap<>();
        Clob clob = mock(Clob.class);
        String jsonResponse = "{\"succeeded\":true,\"data\":{\"batchId\":456}}";
        when(clob.length()).thenReturn((long) jsonResponse.length());
        when(clob.getSubString(1, jsonResponse.length())).thenReturn(jsonResponse);
        outMap.put("p_response", clob);
        when(simpleJdbcCall.execute(any(MapSqlParameterSource.class))).thenReturn(outMap);

        CreatePostingOracleResponseDto responseDto = new CreatePostingOracleResponseDto();
        responseDto.setSuccess(true);
        CreatePostingOracleResponseDataDto dataDto = new CreatePostingOracleResponseDataDto();
        dataDto.setBatchId(456L);
        responseDto.setData(dataDto);

        when(objectMapper.readValue(eq(jsonResponse), eq(CreatePostingOracleResponseDto.class))).thenReturn(responseDto);

        Long batchId = adapter.createPosting(request);
        assertEquals(456L, batchId);
    }

    @Test
    void testCreatePosting_NullResponse() throws Exception {
        CreatePostingRequest request = new CreatePostingRequest();
        when(objectMapper.writeValueAsString(any())).thenReturn("{}");
        Map<String, Object> outMap = new HashMap<>();
        when(simpleJdbcCall.execute(any(MapSqlParameterSource.class))).thenReturn(outMap);
        assertThrows(CreatePostingFailedException.class, () -> adapter.createPosting(request));
    }

    @Test
    void testCreatePosting_FailureFromOracle() throws Exception {
        CreatePostingRequest request = new CreatePostingRequest();
        when(objectMapper.writeValueAsString(any())).thenReturn("{}");

        Map<String, Object> outMap = new HashMap<>();
        String jsonResponse = "{\"succeeded\":false,\"exception\":\"My Error\"}";
        outMap.put("p_response", jsonResponse);
        when(simpleJdbcCall.execute(any(MapSqlParameterSource.class))).thenReturn(outMap);

        CreatePostingOracleResponseDto responseDto = new CreatePostingOracleResponseDto();
        responseDto.setSuccess(false);
        responseDto.setException("My Error");

        when(objectMapper.readValue(eq(jsonResponse), eq(CreatePostingOracleResponseDto.class))).thenReturn(responseDto);

        CreatePostingFailedException exception = assertThrows(CreatePostingFailedException.class, () -> adapter.createPosting(request));
        String actualDetail = exception.getDetail();
        String expectedDetail = "My Error";
        assertEquals(expectedDetail, actualDetail);
    }

    @Test
    void testCreatePosting_FailureFromOracle_NullException() throws Exception {
        CreatePostingRequest request = new CreatePostingRequest();
        when(objectMapper.writeValueAsString(any())).thenReturn("{}");

        Map<String, Object> outMap = new HashMap<>();
        String jsonResponse = "{\"succeeded\":false}";
        outMap.put("p_response", jsonResponse);
        when(simpleJdbcCall.execute(any(MapSqlParameterSource.class))).thenReturn(outMap);

        CreatePostingOracleResponseDto responseDto = new CreatePostingOracleResponseDto();
        responseDto.setSuccess(false);

        when(objectMapper.readValue(eq(jsonResponse), eq(CreatePostingOracleResponseDto.class))).thenReturn(responseDto);

        CreatePostingFailedException exception = assertThrows(CreatePostingFailedException.class, () -> adapter.createPosting(request));
        String actualDetail = exception.getDetail();
        String expectedDetail = "PL/SQL fırlatma hatası.";
        assertEquals(expectedDetail, actualDetail);
    }

    @Test
    void testCreatePosting_JsonProcessingExceptionInRequest() throws Exception {
        CreatePostingRequest request = new CreatePostingRequest();
        when(objectMapper.writeValueAsString(any())).thenThrow(mock(JsonProcessingException.class));
        assertThrows(CreatePostingFailedException.class, () -> adapter.createPosting(request));
    }

    @Test
    void testCreatePosting_DataAccessException() throws Exception {
        CreatePostingRequest request = new CreatePostingRequest();
        when(objectMapper.writeValueAsString(any())).thenReturn("{}");
        when(simpleJdbcCall.execute(any(MapSqlParameterSource.class))).thenThrow(new DataRetrievalFailureException("DB Error"));
        assertThrows(CreatePostingFailedException.class, () -> adapter.createPosting(request));
    }

    @Test
    void testCreatePosting_NullData() throws Exception {
        CreatePostingRequest request = new CreatePostingRequest();
        when(objectMapper.writeValueAsString(any())).thenReturn("{}");
        Map<String, Object> outMap = new HashMap<>();
        String jsonResponse = "{\"succeeded\":true}";
        outMap.put("p_response", jsonResponse);
        when(simpleJdbcCall.execute(any(MapSqlParameterSource.class))).thenReturn(outMap);

        CreatePostingOracleResponseDto responseDto = new CreatePostingOracleResponseDto();
        responseDto.setSuccess(true);

        when(objectMapper.readValue(eq(jsonResponse), eq(CreatePostingOracleResponseDto.class))).thenReturn(responseDto);

        assertThrows(CreatePostingFailedException.class, () -> adapter.createPosting(request));
    }

    @Test
    void testReversePosting_Success() throws Exception {
        ReversePostingRequest request = new ReversePostingRequest();
        when(objectMapper.writeValueAsString(any())).thenReturn("{}");

        Map<String, Object> outMap = new HashMap<>();
        String jsonResponse = "{\"succeeded\":true,\"data\":[{\"batchId\":123, \"reverseBatchId\":456}]}";
        outMap.put("p_response", jsonResponse);
        when(simpleJdbcCall.execute(any(MapSqlParameterSource.class))).thenReturn(outMap);

        ReversePostingOracleResponseDto responseDto = new ReversePostingOracleResponseDto();
        responseDto.setSuccess(true);
        ReversePostingResponse dataDto = new ReversePostingResponse();
        dataDto.setBatchId(123L);
        dataDto.setReverseBatchId(456L);
        responseDto.setData(Collections.singletonList(dataDto));

        when(objectMapper.readValue(eq(jsonResponse), eq(ReversePostingOracleResponseDto.class))).thenReturn(responseDto);

        List<ReversePostingResponse> result = adapter.reversePosting(Collections.singletonList(request));
        assertEquals(1, result.size());
        assertEquals(123L, result.get(0).getBatchId());
        assertEquals(456L, result.get(0).getReverseBatchId());
    }

    @Test
    void testReversePosting_FailureFromOracle() throws Exception {
        ReversePostingRequest request = new ReversePostingRequest();
        when(objectMapper.writeValueAsString(any())).thenReturn("{}");

        Map<String, Object> outMap = new HashMap<>();
        String jsonResponse = "{\"succeeded\":false,\"exception\":\"My Reverse Error\"}";
        outMap.put("p_response", jsonResponse);
        when(simpleJdbcCall.execute(any(MapSqlParameterSource.class))).thenReturn(outMap);

        ReversePostingOracleResponseDto responseDto = new ReversePostingOracleResponseDto();
        responseDto.setSuccess(false);
        responseDto.setException("My Reverse Error");

        when(objectMapper.readValue(eq(jsonResponse), eq(ReversePostingOracleResponseDto.class))).thenReturn(responseDto);

        CreatePostingFailedException exception = assertThrows(CreatePostingFailedException.class, () -> adapter.reversePosting(Collections.singletonList(request)));
        assertTrue("My Reverse Error".equals(exception.getDetail()));
    }

    @Test
    void testReversePosting_SuccessWithClobResponse() throws Exception {
        ReversePostingRequest request = new ReversePostingRequest();
        when(objectMapper.writeValueAsString(any())).thenReturn("{}");

        Map<String, Object> outMap = new HashMap<>();
        Clob clob = mock(Clob.class);
        String jsonResponse = "{\"succeeded\":true,\"data\":[{\"batchId\":123, \"reverseBatchId\":456}]}";
        when(clob.length()).thenReturn((long) jsonResponse.length());
        when(clob.getSubString(1, jsonResponse.length())).thenReturn(jsonResponse);
        outMap.put("p_response", clob);
        when(simpleJdbcCall.execute(any(MapSqlParameterSource.class))).thenReturn(outMap);

        ReversePostingOracleResponseDto responseDto = new ReversePostingOracleResponseDto();
        responseDto.setSuccess(true);
        ReversePostingResponse dataDto = new ReversePostingResponse();
        dataDto.setBatchId(123L);
        dataDto.setReverseBatchId(456L);
        responseDto.setData(Collections.singletonList(dataDto));

        when(objectMapper.readValue(eq(jsonResponse), eq(ReversePostingOracleResponseDto.class))).thenReturn(responseDto);

        List<ReversePostingResponse> result = adapter.reversePosting(Collections.singletonList(request));
        assertEquals(1, result.size());
        assertEquals(456L, result.get(0).getReverseBatchId());
    }

    @Test
    void testReversePosting_NullResponse() throws Exception {
        ReversePostingRequest request = new ReversePostingRequest();
        when(objectMapper.writeValueAsString(any())).thenReturn("{}");
        Map<String, Object> outMap = new HashMap<>();
        when(simpleJdbcCall.execute(any(MapSqlParameterSource.class))).thenReturn(outMap);
        assertThrows(CreatePostingFailedException.class, () -> adapter.reversePosting(Collections.singletonList(request)));
    }

    @Test
    void testReversePosting_FailureFromOracle_NullException() throws Exception {
        ReversePostingRequest request = new ReversePostingRequest();
        when(objectMapper.writeValueAsString(any())).thenReturn("{}");

        Map<String, Object> outMap = new HashMap<>();
        String jsonResponse = "{\"succeeded\":false}";
        outMap.put("p_response", jsonResponse);
        when(simpleJdbcCall.execute(any(MapSqlParameterSource.class))).thenReturn(outMap);

        ReversePostingOracleResponseDto responseDto = new ReversePostingOracleResponseDto();
        responseDto.setSuccess(false);

        when(objectMapper.readValue(eq(jsonResponse), eq(ReversePostingOracleResponseDto.class))).thenReturn(responseDto);

        CreatePostingFailedException exception = assertThrows(CreatePostingFailedException.class, () -> adapter.reversePosting(Collections.singletonList(request)));
        assertTrue("PL/SQL fırlatma hatası.".equals(exception.getDetail()));
    }

    @Test
    void testReversePosting_JsonProcessingExceptionInRequest() throws Exception {
        ReversePostingRequest request = new ReversePostingRequest();
        when(objectMapper.writeValueAsString(any())).thenThrow(mock(JsonProcessingException.class));
        assertThrows(CreatePostingFailedException.class, () -> adapter.reversePosting(Collections.singletonList(request)));
    }

    @Test
    void testReversePosting_DataAccessException() throws Exception {
        ReversePostingRequest request = new ReversePostingRequest();
        when(objectMapper.writeValueAsString(any())).thenReturn("{}");
        when(simpleJdbcCall.execute(any(MapSqlParameterSource.class))).thenThrow(new DataRetrievalFailureException("DB Error"));
        assertThrows(CreatePostingFailedException.class, () -> adapter.reversePosting(Collections.singletonList(request)));
    }

}
