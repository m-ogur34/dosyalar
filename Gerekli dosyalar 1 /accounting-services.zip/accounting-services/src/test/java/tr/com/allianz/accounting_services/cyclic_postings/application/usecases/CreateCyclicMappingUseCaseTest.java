package tr.com.allianz.accounting_services.cyclic_postings.application.usecases;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import tr.com.allianz.accounting_services.cyclic_postings.application.port.out.CyclicPostingMappingPort;
import tr.com.allianz.accounting_services.cyclic_postings.infrastructure.persistence.entity.AlzCyclicAccountMapping;
import tr.com.allianz.accounting_services.cyclic_postings.interfaces.web.dto.CreateAlzCyclicAccountMappingRequest;

import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CreateCyclicMappingUseCaseTest {

    @InjectMocks
    CreateCyclicMappingUseCase createCyclicMappingUseCase;

    @Mock
    CyclicPostingMappingPort cyclicPostingMappingPort;

    @Test
    public void testHandle(){

        String testAccountNo  ="testAcc";
        String testCyclicAccountNo = "testCyclicAcc";

        CreateAlzCyclicAccountMappingRequest request = new CreateAlzCyclicAccountMappingRequest(
                testAccountNo,testCyclicAccountNo
        );

        CreateCyclicMappingCommand command = request.toCommand();
        AlzCyclicAccountMapping entity = new AlzCyclicAccountMapping(command.accountNo(),command.cyclicAccountNo());

        when(cyclicPostingMappingPort.createCyclicPostingMapping(command))
                .thenReturn(entity);

        AlzCyclicAccountMapping result = createCyclicMappingUseCase.handle(request);
        Assertions.assertEquals(entity,result);
    }

}