package tr.com.allianz.accounting_services.actuary.postings.interfaces.web;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import tr.com.allianz.accounting_services.actuary.postings.application.usecases.CreateActuaryPostingBatchCommand;
import tr.com.allianz.accounting_services.actuary.postings.application.usecases.CreateActuaryPostingBatchUseCase;
import tr.com.allianz.accounting_services.actuary.postings.domain.model.CreateActuaryPostingBatchResult;
import tr.com.allianz.accounting_services.actuary.postings.interfaces.web.dto.CreateActuaryPostingBatchRequest;
import tr.com.allianz.accounting_services.actuary.postings.interfaces.web.dto.CreateActuaryPostingBatchResponse;
import tr.com.allianz.accounting_services.shared.api.ApiResponse;
import java.time.LocalDate;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
@ExtendWith(MockitoExtension.class)
class CreateActuaryPostingBatchControllerTest {
    @Mock
    private CreateActuaryPostingBatchUseCase createActuaryPostingBatchUseCase;
    private final CreateActuaryPostingBatchRequest request = new CreateActuaryPostingBatchRequest(10L, LocalDate.of(2026, 7, 15), "3401", 1);
    private final CreateActuaryPostingBatchCommand expectedCommand = new CreateActuaryPostingBatchCommand(10L, LocalDate.of(2026, 7, 15), "3401", 1);
    @Test
    void createBatch_ShouldReturn201AndBatchId_WhenBatchCreatedSuccessfully() {
        when(createActuaryPostingBatchUseCase.handle(expectedCommand)).thenReturn(CreateActuaryPostingBatchResult.created(9001L));
        CreateActuaryPostingBatchController controller = new CreateActuaryPostingBatchController(createActuaryPostingBatchUseCase);
        ResponseEntity<ApiResponse<CreateActuaryPostingBatchResponse>> response = controller.createBatch(request);
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.CREATED);
        assertThat(response.getBody().data().batchId()).isEqualTo(9001L);
        assertThat(response.getBody().data().batchAlreadyExists()).isFalse();
        assertThat(response.getBody().code()).isEqualTo("ACTUARY_POSTING_BATCH_CREATED");
        verify(createActuaryPostingBatchUseCase).handle(expectedCommand);
    }
    @Test
    void createBatch_ShouldReturn200WithExistingFlag_WhenBatchAlreadyExists() {
        when(createActuaryPostingBatchUseCase.handle(expectedCommand)).thenReturn(CreateActuaryPostingBatchResult.existing(5500L));
        CreateActuaryPostingBatchController controller = new CreateActuaryPostingBatchController(createActuaryPostingBatchUseCase);
        ResponseEntity<ApiResponse<CreateActuaryPostingBatchResponse>> response = controller.createBatch(request);
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody().data().batchId()).isEqualTo(5500L);
        assertThat(response.getBody().data().batchAlreadyExists()).isTrue();
        assertThat(response.getBody().code()).isEqualTo("ACTUARY_POSTING_BATCH_ALREADY_EXISTS");
        assertThat(response.getBody().data().message()).contains("mevcuttur");
        verify(createActuaryPostingBatchUseCase).handle(expectedCommand);
    }
}