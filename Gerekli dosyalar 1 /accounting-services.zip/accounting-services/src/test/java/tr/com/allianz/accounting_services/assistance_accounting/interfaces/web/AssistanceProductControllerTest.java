package tr.com.allianz.accounting_services.assistance_accounting.interfaces.web;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import tr.com.allianz.accounting_services.assistance_accounting.application.usecases.ListAssistanceProductUseCase;
import tr.com.allianz.accounting_services.assistance_accounting.domain.valueobject.AssistanceProduct;

import java.util.Collections;
import java.util.List;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)
class AssistanceProductControllerTest {

    private MockMvc mockMvc;

    @Mock
    private ListAssistanceProductUseCase listAssistanceProductUseCase;

    @BeforeEach
    void setUp() {
        AssistanceProductController controller = new AssistanceProductController(listAssistanceProductUseCase);
        mockMvc = MockMvcBuilders.standaloneSetup(controller).build();
    }

    @Test
    void listAssistanceProducts_ShouldReturnListOfProducts() throws Exception {
        AssistanceProduct product = new AssistanceProduct(101L, "REF-101", "Test Product");
        when(listAssistanceProductUseCase.handle(null)).thenReturn(List.of(product));

        mockMvc.perform(get("/api/v1/assistance-product"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data[0].productId").value(101))
                .andExpect(jsonPath("$.data[0].extReference").value("REF-101"))
                .andExpect(jsonPath("$.data[0].longName").value("Test Product"));
    }

    @Test
    void listAssistanceProducts_ShouldReturnFilteredList_WhenAccCoverCodeProvided() throws Exception {
        String accCode = "ACC";
        AssistanceProduct product = new AssistanceProduct(101L, "REF", "Test Product");
        when(listAssistanceProductUseCase.handle(accCode)).thenReturn(List.of(product));

        mockMvc.perform(get("/api/v1/assistance-product").param("accCoverCode", accCode))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true));
    }

    @Test
    void listAssistanceProducts_ShouldReturnEmptyList_WhenNoProductsFound() throws Exception {
        when(listAssistanceProductUseCase.handle(null)).thenReturn(Collections.emptyList());

        mockMvc.perform(get("/api/v1/assistance-product"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data").isEmpty());
    }
}

