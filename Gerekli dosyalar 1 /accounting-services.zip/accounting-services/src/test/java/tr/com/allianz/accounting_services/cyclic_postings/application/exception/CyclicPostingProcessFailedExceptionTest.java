package tr.com.allianz.accounting_services.cyclic_postings.application.exception;

import tr.com.allianz.accounting_services.shared.exception.BaseApplicationException;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class CyclicPostingProcessFailedExceptionTest {


    @Test
    void shouldCreateExceptionWithCorrectValues() {
        // Given
        Long batchId = 12345L;

        // When
        CyclicPostingProcessFailedException exception = new CyclicPostingProcessFailedException(batchId);

        // Then
        assertThat(exception.getBatchId()).isEqualTo(batchId);
        assertThat(exception.getErrorCode()).isEqualTo("CYCLIC_POSTING_PROCESS_FAILED");
        assertThat(exception.getMessage()).isEqualTo("Muhasebeleştirme süreci başarısız oldu.");
        assertThat(exception.getBatchId()).isEqualTo(12345L);
    }

    @Test
    void shouldInheritFromBaseApplicationException() {
        // Given
        Long batchId = 12345L;

        // When
        CyclicPostingProcessFailedException exception = new CyclicPostingProcessFailedException(batchId);

        // Then
        assertThat(exception).isInstanceOf(BaseApplicationException.class);
    }

}