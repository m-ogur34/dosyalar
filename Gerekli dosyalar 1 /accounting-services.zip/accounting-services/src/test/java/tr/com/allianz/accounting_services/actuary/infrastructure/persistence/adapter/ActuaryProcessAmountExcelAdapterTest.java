package tr.com.allianz.accounting_services.actuary.infrastructure.persistence.adapter;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mock.web.MockMultipartFile;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.ActuaryProcessAmountExcelRow;
import tr.com.allianz.accounting_services.actuary.infrastructure.persistence.entity.AlzActProcessRules;
import tr.com.allianz.accounting_services.actuary.infrastructure.persistence.repository.AlzActProcessRulesRepository;

import java.io.ByteArrayOutputStream;
import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ActuaryProcessAmountExcelAdapterTest {

    @Mock
    private AlzActProcessRulesRepository alzActProcessRulesRepository;

    @Test
    void parse_ShouldReadRowsFromExcel() throws Exception {
        byte[] excelBytes = createSampleWorkbook();
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "amounts.xlsx",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                excelBytes
        );

        ActuaryProcessAmountExcelAdapter adapter = new ActuaryProcessAmountExcelAdapter(alzActProcessRulesRepository);
        List<ActuaryProcessAmountExcelRow> rows = adapter.parse(file);

        assertThat(rows).hasSize(1);
        assertThat(rows.getFirst().processId()).isEqualTo("P001");
        assertThat(rows.getFirst().ruleId()).isEqualTo(100);
        assertThat(rows.getFirst().ruleName()).isEqualTo("TestRule");
        assertThat(rows.getFirst().grossCyAmount()).isEqualByComparingTo(new BigDecimal("1000"));
    }

    @Test
    void parse_ShouldReadRowsFromAllSheetsInWorkbookOrder() throws Exception {
        byte[] excelBytes = createWorkbookWithMultipleSheets();
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "amounts-multiple-sheets.xlsx",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                excelBytes
        );

        ActuaryProcessAmountExcelAdapter adapter = new ActuaryProcessAmountExcelAdapter(alzActProcessRulesRepository);
        List<ActuaryProcessAmountExcelRow> rows = adapter.parse(file);

        assertThat(rows).hasSize(2);
        assertThat(rows).extracting(ActuaryProcessAmountExcelRow::processId)
                .containsExactly("P001", "P002");
        assertThat(rows.get(0).grossCyAmount()).isEqualByComparingTo(new BigDecimal("1000"));
        assertThat(rows.get(1).grossCyAmount()).isEqualByComparingTo(new BigDecimal("2000"));
    }

    @Test
    void parse_ShouldReadRowsWhenIfrsColumnsArePresent() throws Exception {
        byte[] excelBytes = createWorkbookWithAllColumns();
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "amounts-complete.xlsx",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                excelBytes
        );

        ActuaryProcessAmountExcelAdapter adapter = new ActuaryProcessAmountExcelAdapter(alzActProcessRulesRepository);
        List<ActuaryProcessAmountExcelRow> rows = adapter.parse(file);

        assertThat(rows).hasSize(1);
        assertThat(rows.getFirst().ruleId()).isEqualTo(100);
        assertThat(rows.getFirst().ruleName()).isEqualTo("TestRule");
        assertThat(rows.getFirst().ifrsCyGross()).isEqualByComparingTo(new BigDecimal("1100"));
        assertThat(rows.getFirst().ifrsPyNet()).isEqualByComparingTo(new BigDecimal("945"));
    }

    @Test
    void parse_ShouldReadTrfsRatesWithoutIfrsRates() throws Exception {
        byte[] excelBytes = createRateWorkbook(new String[]{
                "GROSS_CY_AMOUNT_RATE", "RE_CY_AMOUNT_RATE", "NET_CY_AMOUNT_RATE",
                "GROSS_PY_AMOUNT_RATE", "RE_PY_AMOUNT_RATE", "NET_PY_AMOUNT_RATE"
        });
        MockMultipartFile file = new MockMultipartFile(
                "file", "risk-adjrto-trfs-rates.xlsx",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelBytes);

        ActuaryProcessAmountExcelRow row = new ActuaryProcessAmountExcelAdapter(alzActProcessRulesRepository)
                .parse(file).getFirst();

        assertThat(row.grossCyAmountRate()).isEqualByComparingTo("0.10");
        assertThat(row.netPyAmountRate()).isEqualByComparingTo("0.30");
        assertThat(row.ifrsCyGrossRate()).isNull();
    }

    @Test
    void parse_ShouldReadIfrsRatesWithoutTrfsRates() throws Exception {
        byte[] excelBytes = createRateWorkbook(new String[]{
                "IFRS_CY_GROSS_RATE", "IFRS_CY_RE_RATE", "IFRS_CY_NET_RATE",
                "IFRS_PY_GROSS_RATE", "IFRS_PY_RE_RATE", "IFRS_PY_NET_RATE"
        });
        MockMultipartFile file = new MockMultipartFile(
                "file", "risk-adjrto-ifrs-rates.xlsx",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelBytes);

        ActuaryProcessAmountExcelRow row = new ActuaryProcessAmountExcelAdapter(alzActProcessRulesRepository)
                .parse(file).getFirst();

        assertThat(row.grossCyAmountRate()).isNull();
        assertThat(row.ifrsCyGrossRate()).isEqualByComparingTo("0.10");
        assertThat(row.ifrsPyNetRate()).isEqualByComparingTo("0.30");
    }

    @Test
    void parse_ShouldFindRuleIdWhenEmpty() throws Exception {
        byte[] excelBytes = createWorkbookWithEmptyRuleId();
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "amounts-no-rule-id.xlsx",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                excelBytes
        );

        String processId = "P001";
        String ruleName = "TestRule";
        
        AlzActProcessRules rule = new AlzActProcessRules();
        rule.setRuleId(100);
        rule.setRuleName(ruleName);
        rule.setProcessId(processId);
        
        when(alzActProcessRulesRepository.findByRuleNameAndProcessId(ruleName, processId))
                .thenReturn(Optional.of(rule));

        ActuaryProcessAmountExcelAdapter adapter = new ActuaryProcessAmountExcelAdapter(alzActProcessRulesRepository);
        List<ActuaryProcessAmountExcelRow> rows = adapter.parse(file);

        assertThat(rows).hasSize(1);
        assertThat(rows.getFirst().ruleId()).isEqualTo(100);
        assertThat(rows.getFirst().ruleName()).isEqualTo(ruleName);
    }

    @Test
    void parse_ShouldReadRowsFromXlsExcel() throws Exception {
        byte[] excelBytes = createSampleWorkbookXls();
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "amounts.xls",
                "application/vnd.ms-excel",
                excelBytes
        );

        ActuaryProcessAmountExcelAdapter adapter = new ActuaryProcessAmountExcelAdapter(alzActProcessRulesRepository);
        List<ActuaryProcessAmountExcelRow> rows = adapter.parse(file);

        assertThat(rows).hasSize(1);
        assertThat(rows.getFirst().processId()).isEqualTo("P001");
        assertThat(rows.getFirst().ruleId()).isEqualTo(100);
        assertThat(rows.getFirst().grossCyAmount()).isEqualByComparingTo(new BigDecimal("1000"));
    }

    @Test
    void parse_ShouldThrowWhenRuleIdIsMissingAndRuleCannotBeResolved() throws Exception {
        byte[] excelBytes = createWorkbookWithEmptyRuleId();
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "amounts-no-rule-id.xlsx",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                excelBytes
        );

        when(alzActProcessRulesRepository.findByRuleNameAndProcessId("TestRule", "P001"))
                .thenReturn(Optional.empty());

        ActuaryProcessAmountExcelAdapter adapter = new ActuaryProcessAmountExcelAdapter(alzActProcessRulesRepository);

        assertThatThrownBy(() -> adapter.parse(file))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("Rule ID bulunamadi");
    }

    @Test
    void parse_ShouldRejectInvalidFileFormat() {
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "amounts.txt",
                "text/plain",
                new byte[]{1, 2, 3}
        );

        ActuaryProcessAmountExcelAdapter adapter = new ActuaryProcessAmountExcelAdapter(alzActProcessRulesRepository);

        assertThatThrownBy(() -> adapter.parse(file))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("Geçersiz dosya formatı");
    }

    @Test
    void parse_ShouldThrowWhenExpectedHeadersAreMissing() throws Exception {
        byte[] excelBytes = createWorkbookWithInvalidHeaders();
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "amounts-invalid-headers.xlsx",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                excelBytes
        );

        ActuaryProcessAmountExcelAdapter adapter = new ActuaryProcessAmountExcelAdapter(alzActProcessRulesRepository);

        assertThatThrownBy(() -> adapter.parse(file))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("Beklenen Excel basliklari bulunamadi")
                .hasMessageContaining("Sheet: Sheet1");
    }

    @Test
    void parse_ShouldThrowWhenWorkbookContainsOnlyHeaders() throws Exception {
        byte[] excelBytes = createWorkbookWithHeadersOnly();
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "amounts-headers-only.xlsx",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                excelBytes
        );

        ActuaryProcessAmountExcelAdapter adapter = new ActuaryProcessAmountExcelAdapter(alzActProcessRulesRepository);

        assertThatThrownBy(() -> adapter.parse(file))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("Yuklenecek veri satiri bulunamadi");
    }

    @Test
    void parse_ShouldThrowWhenAmountCellContainsOnlyWhitespace() throws Exception {
        byte[] excelBytes = createWorkbookWithInvalidNumericText(
                new String[]{
                        "GROSS_CY_AMOUNT", "RE_CY_AMOUNT", "NET_CY_AMOUNT",
                        "GROSS_PY_AMOUNT", "RE_PY_AMOUNT", "NET_PY_AMOUNT"
                },
                "   "
        );
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "amounts-invalid-whitespace.xlsx",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                excelBytes
        );

        ActuaryProcessAmountExcelAdapter adapter = new ActuaryProcessAmountExcelAdapter(alzActProcessRulesRepository);

        assertThatThrownBy(() -> adapter.parse(file))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("Sayisal alanlarda sadece sayi olmalidir")
                .hasMessageContaining("Sheet: Sheet1")
                .hasMessageContaining("Kolon: 4 (D)")
                .hasMessageContaining("Baslik: GROSS_CY_AMOUNT");
    }

    @Test
    void parse_ShouldThrowWhenRateCellContainsNonNumericText() throws Exception {
        byte[] excelBytes = createWorkbookWithInvalidNumericText(
                new String[]{
                        "GROSS_CY_AMOUNT_RATE", "RE_CY_AMOUNT_RATE", "NET_CY_AMOUNT_RATE",
                        "GROSS_PY_AMOUNT_RATE", "RE_PY_AMOUNT_RATE", "NET_PY_AMOUNT_RATE"
                },
                "abc"
        );
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "rates-invalid-text.xlsx",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                excelBytes
        );

        ActuaryProcessAmountExcelAdapter adapter = new ActuaryProcessAmountExcelAdapter(alzActProcessRulesRepository);

        assertThatThrownBy(() -> adapter.parse(file))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("Sayisal alanlarda sadece sayi olmalidir")
                .hasMessageContaining("Sheet: Sheet1")
                .hasMessageContaining("Kolon: 4 (D)")
                .hasMessageContaining("Baslik: GROSS_CY_AMOUNT_RATE");
    }

    private byte[] createSampleWorkbook() throws Exception {
        try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            Sheet sheet = workbook.createSheet("Sheet1");

            Row header = sheet.createRow(0);
            header.createCell(0).setCellValue("PROCESS_ID");
            header.createCell(1).setCellValue("RULE_ID");
            header.createCell(2).setCellValue("RULE_NAME");
            header.createCell(3).setCellValue("GROSS_CY_AMOUNT");
            header.createCell(4).setCellValue("RE_CY_AMOUNT");
            header.createCell(5).setCellValue("NET_CY_AMOUNT");
            header.createCell(6).setCellValue("GROSS_PY_AMOUNT");
            header.createCell(7).setCellValue("RE_PY_AMOUNT");
            header.createCell(8).setCellValue("NET_PY_AMOUNT");

            Row row = sheet.createRow(1);
            row.createCell(0).setCellValue("P001");     // PROCESS_ID_COL
            row.createCell(1).setCellValue(100);          // RULE_ID_COL
            row.createCell(2).setCellValue("TestRule"); // RULE_NAME_COL
            row.createCell(3).setCellValue(1000);         // GROSS_CY_AMOUNT_COL
            row.createCell(4).setCellValue(100);          // RE_CY_AMOUNT_COL
            row.createCell(5).setCellValue(900);          // NET_CY_AMOUNT_COL
            row.createCell(6).setCellValue(950);          // GROSS_PY_AMOUNT_COL
            row.createCell(7).setCellValue(95);           // RE_PY_AMOUNT_COL
            row.createCell(8).setCellValue(855);          // NET_PY_AMOUNT_COL

            workbook.write(out);
            return out.toByteArray();
        }
    }

    private byte[] createWorkbookWithInvalidNumericText(String[] headers, String invalidValue) throws Exception {
        try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            Sheet sheet = workbook.createSheet("Sheet1");

            Row header = sheet.createRow(0);
            header.createCell(0).setCellValue("PROCESS_ID");
            header.createCell(1).setCellValue("RULE_ID");
            header.createCell(2).setCellValue("RULE_NAME");
            for (int i = 0; i < headers.length; i++) {
                header.createCell(i + 3).setCellValue(headers[i]);
            }

            Row row = sheet.createRow(1);
            row.createCell(0).setCellValue("P001");
            row.createCell(1).setCellValue(100);
            row.createCell(2).setCellValue("TestRule");
            row.createCell(3).setCellValue(invalidValue);

            workbook.write(out);
            return out.toByteArray();
        }
    }

    private byte[] createWorkbookWithMultipleSheets() throws Exception {
        try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            workbook.createSheet("EmptySheet");
            createAmountSheet(workbook, "FirstSheet", "P001", 1000);
            createAmountSheet(workbook, "SecondSheet", "P002", 2000);

            workbook.write(out);
            return out.toByteArray();
        }
    }

    private void createAmountSheet(Workbook workbook, String sheetName, String processId, int grossCyAmount) {
        Sheet sheet = workbook.createSheet(sheetName);

        Row header = sheet.createRow(0);
        header.createCell(0).setCellValue("PROCESS_ID");
        header.createCell(1).setCellValue("RULE_ID");
        header.createCell(2).setCellValue("RULE_NAME");
        header.createCell(3).setCellValue("GROSS_CY_AMOUNT");
        header.createCell(4).setCellValue("RE_CY_AMOUNT");
        header.createCell(5).setCellValue("NET_CY_AMOUNT");
        header.createCell(6).setCellValue("GROSS_PY_AMOUNT");
        header.createCell(7).setCellValue("RE_PY_AMOUNT");
        header.createCell(8).setCellValue("NET_PY_AMOUNT");

        Row row = sheet.createRow(1);
        row.createCell(0).setCellValue(processId);
        row.createCell(1).setCellValue(100);
        row.createCell(2).setCellValue("TestRule");
        row.createCell(3).setCellValue(grossCyAmount);
    }

    private byte[] createWorkbookWithAllColumns() throws Exception {
        try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            Sheet sheet = workbook.createSheet("Sheet1");

            Row header = sheet.createRow(0);
            header.createCell(0).setCellValue("PROCESS_ID");
            header.createCell(1).setCellValue("RULE_ID");
            header.createCell(2).setCellValue("RULE_NAME");
            header.createCell(3).setCellValue("IFRS_CY_GROSS");
            header.createCell(4).setCellValue("IFRS_CY_RE");
            header.createCell(5).setCellValue("IFRS_CY_NET");
            header.createCell(6).setCellValue("IFRS_PY_GROSS");
            header.createCell(7).setCellValue("IFRS_PY_RE");
            header.createCell(8).setCellValue("IFRS_PY_NET");

            Row row = sheet.createRow(1);
            row.createCell(0).setCellValue("P001");     // PROCESS_ID_COL
            row.createCell(1).setCellValue(100);          // RULE_ID_COL
            row.createCell(2).setCellValue("TestRule"); // RULE_NAME_COL
            row.createCell(3).setCellValue(1100);         // IFRS_CY_GROSS_COL
            row.createCell(4).setCellValue(110);          // IFRS_CY_RE_COL
            row.createCell(5).setCellValue(990);          // IFRS_CY_NET_COL
            row.createCell(6).setCellValue(1050);         // IFRS_PY_GROSS_COL
            row.createCell(7).setCellValue(105);          // IFRS_PY_RE_COL
            row.createCell(8).setCellValue(945);          // IFRS_PY_NET_COL

            workbook.write(out);
            return out.toByteArray();
        }
    }

    private byte[] createWorkbookWithEmptyRuleId() throws Exception {
        try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            Sheet sheet = workbook.createSheet("Sheet1");

            Row header = sheet.createRow(0);
            header.createCell(0).setCellValue("PROCESS_ID");
            header.createCell(1).setCellValue("RULE_ID");
            header.createCell(2).setCellValue("RULE_NAME");
            header.createCell(3).setCellValue("GROSS_CY_AMOUNT");
            header.createCell(4).setCellValue("RE_CY_AMOUNT");
            header.createCell(5).setCellValue("NET_CY_AMOUNT");
            header.createCell(6).setCellValue("GROSS_PY_AMOUNT");
            header.createCell(7).setCellValue("RE_PY_AMOUNT");
            header.createCell(8).setCellValue("NET_PY_AMOUNT");

            Row row = sheet.createRow(1);
            row.createCell(0).setCellValue("P001");      // PROCESS_ID_COL
            row.createCell(1).setCellValue("");          // RULE_ID_COL - empty
            row.createCell(2).setCellValue("TestRule");  // RULE_NAME_COL
            row.createCell(3).setCellValue(1000);          // GROSS_CY_AMOUNT_COL
            row.createCell(4).setCellValue(100);           // RE_CY_AMOUNT_COL
            row.createCell(5).setCellValue(900);           // NET_CY_AMOUNT_COL
            row.createCell(6).setCellValue(950);           // GROSS_PY_AMOUNT_COL
            row.createCell(7).setCellValue(95);            // RE_PY_AMOUNT_COL
            row.createCell(8).setCellValue(855);           // NET_PY_AMOUNT_COL

            workbook.write(out);
            return out.toByteArray();
        }
    }

    private byte[] createWorkbookWithInvalidHeaders() throws Exception {
        try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            Sheet sheet = workbook.createSheet("Sheet1");

            Row header = sheet.createRow(0);
            header.createCell(0).setCellValue("PROCESS_ID");
            header.createCell(1).setCellValue("RULE_ID");
            header.createCell(2).setCellValue("RULE_NAME");
            header.createCell(3).setCellValue("INVALID_1");
            header.createCell(4).setCellValue("INVALID_2");
            header.createCell(5).setCellValue("INVALID_3");
            header.createCell(6).setCellValue("INVALID_4");
            header.createCell(7).setCellValue("INVALID_5");
            header.createCell(8).setCellValue("INVALID_6");

            Row row = sheet.createRow(1);
            row.createCell(0).setCellValue("P001");
            row.createCell(1).setCellValue(100);
            row.createCell(2).setCellValue("TestRule");
            row.createCell(3).setCellValue(1000);

            workbook.write(out);
            return out.toByteArray();
        }
    }

    private byte[] createWorkbookWithHeadersOnly() throws Exception {
        try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            Sheet sheet = workbook.createSheet("Sheet1");

            Row header = sheet.createRow(0);
            header.createCell(0).setCellValue("PROCESS_ID");
            header.createCell(1).setCellValue("RULE_ID");
            header.createCell(2).setCellValue("RULE_NAME");
            header.createCell(3).setCellValue("GROSS_CY_AMOUNT");
            header.createCell(4).setCellValue("RE_CY_AMOUNT");
            header.createCell(5).setCellValue("NET_CY_AMOUNT");
            header.createCell(6).setCellValue("GROSS_PY_AMOUNT");
            header.createCell(7).setCellValue("RE_PY_AMOUNT");
            header.createCell(8).setCellValue("NET_PY_AMOUNT");

            workbook.write(out);
            return out.toByteArray();
        }
    }

    private byte[] createRateWorkbook(String[] rateHeaders) throws Exception {
        try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            Sheet sheet = workbook.createSheet("RISKADJRTO");
            Row header = sheet.createRow(0);
            header.createCell(0).setCellValue("PROCESS_ID");
            header.createCell(1).setCellValue("RULE_ID");
            header.createCell(2).setCellValue("RULE_NAME");
            for (int i = 0; i < rateHeaders.length; i++) {
                header.createCell(i + 3).setCellValue(rateHeaders[i]);
            }

            Row row = sheet.createRow(1);
            row.createCell(0).setCellValue("RISKADJRTO");
            row.createCell(1).setCellValue(1);
            row.createCell(2).setCellValue("Health Corporate");
            double[] rates = {0.10, 0.20, 0.70, 0.30, 0.40, 0.30};
            for (int i = 0; i < rates.length; i++) {
                row.createCell(i + 3).setCellValue(rates[i]);
            }

            workbook.write(out);
            return out.toByteArray();
        }
    }

    private byte[] createSampleWorkbookXls() throws Exception {
        try (Workbook workbook = new HSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            Sheet sheet = workbook.createSheet("Sheet1");

            Row header = sheet.createRow(0);
            header.createCell(0).setCellValue("PROCESS_ID");
            header.createCell(1).setCellValue("RULE_ID");
            header.createCell(2).setCellValue("RULE_NAME");
            header.createCell(3).setCellValue("GROSS_CY_AMOUNT");
            header.createCell(4).setCellValue("RE_CY_AMOUNT");
            header.createCell(5).setCellValue("NET_CY_AMOUNT");
            header.createCell(6).setCellValue("GROSS_PY_AMOUNT");
            header.createCell(7).setCellValue("RE_PY_AMOUNT");
            header.createCell(8).setCellValue("NET_PY_AMOUNT");

            Row row = sheet.createRow(1);
            row.createCell(0).setCellValue("P001");
            row.createCell(1).setCellValue(100);
            row.createCell(2).setCellValue("TestRule");
            row.createCell(3).setCellValue(1000);
            row.createCell(4).setCellValue(100);
            row.createCell(5).setCellValue(900);
            row.createCell(6).setCellValue(950);
            row.createCell(7).setCellValue(95);
            row.createCell(8).setCellValue(855);

            workbook.write(out);
            return out.toByteArray();
        }
    }
}

