package tr.com.allianz.accounting_services.actuary.application.usecases;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import tr.com.allianz.accounting_services.actuary.application.service.ActuaryLogService;
import tr.com.allianz.accounting_services.actuary.application.port.out.SaveActuaryPeriodStatusPort;
import tr.com.allianz.accounting_services.actuary.application.port.out.LoadActuaryPeriodStatusPort;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.ActuaryPeriodStatus;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ApproveActuaryPeriodUseCaseTest {

    @Mock
    private SaveActuaryPeriodStatusPort saveActuaryPeriodStatusPort;

    @Mock
    private LoadActuaryPeriodStatusPort loadActuaryPeriodStatusPort;

    @Mock
    private ActuaryLogService actuaryLogService;

    @InjectMocks
    private ApproveActuaryPeriodUseCase useCase;

    @Test
    void handle_ShouldSetStatusApproved() {
        when(loadActuaryPeriodStatusPort.getStatus("P1001", 2024, 6))
                .thenReturn(ActuaryPeriodStatus.IN_PROGRESS);

        useCase.handle("P1001", 2024, 6, "tester");

        verify(saveActuaryPeriodStatusPort)
                .upsertStatus("P1001", 2024, 6, ActuaryPeriodStatus.APPROVED);
        verify(actuaryLogService).logApprove("P1001", 2024, 6, "tester");
    }

    @Test
    void handle_ShouldRejectIfNotInProgress() {
        when(loadActuaryPeriodStatusPort.getStatus("P1001", 2024, 6))
                .thenReturn(ActuaryPeriodStatus.APPROVED);

        assertThatThrownBy(() -> useCase.handle("P1001", 2024, 6, "tester"))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("'In Progress' olmalıdır");
    }

    @Test
    void handle_ShouldRejectIfStatusIsNull() {
        when(loadActuaryPeriodStatusPort.getStatus("P1001", 2024, 6))
                .thenReturn(null);

        assertThatThrownBy(() -> useCase.handle("P1001", 2024, 6, "tester"))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("'In Progress' olmalıdır")
                .hasMessageContaining("yok");
    }

    @Test
    void handle_WithDefaultSystemUser_ShouldUseSystemUser() {
        when(loadActuaryPeriodStatusPort.getStatus("P1001", 2024, 6))
                .thenReturn(ActuaryPeriodStatus.IN_PROGRESS);

        useCase.handle("P1001", 2024, 6);

        verify(saveActuaryPeriodStatusPort)
                .upsertStatus("P1001", 2024, 6, ActuaryPeriodStatus.APPROVED);
        verify(actuaryLogService).logApprove("P1001", 2024, 6, "SYSTEM");
    }
}

