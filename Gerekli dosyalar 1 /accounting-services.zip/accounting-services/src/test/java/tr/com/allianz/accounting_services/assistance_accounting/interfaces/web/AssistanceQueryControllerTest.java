package tr.com.allianz.accounting_services.assistance_accounting.interfaces.web;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import tr.com.allianz.accounting_services.assistance_accounting.application.usecases.ListAssistanceQueryUseCase;
import tr.com.allianz.accounting_services.assistance_accounting.domain.valueobject.AssistanceQueryCriteria;
import tr.com.allianz.accounting_services.assistance_accounting.domain.valueobject.AssistanceQueryResult;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)
class AssistanceQueryControllerTest {

    private MockMvc mockMvc;

    @Mock
    private ListAssistanceQueryUseCase listAssistanceQueryUseCase;

    private final ObjectMapper objectMapper = new ObjectMapper();

    @BeforeEach
    void setUp() {
        AssistanceQueryController controller = new AssistanceQueryController(listAssistanceQueryUseCase);
        mockMvc = MockMvcBuilders.standaloneSetup(controller).build();
    }

    @Test
    void listAssistanceQueryResults_ShouldReturnList() throws Exception {
        AssistanceQueryCriteria criteria = new AssistanceQueryCriteria(
                BigDecimal.TEN, "ACC_CODE", 2023, 10, null, null, null, 1L
        );
        AssistanceQueryResult result = new AssistanceQueryResult(
                12345L, "Acc Exp", "LOB", "Dist Exp", 1, BigDecimal.TEN, null
        );
        when(listAssistanceQueryUseCase.handle(any(AssistanceQueryCriteria.class))).thenReturn(List.of(result));

        mockMvc.perform(post("/api/v1/assistance-query")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(criteria)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data[0].accountNo").value(12345));
    }

    @Test
    void listAssistanceQueryResults_ShouldReturnEmpty_WhenNoResults() throws Exception {
        AssistanceQueryCriteria criteria = new AssistanceQueryCriteria(
                BigDecimal.TEN, "ACC_CODE", 2023, 10, null, null, null, 1L
        );
        when(listAssistanceQueryUseCase.handle(any(AssistanceQueryCriteria.class))).thenReturn(Collections.emptyList());

        mockMvc.perform(post("/api/v1/assistance-query")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(criteria)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data").isEmpty());
    }
}

