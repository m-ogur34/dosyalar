package tr.com.allianz.accounting_services.actuary.infrastructure.persistence.adapter;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.ActuaryProcessRuleAmount;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.ActuaryQueryCriteria;
import tr.com.allianz.accounting_services.actuary.infrastructure.persistence.repository.AlzActProcessAmountsRepository;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ActuaryQueryAdapterTest {

    @Mock
    private AlzActProcessAmountsRepository repository;

    private ActuaryQueryAdapter adapter;

    @BeforeEach
    void setUp() {
        adapter = new ActuaryQueryAdapter(repository);
    }

    @Test
    void loadActuaryQueryResults_ShouldReturnMappedResults() {
        // Given
        String processId = "P1001";
        Integer year = 2024;
        Integer month = 6;
        ActuaryQueryCriteria criteria = new ActuaryQueryCriteria(processId, year, month);

        Object[] mockRow = {
                "RULE_NAME_1",           // ruleName
                2024,                    // year
                6,                       // month
                "P1001",                 // processId
                100,                     // ruleId
                new BigDecimal("1000"),  // grossCyAmount
                new BigDecimal("100"),   // reCyAmount
                new BigDecimal("900"),   // netCyAmount
                new BigDecimal("950"),   // grossPyAmount
                new BigDecimal("95"),    // rePyAmount
                new BigDecimal("855"),   // netPyAmount
                new BigDecimal("1100"),  // ifrsCyGross
                new BigDecimal("110"),   // ifrsCyRes
                new BigDecimal("990"),   // ifrsCyNet
                new BigDecimal("1050"),  // ifrsPyGross
                new BigDecimal("105"),   // ifrsPyRe
                new BigDecimal("945"),   // ifrsPyNet
                new BigDecimal("1.0"),   // grossCyAmountRate
                new BigDecimal("0.1"),   // reCyAmountRate
                new BigDecimal("0.9"),   // netCyAmountRate
                new BigDecimal("0.95"),  // grossPyAmountRate
                new BigDecimal("0.095"), // rePyAmountRate
                new BigDecimal("0.855"), // netPyAmountRate
                new BigDecimal("1.1"),   // ifrsCyGrossRate
                new BigDecimal("0.11"),  // ifrsCyReRate
                new BigDecimal("0.99"),  // ifrsCyNetRate
                new BigDecimal("1.05"),  // ifrsPyGrossRate
                new BigDecimal("0.105"), // ifrsPyReRate
                new BigDecimal("0.945")  // ifrsPyNetRate
        };

        Object[][] mockRows = {mockRow};
        List<Object[]> resultList = new ArrayList<>();
        resultList.add(mockRows[0]);
        
        when(repository.queryActuaryProcessRuleAmounts(processId, year, month))
                .thenReturn(resultList);

        // When
        List<ActuaryProcessRuleAmount> results = adapter.loadActuaryQueryResults(criteria);

        // Then
        assertThat(results).hasSize(1);
        ActuaryProcessRuleAmount result = results.get(0);
        assertThat(result.ruleName()).isEqualTo("RULE_NAME_1");
        assertThat(result.year()).isEqualTo(2024);
        assertThat(result.month()).isEqualTo(6);
        assertThat(result.processId()).isEqualTo("P1001");
        assertThat(result.ruleId()).isEqualTo(100);
        assertThat(result.grossCyAmount()).isEqualTo(new BigDecimal("1000"));
        
        verify(repository).queryActuaryProcessRuleAmounts(processId, year, month);
    }

    @Test
    void loadActuaryQueryResults_ShouldReturnEmptyListWhenNoResults() {
        // Given
        String processId = "P1001";
        Integer year = 2024;
        Integer month = 6;
        ActuaryQueryCriteria criteria = new ActuaryQueryCriteria(processId, year, month);

        when(repository.queryActuaryProcessRuleAmounts(processId, year, month))
                .thenReturn(List.of());

        // When
        List<ActuaryProcessRuleAmount> results = adapter.loadActuaryQueryResults(criteria);

        // Then
        assertThat(results).isEmpty();
        verify(repository).queryActuaryProcessRuleAmounts(processId, year, month);
    }
}

