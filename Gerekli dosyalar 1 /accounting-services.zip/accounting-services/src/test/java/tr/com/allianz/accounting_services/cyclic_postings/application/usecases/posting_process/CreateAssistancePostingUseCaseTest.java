package tr.com.allianz.accounting_services.cyclic_postings.application.usecases.posting_process;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import tr.com.allianz.accounting_services.assistance_accounting.application.port.out.CreateAssistancePostingPort;
import tr.com.allianz.accounting_services.assistance_accounting.application.usecases.CreateAssistancePostingCommand;
import tr.com.allianz.accounting_services.assistance_accounting.application.usecases.CreateAssistancePostingUseCase;

import java.math.BigDecimal;
import java.time.LocalDate;

import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class CreateAssistancePostingUseCaseTest {

    @Mock
    private CreateAssistancePostingPort createAssistancePostingPort;

    @InjectMocks
    private CreateAssistancePostingUseCase createAssistancePostingUseCase;

    @Test
    void handle_ShouldCallPort() {
        CreateAssistancePostingCommand command = new CreateAssistancePostingCommand(
                "INV123",
                LocalDate.now(),
                "Desc",
                LocalDate.now(),
                1L,
                2023,
                10,
                "ACC",
                BigDecimal.TEN,
                "EB",
                "100",
                "PART"
        );

        createAssistancePostingUseCase.handle(command);

        verify(createAssistancePostingPort).createAssistancePosting(command);
    }
}

