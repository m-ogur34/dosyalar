package tr.com.allianz.accounting_services.actuary.infrastructure.persistence.adapter;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.ActuaryProcess;
import tr.com.allianz.accounting_services.actuary.infrastructure.persistence.entity.AlzActProcesses;
import tr.com.allianz.accounting_services.actuary.infrastructure.persistence.repository.AlzActProcessesRepository;
import java.time.LocalDate;
import java.util.List;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ActuaryProcessesAdapterTest {
    @Mock
    private AlzActProcessesRepository repository;

    @InjectMocks
    private ActuaryProcessesAdapter adapter;

    private LocalDate today;

    @BeforeEach
    void setUp() {
        today = LocalDate.now();
    }

    @Test
    void loadActiveProcesses_ShouldMapEntityToDomain() {
        // Given
        AlzActProcesses entity = new AlzActProcesses("P1001", "Process 1", "Desc", today.minusDays(1), today.plusDays(1));
        when(repository.findActiveProcesses(today)).thenReturn(List.of(entity));

        // When
        List<ActuaryProcess> result = adapter.loadActiveProcesses(today);

        // Then
        assertThat(result).hasSize(1);
        assertThat(result.getFirst().processName()).isEqualTo("Process 1");
        verify(repository).findActiveProcesses(today);
    }

    @Test
    void loadActiveProcesses_ShouldReturnEmptyListWhenNoActiveProcesses() {
        // Given
        when(repository.findActiveProcesses(today)).thenReturn(List.of());

        // When
        List<ActuaryProcess> result = adapter.loadActiveProcesses(today);

        // Then
        assertThat(result).isEmpty();
        verify(repository).findActiveProcesses(today);
    }

    @Test
    void loadActiveProcesses_ShouldMapMultipleEntities() {
        // Given
        AlzActProcesses entity1 = new AlzActProcesses("P1001", "Process 1", "Desc 1", today.minusDays(1), today.plusDays(1));
        AlzActProcesses entity2 = new AlzActProcesses("P1002", "Process 2", "Desc 2", today.minusDays(2), today.plusDays(2));
        when(repository.findActiveProcesses(today)).thenReturn(List.of(entity1, entity2));

        // When
        List<ActuaryProcess> result = adapter.loadActiveProcesses(today);

        // Then
        assertThat(result).hasSize(2);
        assertThat(result.get(0).processId()).isEqualTo("P1001");
        assertThat(result.get(1).processId()).isEqualTo("P1002");
    }

    @Test
    void loadActiveProcesses_ShouldMapAllAttributes() {
        // Given
        LocalDate startDate = today.minusDays(10);
        LocalDate endDate = today.plusDays(10);
        AlzActProcesses entity = new AlzActProcesses("P9999", "Test Process", "Test Description", startDate, endDate);
        when(repository.findActiveProcesses(today)).thenReturn(List.of(entity));

        // When
        List<ActuaryProcess> result = adapter.loadActiveProcesses(today);

        // Then
        assertThat(result).hasSize(1);
        ActuaryProcess process = result.getFirst();
        assertThat(process.processId()).isEqualTo("P9999");
        assertThat(process.processName()).isEqualTo("Test Process");
        assertThat(process.explanation()).isEqualTo("Test Description");
        assertThat(process.validityStartDate()).isEqualTo(startDate);
        assertThat(process.validityEndDate()).isEqualTo(endDate);
    }

    @Test
    void loadActiveProcesses_WithDifferentDates_ShouldPassCorrectDateToRepository() {
        // Given
        LocalDate specificDate = LocalDate.of(2024, 6, 15);
        when(repository.findActiveProcesses(specificDate)).thenReturn(List.of());

        // When
        adapter.loadActiveProcesses(specificDate);

        // Then
        verify(repository).findActiveProcesses(specificDate);
    }
}
