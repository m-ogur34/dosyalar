package tr.com.allianz.accounting_services.actuary.infrastructure.persistence.adapter;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jdbc.core.PreparedStatementCallback;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.IfrsDistributionTotals;
import tr.com.allianz.accounting_services.actuary.infrastructure.persistence.entity.AlzActProcessRules;
import tr.com.allianz.accounting_services.actuary.infrastructure.persistence.repository.AlzActProcessRulesRepository;

import java.math.BigDecimal;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class IfrsDistributionTotalsAdapterTest {

    @Mock
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @Mock
    private AlzActProcessRulesRepository rulesRepository;

    @Test
    void loadPyTotals_ShouldAccumulateAllThreeAggregates() {
        AlzActProcessRules rule = new AlzActProcessRules();
        rule.setProcessId("P1001");
        rule.setRuleId(10);
        rule.setRuleText("branch_code = '01'");

        when(rulesRepository.findByProcessIdAndRuleIdIn("P1001", List.of(10))).thenReturn(List.of(rule));

        doAnswer(invocation -> {
            String sql = invocation.getArgument(0);
            assertThat(sql).doesNotContain("{RULE_CONDITION}").doesNotContain("branch_code = '01'");

            if (sql.contains("ORDER BY t.year DESC, t.month DESC")) {
                return invokeWithRows(invocation, List.of());
            }
            if (sql.contains("AND t.code = 'W'") && sql.contains("t.month = :month")) {
                return invokeWithRows(invocation, List.of(row(
                        "YEAR", 2026,
                        "MONTH", 6,
                        "BRANCH_CODE", "01"
                )));
            }
            if (sql.contains("t.year = :yearMinus1")) {
                return invokeWithRows(invocation, List.of(row(
                        "BRANCH_CODE", "01",
                        "gross_amount_component", new BigDecimal("300.00"),
                        "re_amount_component", new BigDecimal("50.00"),
                        "net_amount_component", new BigDecimal("250.00")
                )));
            }
            if (sql.contains("BETWEEN :yearMinus3 AND :yearMinus2")) {
                return invokeWithRows(invocation, List.of());
            }
            return invokeWithRows(invocation, List.of());
        }).when(namedParameterJdbcTemplate).execute(anyString(), any(MapSqlParameterSource.class), any());

        IfrsDistributionTotalsAdapter adapter =
                new IfrsDistributionTotalsAdapter(namedParameterJdbcTemplate, rulesRepository);
        IfrsDistributionTotals totals = adapter.loadPyTotals("P1001", 10, 2026, 6);

        assertThat(totals.grossAmountTotal()).isEqualByComparingTo("300.00");
        assertThat(totals.reAmountTotal()).isEqualByComparingTo("50.00");
        assertThat(totals.netAmountTotal()).isEqualByComparingTo("250.00");
    }

    @Test
    void loadPyTotals_ShouldSumAcrossAllThreePartitions() {
        AlzActProcessRules rule = new AlzActProcessRules();
        rule.setProcessId("P1001");
        rule.setRuleId(5);
        rule.setRuleText("product_code = 'AUTO'");

        when(rulesRepository.findByProcessIdAndRuleIdIn("P1001", List.of(5))).thenReturn(List.of(rule));

        doAnswer(invocation -> {
            String sql = invocation.getArgument(0);
            if (sql.contains("AND t.code = 'W'") && sql.contains("t.month = :month")) {
                return invokeWithRows(invocation, List.of(row(
                        "YEAR", 2025,
                        "MONTH", 12,
                        "PRODUCT_CODE", "AUTO"
                )));
            }
            if (sql.contains("t.year = :yearMinus1")) {
                return invokeWithRows(invocation, List.of(row(
                        "PRODUCT_CODE", "AUTO",
                        "gross_amount_component", BigDecimal.TEN,
                        "re_amount_component", BigDecimal.ONE,
                        "net_amount_component", new BigDecimal("2.00")
                )));
            }
            if (sql.contains("BETWEEN :yearMinus3 AND :yearMinus2")) {
                return invokeWithRows(invocation, List.of(row(
                        "PRODUCT_CODE", "AUTO",
                        "gross_amount_component", new BigDecimal("5.00"),
                        "re_amount_component", new BigDecimal("3.00"),
                        "net_amount_component", new BigDecimal("4.00")
                )));
            }
            return invokeWithRows(invocation, List.of(row(
                    "PRODUCT_CODE", "AUTO",
                    "gross_amount_component", new BigDecimal("2.00"),
                    "re_amount_component", new BigDecimal("1.00"),
                    "net_amount_component", new BigDecimal("1.00")
            )));
        }).when(namedParameterJdbcTemplate).execute(anyString(), any(MapSqlParameterSource.class), any());

        IfrsDistributionTotalsAdapter adapter =
                new IfrsDistributionTotalsAdapter(namedParameterJdbcTemplate, rulesRepository);
        IfrsDistributionTotals totals = adapter.loadPyTotals("P1001", 5, 2025, 12);

        assertThat(totals.grossAmountTotal()).isEqualByComparingTo("17.00"); // 10+5+2
        assertThat(totals.reAmountTotal()).isEqualByComparingTo("5.00");     // 1+3+1
        assertThat(totals.netAmountTotal()).isEqualByComparingTo("7.00");    // 2+4+1
    }

    @Test
    void loadPyTotals_ShouldUseLatestRulePeriodWhenRequestedPeriodHasNoMatchingRow() {
        AlzActProcessRules rule = new AlzActProcessRules();
        rule.setProcessId("P1001");
        rule.setRuleId(11);
        rule.setRuleText("branch_code = '01'");

        when(rulesRepository.findByProcessIdAndRuleIdIn("P1001", List.of(11))).thenReturn(List.of(rule));

        doAnswer(invocation -> {
            String sql = invocation.getArgument(0);
            MapSqlParameterSource params = invocation.getArgument(1);
            if (sql.contains("AND t.code = 'W'") && sql.contains("t.month = :month")) {
                return invokeWithRows(invocation, List.of());
            }
            if (sql.contains("ORDER BY t.year DESC, t.month DESC")) {
                return invokeWithRows(invocation, List.of(row(
                        "YEAR", 2025,
                        "MONTH", 12,
                        "BRANCH_CODE", "01"
                )));
            }
            if (sql.contains("t.year = :yearMinus1")) {
                assertThat(params.getValue("yearMinus1")).isEqualTo(2024);
                return invokeWithRows(invocation, List.of(row(
                        "BRANCH_CODE", "01",
                        "gross_amount_component", BigDecimal.TEN,
                        "re_amount_component", BigDecimal.ONE,
                        "net_amount_component", new BigDecimal("2.00")
                )));
            }
            if (sql.contains("BETWEEN :yearMinus3 AND :yearMinus2")) {
                assertThat(params.getValue("yearMinus2")).isEqualTo(2023);
                assertThat(params.getValue("yearMinus3")).isEqualTo(2022);
            } else {
                assertThat(params.getValue("yearMinus3")).isEqualTo(2022);
            }
            return invokeWithRows(invocation, List.of(row(
                    "BRANCH_CODE", "01",
                    "gross_amount_component", BigDecimal.TEN,
                    "re_amount_component", BigDecimal.ONE,
                    "net_amount_component", new BigDecimal("2.00")
            )));
        }).when(namedParameterJdbcTemplate).execute(anyString(), any(MapSqlParameterSource.class), any());

        IfrsDistributionTotalsAdapter adapter =
                new IfrsDistributionTotalsAdapter(namedParameterJdbcTemplate, rulesRepository);

        IfrsDistributionTotals totals = adapter.loadPyTotals("P1001", 11, 2026, 4);

        assertThat(totals.grossAmountTotal()).isEqualByComparingTo("30.00");
        assertThat(totals.reAmountTotal()).isEqualByComparingTo("3.00");
        assertThat(totals.netAmountTotal()).isEqualByComparingTo("6.00");
    }

    @Test
    void loadPyTotals_ShouldRejectUnsafeRuleText() {
        AlzActProcessRules rule = new AlzActProcessRules();
        rule.setProcessId("P1001");
        rule.setRuleId(10);
        rule.setRuleText("1=1; drop table x");

        when(rulesRepository.findByProcessIdAndRuleIdIn("P1001", List.of(10))).thenReturn(List.of(rule));

        IfrsDistributionTotalsAdapter adapter =
                new IfrsDistributionTotalsAdapter(namedParameterJdbcTemplate, rulesRepository);

        assertThatThrownBy(() -> adapter.loadPyTotals("P1001", 10, 2026, 6))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("IFRS rule text güvenli değil");
    }

    @Test
    void loadPyTotals_ShouldRejectTautologyRuleText() {
        AlzActProcessRules rule = new AlzActProcessRules();
        rule.setProcessId("P1001");
        rule.setRuleId(12);
        rule.setRuleText("product_code = 'AUTO' OR 1=1");

        when(rulesRepository.findByProcessIdAndRuleIdIn("P1001", List.of(12))).thenReturn(List.of(rule));

        IfrsDistributionTotalsAdapter adapter =
                new IfrsDistributionTotalsAdapter(namedParameterJdbcTemplate, rulesRepository);

        assertThatThrownBy(() -> adapter.loadPyTotals("P1001", 12, 2026, 6))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("IFRS rule text güvenli değil");
    }

    @Test
    void loadPyTotals_ShouldThrowWhenRuleNotFound() {
        when(rulesRepository.findByProcessIdAndRuleIdIn("P1001", List.of(99))).thenReturn(List.of());

        IfrsDistributionTotalsAdapter adapter =
                new IfrsDistributionTotalsAdapter(namedParameterJdbcTemplate, rulesRepository);

        assertThatThrownBy(() -> adapter.loadPyTotals("P1001", 99, 2026, 6))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("IFRS rule tanımı bulunamadı");
    }

    private Object invokeWithRows(InvocationOnMock invocation,
                                  List<Map<String, Object>> rows) throws Throwable {
        PreparedStatementCallback<?> callback = invocation.getArgument(2);
        return callback.doInPreparedStatement(preparedStatement(rows));
    }

    private java.sql.PreparedStatement preparedStatement(List<Map<String, Object>> rows) throws SQLException {
        java.sql.PreparedStatement ps = mock(java.sql.PreparedStatement.class);
        java.sql.ResultSet rs = mock(java.sql.ResultSet.class);
        ResultSetMetaData metaData = mock(ResultSetMetaData.class);
        when(ps.executeQuery()).thenReturn(rs);
        when(rs.getMetaData()).thenReturn(metaData);

        List<String> columns = rows.isEmpty() ? List.of() : new ArrayList<>(rows.getFirst().keySet());
        AtomicInteger index = new AtomicInteger(-1);
        when(rs.next()).thenAnswer(invocation -> index.incrementAndGet() < rows.size());
        lenient().when(metaData.getColumnCount()).thenReturn(columns.size());
        lenient().when(metaData.getColumnLabel(anyInt())).thenAnswer(invocation -> columns.get(invocation.getArgument(0, Integer.class) - 1));
        lenient().when(rs.getObject(anyInt())).thenAnswer(invocation -> {
            int currentIndex = index.get();
            if (currentIndex < 0 || currentIndex >= rows.size()) {
                return null;
            }
            return rows.get(currentIndex).get(columns.get(invocation.getArgument(0, Integer.class) - 1));
        });
        lenient().when(rs.getBigDecimal(anyString())).thenAnswer(invocation -> {
            int currentIndex = index.get();
            if (currentIndex < 0 || currentIndex >= rows.size()) {
                return null;
            }
            Object value = lookup(rows.get(currentIndex), invocation.getArgument(0, String.class));
            return value instanceof BigDecimal bigDecimal ? bigDecimal : null;
        });
        return ps;
    }

    private Object lookup(Map<String, Object> row, String key) {
        if (row.containsKey(key)) {
            return row.get(key);
        }
        for (Map.Entry<String, Object> entry : row.entrySet()) {
            if (entry.getKey().equalsIgnoreCase(key)) {
                return entry.getValue();
            }
        }
        return null;
    }

    private Map<String, Object> row(Object... keyValues) {
        Map<String, Object> row = new LinkedHashMap<>();
        for (int i = 0; i < keyValues.length; i += 2) {
            row.put((String) keyValues[i], keyValues[i + 1]);
        }
        return row;
    }
}
