package tr.com.allianz.accounting_services.accounting_postings.application.exception;

import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import tr.com.allianz.accounting_services.shared.exception.BaseApplicationException;

import static org.assertj.core.api.Assertions.assertThat;

class CreatePostingFailedExceptionTest {

    @Test
    void shouldCreateExceptionWithCorrectValues() {
        // Given
        String detail = "Database connection failed";

        // When
        CreatePostingFailedException exception = new CreatePostingFailedException(detail);

        // Then
        assertThat(exception.getErrorCode()).isEqualTo("CREATE_POSTING_FAILED");
        assertThat(exception.getMessage()).isEqualTo("Fiş oluşturma işlemi sırasında hata ile karşılaşıldı");
        assertThat(exception.getDetail()).isEqualTo(detail);
        assertThat(exception.getHttpStatus()).isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @Test
    void shouldInheritFromBaseApplicationException() {
        // Given
        String detail = "Invalid posting data";

        // When
        CreatePostingFailedException exception = new CreatePostingFailedException(detail);

        // Then
        assertThat(exception).isInstanceOf(BaseApplicationException.class);
    }

    @Test
    void shouldHaveCorrectHttpStatus() {
        // Given
        String detail = "Test error";

        // When
        CreatePostingFailedException exception = new CreatePostingFailedException(detail);

        // Then
        assertThat(exception.getHttpStatus()).isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @Test
    void shouldPreserveDetailMessage() {
        // Given
        String detail = "Very specific error message with details";

        // When
        CreatePostingFailedException exception = new CreatePostingFailedException(detail);

        // Then
        assertThat(exception.getDetail()).isEqualTo(detail);
    }

    @Test
    void shouldHaveErrorCode() {
        // When
        CreatePostingFailedException exception = new CreatePostingFailedException("Any detail");

        // Then
        assertThat(exception.getErrorCode()).isNotBlank();
        assertThat(exception.getErrorCode()).isEqualTo("CREATE_POSTING_FAILED");
    }
}

