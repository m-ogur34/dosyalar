package tr.com.allianz.accounting_services.assistance_accounting.infrastructure.persistence.adapter;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import tr.com.allianz.accounting_services.assistance_accounting.domain.valueobject.AccCoverCode;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AccCoverCodePersistenceAdapterTest {

    @Mock
    private JdbcTemplate jdbcTemplate;

    @InjectMocks
    private AccCoverCodePersistenceAdapter adapter;

    @Test
    void loadAccCoverCodes_ShouldReturnMappedList() {
        // Given
        AccCoverCode accCoverCode = new AccCoverCode("CODE1", "Desc 1");
        when(jdbcTemplate.query(anyString(), any(RowMapper.class))).thenReturn(List.of(accCoverCode));

        // When
        List<AccCoverCode> result = adapter.loadAccCoverCodes();

        // Then
        assertThat(result).hasSize(1);
        assertThat(result.get(0)).isEqualTo(accCoverCode);
        verify(jdbcTemplate).query(anyString(), any(RowMapper.class));
    }
}

