package tr.com.allianz.accounting_services.assistance_accounting.infrastructure.persistence.adapter;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import tr.com.allianz.accounting_services.assistance_accounting.domain.valueobject.AssistancePartition;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AssistancePartitionPersistenceAdapterTest {

    @Mock
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @InjectMocks
    private AssistancePartitionPersistenceAdapter adapter;

    @Test
    void loadAssistancePartitions_ShouldReturnMappedPartitions() {
        // Given
        List<Long> productIds = List.of(100L);
        AssistancePartition partition = new AssistancePartition("TypeA", "Desc");
        when(namedParameterJdbcTemplate.query(anyString(), any(SqlParameterSource.class), any(RowMapper.class))).thenReturn(List.of(partition));

        // When
        List<AssistancePartition> result = adapter.loadAssistancePartitions(productIds);

        // Then
        assertThat(result).hasSize(1);
        assertThat(result.getFirst()).isEqualTo(partition);

        verify(namedParameterJdbcTemplate).query(anyString(), any(SqlParameterSource.class), any(RowMapper.class));
    }
}

