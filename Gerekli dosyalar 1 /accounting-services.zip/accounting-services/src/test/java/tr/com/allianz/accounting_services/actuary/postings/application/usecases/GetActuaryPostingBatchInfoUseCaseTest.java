package tr.com.allianz.accounting_services.actuary.postings.application.usecases;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import tr.com.allianz.accounting_services.actuary.postings.application.port.out.LoadActuaryPostingBatchInfoPort;
import tr.com.allianz.accounting_services.actuary.postings.domain.model.ActuaryPostingBatchInfoLine;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class GetActuaryPostingBatchInfoUseCaseTest {

    @Mock
    private LoadActuaryPostingBatchInfoPort loadActuaryPostingBatchInfoPort;

    @Test
    void handle_ShouldReturnBatchInfoLinesFromPort() {
        GetActuaryPostingBatchInfoCommand command = new GetActuaryPostingBatchInfoCommand(
                10L,
                LocalDate.of(2026, 7, 17),
                "3401",
                60L,
                "PARTITION",
                1
        );
        List<ActuaryPostingBatchInfoLine> expected = List.of(
                new ActuaryPostingBatchInfoLine("100", "Cash", "Line 1", BigDecimal.TEN, BigDecimal.ZERO)
        );
        when(loadActuaryPostingBatchInfoPort.loadBatchInfo(command)).thenReturn(expected);

        GetActuaryPostingBatchInfoUseCase useCase =
                new GetActuaryPostingBatchInfoUseCase(loadActuaryPostingBatchInfoPort);

        List<ActuaryPostingBatchInfoLine> result = useCase.handle(command);

        assertThat(result).isEqualTo(expected);
        verify(loadActuaryPostingBatchInfoPort, times(1)).loadBatchInfo(command);
    }
}

