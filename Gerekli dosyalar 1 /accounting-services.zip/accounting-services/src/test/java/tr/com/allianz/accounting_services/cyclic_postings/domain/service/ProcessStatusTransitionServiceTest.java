package tr.com.allianz.accounting_services.cyclic_postings.domain.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;
import tr.com.allianz.accounting_services.cyclic_postings.domain.valueobject.ProcessStatus;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class ProcessStatusTransitionServiceTest {

    private ProcessStatusTransitionService service;

    @BeforeEach
    void setUp() {
        service = new ProcessStatusTransitionService();
    }

    @Test
    void shouldTransitionToProcessedWhenStatusIsCreated() {
        // Given
        ProcessStatus currentStatus = ProcessStatus.CREATED;

        // When
        ProcessStatus result = service.transitionToProcessed(currentStatus);

        // Then
        assertThat(result).isEqualTo(ProcessStatus.PROCESSED);
    }

    @Test
    void shouldThrowExceptionWhenTransitionToProcessedFromProcessedStatus() {
        // Given
        ProcessStatus currentStatus = ProcessStatus.PROCESSED;

        // When & Then
        assertThatThrownBy(() -> service.transitionToProcessed(currentStatus))
            .isInstanceOf(IllegalStateException.class)
            .hasMessageContaining("Cannot transition to PROCESSED from status: " + currentStatus);
    }

    @Test
    void shouldThrowExceptionWhenTransitionToProcessedFromErrorOccurredStatus() {
        // Given
        ProcessStatus currentStatus = ProcessStatus.ERROR_OCCURRED;

        // When & Then
        assertThatThrownBy(() -> service.transitionToProcessed(currentStatus))
            .isInstanceOf(IllegalStateException.class)
            .hasMessageContaining("Cannot transition to PROCESSED from status: " + currentStatus);
    }

    @Test
    void shouldTransitionToErrorWhenStatusIsCreated() {
        // Given
        ProcessStatus currentStatus = ProcessStatus.CREATED;

        // When
        ProcessStatus result = service.transitionToError(currentStatus);

        // Then
        assertThat(result).isEqualTo(ProcessStatus.ERROR_OCCURRED);
    }

    @Test
    void shouldThrowExceptionWhenTransitionToErrorFromProcessedStatus() {
        // Given
        ProcessStatus currentStatus = ProcessStatus.PROCESSED;

        // When & Then
        assertThatThrownBy(() -> service.transitionToError(currentStatus))
            .isInstanceOf(IllegalStateException.class)
            .hasMessageContaining("Cannot transition to ERROR_OCCURRED from status: " + currentStatus);
    }

    @Test
    void shouldThrowExceptionWhenTransitionToErrorFromErrorOccurredStatus() {
        // Given
        ProcessStatus currentStatus = ProcessStatus.ERROR_OCCURRED;

        // When & Then
        assertThatThrownBy(() -> service.transitionToError(currentStatus))
            .isInstanceOf(IllegalStateException.class)
            .hasMessageContaining("Cannot transition to ERROR_OCCURRED from status: " + currentStatus);
    }

    @Test
    void shouldReturnTrueWhenCanTransitionToProcessedFromCreatedStatus() {
        // Given
        ProcessStatus currentStatus = ProcessStatus.CREATED;

        // When
        boolean result = service.canTransitionToProcessed(currentStatus);

        // Then
        assertThat(result).isTrue();
    }

    @Test
    void shouldReturnFalseWhenCannotTransitionToProcessedFromProcessedStatus() {
        // Given
        ProcessStatus currentStatus = ProcessStatus.PROCESSED;

        // When
        boolean result = service.canTransitionToProcessed(currentStatus);

        // Then
        assertThat(result).isFalse();
    }

    @Test
    void shouldReturnFalseWhenCannotTransitionToProcessedFromErrorOccurredStatus() {
        // Given
        ProcessStatus currentStatus = ProcessStatus.ERROR_OCCURRED;

        // When
        boolean result = service.canTransitionToProcessed(currentStatus);

        // Then
        assertThat(result).isFalse();
    }

    @Test
    void shouldReturnTrueWhenCanTransitionToErrorFromCreatedStatus() {
        // Given
        ProcessStatus currentStatus = ProcessStatus.CREATED;

        // When
        boolean result = service.canTransitionToError(currentStatus);

        // Then
        assertThat(result).isTrue();
    }

    @Test
    void shouldReturnFalseWhenCannotTransitionToErrorFromProcessedStatus() {
        // Given
        ProcessStatus currentStatus = ProcessStatus.PROCESSED;

        // When
        boolean result = service.canTransitionToError(currentStatus);

        // Then
        assertThat(result).isFalse();
    }

    @Test
    void shouldReturnFalseWhenCannotTransitionToErrorFromErrorOccurredStatus() {
        // Given
        ProcessStatus currentStatus = ProcessStatus.ERROR_OCCURRED;

        // When
        boolean result = service.canTransitionToError(currentStatus);

        // Then
        assertThat(result).isFalse();
    }

    @ParameterizedTest
    @EnumSource(value = ProcessStatus.class, names = {"PROCESSED", "ERROR_OCCURRED"})
    void shouldNotAllowTransitionToProcessedFromNonCreatedStatuses(ProcessStatus status) {
        // When & Then
        assertThatThrownBy(() -> service.transitionToProcessed(status))
            .isInstanceOf(IllegalStateException.class);

        assertThat(service.canTransitionToProcessed(status)).isFalse();
    }

    @ParameterizedTest
    @EnumSource(value = ProcessStatus.class, names = {"PROCESSED", "ERROR_OCCURRED"})
    void shouldNotAllowTransitionToErrorFromNonCreatedStatuses(ProcessStatus status) {
        // When & Then
        assertThatThrownBy(() -> service.transitionToError(status))
            .isInstanceOf(IllegalStateException.class);

        assertThat(service.canTransitionToError(status)).isFalse();
    }
}