package tr.com.allianz.accounting_services.shared.exception;

import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;

import static org.assertj.core.api.Assertions.assertThat;

class BaseApplicationExceptionTest {

    private static class TestException extends BaseApplicationException {
        protected TestException(String errorCode, String message, String detail, HttpStatus httpStatus) {
            super(errorCode, message, detail, httpStatus);
        }
    }

    @Test
    void shouldCreateExceptionWithCorrectFields() {
        // Arrange
        String errorCode = "TEST_ERROR";
        String message = "Something went wrong";
        String detail = "More details about error";
        HttpStatus status = HttpStatus.BAD_REQUEST;

        // Act
        TestException exception = new TestException(errorCode, message, detail, status);

        // Assert
        assertThat(exception.getErrorCode()).isEqualTo(errorCode);
        assertThat(exception.getMessage()).isEqualTo(message);
        assertThat(exception.getDetail()).isEqualTo(detail);
        assertThat(exception.getHttpStatus()).isEqualTo(status);
    }
}

