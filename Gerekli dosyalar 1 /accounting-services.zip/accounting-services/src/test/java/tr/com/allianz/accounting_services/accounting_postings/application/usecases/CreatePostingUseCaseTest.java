package tr.com.allianz.accounting_services.accounting_postings.application.usecases;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import tr.com.allianz.accounting_services.accounting_postings.application.port.out.CreatePostingPort;
import tr.com.allianz.accounting_services.accounting_postings.interfaces.web.dto.CreatePostingRequest;
import tr.com.allianz.accounting_services.accounting_postings.interfaces.web.dto.CreatePostingResponse;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CreatePostingUseCaseTest {

    @Mock
    private CreatePostingPort createPostingPort;

    @InjectMocks
    private CreatePostingUseCase createPostingUseCase;

    @Test
    void testHandle() {
        CreatePostingRequest request = new CreatePostingRequest();
        when(createPostingPort.createPosting(request)).thenReturn(999L);
        
        CreatePostingResponse response = createPostingUseCase.handle(request);
        
        assertEquals(999L, response.getBatchId());
    }
}
