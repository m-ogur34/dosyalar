package tr.com.allianz.accounting_services.assistance_accounting.domain.valueobject;

import org.junit.jupiter.api.Test;
import static org.assertj.core.api.Assertions.assertThat;

class AssistanceProductValueObjectTest {

    @Test
    void shouldCreateAssistanceProduct() {
        Long productId = 101L;
        String extReference = "REF-101";
        String longName = "Test Product";

        AssistanceProduct product = new AssistanceProduct(productId, extReference, longName);

        assertThat(product.productId()).isEqualTo(productId);
        assertThat(product.extReference()).isEqualTo(extReference);
        assertThat(product.longName()).isEqualTo(longName);
    }
}

