package tr.com.allianz.accounting_services.assistance_accounting.application.usecases;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import tr.com.allianz.accounting_services.assistance_accounting.application.port.out.LoadAccCoverCodePort;
import tr.com.allianz.accounting_services.assistance_accounting.domain.valueobject.AccCoverCode;

import java.util.Collections;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ListAccCoverCodeUseCaseTest {

    @Mock
    private LoadAccCoverCodePort loadAccCoverCodePort;

    @InjectMocks
    private ListAccCoverCodeUseCase listAccCoverCodeUseCase;

    @Test
    void handle_ShouldReturnListFromPort() {
        // Given
        AccCoverCode accCoverCode = new AccCoverCode("CODE", "DESC");
        List<AccCoverCode> expectedList = List.of(accCoverCode);
        when(loadAccCoverCodePort.loadAccCoverCodes()).thenReturn(expectedList);

        // When
        List<AccCoverCode> result = listAccCoverCodeUseCase.handle();

        // Then
        assertThat(result).hasSize(1);
        assertThat(result).isEqualTo(expectedList);
        verify(loadAccCoverCodePort).loadAccCoverCodes();
    }

    @Test
    void handle_ShouldReturnEmptyList_WhenPortReturnsEmpty() {
        // Given
        when(loadAccCoverCodePort.loadAccCoverCodes()).thenReturn(Collections.emptyList());

        // When
        List<AccCoverCode> result = listAccCoverCodeUseCase.handle();

        // Then
        assertThat(result).isEmpty();
        verify(loadAccCoverCodePort).loadAccCoverCodes();
    }
}

