package tr.com.allianz.accounting_services.cyclic_postings.application.exception;

import tr.com.allianz.accounting_services.shared.exception.BaseApplicationException;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class AcxPostingNotFoundExceptionTest {

    @Test
    void shouldCreateExceptionWithCorrectValues() {
        // Given
        Long batchId = 12345L;

        // When
        AcxPostingNotFoundException exception = new AcxPostingNotFoundException(batchId);

        // Then
        assertThat(exception.getBatchId()).isEqualTo(batchId);
        assertThat(exception.getErrorCode()).isEqualTo("POSTING_NOT_FOUND");
        assertThat(exception.getMessage()).isEqualTo("Fiş sistemde bulunamadı");
    }

    @Test
    void shouldInheritFromBaseApplicationException() {
        // Given
        Long batchId = 12345L;

        // When
        AcxPostingNotFoundException exception = new AcxPostingNotFoundException(batchId);

        // Then
        assertThat(exception).isInstanceOf(BaseApplicationException.class);
    }

    @Test
    void shouldContainBatchIdInDetailedMessage() {
        // Given
        Long batchId = 99999L;

        // When
        AcxPostingNotFoundException exception = new AcxPostingNotFoundException(batchId);

        // Then
        assertThat(exception.getDetail()).contains("Fiş nosu 99999 olan fiş sistemde bulunamadı.");
    }
}