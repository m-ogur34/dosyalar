package tr.com.allianz.accounting_services.actuary.infrastructure.persistence.adapter;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InOrder;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import java.time.LocalDate;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.inOrder;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CleanupUndiscountedReserveReportsAdapterTest {

    @Mock
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @Test
    void cleanup_ShouldUseUndiscountedReserveFilterAndDeleteSubRowsBeforeMainRows() {
        when(namedParameterJdbcTemplate.queryForList(
                anyString(), any(MapSqlParameterSource.class), eq(Long.class)
        )).thenReturn(List.of(101L, 202L));

        CleanupUndiscountedReserveReportsAdapter adapter =
                new CleanupUndiscountedReserveReportsAdapter(namedParameterJdbcTemplate);

        adapter.cleanup(LocalDate.of(2026, 6, 30));

        ArgumentCaptor<String> queryCaptor = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> deleteSqlCaptor = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<MapSqlParameterSource> queryParametersCaptor =
                ArgumentCaptor.forClass(MapSqlParameterSource.class);
        ArgumentCaptor<MapSqlParameterSource> refParametersCaptor =
                ArgumentCaptor.forClass(MapSqlParameterSource.class);
        InOrder order = inOrder(namedParameterJdbcTemplate);

        order.verify(namedParameterJdbcTemplate).queryForList(
                queryCaptor.capture(), queryParametersCaptor.capture(), eq(Long.class)
        );
        order.verify(namedParameterJdbcTemplate, times(4)).update(
                deleteSqlCaptor.capture(), refParametersCaptor.capture()
        );

        assertThat(queryParametersCaptor.getValue().getValue("year")).isEqualTo(2026);
        assertThat(queryParametersCaptor.getValue().getValue("month")).isEqualTo(6);
        assertThat(queryCaptor.getValue().toLowerCase())
                .contains("last_day(to_date(:year || lpad(:month, 2, '0'), 'yyyymm'))")
                .contains("rs.trans_sub_type in ('3001', '3002')");
        assertThat(deleteSqlCaptor.getAllValues().get(0).toLowerCase())
                .contains("delete from customer.alz_reports_data_sub");
        assertThat(deleteSqlCaptor.getAllValues().get(1).toLowerCase())
                .contains("delete from customer.alz_reports_data");
        assertThat(refParametersCaptor.getAllValues().get(0).getValue("ref_id")).isEqualTo(101L);
        assertThat(refParametersCaptor.getAllValues().get(1).getValue("ref_id")).isEqualTo(101L);
        assertThat(refParametersCaptor.getAllValues().get(2).getValue("ref_id")).isEqualTo(202L);
        assertThat(refParametersCaptor.getAllValues().get(3).getValue("ref_id")).isEqualTo(202L);
    }
}
