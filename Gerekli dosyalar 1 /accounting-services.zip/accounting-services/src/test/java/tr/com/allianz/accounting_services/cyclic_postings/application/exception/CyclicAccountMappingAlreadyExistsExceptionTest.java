package tr.com.allianz.accounting_services.cyclic_postings.application.exception;


import tr.com.allianz.accounting_services.shared.exception.BaseApplicationException;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class CyclicAccountMappingAlreadyExistsExceptionTest {

    @Test
    void testAlreadyExistsException() {
        String accountNo = "testAccountNo";
        CyclicAccountMappingAlreadyExistsException ex =
                new CyclicAccountMappingAlreadyExistsException(accountNo);

        assertThat(ex.getErrorCode()).isEqualTo("CYCLIC_ACCOUNT_MAPPING_ALREADY_EXISTS");
        assertThat(ex.getMessage()).isEqualTo("Cyclic account mapping already exists.");
        assertThat(ex.getDetail()).isEqualTo("Account with no " + accountNo +
                " mapping already exists.");
        assertThat(ex.getAccountNo()).isEqualTo(accountNo);
    }

    @Test
    void shouldInheritFromBaseApplicationException() {
        String accountNo = "testAccountNo";
        CyclicAccountMappingAlreadyExistsException ex =
                new CyclicAccountMappingAlreadyExistsException(accountNo);

        assertThat(ex).isInstanceOf(BaseApplicationException.class);
    }
}