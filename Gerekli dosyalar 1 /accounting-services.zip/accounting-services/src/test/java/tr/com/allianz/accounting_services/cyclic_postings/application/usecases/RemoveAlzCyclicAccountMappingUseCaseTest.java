package tr.com.allianz.accounting_services.cyclic_postings.application.usecases;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import tr.com.allianz.accounting_services.cyclic_postings.application.port.out.CyclicPostingMappingPort;
import tr.com.allianz.accounting_services.cyclic_postings.interfaces.web.dto.RemoveAlzCyclicAccountMappingRequest;

import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class RemoveAlzCyclicAccountMappingUseCaseTest {

    @InjectMocks
    RemoveAlzCyclicAccountMappingUseCase useCase;

    @Mock
    CyclicPostingMappingPort cyclicPostingMappingPort;


    @Test
    void handle() {
        String testAccountNo  ="testAcc";

        RemoveAlzCyclicAccountMappingRequest request = new RemoveAlzCyclicAccountMappingRequest(
                testAccountNo
        );

        doNothing().when(cyclicPostingMappingPort)
                .removeCyclicPostingMapping(request);

        useCase.handle(request);
        verify(cyclicPostingMappingPort).removeCyclicPostingMapping(request);
    }
}