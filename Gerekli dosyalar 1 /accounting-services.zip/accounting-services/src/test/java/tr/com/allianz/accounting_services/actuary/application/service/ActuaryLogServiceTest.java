package tr.com.allianz.accounting_services.actuary.application.service;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import tr.com.allianz.accounting_services.actuary.application.usecases.SaveActuaryLogUseCase;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.ActuaryLogType;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.times;

@ExtendWith(MockitoExtension.class)
class ActuaryLogServiceTest {

    @Mock
    private SaveActuaryLogUseCase saveActuaryLogUseCase;

    @InjectMocks
    private ActuaryLogService actuaryLogService;

    @Test
    void logQuery_ShouldCallSaveActuaryLogUseCaseWithQueryLogType() {
        // Given
        String processId = "P1001";
        Integer year = 2024;
        Integer month = 6;
        String byUser = "test-user";

        // When
        actuaryLogService.logQuery(processId, year, month, byUser);

        // Then
        verify(saveActuaryLogUseCase, times(1)).handle(
                year,
                month,
                processId,
                null,
                ActuaryLogType.QUERY,
                "Actuary query executed",
                byUser
        );
    }

    @Test
    void logApprove_ShouldCallSaveActuaryLogUseCaseWithApproveLogType() {
        // Given
        String processId = "P1001";
        Integer year = 2024;
        Integer month = 6;
        String byUser = "test-user";

        // When
        actuaryLogService.logApprove(processId, year, month, byUser);

        // Then
        verify(saveActuaryLogUseCase, times(1)).handle(
                year,
                month,
                processId,
                null,
                ActuaryLogType.APPROVE,
                "Actuary period approved",
                byUser
        );
    }

    @Test
    void logInProgress_ShouldCallSaveActuaryLogUseCaseWithInProgressLogType() {
        // Given
        String processId = "P1001";
        Integer year = 2024;
        Integer month = 6;
        String byUser = "test-user";

        // When
        actuaryLogService.logInProgress(processId, year, month, byUser);

        // Then
        verify(saveActuaryLogUseCase, times(1)).handle(
                year,
                month,
                processId,
                null,
                ActuaryLogType.IN_PROGRESS,
                "Actuary period set to In Progress",
                byUser
        );
    }

    @Test
    void logExcelUpload_ShouldCallSaveActuaryLogUseCaseWithExcelUploadLogType() {
        // Given
        String processId = "P1001";
        Integer year = 2024;
        Integer month = 6;
        Integer recordCount = 100;
        String byUser = "test-user";

        // When
        actuaryLogService.logExcelUpload(processId, year, month, recordCount, byUser);

        // Then
        verify(saveActuaryLogUseCase, times(1)).handle(
                year,
                month,
                processId,
                null,
                ActuaryLogType.EXCEL_UPLOAD,
                "Excel file uploaded with " + recordCount + " records",
                byUser
        );
    }

    @Test
    void logAmountUpdate_ShouldCallSaveActuaryLogUseCaseWithAmountUpdateLogType() {
        // Given
        String processId = "P1001";
        Integer year = 2024;
        Integer month = 6;
        Integer ruleId = 123;
        String changeDescription = "Amount updated for rule";
        String byUser = "test-user";

        // When
        actuaryLogService.logAmountUpdate(processId, year, month, ruleId, changeDescription, byUser);

        // Then
        verify(saveActuaryLogUseCase, times(1)).handle(
                year,
                month,
                processId,
                ruleId,
                ActuaryLogType.AMOUNT_UPDATE,
                changeDescription,
                byUser
        );
    }

    @Test
    void logError_ShouldCallSaveActuaryLogUseCaseWithErrorLogType() {
        // Given
        String processId = "P1001";
        Integer year = 2024;
        Integer month = 6;
        String errorMessage = "An error occurred";
        String byUser = "test-user";

        // When
        actuaryLogService.logError(processId, year, month, errorMessage, byUser);

        // Then
        verify(saveActuaryLogUseCase, times(1)).handle(
                year,
                month,
                processId,
                null,
                ActuaryLogType.ERROR,
                errorMessage,
                byUser
        );
    }
}

