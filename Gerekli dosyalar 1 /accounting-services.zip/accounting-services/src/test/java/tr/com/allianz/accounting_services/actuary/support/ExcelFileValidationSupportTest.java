package tr.com.allianz.accounting_services.actuary.support;

import org.junit.jupiter.api.Test;
import org.springframework.mock.web.MockMultipartFile;

import static org.assertj.core.api.Assertions.assertThatCode;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class ExcelFileValidationSupportTest {

    private static final String INVALID_EXTENSION_MESSAGE = "invalid extension";
    private static final String INVALID_CONTENT_TYPE_MESSAGE = "invalid content type";

    @Test
    void validateExcelType_ShouldAcceptXlsxFile() {
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "amounts.xlsx",
                ExcelFileValidationSupport.XLSX_CONTENT_TYPE,
                new byte[]{1, 2, 3}
        );

        assertThatCode(() -> ExcelFileValidationSupport.validateExcelType(
                file,
                INVALID_EXTENSION_MESSAGE,
                INVALID_CONTENT_TYPE_MESSAGE
        )).doesNotThrowAnyException();
    }

    @Test
    void validateExcelType_ShouldAcceptXlsFile() {
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "amounts.xls",
                ExcelFileValidationSupport.XLS_CONTENT_TYPE,
                new byte[]{1, 2, 3}
        );

        assertThatCode(() -> ExcelFileValidationSupport.validateExcelType(
                file,
                INVALID_EXTENSION_MESSAGE,
                INVALID_CONTENT_TYPE_MESSAGE
        )).doesNotThrowAnyException();
    }

    @Test
    void validateExcelType_ShouldRejectInvalidExtension() {
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "amounts.csv",
                ExcelFileValidationSupport.XLSX_CONTENT_TYPE,
                new byte[]{1, 2, 3}
        );

        assertThatThrownBy(() -> ExcelFileValidationSupport.validateExcelType(
                file,
                INVALID_EXTENSION_MESSAGE,
                INVALID_CONTENT_TYPE_MESSAGE
        ))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage(INVALID_EXTENSION_MESSAGE);
    }

    @Test
    void validateExcelType_ShouldRejectInvalidContentType() {
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "amounts.xlsx",
                "text/csv",
                new byte[]{1, 2, 3}
        );

        assertThatThrownBy(() -> ExcelFileValidationSupport.validateExcelType(
                file,
                INVALID_EXTENSION_MESSAGE,
                INVALID_CONTENT_TYPE_MESSAGE
        ))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage(INVALID_CONTENT_TYPE_MESSAGE);
    }

    @Test
    void validateExcelType_ShouldRejectNullContentType() {
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "amounts.xlsx",
                null,
                new byte[]{1, 2, 3}
        );

        assertThatThrownBy(() -> ExcelFileValidationSupport.validateExcelType(
                file,
                INVALID_EXTENSION_MESSAGE,
                INVALID_CONTENT_TYPE_MESSAGE
        ))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage(INVALID_CONTENT_TYPE_MESSAGE);
    }
}

