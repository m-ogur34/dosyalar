package tr.com.allianz.accounting_services.cyclic_postings.interfaces.web.error;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import tr.com.allianz.accounting_services.cyclic_postings.application.exception.*;
import tr.com.allianz.accounting_services.shared.api.ApiResponse;
import tr.com.allianz.accounting_services.shared.api.ErrorDetail;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@ExtendWith(MockitoExtension.class)
class CyclicPostingsExceptionHandlerTest {

    @InjectMocks
    private CyclicPostingsExceptionHandler exceptionHandler;

    @Test
    void shouldHandleCyclicBatchIdAlreadyExistsException() {
        // Given
        long batchId = 1L;
        CyclicPostingProcessAlreadyExistsException exception =
            new CyclicPostingProcessAlreadyExistsException(batchId);

        // When
        ResponseEntity<ApiResponse<List<ErrorDetail>>> response =
            exceptionHandler.handleAlzCyclicPostingProcessAlreadyExistsException(exception);

        // Then
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.CONFLICT);
        assertThat(response.getBody()).isNotNull();
    }

    @Test
    void shouldHandleAlzCyclicAccountMappingNotFoundException() {
        // Given
        String accountNo = "ACC001";
        CyclicAccountMappingNotFoundException exception =
            new CyclicAccountMappingNotFoundException(accountNo);

        // When
        ResponseEntity<ApiResponse<List<ErrorDetail>>> response =
            exceptionHandler.handleAlzCyclicAccountMappingNotFoundException(exception);

        // Then
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.NOT_FOUND);
        assertThat(response.getBody()).isNotNull();
    }

    @Test
    void shouldHandleAlzCyclicAccountMappingAlreadyExistsException() {
        // Given
        String accountNo = "ACC002";
        CyclicAccountMappingAlreadyExistsException exception =
            new CyclicAccountMappingAlreadyExistsException(accountNo);

        // When
        ResponseEntity<ApiResponse<List<ErrorDetail>>> response =
            exceptionHandler.handleAlzCyclicAccountMappingAlreadyExistsException(exception);

        // Then
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.CONFLICT);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().message()).contains(accountNo+" nolu hesap önceden eklenmiş. ");
    }

    @Test
    void shouldHandleCyclicPostingProcessFailedException() {
        // Given
        Long batchId = 12345L;
        CyclicPostingProcessFailedException exception =
                new CyclicPostingProcessFailedException(batchId);

        // When
        ResponseEntity<ApiResponse<List<ErrorDetail>>> response =
                exceptionHandler.handleCyclicPostingProcessFailedException(exception);

        // Then
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.UNPROCESSABLE_ENTITY);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().message()).contains( "Muhasebeleştirme süreci başarısız oldu.");
    }






}