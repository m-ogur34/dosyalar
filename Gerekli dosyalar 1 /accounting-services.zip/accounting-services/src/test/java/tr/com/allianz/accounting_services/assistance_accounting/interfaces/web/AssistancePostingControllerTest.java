package tr.com.allianz.accounting_services.assistance_accounting.interfaces.web;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import tr.com.allianz.accounting_services.assistance_accounting.application.usecases.CreateAssistancePostingCommand;
import tr.com.allianz.accounting_services.assistance_accounting.application.usecases.CreateAssistancePostingUseCase;
import tr.com.allianz.accounting_services.assistance_accounting.interfaces.web.dto.CreateAssistancePostingRequest;

import java.math.BigDecimal;
import java.time.LocalDate;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)
class AssistancePostingControllerTest {

    private MockMvc mockMvc;

    @Mock
    private CreateAssistancePostingUseCase createAssistancePostingUseCase;

    @InjectMocks
    private AssistancePostingController assistancePostingController;

    private final ObjectMapper objectMapper = new ObjectMapper();

    @BeforeEach
    void setUp() {
        // Register JavaTimeModule to handle LocalDate serialization/deserialization
        objectMapper.registerModule(new com.fasterxml.jackson.datatype.jsr310.JavaTimeModule());
        mockMvc = MockMvcBuilders.standaloneSetup(assistancePostingController).build();
    }

    @Test
    void createAssistancePosting_ShouldCallUseCaseAndReturnSuccess() throws Exception {
        // Given
        CreateAssistancePostingRequest request = new CreateAssistancePostingRequest();
        request.setInvoiceNo("INV-001");
        request.setInvoiceDate(LocalDate.of(2023, 10, 1));
        request.setBatchDescription("Test Batch");
        request.setAccountingDate(LocalDate.of(2023, 10, 2));
        request.setAgencyId(123L);
        request.setYear(2023);
        request.setMonth(10);
        request.setAccCoverCode("ACC1");
        request.setPayableAmount(new BigDecimal("100.50"));
        request.setEbType("TYPE1");
        request.setProductId("1001");
        request.setPartitionType("PART1");

        when(createAssistancePostingUseCase.handle(any(CreateAssistancePostingCommand.class))).thenReturn(12345L);

        // When/Then
        mockMvc.perform(post("/api/v1/assistance-posting/create")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.code").value("ASSISTANCE_POSTING_CREATED"))
                .andExpect(jsonPath("$.data").value(12345));

        verify(createAssistancePostingUseCase).handle(any(CreateAssistancePostingCommand.class));
    }
}
