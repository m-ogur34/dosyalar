package tr.com.allianz.accounting_services.actuary.infrastructure.persistence.adapter;

import org.junit.jupiter.api.Test;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.mockito.ArgumentCaptor;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class CreateIbnrReportsDataAdapterTest {

    @Test
    void create_ShouldCallIbnrReportsProcedureWithYearMonthAndRuleId() {
        SimpleJdbcCall call = mock(SimpleJdbcCall.class);
        when(call.withSchemaName("CUSTOMER")).thenReturn(call);
        when(call.withCatalogName("ALZ_ACT_PROCESS_UTILS")).thenReturn(call);
        when(call.withProcedureName("CREATE_IBNR_REPORTS_DATA")).thenReturn(call);
        when(call.withoutProcedureColumnMetaDataAccess()).thenReturn(call);
        when(call.declareParameters(any(SqlParameter[].class))).thenReturn(call);
        when(call.execute(any(MapSqlParameterSource.class))).thenReturn(Map.of());

        CreateIbnrReportsDataAdapter adapter = new CreateIbnrReportsDataAdapterTestSubject(call);

        adapter.create(2026, 6, 47);

        ArgumentCaptor<MapSqlParameterSource> parameters = ArgumentCaptor.forClass(MapSqlParameterSource.class);
        verify(call).execute(parameters.capture());

        assertEquals(2026, parameters.getValue().getValue("p_year"));
        assertEquals(6, parameters.getValue().getValue("p_month"));
        assertEquals(47, parameters.getValue().getValue("p_rule_id"));
    }

    private static class CreateIbnrReportsDataAdapterTestSubject extends CreateIbnrReportsDataAdapter {

        private final SimpleJdbcCall call;

        private CreateIbnrReportsDataAdapterTestSubject(SimpleJdbcCall call) {
            super(mock(JdbcTemplate.class));
            this.call = call;
        }

        @Override
        protected SimpleJdbcCall createSimpleJdbcCall() {
            return call;
        }
    }
}
