package tr.com.allianz.accounting_services.actuary.postings.interfaces.web;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import tr.com.allianz.accounting_services.actuary.postings.application.usecases.ListActuaryPostingBranchesUseCase;
import tr.com.allianz.accounting_services.actuary.postings.domain.model.ActuaryPostingBranch;
import tr.com.allianz.accounting_services.actuary.postings.interfaces.web.dto.ActuaryPostingBranchResponse;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ActuaryPostingBranchControllerTest {

    @Mock
    private ListActuaryPostingBranchesUseCase listActuaryPostingBranchesUseCase;

    @Test
    void getAllBranches_ShouldReturnMappedResponse() {
        when(listActuaryPostingBranchesUseCase.handle()).thenReturn(List.of(
                new ActuaryPostingBranch("34", "Istanbul", "3401"),
                new ActuaryPostingBranch("06", "Ankara", "")
        ));

        ActuaryPostingBranchController controller =
                new ActuaryPostingBranchController(listActuaryPostingBranchesUseCase);

        ResponseEntity<List<ActuaryPostingBranchResponse>> response = controller.getAllBranches();

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody()).hasSize(2);
        assertThat(response.getBody().get(0).getBranchId()).isEqualTo("34");
        assertThat(response.getBody().get(0).getBranchName()).isEqualTo("Istanbul");
        assertThat(response.getBody().get(0).getExtReference()).isEqualTo("3401");
        assertThat(response.getBody().get(1).getBranchId()).isEqualTo("06");
        assertThat(response.getBody().get(1).getBranchName()).isEqualTo("Ankara");
        assertThat(response.getBody().get(1).getExtReference()).isEqualTo("");
    }

    @Test
    void getAllBranches_ShouldReturnEmptyList_WhenNoBranchExists() {
        when(listActuaryPostingBranchesUseCase.handle()).thenReturn(List.of());

        ActuaryPostingBranchController controller =
                new ActuaryPostingBranchController(listActuaryPostingBranchesUseCase);

        ResponseEntity<List<ActuaryPostingBranchResponse>> response = controller.getAllBranches();

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody()).isEmpty();
    }
}

