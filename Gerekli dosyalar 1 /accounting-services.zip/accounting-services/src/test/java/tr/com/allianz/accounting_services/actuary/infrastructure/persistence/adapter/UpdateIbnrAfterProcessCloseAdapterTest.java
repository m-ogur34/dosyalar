package tr.com.allianz.accounting_services.actuary.infrastructure.persistence.adapter;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import java.time.LocalDate;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class UpdateIbnrAfterProcessCloseAdapterTest {

    @Mock
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @Test
    void update_ShouldSetIStatusCodeForEligibleIbnrClose() {
        when(namedParameterJdbcTemplate.update(anyString(), any(MapSqlParameterSource.class))).thenReturn(1);
        UpdateIbnrAfterProcessCloseAdapter adapter =
                new UpdateIbnrAfterProcessCloseAdapter(namedParameterJdbcTemplate);

        adapter.update(LocalDate.of(2026, 6, 30));

        ArgumentCaptor<String> sqlCaptor = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<MapSqlParameterSource> parametersCaptor = ArgumentCaptor.forClass(MapSqlParameterSource.class);
        verify(namedParameterJdbcTemplate).update(sqlCaptor.capture(), parametersCaptor.capture());

        String sql = sqlCaptor.getValue().toLowerCase();
        assertThat(sql).contains("set i_status_code = 2")
                .contains("agent_int_id = 12354")
                .contains("process_type = 'ibnr'")
                .contains("branch_id = 1")
                .contains("close_date = :close_date")
                .contains("status_code = 2")
                .contains("i_status_code is null");
        assertThat(parametersCaptor.getValue().getValue("close_date"))
                .isEqualTo(java.sql.Date.valueOf("2026-06-30"));
    }
}
