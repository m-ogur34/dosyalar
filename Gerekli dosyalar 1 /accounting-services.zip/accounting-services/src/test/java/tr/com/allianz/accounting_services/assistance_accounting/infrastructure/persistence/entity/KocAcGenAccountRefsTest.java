package tr.com.allianz.accounting_services.assistance_accounting.infrastructure.persistence.entity;

import org.junit.jupiter.api.Test;
import static org.assertj.core.api.Assertions.assertThat;

class KocAcGenAccountRefsTest {

    @Test
    void shouldCreateEntityAndAccessFields() {
        Long intId = 1L;
        String extRef = "REF";
        String accountCode = "ACC";
        String name = "Agency";
        Integer isAssistance = 1;

        KocAcGenAccountRefs entity = new KocAcGenAccountRefs();
        entity.setIntId(intId);
        entity.setExtReference(extRef);
        entity.setAccountCode(accountCode);
        entity.setName(name);
        entity.setIsAssistanceCompany(isAssistance);

        assertThat(entity.getIntId()).isEqualTo(intId);
        assertThat(entity.getExtReference()).isEqualTo(extRef);
        assertThat(entity.getAccountCode()).isEqualTo(accountCode);
        assertThat(entity.getName()).isEqualTo(name);
        assertThat(entity.getIsAssistanceCompany()).isEqualTo(isAssistance);
    }

    @Test
    void shouldTestAllArgsConstructor() {
        KocAcGenAccountRefs entity = new KocAcGenAccountRefs(1L, "REF", "ACC", "NAME", 1);

        assertThat(entity.getIntId()).isEqualTo(1L);
        assertThat(entity.getExtReference()).isEqualTo("REF");
        assertThat(entity.getAccountCode()).isEqualTo("ACC");
        assertThat(entity.getName()).isEqualTo("NAME");
        assertThat(entity.getIsAssistanceCompany()).isEqualTo(1);
    }
}

