package tr.com.allianz.accounting_services.assistance_accounting.interfaces.web;

import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import tr.com.allianz.accounting_services.assistance_accounting.application.usecases.ListAssistanceCompanyUseCase;
import tr.com.allianz.accounting_services.assistance_accounting.domain.valueobject.AssistanceCompany;
import tr.com.allianz.accounting_services.shared.api.ApiResponse;

import java.util.Collections;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class AssistanceCompanyControllerTest {

    private final ListAssistanceCompanyUseCase listAssistanceCompanyUseCase = mock(ListAssistanceCompanyUseCase.class);
    private final AssistanceCompanyController controller = new AssistanceCompanyController(listAssistanceCompanyUseCase);

    @Test
    void shouldReturnAssistanceCompanies() {
        AssistanceCompany company = new AssistanceCompany(1L, "REF1", "ACC1", "Agency1");
        when(listAssistanceCompanyUseCase.handle()).thenReturn(List.of(company));

        ResponseEntity<ApiResponse<List<AssistanceCompany>>> response = controller.listAssistanceCompanies();

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().data()).hasSize(1);
        assertThat(response.getBody().data().getFirst()).isEqualTo(company);
    }

    @Test
    void shouldReturnEmptyList() {
        when(listAssistanceCompanyUseCase.handle()).thenReturn(Collections.emptyList());

        ResponseEntity<ApiResponse<List<AssistanceCompany>>> response = controller.listAssistanceCompanies();

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().data()).isEmpty();
    }
}

