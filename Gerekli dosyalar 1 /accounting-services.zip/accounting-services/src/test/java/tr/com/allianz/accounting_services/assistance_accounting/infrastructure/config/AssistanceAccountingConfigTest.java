package tr.com.allianz.accounting_services.assistance_accounting.infrastructure.config;

import org.junit.jupiter.api.Test;
import tr.com.allianz.accounting_services.assistance_accounting.application.port.out.AssistancePartitionLoaderPort;
import tr.com.allianz.accounting_services.assistance_accounting.application.port.out.CreateAssistancePostingPort;
import tr.com.allianz.accounting_services.assistance_accounting.application.port.out.LoadAccCoverCodePort;
import tr.com.allianz.accounting_services.assistance_accounting.application.port.out.LoadAssistanceCompanyPort;
import tr.com.allianz.accounting_services.assistance_accounting.application.port.out.LoadAssistanceProductPort;
import tr.com.allianz.accounting_services.assistance_accounting.application.port.out.LoadAssistanceQueryPort;
import tr.com.allianz.accounting_services.assistance_accounting.application.usecases.CreateAssistancePostingUseCase;
import tr.com.allianz.accounting_services.assistance_accounting.application.usecases.ListAccCoverCodeUseCase;
import tr.com.allianz.accounting_services.assistance_accounting.application.usecases.ListAssistanceCompanyUseCase;
import tr.com.allianz.accounting_services.assistance_accounting.application.usecases.ListAssistancePartitionUseCase;
import tr.com.allianz.accounting_services.assistance_accounting.application.usecases.ListAssistanceProductUseCase;
import tr.com.allianz.accounting_services.assistance_accounting.application.usecases.ListAssistanceQueryUseCase;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;

class AssistanceAccountingConfigTest {

    private final AssistanceAccountingConfig config = new AssistanceAccountingConfig();

    @Test
    void shouldCreateListAssistanceProductUseCase() {
        LoadAssistanceProductPort port = mock(LoadAssistanceProductPort.class);
        ListAssistanceProductUseCase useCase = config.listAssistanceProductUseCase(port);
        assertThat(useCase).isNotNull();
        assertThat(useCase).isInstanceOf(ListAssistanceProductUseCase.class);
    }

    @Test
    void shouldCreateListAssistancePartitionUseCase() {
        AssistancePartitionLoaderPort port = mock(AssistancePartitionLoaderPort.class);
        ListAssistancePartitionUseCase useCase = config.listAssistancePartitionUseCase(port);
        assertThat(useCase).isNotNull();
        assertThat(useCase).isInstanceOf(ListAssistancePartitionUseCase.class);
    }

    @Test
    void shouldCreateListAssistanceQueryUseCase() {
        LoadAssistanceQueryPort queryPort = mock(LoadAssistanceQueryPort.class);
        ListAssistanceQueryUseCase useCase = config.listAssistanceQueryUseCase(queryPort);
        assertThat(useCase).isNotNull();
        assertThat(useCase).isInstanceOf(ListAssistanceQueryUseCase.class);
    }

    @Test
    void shouldCreateListAccCoverCodeUseCase() {
        LoadAccCoverCodePort port = mock(LoadAccCoverCodePort.class);
        ListAccCoverCodeUseCase useCase = config.listAccCoverCodeUseCase(port);
        assertThat(useCase).isNotNull();
        assertThat(useCase).isInstanceOf(ListAccCoverCodeUseCase.class);
    }

    @Test
    void shouldCreateCreateAssistancePostingUseCase() {
        CreateAssistancePostingPort port = mock(CreateAssistancePostingPort.class);
        CreateAssistancePostingUseCase useCase = config.createAssistancePostingUseCase(port);
        assertThat(useCase).isNotNull();
        assertThat(useCase).isInstanceOf(CreateAssistancePostingUseCase.class);
    }


    @Test
    void shouldCreateListAssistanceCompanyUseCase() {
        LoadAssistanceCompanyPort port = mock(LoadAssistanceCompanyPort.class);
        ListAssistanceCompanyUseCase useCase = config.listAssistanceCompanyUseCase(port);
        assertThat(useCase).isNotNull();
        assertThat(useCase).isInstanceOf(ListAssistanceCompanyUseCase.class);
    }

    @Test
    void shouldCreateDistinctUseCaseInstances() {
        LoadAssistanceProductPort port1 = mock(LoadAssistanceProductPort.class);
        LoadAssistanceProductPort port2 = mock(LoadAssistanceProductPort.class);
        ListAssistanceProductUseCase useCase1 = config.listAssistanceProductUseCase(port1);
        ListAssistanceProductUseCase useCase2 = config.listAssistanceProductUseCase(port2);
        assertThat(useCase1).isNotSameAs(useCase2);
    }
}
