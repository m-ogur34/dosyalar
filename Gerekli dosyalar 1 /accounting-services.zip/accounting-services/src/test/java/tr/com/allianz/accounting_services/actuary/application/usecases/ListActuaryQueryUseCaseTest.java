package tr.com.allianz.accounting_services.actuary.application.usecases;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import tr.com.allianz.accounting_services.actuary.application.port.out.LoadActuaryQueryPort;
import tr.com.allianz.accounting_services.actuary.application.port.out.SaveActuaryPeriodStatusPort;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.ActuaryProcessRuleAmount;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.ActuaryQueryCriteria;
import tr.com.allianz.accounting_services.actuary.infrastructure.persistence.entity.AlzActPeriods;

import java.math.BigDecimal;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ListActuaryQueryUseCaseTest {

    @Mock
    private LoadActuaryQueryPort loadActuaryQueryPort;

    @Mock
    private SaveActuaryPeriodStatusPort saveActuaryPeriodStatusPort;

    @Test
    void handle_ShouldCallPortAndReturnResults() {
        // Given
        ActuaryQueryCriteria criteria = new ActuaryQueryCriteria("P1001", 2024, 6);
        ActuaryProcessRuleAmount mockResult = new ActuaryProcessRuleAmount(
                "TEST_RULE",
                2024,
                6,
                "P1001",
                100,
                new BigDecimal("1000"),
                new BigDecimal("100"),
                new BigDecimal("900"),
                new BigDecimal("950"),
                new BigDecimal("95"),
                new BigDecimal("855"),
                new BigDecimal("1100"),
                new BigDecimal("110"),
                new BigDecimal("990"),
                new BigDecimal("1050"),
                new BigDecimal("105"),
                new BigDecimal("945"),
                new BigDecimal("1.0"),
                new BigDecimal("0.1"),
                new BigDecimal("0.9"),
                new BigDecimal("0.95"),
                new BigDecimal("0.095"),
                new BigDecimal("0.855"),
                new BigDecimal("1.1"),
                new BigDecimal("0.11"),
                new BigDecimal("0.99"),
                new BigDecimal("1.05"),
                new BigDecimal("0.105"),
                new BigDecimal("0.945")
        );

        when(loadActuaryQueryPort.loadActuaryQueryResults(criteria))
                .thenReturn(List.of(mockResult));
        when(saveActuaryPeriodStatusPort.getOrCreateInProgress("P1001", 2024, 6))
                .thenReturn(new AlzActPeriods("P1001", 2024, 6, "In Progress"));

        ListActuaryQueryUseCase useCase = new ListActuaryQueryUseCase(loadActuaryQueryPort, saveActuaryPeriodStatusPort);

        // When
        ListActuaryQueryResponse response = useCase.handle(criteria);

        // Then
        assertThat(response.results()).hasSize(1);
        assertThat(response.results().get(0).ruleName()).isEqualTo("TEST_RULE");
        assertThat(response.results().get(0).processId()).isEqualTo("P1001");
        assertThat(response.period()).isNotNull();
        assertThat(response.period().getStatus()).isEqualTo("In Progress");
        
        verify(loadActuaryQueryPort).loadActuaryQueryResults(criteria);
        verify(saveActuaryPeriodStatusPort).getOrCreateInProgress("P1001", 2024, 6);
    }

    @Test
    void handle_ShouldReturnEmptyListWhenNoResults() {
        // Given
        ActuaryQueryCriteria criteria = new ActuaryQueryCriteria("P9999", 2024, 6);

        when(loadActuaryQueryPort.loadActuaryQueryResults(criteria))
                .thenReturn(List.of());
        when(saveActuaryPeriodStatusPort.getOrCreateInProgress("P9999", 2024, 6))
                .thenReturn(new AlzActPeriods("P9999", 2024, 6, "In Progress"));

        ListActuaryQueryUseCase useCase = new ListActuaryQueryUseCase(loadActuaryQueryPort, saveActuaryPeriodStatusPort);

        // When
        ListActuaryQueryResponse response = useCase.handle(criteria);

        // Then
        assertThat(response.results()).isEmpty();
        assertThat(response.period()).isNotNull();
        verify(loadActuaryQueryPort).loadActuaryQueryResults(criteria);
        verify(saveActuaryPeriodStatusPort).getOrCreateInProgress("P9999", 2024, 6);
    }
}

