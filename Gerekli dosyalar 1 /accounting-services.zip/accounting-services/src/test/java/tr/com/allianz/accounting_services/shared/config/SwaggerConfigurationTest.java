package tr.com.allianz.accounting_services.shared.config;

import io.swagger.v3.oas.models.OpenAPI;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class SwaggerConfigurationTest {

    @Test
    void customOpenAPI_ShouldReturnConfiguredOpenAPI() {
        // Arrange
        SwaggerConfiguration configuration = new SwaggerConfiguration();

        // Act
        OpenAPI openAPI = configuration.customOpenAPI();

        // Assert
        assertThat(openAPI).isNotNull();
        assertThat(openAPI.getInfo()).isNotNull();
    }
}

