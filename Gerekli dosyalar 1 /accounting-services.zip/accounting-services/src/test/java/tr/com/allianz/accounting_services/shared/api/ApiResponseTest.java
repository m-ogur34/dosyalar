package tr.com.allianz.accounting_services.shared.api;


import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class ApiResponseTest {

    @Test
    void ok_shouldCreateSuccessResponse() {
        // GIVEN
        TestData data = new TestData("value");

        // WHEN
        ApiResponse<TestData> response =
                ApiResponse.ok("SUCCESS_CODE", "Operation successful", data);

        // THEN
        assertThat(response.success()).isTrue();
        assertThat(response.code()).isEqualTo("SUCCESS_CODE");
        assertThat(response.message()).isEqualTo("Operation successful");
        assertThat(response.data()).isEqualTo(data);
        assertThat(response.timestamp()).isNotNull(); // timestamp set edilmeli
    }

    @Test
    void error_shouldCreateErrorResponse() {
        // GIVEN
        TestData data = new TestData("err");

        // WHEN
        ApiResponse<TestData> response =
                ApiResponse.error("ERROR_CODE", "Something went wrong", data);

        // THEN
        assertThat(response.success()).isFalse();
        assertThat(response.code()).isEqualTo("ERROR_CODE");
        assertThat(response.message()).isEqualTo("Something went wrong");
        assertThat(response.data()).isEqualTo(data);
        assertThat(response.timestamp()).isNotNull();
    }

    // generic T için basit test objesi
    private record TestData(String value) {}
}
