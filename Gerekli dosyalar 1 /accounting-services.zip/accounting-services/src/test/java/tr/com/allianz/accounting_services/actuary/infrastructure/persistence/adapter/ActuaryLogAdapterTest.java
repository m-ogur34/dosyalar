package tr.com.allianz.accounting_services.actuary.infrastructure.persistence.adapter;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.ActuaryLog;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.ActuaryLogType;
import tr.com.allianz.accounting_services.actuary.infrastructure.persistence.entity.AlzActLog;
import tr.com.allianz.accounting_services.actuary.infrastructure.persistence.repository.AlzActLogRepository;

import java.time.LocalDateTime;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ActuaryLogAdapterTest {

    @Mock
    private AlzActLogRepository repository;

    @InjectMocks
    private ActuaryLogAdapter adapter;

    private ActuaryLog actuaryLog;
    private LocalDateTime testDate;

    @BeforeEach
    void setUp() {
        testDate = LocalDateTime.now();
        actuaryLog = new ActuaryLog(
                2024,
                6,
                "P1001",
                null,
                ActuaryLogType.QUERY,
                "Test query executed",
                "test-user",
                testDate
        );
    }

    @Test
    void save_ShouldConvertActuaryLogToDomainAndSaveToRepository() {
        // When
        adapter.save(actuaryLog);

        // Then
        ArgumentCaptor<AlzActLog> captor = ArgumentCaptor.forClass(AlzActLog.class);
        verify(repository, times(1)).save(captor.capture());
        
        AlzActLog savedEntity = captor.getValue();
        assertThat(savedEntity).isNotNull();
        assertThat(savedEntity.getYear()).isEqualTo(2024);
        assertThat(savedEntity.getMonth()).isEqualTo(6);
        assertThat(savedEntity.getProcessId()).isEqualTo("P1001");
        assertThat(savedEntity.getRuleId()).isNull();
        assertThat(savedEntity.getLogType()).isEqualTo("QUERY");
        assertThat(savedEntity.getLogText()).isEqualTo("Test query executed");
        assertThat(savedEntity.getByUser()).isEqualTo("test-user");
        assertThat(savedEntity.getDateCreated()).isEqualTo(testDate);
    }

    @Test
    void save_WithRuleId_ShouldSaveRuleIdToEntity() {
        // Given
        ActuaryLog logWithRuleId = new ActuaryLog(
                2024,
                6,
                "P1001",
                123,
                ActuaryLogType.AMOUNT_UPDATE,
                "Amount updated",
                "test-user",
                testDate
        );

        // When
        adapter.save(logWithRuleId);

        // Then
        ArgumentCaptor<AlzActLog> captor = ArgumentCaptor.forClass(AlzActLog.class);
        verify(repository, times(1)).save(captor.capture());
        
        AlzActLog savedEntity = captor.getValue();
        assertThat(savedEntity.getRuleId()).isEqualTo(123);
    }

    @ParameterizedTest
    @EnumSource(ActuaryLogType.class)
    void save_WithVariousLogTypes_ShouldSaveCorrectLogType(ActuaryLogType logType) {
        // Given
        ActuaryLog log = new ActuaryLog(
                2024,
                6,
                "P1001",
                null,
                logType,
                "Test log",
                "test-user",
                testDate
        );

        // When
        adapter.save(log);

        // Then
        ArgumentCaptor<AlzActLog> captor = ArgumentCaptor.forClass(AlzActLog.class);
        verify(repository, times(1)).save(captor.capture());
        
        AlzActLog savedEntity = captor.getValue();
        assertThat(savedEntity.getLogType()).isEqualTo(logType.name());
    }

    @Test
    void save_WithQueryLogType_ShouldSaveCorrectly() {
        // When
        adapter.save(actuaryLog);

        // Then
        ArgumentCaptor<AlzActLog> captor = ArgumentCaptor.forClass(AlzActLog.class);
        verify(repository).save(captor.capture());
        assertThat(captor.getValue().getLogType()).isEqualTo("QUERY");
    }

    @Test
    void save_WithErrorLogType_ShouldSaveCorrectly() {
        // Given
        ActuaryLog errorLog = new ActuaryLog(
                2024,
                6,
                "P1001",
                null,
                ActuaryLogType.ERROR,
                "Error occurred",
                "test-user",
                testDate
        );

        // When
        adapter.save(errorLog);

        // Then
        ArgumentCaptor<AlzActLog> captor = ArgumentCaptor.forClass(AlzActLog.class);
        verify(repository).save(captor.capture());
        assertThat(captor.getValue().getLogType()).isEqualTo("ERROR");
    }

    @Test
    void save_WithExcelUploadLogType_ShouldSaveCorrectly() {
        // Given
        ActuaryLog excelLog = new ActuaryLog(
                2024,
                6,
                "P1001",
                null,
                ActuaryLogType.EXCEL_UPLOAD,
                "Excel file uploaded",
                "test-user",
                testDate
        );

        // When
        adapter.save(excelLog);

        // Then
        ArgumentCaptor<AlzActLog> captor = ArgumentCaptor.forClass(AlzActLog.class);
        verify(repository).save(captor.capture());
        assertThat(captor.getValue().getLogType()).isEqualTo("EXCEL_UPLOAD");
    }

    @Test
    void save_WithSpecialCharactersInDescription_ShouldPreserveText() {
        // Given
        String specialText = "Test with special chars: !@#$%^&*()_+-=[]{}|;':\",./<>?";
        ActuaryLog logWithSpecialChars = new ActuaryLog(
                2024,
                6,
                "P1001",
                null,
                ActuaryLogType.QUERY,
                specialText,
                "test-user",
                testDate
        );

        // When
        adapter.save(logWithSpecialChars);

        // Then
        ArgumentCaptor<AlzActLog> captor = ArgumentCaptor.forClass(AlzActLog.class);
        verify(repository).save(captor.capture());
        assertThat(captor.getValue().getLogText()).isEqualTo(specialText);
    }

    @Test
    void save_WithNullRuleId_ShouldSaveNullValue() {
        // Given
        ActuaryLog logWithoutRuleId = new ActuaryLog(
                2024,
                6,
                "P1001",
                null,
                ActuaryLogType.QUERY,
                "Query without rule",
                "test-user",
                testDate
        );

        // When
        adapter.save(logWithoutRuleId);

        // Then
        ArgumentCaptor<AlzActLog> captor = ArgumentCaptor.forClass(AlzActLog.class);
        verify(repository).save(captor.capture());
        assertThat(captor.getValue().getRuleId()).isNull();
    }

    @Test
    void save_ShouldCallRepositorySaveOnce() {
        // When
        adapter.save(actuaryLog);

        // Then
        verify(repository, times(1)).save(any(AlzActLog.class));
        verifyNoMoreInteractions(repository);
    }

    @Test
    void save_WithMultipleLogs_ShouldSaveMultipleTimes() {
        // Given
        ActuaryLog log1 = new ActuaryLog(2024, 6, "P1001", null, ActuaryLogType.QUERY, "Log 1", "user1", testDate);
        ActuaryLog log2 = new ActuaryLog(2024, 7, "P1001", null, ActuaryLogType.APPROVE, "Log 2", "user2", testDate);

        // When
        adapter.save(log1);
        adapter.save(log2);

        // Then
        verify(repository, times(2)).save(any(AlzActLog.class));
    }
}

