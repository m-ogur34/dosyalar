package tr.com.allianz.accounting_services.cyclic_postings.infrastructure.persistence.entity;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.time.LocalDateTime;

import static org.assertj.core.api.Assertions.assertThat;

public class AlzCyclicPostingProcessTest {

    private AlzCyclicPostingProcess cyclicPostingProcess;

    @BeforeEach
    void setUp() {
        cyclicPostingProcess = new AlzCyclicPostingProcess(
                1L,
                LocalDate.of(2026, 1, 20),
                123L,
                "PROCESSING",
                "No errors",
                LocalDateTime.now(),
                LocalDateTime.now()
        );
    }

    @Test
    void testConstructorWithAllArgs() {
        // Verify that the constructor initializes all fields correctly
        assertThat(cyclicPostingProcess).isNotNull();
        assertThat(cyclicPostingProcess.getBatchId()).isEqualTo(1L);
        assertThat(cyclicPostingProcess.getPostingDate()).isEqualTo(LocalDate.of(2026, 1, 20));
        assertThat(cyclicPostingProcess.getCyclicBatchId()).isEqualTo(123L);
        assertThat(cyclicPostingProcess.getProcessStatus()).isEqualTo("PROCESSING");
        assertThat(cyclicPostingProcess.getErrText()).isEqualTo("No errors");
        assertThat(cyclicPostingProcess.getCreatedDate()).isNotNull();
        assertThat(cyclicPostingProcess.getUpdatedDate()).isNotNull();
    }

    @Test
    void testDefaultConstructor() {
        AlzCyclicPostingProcess defaultEntity = new AlzCyclicPostingProcess();

        // Verify that the default constructor creates an empty entity (null values)
        assertThat(defaultEntity).isNotNull();
        assertThat(defaultEntity.getBatchId()).isNull();
        assertThat(defaultEntity.getPostingDate()).isNull();
        assertThat(defaultEntity.getCyclicBatchId()).isNull();
        assertThat(defaultEntity.getProcessStatus()).isNull();
        assertThat(defaultEntity.getErrText()).isNull();
        assertThat(defaultEntity.getCreatedDate()).isNull();
        assertThat(defaultEntity.getUpdatedDate()).isNull();
    }

    @Test
    void testSettersAndGetters() {
        // Test the setter and getter methods
        cyclicPostingProcess.setBatchId(2L);
        cyclicPostingProcess.setPostingDate(LocalDate.of(2026, 2, 20));
        cyclicPostingProcess.setCyclicBatchId(456L);
        cyclicPostingProcess.setProcessStatus("COMPLETED");
        cyclicPostingProcess.setErrText("No Errors");
        cyclicPostingProcess.setCreatedDate(LocalDateTime.of(2026, 2, 1, 10, 0));
        cyclicPostingProcess.setUpdatedDate(LocalDateTime.of(2026, 2, 1, 10, 5));

        // Verify all setter methods are working as expected
        assertThat(cyclicPostingProcess.getBatchId()).isEqualTo(2L);
        assertThat(cyclicPostingProcess.getPostingDate()).isEqualTo(LocalDate.of(2026, 2, 20));
        assertThat(cyclicPostingProcess.getCyclicBatchId()).isEqualTo(456L);
        assertThat(cyclicPostingProcess.getProcessStatus()).isEqualTo("COMPLETED");
        assertThat(cyclicPostingProcess.getErrText()).isEqualTo("No Errors");
        assertThat(cyclicPostingProcess.getCreatedDate()).isEqualTo(LocalDateTime.of(2026, 2, 1, 10, 0));
        assertThat(cyclicPostingProcess.getUpdatedDate()).isEqualTo(LocalDateTime.of(2026, 2, 1, 10, 5));
    }

}
