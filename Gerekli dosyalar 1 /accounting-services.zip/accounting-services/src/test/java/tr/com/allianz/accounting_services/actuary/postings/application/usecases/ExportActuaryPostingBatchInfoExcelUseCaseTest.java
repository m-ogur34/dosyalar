package tr.com.allianz.accounting_services.actuary.postings.application.usecases;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import tr.com.allianz.accounting_services.actuary.postings.application.port.out.ExportActuaryPostingBatchInfoExcelPort;
import tr.com.allianz.accounting_services.actuary.postings.domain.model.ActuaryPostingBatchInfoExcelFile;

import java.time.LocalDate;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ExportActuaryPostingBatchInfoExcelUseCaseTest {

    @Mock
    private ExportActuaryPostingBatchInfoExcelPort exportPort;

    @Test
    void handle_ShouldDelegateToPort() {
        GetActuaryPostingBatchInfoCommand command = new GetActuaryPostingBatchInfoCommand(
                10L,
                LocalDate.of(2026, 7, 17),
                "3401",
                60L,
                "PARTITION",
                1
        );
        ActuaryPostingBatchInfoExcelFile expected = new ActuaryPostingBatchInfoExcelFile("batch.xlsx", new byte[]{1, 2});

        when(exportPort.exportToExcel(command)).thenReturn(expected);

        ExportActuaryPostingBatchInfoExcelUseCase useCase = new ExportActuaryPostingBatchInfoExcelUseCase(exportPort);
        ActuaryPostingBatchInfoExcelFile result = useCase.handle(command);

        assertThat(result).isEqualTo(expected);
        verify(exportPort).exportToExcel(command);
    }

    @Test
    void handle_ShouldPropagatePortException() {
        GetActuaryPostingBatchInfoCommand command = new GetActuaryPostingBatchInfoCommand(
                10L,
                LocalDate.of(2026, 7, 17),
                "3401",
                60L,
                "PARTITION",
                1
        );
        when(exportPort.exportToExcel(command)).thenThrow(new IllegalStateException("boom"));

        ExportActuaryPostingBatchInfoExcelUseCase useCase = new ExportActuaryPostingBatchInfoExcelUseCase(exportPort);

        assertThatThrownBy(() -> useCase.handle(command))
                .isInstanceOf(IllegalStateException.class)
                .hasMessageContaining("boom");
    }
}

