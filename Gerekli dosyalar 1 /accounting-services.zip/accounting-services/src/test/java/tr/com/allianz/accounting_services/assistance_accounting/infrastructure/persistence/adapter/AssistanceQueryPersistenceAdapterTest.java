package tr.com.allianz.accounting_services.assistance_accounting.infrastructure.persistence.adapter;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import tr.com.allianz.accounting_services.assistance_accounting.domain.valueobject.AssistanceQueryCriteria;
import tr.com.allianz.accounting_services.assistance_accounting.domain.valueobject.AssistanceQueryResult;

import java.math.BigDecimal;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AssistanceQueryPersistenceAdapterTest {

    @Mock
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @InjectMocks
    private AssistanceQueryPersistenceAdapter adapter;

    @Test
    void loadAssistanceQueryResults_ShouldExecuteQueryWithCorrectParams() {
        // Given
        BigDecimal totalAmount = BigDecimal.valueOf(100.50);
        String accCoverCode = "ACC_CODE_TEST";
        Integer year = 2023;
        Integer month = 10;
        Integer isIndustrial = 0;
        String productId = "55";
        String partitionType = "TypeX";
        Long companyId = 77L;

        AssistanceQueryCriteria criteria = new AssistanceQueryCriteria(
                totalAmount, accCoverCode, year, month, isIndustrial, productId, partitionType, companyId
        );

        AssistanceQueryResult expectedResult = new AssistanceQueryResult(
                12345L, "Acc Exp", "LOB", "Dist Exp", 0, totalAmount, null
        );

        when(namedParameterJdbcTemplate.query(anyString(), any(SqlParameterSource.class), any(RowMapper.class)))
                .thenReturn(List.of(expectedResult));

        // When
        List<AssistanceQueryResult> results = adapter.loadAssistanceQueryResults(criteria);

        // Then
        assertThat(results).hasSize(1);
        assertThat(results.getFirst()).isEqualTo(expectedResult);

        ArgumentCaptor<SqlParameterSource> captor = ArgumentCaptor.forClass(SqlParameterSource.class);
        verify(namedParameterJdbcTemplate).query(anyString(), captor.capture(), any(RowMapper.class));

        SqlParameterSource params = captor.getValue();
        assertThat(params.getValue("company_id")).isEqualTo(companyId);
        assertThat(params.getValue("p_amount")).isEqualTo(totalAmount);
        assertThat(params.getValue("p_acc_cover_code")).isEqualTo(accCoverCode);
        assertThat(params.getValue("p_year")).isEqualTo(year);
        assertThat(params.getValue("p_month")).isEqualTo(month);
        assertThat(params.getValue("p_is_industrial")).isEqualTo(isIndustrial);
        assertThat(params.getValue("p_product_id")).isEqualTo(productId);
        assertThat(params.getValue("p_partition_type")).isEqualTo(partitionType);
    }
}
