package tr.com.allianz.accounting_services.actuary.infrastructure.persistence.adapter;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.ActuaryProcessAmount;
import tr.com.allianz.accounting_services.actuary.infrastructure.persistence.entity.AlzActProcessAmounts;
import tr.com.allianz.accounting_services.actuary.infrastructure.persistence.entity.AlzActProcessAmountsId;
import tr.com.allianz.accounting_services.actuary.infrastructure.persistence.repository.AlzActProcessAmountsRepository;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ActuaryProcessAmountAdapterTest {

    @Mock
    private AlzActProcessAmountsRepository repository;

    @Test
    void save_ShouldPersistIncomingEntity_WhenNoExistingRecord() {
        ActuaryProcessAmount amount = amount(
                "P1001",
                10,
                new BigDecimal("100"),
                new BigDecimal("10"),
                new BigDecimal("90"),
                new BigDecimal("1.25")
        );

        when(repository.findById(any(AlzActProcessAmountsId.class))).thenReturn(Optional.empty());

        ActuaryProcessAmountAdapter adapter = new ActuaryProcessAmountAdapter(repository);
        adapter.save(amount);

        ArgumentCaptor<AlzActProcessAmounts> captor = ArgumentCaptor.forClass(AlzActProcessAmounts.class);
        verify(repository).save(captor.capture());

        AlzActProcessAmounts saved = captor.getValue();
        assertThat(saved.getProcessId()).isEqualTo("P1001");
        assertThat(saved.getRuleId()).isEqualTo(10);
        assertThat(saved.getGrossCyAmount()).isEqualByComparingTo("100");
        assertThat(saved.getReCyAmount()).isEqualByComparingTo("10");
        assertThat(saved.getNetCyAmount()).isEqualByComparingTo("90");
        assertThat(saved.getGrossCyAmountRate()).isEqualByComparingTo("1.25");
    }

    @Test
    void save_ShouldMergeNullFields_FromExistingRecord() {
        ActuaryProcessAmount incoming = amount(
                "P1001",
                10,
                null,
                new BigDecimal("20"),
                null,
                null
        );

        AlzActProcessAmounts existing = new AlzActProcessAmounts(
                2026,
                7,
                "P1001",
                10,
                new BigDecimal("999"),
                new BigDecimal("88"),
                new BigDecimal("777"),
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                new BigDecimal("2.50"),
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null
        );

        when(repository.findById(any(AlzActProcessAmountsId.class))).thenReturn(Optional.of(existing));

        ActuaryProcessAmountAdapter adapter = new ActuaryProcessAmountAdapter(repository);
        adapter.save(incoming);

        ArgumentCaptor<AlzActProcessAmounts> captor = ArgumentCaptor.forClass(AlzActProcessAmounts.class);
        verify(repository).save(captor.capture());

        AlzActProcessAmounts saved = captor.getValue();
        assertThat(saved.getGrossCyAmount()).isEqualByComparingTo("999");
        assertThat(saved.getReCyAmount()).isEqualByComparingTo("20");
        assertThat(saved.getNetCyAmount()).isEqualByComparingTo("777");
        assertThat(saved.getGrossCyAmountRate()).isEqualByComparingTo("2.50");
    }

    @Test
    void saveAll_ShouldPersistAllMappedEntities() {
        ActuaryProcessAmount first = amount("P1001", 10, new BigDecimal("100"), null, null, null);
        ActuaryProcessAmount second = amount("P1001", 11, new BigDecimal("200"), null, null, null);

        when(repository.findById(any(AlzActProcessAmountsId.class))).thenReturn(Optional.empty());

        ActuaryProcessAmountAdapter adapter = new ActuaryProcessAmountAdapter(repository);
        adapter.saveAll(List.of(first, second));

        ArgumentCaptor<List<AlzActProcessAmounts>> captor = ArgumentCaptor.forClass(List.class);
        verify(repository).saveAll(captor.capture());

        List<AlzActProcessAmounts> saved = captor.getValue();
        assertThat(saved).hasSize(2);
        assertThat(saved).extracting(AlzActProcessAmounts::getRuleId).containsExactly(10, 11);
    }

    private ActuaryProcessAmount amount(String processId,
                                        Integer ruleId,
                                        BigDecimal grossCy,
                                        BigDecimal reCy,
                                        BigDecimal netCy,
                                        BigDecimal grossCyRate) {
        return new ActuaryProcessAmount(
                2026,
                7,
                processId,
                ruleId,
                grossCy,
                reCy,
                netCy,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                grossCyRate,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null
        );
    }
}

