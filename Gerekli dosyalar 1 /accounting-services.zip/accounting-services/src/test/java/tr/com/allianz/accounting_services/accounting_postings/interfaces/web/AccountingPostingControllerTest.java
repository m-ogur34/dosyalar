package tr.com.allianz.accounting_services.accounting_postings.interfaces.web;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import tr.com.allianz.accounting_services.accounting_postings.application.usecases.CreatePostingUseCase;
import tr.com.allianz.accounting_services.accounting_postings.application.usecases.ReversePostingUseCase;
import tr.com.allianz.accounting_services.accounting_postings.interfaces.web.dto.CreatePostingRequest;
import tr.com.allianz.accounting_services.accounting_postings.interfaces.web.dto.CreatePostingResponse;
import tr.com.allianz.accounting_services.accounting_postings.interfaces.web.dto.PostingCreateDto;
import tr.com.allianz.accounting_services.accounting_postings.interfaces.web.dto.ReversePostingRequest;
import tr.com.allianz.accounting_services.accounting_postings.interfaces.web.dto.ReversePostingResponse;

import java.util.Collections;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)
class AccountingPostingControllerTest {

    private MockMvc mockMvc;

    @Mock
    private CreatePostingUseCase createPostingUseCase;

    @Mock
    private ReversePostingUseCase reversePostingUseCase;

    @InjectMocks
    private AccountingPostingController accountingPostingController;

    private final ObjectMapper objectMapper = new ObjectMapper();

    @BeforeEach
    void setUp() {
        objectMapper.registerModule(new com.fasterxml.jackson.datatype.jsr310.JavaTimeModule());
        objectMapper.disable(com.fasterxml.jackson.databind.SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
        
        org.springframework.http.converter.json.MappingJackson2HttpMessageConverter converter = 
                new org.springframework.http.converter.json.MappingJackson2HttpMessageConverter(objectMapper);
                
        mockMvc = MockMvcBuilders.standaloneSetup(accountingPostingController)
                .setMessageConverters(converter)
                .build();
    }

    @Test
    void testCreatePosting() throws Exception {
        CreatePostingResponse response = new CreatePostingResponse();
        response.setBatchId(12345L);

        when(createPostingUseCase.handle(any(CreatePostingRequest.class))).thenReturn(response);

        CreatePostingRequest request = new CreatePostingRequest();
        PostingCreateDto dto = new PostingCreateDto();
        dto.setAccountCategoryCode("ACC1");
        dto.setEventTypeCode("EV1");
        dto.setPostingType("PT1");
        dto.setEventOrderNo(1L);
        dto.setSubfactor1Val("S1");
        dto.setSubfactor2Val("S2");
        dto.setSubfactor3Val("S3");
        dto.setSubfactor4Val("S4");
        dto.setPostingAmount(new java.math.BigDecimal("100.50"));
        dto.setPostingDate(java.time.LocalDate.of(2026, 4, 15));
        dto.setSwiftCode("SWIFT1");
        dto.setCurrencyExchangeRate(new java.math.BigDecimal("1.0"));
        dto.setExplanation("Explanation");
        dto.setInvoiceNo("INV1");
        dto.setInvoiceDate(java.time.LocalDate.of(2026, 4, 15));
        dto.setExternalBankReferenceNo("EXT1");
        dto.setInternalBankReferenceNo("INT1");
        request.setPostings(Collections.singletonList(dto));

        mockMvc.perform(post("/api/v1/accounting-postings/create")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.code").value("ACCOUNTING_POSTING_CREATED"))
                .andExpect(jsonPath("$.data.batchId").value(12345));
                
        verify(createPostingUseCase).handle(any(CreatePostingRequest.class));
    }

    @Test
    void testReversePosting() throws Exception {
        ReversePostingResponse response = new ReversePostingResponse();
        response.setBatchId(123L);
        response.setPostingDate(java.time.LocalDate.of(2026, 4, 16));
        response.setReverseBatchId(456L);

        when(reversePostingUseCase.handle(any())).thenReturn(Collections.singletonList(response));

        ReversePostingRequest req = new ReversePostingRequest();
        req.setBatchId(123L);
        req.setPostingDate(java.time.LocalDate.of(2026, 4, 16));

        List<ReversePostingRequest> requestList = Collections.singletonList(req);

        mockMvc.perform(post("/api/v1/accounting-postings/reverse")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(requestList)))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.code").value("ACCOUNTING_POSTING_REVERSED"))
                .andExpect(jsonPath("$.data[0].batchId").value(123))
                .andExpect(jsonPath("$.data[0].reverseBatchId").value(456))
                .andExpect(jsonPath("$.data[0].postingDate").value("2026-04-16"));

        verify(reversePostingUseCase).handle(any());
    }
}
