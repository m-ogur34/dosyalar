package tr.com.allianz.accounting_services.cyclic_postings.infrastructure.persistence.adapter;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import tr.com.allianz.accounting_services.cyclic_postings.application.exception.CyclicAccountMappingNotFoundException;
import tr.com.allianz.accounting_services.cyclic_postings.application.usecases.AlzCyclicAccountMappingReadModel;
import tr.com.allianz.accounting_services.cyclic_postings.application.usecases.CreateCyclicMappingCommand;
import tr.com.allianz.accounting_services.cyclic_postings.infrastructure.persistence.entity.AlzCyclicAccountMapping;
import tr.com.allianz.accounting_services.cyclic_postings.infrastructure.persistence.repository.AlzCyclicAccountMappingRepository;
import tr.com.allianz.accounting_services.cyclic_postings.interfaces.web.dto.RemoveAlzCyclicAccountMappingRequest;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CyclicPostingMappingAdapterTest {

    @InjectMocks
    CyclicPostingMappingAdapter adapter;

    @Mock
    AlzCyclicAccountMappingRepository repository;

    @Test
    void shouldCreateAndSaveCyclicPostingMapping() {
        // given
        CreateCyclicMappingCommand command =
                new CreateCyclicMappingCommand("ACC001", "CYCLIC001");

        String expectedId ="ACC001";
        String expectedCyclicId ="CYCLIC001";

        AlzCyclicAccountMapping savedEntity =
                new AlzCyclicAccountMapping(expectedId,expectedCyclicId);

        when(repository.save(any(AlzCyclicAccountMapping.class)))
                .thenReturn(savedEntity);

        // when
        AlzCyclicAccountMapping result =
                adapter.createCyclicPostingMapping(command);

        // then
        assertNotNull(result);
        assertEquals("ACC001", result.getAccountNo());
        assertEquals("CYCLIC001", result.getCyclicAccountNo());

        ArgumentCaptor<AlzCyclicAccountMapping> captor =
                ArgumentCaptor.forClass(AlzCyclicAccountMapping.class);

        verify(repository).save(captor.capture());

        AlzCyclicAccountMapping capturedEntity = captor.getValue();
        assertEquals(expectedId, capturedEntity.getAccountNo());
    }

    @Test
    void shouldReturnMappedCyclingAccountList() {
        // given
        AlzCyclicAccountMapping mapping1 = new AlzCyclicAccountMapping("ACC001", "CYCLIC001");
        AlzCyclicAccountMapping mapping2 = new AlzCyclicAccountMapping("ACC002", "CYCLIC002");

        when(repository.findAll())
                .thenReturn(java.util.List.of(mapping1, mapping2));

        // when
        List<AlzCyclicAccountMappingReadModel> result = adapter.listCyclingAccountMapping();

        // then
        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals("ACC001", result.get(0).accountNo());
        assertEquals("CYCLIC001", result.get(0).cyclicAccountNo());
        assertEquals("ACC002", result.get(1).accountNo());
        assertEquals("CYCLIC002", result.get(1).cyclicAccountNo());

        verify(repository).findAll();
    }

    @Test
    void shouldReturnEmptyListWhenNoMappingsFound() {
        // given
        when(repository.findAll()).thenReturn(Collections.emptyList());

        // when
        List<AlzCyclicAccountMappingReadModel> result = adapter.listCyclingAccountMapping();

        // then
        assertThat(result).isEmpty();
        verify(repository).findAll();
    }

    @Test
    void shouldRemoveCyclicPostingMappingSuccessfully() {
        // given
        String accountNo = "ACC001";
        RemoveAlzCyclicAccountMappingRequest request = new RemoveAlzCyclicAccountMappingRequest(accountNo);
        AlzCyclicAccountMapping existingMapping = new AlzCyclicAccountMapping(accountNo, "CYCLIC001");

        when(repository.findById(accountNo)).thenReturn(Optional.of(existingMapping));
        doNothing().when(repository).delete(existingMapping);

        // when
        adapter.removeCyclicPostingMapping(request);

        // then
        verify(repository).findById(accountNo);
        verify(repository).delete(existingMapping);
    }

    @Test
    void shouldThrowExceptionWhenRemovingNonExistentMapping() {
        // given
        String accountNo = "ACC999";
        RemoveAlzCyclicAccountMappingRequest request = new RemoveAlzCyclicAccountMappingRequest(accountNo);

        when(repository.findById(accountNo)).thenReturn(Optional.empty());

        // when & then
        assertThatThrownBy(() -> adapter.removeCyclicPostingMapping(request))
                .isInstanceOf(CyclicAccountMappingNotFoundException.class)
                .hasMessageContaining("Cyclic account mapping not found");

        verify(repository).findById(accountNo);
        verify(repository, never()).delete(any(AlzCyclicAccountMapping.class));
    }

    @Test
    void shouldCreateMultipleMappingsWithDifferentAccounts() {
        // given
        CreateCyclicMappingCommand command1 = new CreateCyclicMappingCommand("ACC001", "CYCLIC001");
        CreateCyclicMappingCommand command2 = new CreateCyclicMappingCommand("ACC002", "CYCLIC002");

        AlzCyclicAccountMapping savedEntity1 = new AlzCyclicAccountMapping("ACC001", "CYCLIC001");
        AlzCyclicAccountMapping savedEntity2 = new AlzCyclicAccountMapping("ACC002", "CYCLIC002");

        when(repository.save(any(AlzCyclicAccountMapping.class)))
                .thenReturn(savedEntity1)
                .thenReturn(savedEntity2);

        // when
        AlzCyclicAccountMapping result1 = adapter.createCyclicPostingMapping(command1);
        AlzCyclicAccountMapping result2 = adapter.createCyclicPostingMapping(command2);

        // then
        assertThat(result1.getAccountNo()).isEqualTo("ACC001");
        assertThat(result2.getAccountNo()).isEqualTo("ACC002");
        verify(repository, times(2)).save(any(AlzCyclicAccountMapping.class));
    }

    @Test
    void shouldMapReadModelCorrectly() {
        // given
        AlzCyclicAccountMapping mapping = new AlzCyclicAccountMapping("ACC123", "CYCLIC456");
        when(repository.findAll()).thenReturn(List.of(mapping));

        // when
        List<AlzCyclicAccountMappingReadModel> result = adapter.listCyclingAccountMapping();

        // then
        assertThat(result).hasSize(1);
        AlzCyclicAccountMappingReadModel readModel = result.getFirst();
        assertThat(readModel.accountNo()).isEqualTo("ACC123");
        assertThat(readModel.cyclicAccountNo()).isEqualTo("CYCLIC456");
    }

    @Test
    void shouldVerifyRepositoryInteractionsForRemove() {
        // given
        String accountNo = "ACC001";
        RemoveAlzCyclicAccountMappingRequest request = new RemoveAlzCyclicAccountMappingRequest(accountNo);
        AlzCyclicAccountMapping existingMapping = new AlzCyclicAccountMapping(accountNo, "CYCLIC001");

        when(repository.findById(accountNo)).thenReturn(Optional.of(existingMapping));

        // when
        adapter.removeCyclicPostingMapping(request);

        // then
        verify(repository, times(1)).findById(accountNo);
        verify(repository, times(1)).delete(existingMapping);
        verifyNoMoreInteractions(repository);
    }

    @Test
    void shouldHandleNullValuesInCommand() {
        // given
        CreateCyclicMappingCommand command = new CreateCyclicMappingCommand(null, null);
        AlzCyclicAccountMapping savedEntity = new AlzCyclicAccountMapping(null, null);

        when(repository.save(any(AlzCyclicAccountMapping.class))).thenReturn(savedEntity);

        // when
        AlzCyclicAccountMapping result = adapter.createCyclicPostingMapping(command);

        // then
        assertThat(result.getAccountNo()).isNull();
        assertThat(result.getCyclicAccountNo()).isNull();
        verify(repository).save(any(AlzCyclicAccountMapping.class));
    }

    @Test
    void shouldListMultipleMappings() {
        // given
        AlzCyclicAccountMapping mapping1 = new AlzCyclicAccountMapping("ACC001", "CYCLIC001");
        AlzCyclicAccountMapping mapping2 = new AlzCyclicAccountMapping("ACC002", "CYCLIC002");
        AlzCyclicAccountMapping mapping3 = new AlzCyclicAccountMapping("ACC003", "CYCLIC003");

        when(repository.findAll()).thenReturn(List.of(mapping1, mapping2, mapping3));

        // when
        List<AlzCyclicAccountMappingReadModel> result = adapter.listCyclingAccountMapping();

        // then
        assertThat(result).hasSize(3);
        assertThat(result.get(0).accountNo()).isEqualTo("ACC001");
        assertThat(result.get(1).accountNo()).isEqualTo("ACC002");
        assertThat(result.get(2).accountNo()).isEqualTo("ACC003");
    }
}