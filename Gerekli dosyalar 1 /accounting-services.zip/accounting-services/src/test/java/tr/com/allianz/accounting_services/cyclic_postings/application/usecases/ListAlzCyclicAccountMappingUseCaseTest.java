package tr.com.allianz.accounting_services.cyclic_postings.application.usecases;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import tr.com.allianz.accounting_services.cyclic_postings.application.port.out.CyclicPostingMappingPort;

import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class ListAlzCyclicAccountMappingUseCaseTest {

    @Test
    void handle_ShouldReturnListFromPort() {
        // Arrange
        CyclicPostingMappingPort mockPort = mock(CyclicPostingMappingPort.class);
        ListAlzCyclicAccountMappingUseCase useCase = new ListAlzCyclicAccountMappingUseCase(mockPort);
        List<AlzCyclicAccountMappingReadModel> expectedList = Collections.emptyList();
        when(mockPort.listCyclingAccountMapping()).thenReturn(expectedList);

        // Act
        List<AlzCyclicAccountMappingReadModel> result = useCase.handle();

        // Assert
        assertEquals(expectedList, result);
        Mockito.verify(mockPort).listCyclingAccountMapping();
    }
}