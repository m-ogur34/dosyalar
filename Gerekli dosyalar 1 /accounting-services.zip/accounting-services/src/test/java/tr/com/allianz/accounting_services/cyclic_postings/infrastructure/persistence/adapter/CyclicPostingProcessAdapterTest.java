package tr.com.allianz.accounting_services.cyclic_postings.infrastructure.persistence.adapter;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import tr.com.allianz.accounting_services.cyclic_postings.application.usecases.posting_process.AlzCyclicPostingProcessReadModel;
import tr.com.allianz.accounting_services.cyclic_postings.domain.valueobject.ProcessStatus;
import tr.com.allianz.accounting_services.cyclic_postings.infrastructure.persistence.entity.AlzCyclicPostingProcess;
import tr.com.allianz.accounting_services.cyclic_postings.infrastructure.persistence.repository.AlzCyclicPostingProcessRepository;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CyclicPostingProcessAdapterTest {

    @Mock
    private AlzCyclicPostingProcessRepository repository;

    @InjectMocks
    private CyclicPostingProcessAdapter adapter;

    private AlzCyclicPostingProcess testProcess;
    private LocalDateTime now;

    final Pageable pageable = PageRequest.of(0, 10);


    private final Long batchId = null;
    private final Long cyclicBatchId = null;
    private final String status = null;

    @BeforeEach
    void setUp() {
        now = LocalDateTime.now();
        testProcess = createProcess(1L, 2L, ProcessStatus.CREATED, null);
    }

    @Test
    void shouldFindProcessById() {
        // Given
        Long batchId = 1L;
        when(repository.findById(batchId)).thenReturn(Optional.of(testProcess));

        // When
        AlzCyclicPostingProcess result = adapter.findById(batchId);

        // Then
        assertThat(result).isNotNull();
        assertThat(result.getBatchId()).isEqualTo(batchId);
        verify(repository).findById(batchId);
    }

    @Test
    void shouldReturnNullWhenProcessNotFound() {
        // Given
        Long batchId = 999L;
        when(repository.findById(batchId)).thenReturn(Optional.empty());

        // When
        AlzCyclicPostingProcess result = adapter.findById(batchId);

        // Then
        assertThat(result).isNull();
        verify(repository).findById(batchId);
    }

    @Test
    void shouldSaveProcess() {
        // Given
        when(repository.save(testProcess)).thenReturn(testProcess);

        // When
        AlzCyclicPostingProcess result = adapter.save(testProcess);

        // Then
        assertThat(result).isNotNull();
        assertThat(result).isEqualTo(testProcess);
        verify(repository).save(testProcess);
    }

    @Test
    void shouldCallCyclicPostingProcedure() {
        // Given
        Long batchId = 1L;
        doNothing().when(repository).callCyclicPostingProcedure(batchId);

        // When
        adapter.callCyclicPostingProcedure(batchId);

        // Then
        verify(repository).callCyclicPostingProcedure(batchId);
    }

    @Test
    void shouldListAllCyclicPostingProcesses() {
        // Given
        AlzCyclicPostingProcess process1 = createProcess(1L, 4L, ProcessStatus.CREATED, null);
        AlzCyclicPostingProcess process2 = createProcess(2L, 5L, ProcessStatus.PROCESSED, null);
        AlzCyclicPostingProcess process3 = createProcess(3L, 6L, ProcessStatus.ERROR_OCCURRED, "Error message");

        List<AlzCyclicPostingProcess> processes = Arrays.asList(process1, process2, process3);

        Page<AlzCyclicPostingProcess> page = new org.springframework.data.domain.PageImpl<>(processes);

        // Fixed: Use matches for (Example, Pageable) instead of just (Pageable)
        when(repository.findAll(any(org.springframework.data.domain.Example.class), any(Pageable.class)))
                .thenReturn(page);

        // When
        List<AlzCyclicPostingProcessReadModel> result = adapter.listAllCyclicPostingProcesses(pageable, batchId, cyclicBatchId, status);

        // Then
        assertThat(result).hasSize(3);
        assertThat(result.getFirst().batchId()).isEqualTo(1L);
        assertThat(result.get(0).cyclicBatchId()).isEqualTo(4L);
        assertThat(result.get(0).processStatus()).isEqualTo(ProcessStatus.CREATED.getValue());
        assertThat(result.get(1).batchId()).isEqualTo(2L);
        assertThat(result.get(2).batchId()).isEqualTo(3L);
        assertThat(result.get(2).errText()).isEqualTo("Error message");

        // Fixed: Verify the correct method signature
        verify(repository).findAll(any(org.springframework.data.domain.Example.class), any(Pageable.class));
    }

    @Test
    void shouldReturnEmptyListWhenNoProcessesFound() {
        // Given
        // Match findAll(Example, Pageable) because the adapter uses Query By Example for filtering
        when(repository.findAll(any(org.springframework.data.domain.Example.class), any(Pageable.class)))
                .thenReturn(Page.empty());

        // When
        List<AlzCyclicPostingProcessReadModel> result = adapter.listAllCyclicPostingProcesses(pageable, batchId, cyclicBatchId, status);

        // Then
        assertThat(result).isEmpty();
        verify(repository).findAll(any(org.springframework.data.domain.Example.class), any(Pageable.class));
    }

    @Test
    void shouldRemoveCyclicPostingProcess() {
        // Given
        Long batchId = 1L;
        doNothing().when(repository).deleteById(batchId);

        // When
        adapter.removeCyclicPostingProcess(batchId);

        // Then
        verify(repository).deleteById(batchId);
    }

    @Test
    void shouldSaveAllProcesses() {
        // Given
        AlzCyclicPostingProcess process1 = createProcess(1L, 3L, ProcessStatus.CREATED, null);
        AlzCyclicPostingProcess process2 = createProcess(2L, 4L, ProcessStatus.CREATED, null);
        List<AlzCyclicPostingProcess> processes = Arrays.asList(process1, process2);

        when(repository.saveAll(processes)).thenReturn(processes);

        // When
        List<AlzCyclicPostingProcess> result = adapter.saveAll(processes);

        // Then
        assertThat(result).hasSize(2);
        assertThat(result).containsExactly(process1, process2);
        verify(repository).saveAll(processes);
    }

    @Test
    void shouldSaveEmptyList() {
        // Given
        List<AlzCyclicPostingProcess> emptyList = Collections.emptyList();
        when(repository.saveAll(emptyList)).thenReturn(emptyList);

        // When
        List<AlzCyclicPostingProcess> result = adapter.saveAll(emptyList);

        // Then
        assertThat(result).isEmpty();
        verify(repository).saveAll(emptyList);
    }

    @Test
    void shouldMapReadModelCorrectly() {
        // Given
        AlzCyclicPostingProcess process = createProcess(1L, 2L, ProcessStatus.PROCESSED, "Test error");

        // Wrap the list in a Page
        Page<AlzCyclicPostingProcess> page = new org.springframework.data.domain.PageImpl<>(Collections.singletonList(process));

        // Fixed: Match findAll(Example, Pageable) instead of just (Pageable)
        when(repository.findAll(any(org.springframework.data.domain.Example.class), any(Pageable.class)))
                .thenReturn(page);

        // When
        List<AlzCyclicPostingProcessReadModel> result = adapter.listAllCyclicPostingProcesses(pageable, batchId, cyclicBatchId, status);

        // Then
        assertThat(result).hasSize(1);
        AlzCyclicPostingProcessReadModel readModel = result.getFirst();
        assertThat(readModel.batchId()).isEqualTo(process.getBatchId());
        assertThat(readModel.cyclicBatchId()).isEqualTo(process.getCyclicBatchId());
        assertThat(readModel.processStatus()).isEqualTo(process.getProcessStatus());
        assertThat(readModel.errText()).isEqualTo(process.getErrText());
        assertThat(readModel.createdDate()).isEqualTo(process.getCreatedDate());
        assertThat(readModel.updatedDate()).isEqualTo(process.getUpdatedDate());

        // Fixed: Verify the correct method signature
        verify(repository).findAll(any(org.springframework.data.domain.Example.class), any(Pageable.class));
    }

    @Test
    void shouldVerifyRepositoryInteractions() {
        // Given
        Long batchId = 1L;
        when(repository.findById(batchId)).thenReturn(Optional.of(testProcess));
        when(repository.save(testProcess)).thenReturn(testProcess);

        // When
        adapter.findById(batchId);
        adapter.save(testProcess);

        // Then
        verify(repository, times(1)).findById(batchId);
        verify(repository, times(1)).save(testProcess);
    }

    private AlzCyclicPostingProcess createProcess(Long batchId, Long cyclicBatchId, ProcessStatus status, String errText) {
        AlzCyclicPostingProcess process = new AlzCyclicPostingProcess();
        process.setBatchId(batchId);
        process.setCyclicBatchId(cyclicBatchId);
        process.setProcessStatusEnum(status);
        process.setErrText(errText);
        process.setPostingDate(LocalDate.now());
        process.setCreatedDate(now);
        process.setUpdatedDate(now);
        return process;
    }
}