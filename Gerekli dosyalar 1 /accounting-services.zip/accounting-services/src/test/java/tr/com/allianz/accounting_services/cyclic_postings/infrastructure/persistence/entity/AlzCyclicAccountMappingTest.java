package tr.com.allianz.accounting_services.cyclic_postings.infrastructure.persistence.entity;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class AlzCyclicAccountMappingTest {
    private final String accountNo = "ACC001";
    private final String cyclicAccountNo = "CYCLIC001";

    @Test
    void testConstructorAndGetId() {
        AlzCyclicAccountMapping entity =
                new AlzCyclicAccountMapping(accountNo, cyclicAccountNo);

        assertNotNull(entity.getAccountNo());
        assertEquals(accountNo, entity.getAccountNo());
    }

    @Test
    void testGetAccountNo() {

        AlzCyclicAccountMapping entity =
                new AlzCyclicAccountMapping(accountNo, cyclicAccountNo);

        assertEquals("ACC001", entity.getAccountNo());
    }

    @Test
    void testGetCyclicAccountNo() {

        AlzCyclicAccountMapping entity =
                new AlzCyclicAccountMapping(accountNo, cyclicAccountNo);

        assertEquals("CYCLIC001", entity.getCyclicAccountNo());
    }

    @Test
    void testNoArgsConstructor() {
        AlzCyclicAccountMapping entity = new AlzCyclicAccountMapping();
        assertNull(entity.getAccountNo());
    }
}
