package tr.com.allianz.accounting_services.actuary.application.usecases;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import tr.com.allianz.accounting_services.actuary.application.port.out.SaveActuaryLogPort;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.ActuaryLog;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.ActuaryLogType;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class SaveActuaryLogUseCaseTest {

    @Mock
    private SaveActuaryLogPort saveActuaryLogPort;

    @Test
    void handle_ShouldBuildAndPersistLogWithEnumType() {
        SaveActuaryLogUseCase useCase = new SaveActuaryLogUseCase(saveActuaryLogPort);

        useCase.handle(
                2024,
                6,
                "P1001",
                100,
                ActuaryLogType.AMOUNT_UPDATE,
                "Amount updated for rule ID: 100",
                "tester"
        );

        ArgumentCaptor<ActuaryLog> captor = ArgumentCaptor.forClass(ActuaryLog.class);
        verify(saveActuaryLogPort).save(captor.capture());

        ActuaryLog savedLog = captor.getValue();
        assertThat(savedLog.year()).isEqualTo(2024);
        assertThat(savedLog.month()).isEqualTo(6);
        assertThat(savedLog.processId()).isEqualTo("P1001");
        assertThat(savedLog.ruleId()).isEqualTo(100);
        assertThat(savedLog.logType()).isEqualTo(ActuaryLogType.AMOUNT_UPDATE);
        assertThat(savedLog.logText()).isEqualTo("Amount updated for rule ID: 100");
        assertThat(savedLog.byUser()).isEqualTo("tester");
        assertThat(savedLog.dateCreated()).isNotNull();
    }

    @Test
    void handle_ShouldRejectProcessIdLongerThanTenChars() {
        SaveActuaryLogUseCase useCase = new SaveActuaryLogUseCase(saveActuaryLogPort);

        assertThatThrownBy(() -> useCase.handle(
                2024,
                6,
                "EXCEL_BULK_UPLOAD",
                null,
                ActuaryLogType.EXCEL_UPLOAD,
                "Excel file uploaded with 1 records",
                "tester"
        ))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("at most 10 characters");
    }

    @Test
    void handle_ShouldAllowNullProcessId() {
        SaveActuaryLogUseCase useCase = new SaveActuaryLogUseCase(saveActuaryLogPort);

        useCase.handle(
                2024,
                6,
                null,
                null,
                ActuaryLogType.EXCEL_UPLOAD,
                "Excel file uploaded with 1 records",
                "tester"
        );

        ArgumentCaptor<ActuaryLog> captor = ArgumentCaptor.forClass(ActuaryLog.class);
        verify(saveActuaryLogPort).save(captor.capture());
        assertThat(captor.getValue().processId()).isNull();
    }

    @Test
    void handle_ShouldRejectNullProcessIdForAmountUpdate() {
        SaveActuaryLogUseCase useCase = new SaveActuaryLogUseCase(saveActuaryLogPort);

        assertThatThrownBy(() -> useCase.handle(
                2024,
                6,
                null,
                100,
                ActuaryLogType.AMOUNT_UPDATE,
                "Amount updated for rule ID: 100",
                "tester"
        ))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("required for AMOUNT_UPDATE");
    }
}

