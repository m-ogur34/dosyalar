package tr.com.allianz.accounting_services.actuary.postings.interfaces.web;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import tr.com.allianz.accounting_services.actuary.postings.application.usecases.ExportActuaryPostingBatchInfoExcelUseCase;
import tr.com.allianz.accounting_services.actuary.postings.application.usecases.GetActuaryPostingBatchInfoCommand;
import tr.com.allianz.accounting_services.actuary.postings.application.usecases.GetActuaryPostingBatchInfoUseCase;
import tr.com.allianz.accounting_services.actuary.postings.domain.model.ActuaryPostingBatchInfoExcelFile;
import tr.com.allianz.accounting_services.actuary.postings.domain.model.ActuaryPostingBatchInfoLine;
import tr.com.allianz.accounting_services.actuary.postings.interfaces.web.dto.ActuaryPostingBatchInfoRequest;
import tr.com.allianz.accounting_services.actuary.postings.interfaces.web.dto.ActuaryPostingBatchInfoResponse;
import tr.com.allianz.accounting_services.shared.api.ApiResponse;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ActuaryPostingBatchInfoControllerTest {

    @Mock
    private GetActuaryPostingBatchInfoUseCase getActuaryPostingBatchInfoUseCase;

    @Mock
    private ExportActuaryPostingBatchInfoExcelUseCase exportActuaryPostingBatchInfoExcelUseCase;

    @Test
    void getBatchInfo_ShouldReturnMappedApiResponse() {
        ActuaryPostingBatchInfoRequest request = new ActuaryPostingBatchInfoRequest(
                10L,
                LocalDate.of(2026, 7, 17),
                "3401",
                60L,
                "PARTITION",
                1
        );
        GetActuaryPostingBatchInfoCommand expectedCommand = new GetActuaryPostingBatchInfoCommand(
                10L,
                LocalDate.of(2026, 7, 17),
                "3401",
                60L,
                "PARTITION",
                1
        );
        when(getActuaryPostingBatchInfoUseCase.handle(expectedCommand)).thenReturn(List.of(
                new ActuaryPostingBatchInfoLine("100", "Cash", "Explanation 1", BigDecimal.TEN, BigDecimal.ZERO)
        ));

        ActuaryPostingBatchInfoController controller = new ActuaryPostingBatchInfoController(
                getActuaryPostingBatchInfoUseCase,
                exportActuaryPostingBatchInfoExcelUseCase
        );

        ResponseEntity<ApiResponse<ActuaryPostingBatchInfoResponse>> response = controller.getBatchInfo(request);

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().data().items()).hasSize(1);
        assertThat(response.getBody().data().items().getFirst().accountNo()).isEqualTo("100");
        assertThat(response.getBody().data().items().getFirst().accountExp()).isEqualTo("Cash");
        assertThat(response.getBody().data().items().getFirst().explanation()).isEqualTo("Explanation 1");
        assertThat(response.getBody().data().items().getFirst().borc()).isEqualByComparingTo("10");
        assertThat(response.getBody().data().items().getFirst().alacak()).isEqualByComparingTo("0");
        verify(getActuaryPostingBatchInfoUseCase).handle(expectedCommand);
    }

    @Test
    void exportBatchInfoToExcel_ShouldReturnAttachmentResponse() {
        ActuaryPostingBatchInfoRequest request = new ActuaryPostingBatchInfoRequest(
                10L,
                LocalDate.of(2026, 7, 17),
                "3401",
                60L,
                "PARTITION",
                1
        );
        GetActuaryPostingBatchInfoCommand expectedCommand = new GetActuaryPostingBatchInfoCommand(
                10L,
                LocalDate.of(2026, 7, 17),
                "3401",
                60L,
                "PARTITION",
                1
        );
        byte[] content = {1, 2, 3};
        when(exportActuaryPostingBatchInfoExcelUseCase.handle(expectedCommand))
                .thenReturn(new ActuaryPostingBatchInfoExcelFile("Aylık_Fişi_202607201430.xlsx", content));

        ActuaryPostingBatchInfoController controller = new ActuaryPostingBatchInfoController(
                getActuaryPostingBatchInfoUseCase,
                exportActuaryPostingBatchInfoExcelUseCase
        );

        ResponseEntity<byte[]> response = controller.exportBatchInfoToExcel(request);

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        String contentDisposition = response.getHeaders().getFirst(HttpHeaders.CONTENT_DISPOSITION);
        assertThat(contentDisposition).isNotNull();
        assertThat(contentDisposition).contains("attachment;");
        assertThat(contentDisposition).contains("filename*=UTF-8''Ayl%C4%B1k_Fi%C5%9Fi_202607201430.xlsx");
        assertThat(response.getHeaders().getContentType()).isEqualTo(org.springframework.http.MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"));
        assertThat(response.getBody()).containsExactly(content);
        verify(exportActuaryPostingBatchInfoExcelUseCase).handle(expectedCommand);
    }

    @Test
    void getBatchInfo_ShouldPassThroughOptionalNullFields() {
        ActuaryPostingBatchInfoRequest request = new ActuaryPostingBatchInfoRequest(
                10L,
                LocalDate.of(2026, 7, 17),
                null,
                null,
                null,
                null
        );
        GetActuaryPostingBatchInfoCommand expectedCommand = new GetActuaryPostingBatchInfoCommand(
                10L,
                LocalDate.of(2026, 7, 17),
                null,
                null,
                null,
                null
        );
        when(getActuaryPostingBatchInfoUseCase.handle(expectedCommand)).thenReturn(List.of());

        ActuaryPostingBatchInfoController controller = new ActuaryPostingBatchInfoController(
                getActuaryPostingBatchInfoUseCase,
                exportActuaryPostingBatchInfoExcelUseCase
        );

        ResponseEntity<ApiResponse<ActuaryPostingBatchInfoResponse>> response = controller.getBatchInfo(request);

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().data().items()).isEmpty();
        verify(getActuaryPostingBatchInfoUseCase).handle(expectedCommand);
    }
}

