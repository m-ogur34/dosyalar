package tr.com.allianz.accounting_services.actuary.infrastructure.persistence.adapter;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.ActuaryPeriodStatus;
import tr.com.allianz.accounting_services.actuary.infrastructure.persistence.entity.AlzActPeriods;
import tr.com.allianz.accounting_services.actuary.infrastructure.persistence.entity.AlzActPeriodsId;
import tr.com.allianz.accounting_services.actuary.infrastructure.persistence.repository.AlzActPeriodsRepository;

import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ActuaryPeriodStatusAdapterTest {

    @Mock
    private AlzActPeriodsRepository repository;

    @InjectMocks
    private ActuaryPeriodStatusAdapter adapter;

    private String processId = "P1001";
    private Integer year = 2024;
    private Integer month = 6;

    @BeforeEach
    void setUp() {
        processId = "P1001";
        year = 2024;
        month = 6;
    }

    @Test
    void getOrCreateInProgress_WhenPeriodExists_ShouldReturnExistingPeriod() {
        // Given
        AlzActPeriodsId id = new AlzActPeriodsId(processId, year, month);
        AlzActPeriods existingPeriod = new AlzActPeriods(processId, year, month, "EXISTING");
        existingPeriod.setStatusEnum(ActuaryPeriodStatus.IN_PROGRESS);
        when(repository.findById(id)).thenReturn(Optional.of(existingPeriod));

        // When
        AlzActPeriods result = adapter.getOrCreateInProgress(processId, year, month);

        // Then
        assertThat(result).isEqualTo(existingPeriod);
        verify(repository, times(1)).findById(id);
        verify(repository, never()).save(any());
    }

    @Test
    void getOrCreateInProgress_WhenPeriodDoesNotExist_ShouldCreateNewPeriodWithInProgressStatus() {
        // Given
        AlzActPeriodsId id = new AlzActPeriodsId(processId, year, month);
        AlzActPeriods newPeriod = new AlzActPeriods(processId, year, month, null);
        newPeriod.setStatusEnum(ActuaryPeriodStatus.IN_PROGRESS);
        
        when(repository.findById(id)).thenReturn(Optional.empty());
        when(repository.save(any(AlzActPeriods.class))).thenReturn(newPeriod);

        // When
        AlzActPeriods result = adapter.getOrCreateInProgress(processId, year, month);

        // Then
        assertThat(result).isNotNull();
        assertThat(result.getStatusEnum()).isEqualTo(ActuaryPeriodStatus.IN_PROGRESS);
        verify(repository, times(1)).findById(id);
        verify(repository, times(1)).save(any(AlzActPeriods.class));
    }

    @Test
    void upsertStatus_WhenPeriodExists_ShouldUpdateStatus() {
        // Given
        AlzActPeriodsId id = new AlzActPeriodsId(processId, year, month);
        AlzActPeriods existingPeriod = new AlzActPeriods(processId, year, month, "EXISTING");
        existingPeriod.setStatusEnum(ActuaryPeriodStatus.IN_PROGRESS);
        
        AlzActPeriods updatedPeriod = new AlzActPeriods(processId, year, month, "EXISTING");
        updatedPeriod.setStatusEnum(ActuaryPeriodStatus.APPROVED);

        when(repository.findById(id)).thenReturn(Optional.of(existingPeriod));
        when(repository.save(any(AlzActPeriods.class))).thenReturn(updatedPeriod);

        // When
        AlzActPeriods result = adapter.upsertStatus(processId, year, month, ActuaryPeriodStatus.APPROVED);

        // Then
        assertThat(result).isNotNull();
        assertThat(result.getStatusEnum()).isEqualTo(ActuaryPeriodStatus.APPROVED);
        verify(repository, times(1)).findById(id);
        verify(repository, times(1)).save(any(AlzActPeriods.class));
    }

    @Test
    void upsertStatus_WhenPeriodDoesNotExist_ShouldCreateNewPeriodWithGivenStatus() {
        // Given
        AlzActPeriodsId id = new AlzActPeriodsId(processId, year, month);
        AlzActPeriods newPeriod = new AlzActPeriods(processId, year, month, null);
        newPeriod.setStatusEnum(ActuaryPeriodStatus.APPROVED);

        when(repository.findById(id)).thenReturn(Optional.empty());
        when(repository.save(any(AlzActPeriods.class))).thenReturn(newPeriod);

        // When
        AlzActPeriods result = adapter.upsertStatus(processId, year, month, ActuaryPeriodStatus.APPROVED);

        // Then
        assertThat(result).isNotNull();
        assertThat(result.getStatusEnum()).isEqualTo(ActuaryPeriodStatus.APPROVED);
        verify(repository, times(1)).findById(id);
        verify(repository, times(1)).save(any(AlzActPeriods.class));
    }

    @ParameterizedTest
    @EnumSource(ActuaryPeriodStatus.class)
    void upsertStatus_WithVariousStatuses_ShouldUpdateCorrectly(ActuaryPeriodStatus status) {
        // Given
        AlzActPeriodsId id = new AlzActPeriodsId(processId, year, month);
        AlzActPeriods existingPeriod = new AlzActPeriods(processId, year, month, "TEST");
        AlzActPeriods updatedPeriod = new AlzActPeriods(processId, year, month, "TEST");
        updatedPeriod.setStatusEnum(status);

        when(repository.findById(id)).thenReturn(Optional.of(existingPeriod));
        when(repository.save(any(AlzActPeriods.class))).thenReturn(updatedPeriod);

        // When
        AlzActPeriods result = adapter.upsertStatus(processId, year, month, status);

        // Then
        assertThat(result.getStatusEnum()).isEqualTo(status);
    }

    @Test
    void getStatus_WhenPeriodExists_ShouldReturnStatus() {
        // Given
        AlzActPeriodsId id = new AlzActPeriodsId(processId, year, month);
        AlzActPeriods period = new AlzActPeriods(processId, year, month, "TEST");
        period.setStatusEnum(ActuaryPeriodStatus.APPROVED);

        when(repository.findById(id)).thenReturn(Optional.of(period));

        // When
        ActuaryPeriodStatus result = adapter.getStatus(processId, year, month);

        // Then
        assertThat(result).isEqualTo(ActuaryPeriodStatus.APPROVED);
        verify(repository, times(1)).findById(id);
    }

    @Test
    void getStatus_WhenPeriodDoesNotExist_ShouldReturnNull() {
        // Given
        AlzActPeriodsId id = new AlzActPeriodsId(processId, year, month);
        when(repository.findById(id)).thenReturn(Optional.empty());

        // When
        ActuaryPeriodStatus result = adapter.getStatus(processId, year, month);

        // Then
        assertThat(result).isNull();
        verify(repository, times(1)).findById(id);
    }

    @Test
    void getStatus_WithDifferentProcessIds_ShouldRetrieveCorrectly() {
        // Given
        String processId1 = "P1001";
        String processId2 = "P1002";
        
        AlzActPeriodsId id1 = new AlzActPeriodsId(processId1, 2024, 6);
        AlzActPeriodsId id2 = new AlzActPeriodsId(processId2, 2024, 6);
        
        AlzActPeriods period1 = new AlzActPeriods(processId1, 2024, 6, "TEST1");
        period1.setStatusEnum(ActuaryPeriodStatus.APPROVED);
        
        AlzActPeriods period2 = new AlzActPeriods(processId2, 2024, 6, "TEST2");
        period2.setStatusEnum(ActuaryPeriodStatus.IN_PROGRESS);

        when(repository.findById(id1)).thenReturn(Optional.of(period1));
        when(repository.findById(id2)).thenReturn(Optional.of(period2));

        // When & Then
        assertThat(adapter.getStatus(processId1, 2024, 6)).isEqualTo(ActuaryPeriodStatus.APPROVED);
        assertThat(adapter.getStatus(processId2, 2024, 6)).isEqualTo(ActuaryPeriodStatus.IN_PROGRESS);
    }
}

