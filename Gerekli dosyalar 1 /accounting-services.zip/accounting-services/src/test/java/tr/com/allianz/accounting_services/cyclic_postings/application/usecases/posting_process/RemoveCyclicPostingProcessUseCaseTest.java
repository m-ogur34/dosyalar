package tr.com.allianz.accounting_services.cyclic_postings.application.usecases.posting_process;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import tr.com.allianz.accounting_services.cyclic_postings.application.exception.CyclicPostingProcessNotFoundException;
import tr.com.allianz.accounting_services.cyclic_postings.application.port.out.CyclicPostingProcessPort;
import tr.com.allianz.accounting_services.cyclic_postings.domain.valueobject.ProcessStatus;
import tr.com.allianz.accounting_services.cyclic_postings.infrastructure.persistence.entity.AlzCyclicPostingProcess;

import java.time.LocalDate;
import java.time.LocalDateTime;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class RemoveCyclicPostingProcessUseCaseTest {

    @Mock
    private CyclicPostingProcessPort cyclicPostingProcessPort;

    private RemoveCyclicPostingProcessUseCase useCase;

    @BeforeEach
    void setUp() {
        useCase = new RemoveCyclicPostingProcessUseCase(cyclicPostingProcessPort);
    }

    @Test
    void shouldRemoveCyclicPostingProcessWhenStatusIsCreated() {
        // Given
        Long batchId = 1L;
        AlzCyclicPostingProcess process = createProcess(batchId, ProcessStatus.CREATED);
        when(cyclicPostingProcessPort.findById(batchId)).thenReturn(process);

        // When
        useCase.handle(batchId);

        // Then
        verify(cyclicPostingProcessPort).findById(batchId);
        verify(cyclicPostingProcessPort).removeCyclicPostingProcess(batchId);
    }

    @Test
    void shouldRemoveCyclicPostingProcessWhenStatusIsError() {
        // Given
        Long batchId = 2L;
        AlzCyclicPostingProcess process = createProcess(batchId, ProcessStatus.ERROR_OCCURRED);
        when(cyclicPostingProcessPort.findById(batchId)).thenReturn(process);

        // When
        useCase.handle(batchId);

        // Then
        verify(cyclicPostingProcessPort).findById(batchId);
        verify(cyclicPostingProcessPort).removeCyclicPostingProcess(batchId);
    }

    @Test
    void shouldThrowExceptionWhenProcessNotFound() {
        // Given
        Long batchId = 1L;
        when(cyclicPostingProcessPort.findById(batchId)).thenReturn(null);

        // When & Then
        assertThatThrownBy(() -> useCase.handle(batchId))
            .isInstanceOf(CyclicPostingProcessNotFoundException.class)
            .hasMessageContaining("Devreden fiş işleme kaydı bulunamadı");

        verify(cyclicPostingProcessPort).findById(batchId);
        verify(cyclicPostingProcessPort, never()).removeCyclicPostingProcess(anyLong());
    }

    @Test
    void shouldThrowExceptionWhenProcessStatusIsProcessed() {
        // Given
        Long batchId = 3L;
        AlzCyclicPostingProcess process = createProcess(batchId, ProcessStatus.PROCESSED);
        when(cyclicPostingProcessPort.findById(batchId)).thenReturn(process);

        // When & Then
        assertThatThrownBy(() -> useCase.handle(batchId))
            .isInstanceOf(IllegalStateException.class)
            .hasMessage("Sadece Yeni ve Hata durumundaki kayıtlar silinebilir.");

        verify(cyclicPostingProcessPort).findById(batchId);
        verify(cyclicPostingProcessPort, never()).removeCyclicPostingProcess(anyLong());
    }

    @Test
    void shouldHandleDifferentBatchIds() {
        // Given
        Long batchId1 = 100L;
        Long batchId2 = 200L;

        AlzCyclicPostingProcess process1 = createProcess(batchId1, ProcessStatus.CREATED);
        AlzCyclicPostingProcess process2 = createProcess(batchId2, ProcessStatus.ERROR_OCCURRED);

        when(cyclicPostingProcessPort.findById(batchId1)).thenReturn(process1);
        when(cyclicPostingProcessPort.findById(batchId2)).thenReturn(process2);

        // When
        useCase.handle(batchId1);
        useCase.handle(batchId2);

        // Then
        verify(cyclicPostingProcessPort).removeCyclicPostingProcess(batchId1);
        verify(cyclicPostingProcessPort).removeCyclicPostingProcess(batchId2);
    }

    @Test
    void shouldNotRemoveWhenStatusIsProcessedAndVerifyNoInteraction() {
        // Given
        Long batchId = 4L;
        AlzCyclicPostingProcess process = createProcess(batchId, ProcessStatus.PROCESSED);
        when(cyclicPostingProcessPort.findById(batchId)).thenReturn(process);

        // When & Then
        assertThatThrownBy(() -> useCase.handle(batchId))
            .isInstanceOf(IllegalStateException.class);

        verify(cyclicPostingProcessPort, times(1)).findById(batchId);
        verifyNoMoreInteractions(cyclicPostingProcessPort);
    }

    @Test
    void shouldHandleNullBatchIdScenario() {
        // Given
        Long batchId = null;
        when(cyclicPostingProcessPort.findById(batchId)).thenReturn(null);

        // When & Then
        assertThatThrownBy(() -> useCase.handle(batchId))
            .isInstanceOf(CyclicPostingProcessNotFoundException.class);

        verify(cyclicPostingProcessPort).findById(null);
    }

    private AlzCyclicPostingProcess createProcess(Long batchId, ProcessStatus status) {
        AlzCyclicPostingProcess process = new AlzCyclicPostingProcess();
        process.setBatchId(batchId);
        process.setProcessStatusEnum(status);
        process.setPostingDate(LocalDate.now());
        process.setCreatedDate(LocalDateTime.now());
        process.setUpdatedDate(LocalDateTime.now());
        return process;
    }
}