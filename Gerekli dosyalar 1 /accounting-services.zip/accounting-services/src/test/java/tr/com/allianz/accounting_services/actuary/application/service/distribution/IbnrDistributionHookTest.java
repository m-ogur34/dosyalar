package tr.com.allianz.accounting_services.actuary.application.service.distribution;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import tr.com.allianz.accounting_services.actuary.application.port.out.SaveActuaryPeriodStatusPort;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.ActuaryPeriodStatus;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class IbnrDistributionHookTest {

    @Mock
    private SaveActuaryPeriodStatusPort saveActuaryPeriodStatusPort;

    private IbnrDistributionHook hook() {
        return new IbnrDistributionHook(saveActuaryPeriodStatusPort);
    }

    @Test
    void supports_ShouldOnlyMatchIbnrProcessId() {
        IbnrDistributionHook hook = hook();

        assertThat(hook.supports("IBNR")).isTrue();
        assertThat(hook.supports("ULAE")).isFalse();
        assertThat(hook.supports(null)).isFalse();
    }


    @Test
    void afterExecute_ShouldMarkPeriodAsToBeReported() {
        IbnrDistributionHook hook = hook();
        DistributionProcessContext context = new DistributionProcessContext("IBNR", 2026, 6, "tester");

        hook.afterExecute(context);

        verify(saveActuaryPeriodStatusPort)
                .upsertStatus("IBNR", 2026, 6, ActuaryPeriodStatus.TO_BE_REPORTED);
    }
}
