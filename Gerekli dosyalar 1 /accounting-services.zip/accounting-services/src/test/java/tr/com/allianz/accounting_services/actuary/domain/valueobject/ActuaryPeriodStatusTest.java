package tr.com.allianz.accounting_services.actuary.domain.valueobject;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class ActuaryPeriodStatusTest {

    @Test
    void getValue_ShouldReturnCorrectStringForInProgress() {
        assertThat(ActuaryPeriodStatus.IN_PROGRESS.getValue()).isEqualTo("In Progress");
    }

    @Test
    void getValue_ShouldReturnCorrectStringForApproved() {
        assertThat(ActuaryPeriodStatus.APPROVED.getValue()).isEqualTo("Approved");
    }

    @Test
    void getValue_ShouldReturnCorrectStringForToBeReported() {
        assertThat(ActuaryPeriodStatus.TO_BE_REPORTED.getValue()).isEqualTo("ToBeReported");
    }

    @Test
    void getValue_ShouldReturnCorrectStringForReporting() {
        assertThat(ActuaryPeriodStatus.REPORTING.getValue()).isEqualTo("Reporting");
    }

    @Test
    void getValue_ShouldReturnCorrectStringForErrorOccurred() {
        assertThat(ActuaryPeriodStatus.ERROR_OCCURRED.getValue()).isEqualTo("ErrorOccurred");
    }

    @Test
    void fromValue_ShouldReturnInProgressWhenGivenInProgressInput() {
        ActuaryPeriodStatus result = ActuaryPeriodStatus.fromValue("In Progress");
        assertThat(result).isEqualTo(ActuaryPeriodStatus.IN_PROGRESS);
    }

    @Test
    void fromValue_ShouldReturnApprovedWhenGivenApprovedInput() {
        ActuaryPeriodStatus result = ActuaryPeriodStatus.fromValue("Approved");
        assertThat(result).isEqualTo(ActuaryPeriodStatus.APPROVED);
    }

    @Test
    void fromValue_ShouldReturnToBeReportedWhenGivenToBeReportedInput() {
        ActuaryPeriodStatus result = ActuaryPeriodStatus.fromValue("ToBeReported");
        assertThat(result).isEqualTo(ActuaryPeriodStatus.TO_BE_REPORTED);
    }

    @Test
    void fromValue_ShouldReturnReportingWhenGivenReportingInput() {
        ActuaryPeriodStatus result = ActuaryPeriodStatus.fromValue("Reporting");
        assertThat(result).isEqualTo(ActuaryPeriodStatus.REPORTING);
    }

    @Test
    void fromValue_ShouldReturnErrorOccurredWhenGivenErrorOccurredInput() {
        ActuaryPeriodStatus result = ActuaryPeriodStatus.fromValue("ErrorOccurred");
        assertThat(result).isEqualTo(ActuaryPeriodStatus.ERROR_OCCURRED);
    }

    @Test
    void fromValue_ShouldBeCaseInsensitive() {
        assertThat(ActuaryPeriodStatus.fromValue("in progress")).isEqualTo(ActuaryPeriodStatus.IN_PROGRESS);
        assertThat(ActuaryPeriodStatus.fromValue("IN PROGRESS")).isEqualTo(ActuaryPeriodStatus.IN_PROGRESS);
        assertThat(ActuaryPeriodStatus.fromValue("approved")).isEqualTo(ActuaryPeriodStatus.APPROVED);
        assertThat(ActuaryPeriodStatus.fromValue("APPROVED")).isEqualTo(ActuaryPeriodStatus.APPROVED);
        assertThat(ActuaryPeriodStatus.fromValue("tobereported")).isEqualTo(ActuaryPeriodStatus.TO_BE_REPORTED);
        assertThat(ActuaryPeriodStatus.fromValue("TOBEREPORTED")).isEqualTo(ActuaryPeriodStatus.TO_BE_REPORTED);
        assertThat(ActuaryPeriodStatus.fromValue("reporting")).isEqualTo(ActuaryPeriodStatus.REPORTING);
        assertThat(ActuaryPeriodStatus.fromValue("REPORTING")).isEqualTo(ActuaryPeriodStatus.REPORTING);
        assertThat(ActuaryPeriodStatus.fromValue("erroroccurred")).isEqualTo(ActuaryPeriodStatus.ERROR_OCCURRED);
        assertThat(ActuaryPeriodStatus.fromValue("ERROROCCURRED")).isEqualTo(ActuaryPeriodStatus.ERROR_OCCURRED);
    }

    @Test
    void fromValue_ShouldReturnNullWhenGivenNull() {
        ActuaryPeriodStatus result = ActuaryPeriodStatus.fromValue(null);
        assertThat(result).isNull();
    }

    @Test
    void fromValue_ShouldThrowExceptionWhenGivenInvalidValue() {
        assertThatThrownBy(() -> ActuaryPeriodStatus.fromValue("Invalid"))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("Unknown ActuaryPeriodStatus value: Invalid");
    }

    @Test
    void fromValue_ShouldThrowExceptionWhenGivenEmptyString() {
        assertThatThrownBy(() -> ActuaryPeriodStatus.fromValue(""))
                .isInstanceOf(IllegalArgumentException.class);
    }

    @ParameterizedTest
    @ValueSource(strings = {"In Progress", "Approved", "ToBeReported", "Reporting", "ErrorOccurred"})
    void fromValue_ShouldRecognizeAllValidStatuses(String value) {
        ActuaryPeriodStatus status = ActuaryPeriodStatus.fromValue(value);
        assertThat(status).isNotNull();
        assertThat(status.getValue()).isEqualTo(value);
    }

    @Test
    void values_ShouldContainOnlyActiveStatuses() {
        ActuaryPeriodStatus[] statuses = ActuaryPeriodStatus.values();
        assertThat(statuses).containsExactlyInAnyOrder(
                ActuaryPeriodStatus.IN_PROGRESS,
                ActuaryPeriodStatus.APPROVED,
                ActuaryPeriodStatus.TO_BE_REPORTED,
                ActuaryPeriodStatus.REPORTING,
                ActuaryPeriodStatus.ERROR_OCCURRED
        );
    }

    @Test
    void valueOf_ShouldReturnCorrectStatus() {
        assertThat(ActuaryPeriodStatus.valueOf("IN_PROGRESS")).isEqualTo(ActuaryPeriodStatus.IN_PROGRESS);
        assertThat(ActuaryPeriodStatus.valueOf("APPROVED")).isEqualTo(ActuaryPeriodStatus.APPROVED);
        assertThat(ActuaryPeriodStatus.valueOf("TO_BE_REPORTED")).isEqualTo(ActuaryPeriodStatus.TO_BE_REPORTED);
        assertThat(ActuaryPeriodStatus.valueOf("REPORTING")).isEqualTo(ActuaryPeriodStatus.REPORTING);
        assertThat(ActuaryPeriodStatus.valueOf("ERROR_OCCURRED")).isEqualTo(ActuaryPeriodStatus.ERROR_OCCURRED);
    }
}

