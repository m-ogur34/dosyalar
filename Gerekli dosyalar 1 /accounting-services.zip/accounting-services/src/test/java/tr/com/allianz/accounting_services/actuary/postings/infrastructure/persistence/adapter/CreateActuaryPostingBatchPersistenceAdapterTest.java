package tr.com.allianz.accounting_services.actuary.postings.infrastructure.persistence.adapter;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import tr.com.allianz.accounting_services.actuary.postings.application.exception.CreateActuaryPostingBatchFailedException;
import tr.com.allianz.accounting_services.actuary.postings.application.usecases.CreateActuaryPostingBatchCommand;
import tr.com.allianz.accounting_services.actuary.postings.domain.model.CreateActuaryPostingBatchResult;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CreateActuaryPostingBatchPersistenceAdapterTest {

    @Mock
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    private final CreateActuaryPostingBatchCommand command = new CreateActuaryPostingBatchCommand(
            10L, LocalDate.of(2026, 7, 15), "3401", 1);

    @Test
    void createBatch_ShouldReturnExisting_WhenBatchAlreadyExists() {
        when(namedParameterJdbcTemplate.queryForList(anyString(), any(MapSqlParameterSource.class), any(Class.class)))
                .thenReturn(List.of(5500L));

        CreateActuaryPostingBatchPersistenceAdapter adapter =
                new CreateActuaryPostingBatchPersistenceAdapter(mock(JdbcTemplate.class), namedParameterJdbcTemplate);

        CreateActuaryPostingBatchResult result = adapter.createBatch(command);

        assertThat(result.batchAlreadyExists()).isTrue();
        assertThat(result.batchId()).isEqualTo(5500L);
    }

    @Test
    void createBatch_ShouldNotCallProcedure_WhenBatchAlreadyExists() {
        when(namedParameterJdbcTemplate.queryForList(anyString(), any(MapSqlParameterSource.class), any(Class.class)))
                .thenReturn(List.of(5500L));

        CreateActuaryPostingBatchPersistenceAdapter adapter =
                new CreateActuaryPostingBatchPersistenceAdapter(mock(JdbcTemplate.class), namedParameterJdbcTemplate) {
                    @Override
                    protected SimpleJdbcCall createSimpleJdbcCall() {
                        throw new AssertionError("Procedure should not be called when batch already exists");
                    }
                };

        CreateActuaryPostingBatchResult result = adapter.createBatch(command);

        assertThat(result.batchAlreadyExists()).isTrue();
        assertThat(result.batchId()).isEqualTo(5500L);
    }

    @Test
    void createBatch_ShouldRunProcessAndReturnCreated_WhenBatchDoesNotExist() {
        SimpleJdbcCall simpleJdbcCall = mock(SimpleJdbcCall.class, org.mockito.Mockito.RETURNS_SELF);
        when(simpleJdbcCall.execute(any(MapSqlParameterSource.class))).thenReturn(Map.of());

        when(namedParameterJdbcTemplate.queryForList(anyString(), any(MapSqlParameterSource.class), any(Class.class)))
                .thenReturn(List.of())
                .thenReturn(List.of(9001L));

        CreateActuaryPostingBatchPersistenceAdapter adapter =
                new CreateActuaryPostingBatchPersistenceAdapter(mock(JdbcTemplate.class), namedParameterJdbcTemplate) {
                    @Override
                    protected SimpleJdbcCall createSimpleJdbcCall() {
                        return simpleJdbcCall;
                    }
                };

        CreateActuaryPostingBatchResult result = adapter.createBatch(command);

        assertThat(result.batchAlreadyExists()).isFalse();
        assertThat(result.batchId()).isEqualTo(9001L);
    }

    @Test
    void createBatch_ShouldThrow_WhenBatchIdNotFoundAfterCreation() {
        SimpleJdbcCall simpleJdbcCall = mock(SimpleJdbcCall.class, org.mockito.Mockito.RETURNS_SELF);
        when(simpleJdbcCall.execute(any(MapSqlParameterSource.class))).thenReturn(Map.of());

        when(namedParameterJdbcTemplate.queryForList(anyString(), any(MapSqlParameterSource.class), any(Class.class)))
                .thenReturn(List.of())
                .thenReturn(List.of());

        CreateActuaryPostingBatchPersistenceAdapter adapter =
                new CreateActuaryPostingBatchPersistenceAdapter(mock(JdbcTemplate.class), namedParameterJdbcTemplate) {
                    @Override
                    protected SimpleJdbcCall createSimpleJdbcCall() {
                        return simpleJdbcCall;
                    }
                };

        assertThatThrownBy(() -> adapter.createBatch(command))
                .isInstanceOf(CreateActuaryPostingBatchFailedException.class);
    }

    @Test
    void createBatch_ShouldWrapDataAccessException_UsingMostSpecificCauseMessage() {
        when(namedParameterJdbcTemplate.queryForList(anyString(), any(MapSqlParameterSource.class), any(Class.class)))
                .thenThrow(new DataAccessResourceFailureException("db failed", new RuntimeException("ORA-12345")));

        CreateActuaryPostingBatchPersistenceAdapter adapter =
                new CreateActuaryPostingBatchPersistenceAdapter(mock(JdbcTemplate.class), namedParameterJdbcTemplate);

        assertThatThrownBy(() -> adapter.createBatch(command))
                .isInstanceOf(CreateActuaryPostingBatchFailedException.class)
                .satisfies(ex -> assertThat(((CreateActuaryPostingBatchFailedException) ex).getDetail())
                        .contains("ORA-12345"));

        verify(namedParameterJdbcTemplate, never()).update(anyString(), any(MapSqlParameterSource.class));
    }

    @Test
    void createBatch_ShouldWrapDataAccessException_UsingExceptionMessageWhenMostSpecificCauseIsMissing() {
        when(namedParameterJdbcTemplate.queryForList(anyString(), any(MapSqlParameterSource.class), any(Class.class)))
                .thenThrow(new DataAccessResourceFailureException("db failed"));

        CreateActuaryPostingBatchPersistenceAdapter adapter =
                new CreateActuaryPostingBatchPersistenceAdapter(mock(JdbcTemplate.class), namedParameterJdbcTemplate);

        assertThatThrownBy(() -> adapter.createBatch(command))
                .isInstanceOf(CreateActuaryPostingBatchFailedException.class)
                .satisfies(ex -> assertThat(((CreateActuaryPostingBatchFailedException) ex).getDetail())
                        .contains("db failed"));
    }
}
