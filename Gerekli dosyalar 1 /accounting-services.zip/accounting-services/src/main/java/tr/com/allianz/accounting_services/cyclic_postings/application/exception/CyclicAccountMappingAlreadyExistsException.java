package tr.com.allianz.accounting_services.cyclic_postings.application.exception;


import tr.com.allianz.accounting_services.shared.exception.BaseApplicationException;
import lombok.Getter;
import org.springframework.http.HttpStatus;

@Getter
public class CyclicAccountMappingAlreadyExistsException extends BaseApplicationException {

    private final String accountNo;

    public CyclicAccountMappingAlreadyExistsException(String accountNo) {
        super("CYCLIC_ACCOUNT_MAPPING_ALREADY_EXISTS",
                "Cyclic account mapping already exists.",
                "Account with no " + accountNo +
                        " mapping already exists.",
                HttpStatus.CONFLICT);
        this.accountNo = accountNo;
    }
}
