package tr.com.allianz.accounting_services.actuary.infrastructure.persistence.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import tr.com.allianz.accounting_services.actuary.infrastructure.persistence.entity.AlzActPeriodRules;
import tr.com.allianz.accounting_services.actuary.infrastructure.persistence.entity.AlzActPeriodRulesId;

import java.util.List;

public interface AlzActPeriodRulesRepository extends JpaRepository<AlzActPeriodRules, AlzActPeriodRulesId> {

	List<AlzActPeriodRules> findByProcessIdAndYearAndMonthAndStatus(
			String processId, Integer year, Integer month, String status);
}

