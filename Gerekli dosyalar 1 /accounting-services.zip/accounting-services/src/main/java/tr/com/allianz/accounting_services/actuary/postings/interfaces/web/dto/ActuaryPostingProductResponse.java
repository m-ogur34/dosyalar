package tr.com.allianz.accounting_services.actuary.postings.interfaces.web.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@AllArgsConstructor
@NoArgsConstructor
public class ActuaryPostingProductResponse {
    private Long productId;
    private String extReference;
    private String longName;
}

