package tr.com.allianz.accounting_services.assistance_accounting.interfaces.web.dto;

import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
public class CreateAssistancePostingRequest {
    private String invoiceNo;
    private LocalDate invoiceDate;
    private String batchDescription;
    private LocalDate accountingDate;
    private Long agencyId;
    private Integer year;
    private Integer month;
    private String accCoverCode;
    private BigDecimal payableAmount;
    private String ebType;
    private String productId;
    private String partitionType;
}
