package tr.com.allianz.accounting_services.actuary.infrastructure.persistence.adapter;

import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;
import tr.com.allianz.accounting_services.actuary.application.port.out.CleanupUndiscountedReserveReportsPort;

import java.sql.Types;
import java.time.LocalDate;
import java.util.List;

@Component
@RequiredArgsConstructor
public class CleanupUndiscountedReserveReportsAdapter implements CleanupUndiscountedReserveReportsPort {

    private static final String FIND_REF_IDS = """
            select distinct rd.ref_id
              from alz_reports_data rd,
                   alz_reports_data_sub rs
             where rd.ref_id = rs.ref_id
               and rd.payroll_date = last_day(to_date(:year || lpad(:month, 2, '0'), 'yyyymm'))
               and rs.trans_sub_type in ('3001', '3002')
            """;

    private static final String DELETE_SUB = """
            delete from customer.ALZ_REPORTS_DATA_SUB
             where ref_id = :ref_id
            """;

    private static final String DELETE_DATA = """
            delete from customer.ALZ_REPORTS_DATA
             where ref_id = :ref_id
            """;

    private final NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @Override
    public void cleanup(LocalDate payrollDate) {
        MapSqlParameterSource periodParameters = new MapSqlParameterSource()
                .addValue("year", payrollDate.getYear(), Types.NUMERIC)
                .addValue("month", payrollDate.getMonthValue(), Types.NUMERIC);

        List<Long> refIds = namedParameterJdbcTemplate.queryForList(
                FIND_REF_IDS,
                periodParameters,
                Long.class
        );
        for (Long refId : refIds) {
            MapSqlParameterSource refIdParameters = new MapSqlParameterSource()
                    .addValue("ref_id", refId);
            namedParameterJdbcTemplate.update(DELETE_SUB, refIdParameters);
            namedParameterJdbcTemplate.update(DELETE_DATA, refIdParameters);
        }
    }
}
