package tr.com.allianz.accounting_services.accounting_postings.application.exception;

import org.springframework.http.HttpStatus;
import tr.com.allianz.accounting_services.shared.exception.BaseApplicationException;

public class CreatePostingFailedException extends BaseApplicationException {

    public CreatePostingFailedException(String detail) {
        super("CREATE_POSTING_FAILED", "Fiş oluşturma işlemi sırasında hata ile karşılaşıldı", detail, HttpStatus.INTERNAL_SERVER_ERROR);
    }
}

