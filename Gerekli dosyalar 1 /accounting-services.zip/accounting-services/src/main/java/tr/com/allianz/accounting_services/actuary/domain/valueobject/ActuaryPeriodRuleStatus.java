package tr.com.allianz.accounting_services.actuary.domain.valueobject;

public enum ActuaryPeriodRuleStatus {
    STARTED("Started"),
    EXECUTED("Executed");

    private final String value;

    ActuaryPeriodRuleStatus(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public static ActuaryPeriodRuleStatus fromValue(String value) {
        if (value == null) {
            return null;
        }
        for (ActuaryPeriodRuleStatus status : values()) {
            if (status.value.equalsIgnoreCase(value)) {
                return status;
            }
        }
        throw new IllegalArgumentException("Unknown ActuaryPeriodRuleStatus value: " + value);
    }
}

