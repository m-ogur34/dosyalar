package tr.com.allianz.accounting_services.cyclic_postings.infrastructure.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import tr.com.allianz.accounting_services.cyclic_postings.application.port.out.CyclicPostingCheckPort;
import tr.com.allianz.accounting_services.cyclic_postings.application.port.out.CyclicPostingProcessPort;
import tr.com.allianz.accounting_services.cyclic_postings.application.usecases.posting_process.CreateCyclicPostingUseCase;
import tr.com.allianz.accounting_services.cyclic_postings.application.usecases.posting_process.ListCyclicPostingProcessUseCase;
import tr.com.allianz.accounting_services.cyclic_postings.application.usecases.posting_process.ProcessCyclicPostingUseCase;
import tr.com.allianz.accounting_services.cyclic_postings.application.usecases.posting_process.RemoveCyclicPostingProcessUseCase;

@Configuration
public class CyclicAccountingProcessConfig {

    @Bean
    public ProcessCyclicPostingUseCase processCyclicPostingUseCase(CyclicPostingProcessPort cyclicPostingProcessPort) {
        return new ProcessCyclicPostingUseCase(cyclicPostingProcessPort);
    }

    @Bean
    public CreateCyclicPostingUseCase createCyclicPostingUseCase(CyclicPostingProcessPort cyclicPostingProcessPort, CyclicPostingCheckPort cyclicPostingCheckPort) {
        return new CreateCyclicPostingUseCase(cyclicPostingProcessPort, cyclicPostingCheckPort);
    }

    @Bean
    public ListCyclicPostingProcessUseCase listCyclicPostingUseCase(CyclicPostingProcessPort cyclicPostingProcessPort) {
        return new ListCyclicPostingProcessUseCase(cyclicPostingProcessPort);
    }

    @Bean
    public RemoveCyclicPostingProcessUseCase removeCyclicPostingProcessUseCase(CyclicPostingProcessPort cyclicPostingProcessPort) {
        return new RemoveCyclicPostingProcessUseCase(cyclicPostingProcessPort);
    }


}
