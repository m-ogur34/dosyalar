package tr.com.allianz.accounting_services.cyclic_postings.application.usecases.posting_process;

import lombok.extern.slf4j.Slf4j;
import tr.com.allianz.accounting_services.cyclic_postings.application.exception.CyclicPostingProcessFailedException;
import tr.com.allianz.accounting_services.cyclic_postings.application.exception.CyclicPostingProcessNotFoundException;
import tr.com.allianz.accounting_services.cyclic_postings.application.port.out.CyclicPostingProcessPort;
import tr.com.allianz.accounting_services.cyclic_postings.domain.service.ProcessStatusTransitionService;
import tr.com.allianz.accounting_services.cyclic_postings.infrastructure.persistence.entity.AlzCyclicPostingProcess;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
public class ProcessCyclicPostingUseCase {

    private final CyclicPostingProcessPort cyclicPostingProcessPort;

    public ProcessCyclicPostingUseCase(
        CyclicPostingProcessPort cyclicPostingProcessPort
    ) {
        this.cyclicPostingProcessPort = cyclicPostingProcessPort;
        ProcessStatusTransitionService statusTransitionService = new ProcessStatusTransitionService();
    }

    public List<AlzCyclicPostingProcess> handle(List<ProcessCyclicPostingUseCase.ProcessCyclicPostingCommand> commands) {
        List<AlzCyclicPostingProcess> processes = commands.stream()
                .map((processCyclicPostingCommand ->
                        processAccountingCyclicPosting(processCyclicPostingCommand.batchId())
                        ))
                .collect(Collectors.toList());

        return cyclicPostingProcessPort.saveAll(processes);
    }

    public AlzCyclicPostingProcess processAccountingCyclicPosting(Long batchId) {
        AlzCyclicPostingProcess process = cyclicPostingProcessPort.findById(batchId);
        if(process == null) {
           throw new CyclicPostingProcessNotFoundException(batchId);
        }
        try {
            cyclicPostingProcessPort.callCyclicPostingProcedure(
                process.getBatchId()
            );
        } catch (Exception e) {
            log.error("Error processing cyclic posting: {}", batchId, e);
            throw new CyclicPostingProcessFailedException(batchId);
        }
        return cyclicPostingProcessPort.findById(process.getBatchId());
    }


    public record ProcessCyclicPostingCommand(Long batchId) {
    }


}