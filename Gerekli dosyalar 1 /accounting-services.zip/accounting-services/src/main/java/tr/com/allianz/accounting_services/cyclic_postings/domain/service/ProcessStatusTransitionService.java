package tr.com.allianz.accounting_services.cyclic_postings.domain.service;

import tr.com.allianz.accounting_services.cyclic_postings.domain.valueobject.ProcessStatus;

public class ProcessStatusTransitionService {

    public ProcessStatus transitionToProcessed(ProcessStatus currentStatus) {
        if (currentStatus != ProcessStatus.CREATED) {
            throw new IllegalStateException(
                "Cannot transition to PROCESSED from status: " + currentStatus
            );
        }
        return ProcessStatus.PROCESSED;
    }

    public ProcessStatus transitionToError(ProcessStatus currentStatus) {
        if (currentStatus != ProcessStatus.CREATED) {
            throw new IllegalStateException(
                "Cannot transition to ERROR_OCCURRED from status: " + currentStatus
            );
        }
        return ProcessStatus.ERROR_OCCURRED;
    }

    public boolean canTransitionToProcessed(ProcessStatus currentStatus) {
        return currentStatus == ProcessStatus.CREATED;
    }

    public boolean canTransitionToError(ProcessStatus currentStatus) {
        return currentStatus == ProcessStatus.CREATED;
    }
}