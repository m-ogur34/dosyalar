package tr.com.allianz.accounting_services.actuary.application.service.distribution;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import tr.com.allianz.accounting_services.actuary.application.port.out.CreateUndiscountedReserveDataPort;

@Component
@RequiredArgsConstructor
public class UndiscountedReserveDistributionProcessHandler implements DistributionProcessHandler {

    private static final String UNDISCRES_PROCESS_ID = "UNDISCRES";

    private final CreateUndiscountedReserveDataPort createUndiscountedReserveDataPort;

    @Override
    public boolean supports(String processId) {
        return UNDISCRES_PROCESS_ID.equals(processId);
    }

    @Override
    public void execute(String processId, Integer year, Integer month) {
        createUndiscountedReserveDataPort.create(year, month);
    }
}
