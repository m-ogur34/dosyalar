package tr.com.allianz.accounting_services.cyclic_postings.application.usecases.posting_process;

import java.time.LocalDate;
import java.time.LocalDateTime;

public record AlzCyclicPostingProcessReadModel(Long batchId,
                                               LocalDate postingDate,
                                               Long cyclicBatchId,
                                               String processStatus,
                                               String errText,
                                               LocalDateTime createdDate,
                                               LocalDateTime updatedDate) {
}
