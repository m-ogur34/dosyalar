package tr.com.allianz.accounting_services.actuary.postings.application.usecases;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import tr.com.allianz.accounting_services.actuary.postings.application.port.out.LoadActuaryPostingProcessesPort;
import tr.com.allianz.accounting_services.actuary.postings.domain.model.ActuaryPostingProcess;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ListActuaryPostingProcessesUseCase {

    private final LoadActuaryPostingProcessesPort loadActuaryPostingProcessesPort;

    public List<ActuaryPostingProcess> handle() {
        return loadActuaryPostingProcessesPort.loadAll();
    }
}

