package tr.com.allianz.accounting_services.assistance_accounting.interfaces.web;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import tr.com.allianz.accounting_services.assistance_accounting.application.usecases.ListAssistanceQueryUseCase;
import tr.com.allianz.accounting_services.assistance_accounting.domain.valueobject.AssistanceQueryCriteria;
import tr.com.allianz.accounting_services.assistance_accounting.domain.valueobject.AssistanceQueryResult;
import tr.com.allianz.accounting_services.shared.api.ApiResponse;

import java.util.List;

@RestController
@RequestMapping("/api/v1/assistance-query")
@CrossOrigin
@RequiredArgsConstructor
public class AssistanceQueryController {

    private final ListAssistanceQueryUseCase listAssistanceQueryUseCase;

    @PostMapping
    public ResponseEntity<ApiResponse<List<AssistanceQueryResult>>> listAssistanceQueryResults(
            @RequestBody AssistanceQueryCriteria criteria
    )
    {
        List<AssistanceQueryResult> results = listAssistanceQueryUseCase.handle(criteria);
        return ResponseEntity.ok(ApiResponse.ok("SUCCESS", "Query executed successfully", results));
    }
}

