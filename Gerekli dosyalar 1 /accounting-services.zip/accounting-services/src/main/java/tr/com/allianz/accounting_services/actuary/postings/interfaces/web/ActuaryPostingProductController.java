package tr.com.allianz.accounting_services.actuary.postings.interfaces.web;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import tr.com.allianz.accounting_services.actuary.postings.application.usecases.ListActuaryPostingProductsUseCase;
import tr.com.allianz.accounting_services.actuary.postings.interfaces.web.dto.ActuaryPostingProductResponse;

import java.util.List;

@RestController
@RequestMapping("/api/v1/actuary-posting-products")
@RequiredArgsConstructor
@CrossOrigin
public class ActuaryPostingProductController {

    private final ListActuaryPostingProductsUseCase listActuaryPostingProductsUseCase;

    @GetMapping
    public ResponseEntity<List<ActuaryPostingProductResponse>> getProductsByBranchId(
            @RequestParam("branchId") String branchId
    ) {
        var responses = listActuaryPostingProductsUseCase.handle(branchId)
                .stream()
                .map(p -> new ActuaryPostingProductResponse(
                        p.getProductId(),
                        p.getExtReference(),
                        p.getLongName()
                ))
                .toList();
        return ResponseEntity.ok(responses);
    }
}

