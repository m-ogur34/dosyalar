package tr.com.allianz.accounting_services.cyclic_postings.application.usecases.posting_process;

import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Pageable;
import tr.com.allianz.accounting_services.cyclic_postings.application.port.out.CyclicPostingProcessPort;

import java.util.List;

@Slf4j
public class ListCyclicPostingProcessUseCase {

    private final CyclicPostingProcessPort cyclicPostingProcessPort;


    public ListCyclicPostingProcessUseCase(CyclicPostingProcessPort cyclicPostingProcessPort) {
        this.cyclicPostingProcessPort = cyclicPostingProcessPort;
    }

    public List<AlzCyclicPostingProcessReadModel> handle(Pageable pageable, Long batchId, Long cyclicBatchId, String status){
        log.info("Listing all cyclic posting processes");
        return cyclicPostingProcessPort.listAllCyclicPostingProcesses(pageable,batchId,cyclicBatchId,status);
    }
}
