package tr.com.allianz.accounting_services.cyclic_postings.interfaces.web.dto;

public record RemoveAlzCyclicAccountMappingResponse(String accountNo) {
}
