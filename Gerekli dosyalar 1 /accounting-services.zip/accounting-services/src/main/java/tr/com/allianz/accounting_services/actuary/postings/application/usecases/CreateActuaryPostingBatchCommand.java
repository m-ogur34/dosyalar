package tr.com.allianz.accounting_services.actuary.postings.application.usecases;

import java.time.LocalDate;

public record CreateActuaryPostingBatchCommand(
        Long batchType,
        LocalDate postingDate,
        String branchExtRef,
        Integer isIndustrial
) {
}
