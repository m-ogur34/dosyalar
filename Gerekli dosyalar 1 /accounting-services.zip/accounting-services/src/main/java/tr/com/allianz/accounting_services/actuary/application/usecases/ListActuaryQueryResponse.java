package tr.com.allianz.accounting_services.actuary.application.usecases;

import tr.com.allianz.accounting_services.actuary.domain.valueobject.ActuaryProcessRuleAmount;
import tr.com.allianz.accounting_services.actuary.infrastructure.persistence.entity.AlzActPeriods;

import java.util.List;

public record ListActuaryQueryResponse(
        List<ActuaryProcessRuleAmount> results,
        AlzActPeriods period
) {
}

