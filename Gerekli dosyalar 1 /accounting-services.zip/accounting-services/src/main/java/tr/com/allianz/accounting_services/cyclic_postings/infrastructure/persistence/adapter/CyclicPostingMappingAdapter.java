package tr.com.allianz.accounting_services.cyclic_postings.infrastructure.persistence.adapter;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import tr.com.allianz.accounting_services.cyclic_postings.application.exception.CyclicAccountMappingNotFoundException;
import tr.com.allianz.accounting_services.cyclic_postings.application.port.out.CyclicPostingMappingPort;
import tr.com.allianz.accounting_services.cyclic_postings.application.usecases.AlzCyclicAccountMappingReadModel;
import tr.com.allianz.accounting_services.cyclic_postings.application.usecases.CreateCyclicMappingCommand;
import tr.com.allianz.accounting_services.cyclic_postings.infrastructure.persistence.entity.AlzCyclicAccountMapping;
import tr.com.allianz.accounting_services.cyclic_postings.infrastructure.persistence.repository.AlzCyclicAccountMappingRepository;
import tr.com.allianz.accounting_services.cyclic_postings.interfaces.web.dto.RemoveAlzCyclicAccountMappingRequest;

import java.util.List;
import java.util.Optional;

@Component
@Transactional
public class CyclicPostingMappingAdapter implements CyclicPostingMappingPort {

    private final AlzCyclicAccountMappingRepository alzCyclicAccountMappingRepository;

    public CyclicPostingMappingAdapter(AlzCyclicAccountMappingRepository alzCyclicAccountMappingRepository) {
        this.alzCyclicAccountMappingRepository = alzCyclicAccountMappingRepository;
    }


    @Override
    public Optional<AlzCyclicAccountMapping> findByAccountNo(String accountNo) {
        return alzCyclicAccountMappingRepository.findById(accountNo);
    }

    @Override
    public AlzCyclicAccountMapping createCyclicPostingMapping(CreateCyclicMappingCommand command) {
        AlzCyclicAccountMapping alzCyclicAccountMapping  =new AlzCyclicAccountMapping(command.accountNo(),command.cyclicAccountNo());
        return alzCyclicAccountMappingRepository.save(alzCyclicAccountMapping);
    }

    @Override
    public List<AlzCyclicAccountMappingReadModel> listCyclingAccountMapping() {
        return alzCyclicAccountMappingRepository.findAll()
                .stream().map(alzCyclicAccountMapping ->
                        new AlzCyclicAccountMappingReadModel(alzCyclicAccountMapping.getAccountNo()
                                ,alzCyclicAccountMapping.getCyclicAccountNo())
                        ).toList();
    }

    @Override
    public void removeCyclicPostingMapping(RemoveAlzCyclicAccountMappingRequest request) {
        AlzCyclicAccountMapping entity = alzCyclicAccountMappingRepository.findById(request.accountNo()).orElseThrow(()->
                new CyclicAccountMappingNotFoundException(request.accountNo())
        );
        alzCyclicAccountMappingRepository.delete(entity);
    }

}
