package tr.com.allianz.accounting_services.assistance_accounting.application.usecases;

import tr.com.allianz.accounting_services.assistance_accounting.application.port.out.AssistancePartitionLoaderPort;
import tr.com.allianz.accounting_services.assistance_accounting.domain.valueobject.AssistancePartition;

import java.util.List;

public class ListAssistancePartitionUseCase {

    private final AssistancePartitionLoaderPort assistancePartitionLoaderPort;

    public ListAssistancePartitionUseCase(AssistancePartitionLoaderPort assistancePartitionLoaderPort) {
        this.assistancePartitionLoaderPort = assistancePartitionLoaderPort;
    }

    public List<AssistancePartition> handle(List<Long> productIds) {
        return assistancePartitionLoaderPort.loadAssistancePartitions(productIds);
    }
}
