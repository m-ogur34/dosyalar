package tr.com.allianz.accounting_services.assistance_accounting.interfaces.web;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import tr.com.allianz.accounting_services.assistance_accounting.application.usecases.ListAssistanceCompanyUseCase;
import tr.com.allianz.accounting_services.assistance_accounting.domain.valueobject.AssistanceCompany;
import tr.com.allianz.accounting_services.shared.api.ApiResponse;

import java.util.List;

@RestController
@RequestMapping("/api/v1/assistance-company")
@CrossOrigin
@RequiredArgsConstructor
public class AssistanceCompanyController {

    private final ListAssistanceCompanyUseCase listAssistanceCompanyUseCase;

    @GetMapping
    public ResponseEntity<ApiResponse<List<AssistanceCompany>>> listAssistanceCompanies() {
        List<AssistanceCompany> companies = listAssistanceCompanyUseCase.handle();
        return ResponseEntity.ok(ApiResponse.ok("SUCCESS", "List retrieved successfully", companies));
    }
}

