# Cyclic Postings Module

This module handles the logic for cyclic postings and account mappings.

## Structure
- `application`: Use cases, ports, and exceptions (Hexagonal Architecture / Clean Architecture).
- `domain`: Core business logic and entities.
- `infrastructure`: Adapters for database, configuration, etc.
- `interfaces`: Web controllers (REST API).

## Shared Components
Common components like `ApiResponse`, `ErrorDetail`, and `BaseApplicationException` are located in the `tr.com.allianz.accounting_services.shared` package.
Please use `SharedExceptionHandler` for consistent error handling, or the module-specific `CyclicPostingsExceptionHandler` for specialized cases.

