package tr.com.allianz.accounting_services.actuary.postings.infrastructure.persistence.adapter;

import lombok.RequiredArgsConstructor;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataFormat;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Component;
import tr.com.allianz.accounting_services.actuary.postings.application.exception.ActuaryPostingBatchInfoFailedException;
import tr.com.allianz.accounting_services.actuary.postings.application.port.out.ExportActuaryPostingBatchInfoExcelPort;
import tr.com.allianz.accounting_services.actuary.postings.application.usecases.GetActuaryPostingBatchInfoCommand;
import tr.com.allianz.accounting_services.actuary.postings.domain.model.ActuaryPostingBatchInfoExcelFile;
import tr.com.allianz.accounting_services.actuary.postings.domain.model.ActuaryPostingBatchInfoExcelRow;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Types;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.util.List;
import java.util.Map;

@Component
@RequiredArgsConstructor
public class ExportActuaryPostingBatchInfoExcelAdapter implements ExportActuaryPostingBatchInfoExcelPort {

    private static final String REF_CURSOR = "v_refcur";
    private static final int EXPORT_LIMIT = 0;
    private static final String DEFAULT_BATCH_NAME = "BatchInfo";
    private static final DateTimeFormatter FILE_NAME_TIMESTAMP = DateTimeFormatter.ofPattern("yyyyMMddHHmm");
    private static final String[] HEADERS = {
            "HESAP NO",
            "HESAP ADI",
            "AÇIKLAMA",
            "BORÇ",
            "ALACAK",
            "TUTAR",
            "DÖVIZLI BORÇ",
            "DÖVIZLI ALACAK",
            "DÖVIZLI TUTAR",
            "FIS TARIHI",
            "DÖVIZ KODU",
            "DÖVIZ KURU",
            "ÜRÜN ADI",
            "ÜRÜN NEVI",
            "BRANS",
            "BRANS ADI",
            "ENDÜSTRIYEL / BIREYSEL",
            "DEPREMLI / DEPREMSIZ",
            "ACC CODE",
            "ACC AÇIKLAMA",
            "ANLASMA",
            "ANLASMA ADI",
            "SIRKET KODU",
            "SIRKET ADI",
            "DAGITIM KANALI",
            "LAYER",
            "HASAR DOSYA NO",
            "DAVALI/MUALLAK",
            "HASAR TARIHI"
    };
    private static final int[] COLUMN_WIDTHS = {
            14, 22, 32, 14, 14, 14, 16, 16, 16, 14,
            14, 14, 22, 18, 14, 22, 22, 20, 16, 24,
            16, 24, 16, 24, 22, 18, 20, 18, 14
    };

    private final JdbcTemplate jdbcTemplate;

    @Override
    public ActuaryPostingBatchInfoExcelFile exportToExcel(GetActuaryPostingBatchInfoCommand command) {
        List<ActuaryPostingBatchInfoExcelRow> data = loadBatchInfo(command);
        String fileName = buildFileName(command.batchType());
        return new ActuaryPostingBatchInfoExcelFile(fileName, generateExcelFile(data));
    }

    @SuppressWarnings("unchecked")
    private List<ActuaryPostingBatchInfoExcelRow> loadBatchInfo(GetActuaryPostingBatchInfoCommand command) {
        SimpleJdbcCall simpleJdbcCall = createSimpleJdbcCall()
                .withSchemaName("CUSTOMER")
                .withCatalogName("ALZ_RCI_POSTING_UTILS")
                .withProcedureName("GET_BATCH_INFO")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlParameter("p_batch_type", Types.NUMERIC),
                        new SqlParameter("p_date", Types.DATE),
                        new SqlParameter("p_branch_ext_ref", Types.VARCHAR),
                        new SqlParameter("p_product_id", Types.NUMERIC),
                        new SqlParameter("p_partition_type", Types.VARCHAR),
                        new SqlParameter("p_is_industrial", Types.NUMERIC),
                        new SqlParameter("p_rownum", Types.NUMERIC),
                        new SqlOutParameter(REF_CURSOR, Types.REF_CURSOR, (rs, rowNum) -> new ActuaryPostingBatchInfoExcelRow(
                                trim(rs.getString("account_no")),
                                trim(rs.getString("account_exp")),
                                trim(rs.getString("explanation")),
                                rs.getBigDecimal("posting_amount"),
                                toLocalDate(rs.getDate("posting_date")),
                                trim(rs.getString("swift_code")),
                                rs.getBigDecimal("curr_exchg_rate"),
                                trim(rs.getString("product_name")),
                                trim(rs.getString("partition_name")),
                                trim(rs.getString("branch_ext_ref")),
                                trim(rs.getString("branch_name")),
                                trim(rs.getString("is_industrial")),
                                trim(rs.getString("is_eartquake")),
                                trim(rs.getString("acc_cover_group")),
                                trim(rs.getString("acc_cover_group_exp")),
                                trim(rs.getString("arrangement_id")),
                                trim(rs.getString("arrangement_exp")),
                                trim(rs.getString("trading_code")),
                                trim(rs.getString("company_exp")),
                                trim(rs.getString("sap_dist_channel_exp")),
                                trim(rs.getString("layer_exp")),
                                trim(rs.getString("claim_ext_ref")),
                                trim(rs.getString("trans_type")),
                                toLocalDate(rs.getDate("date_of_loss"))
                        ))
                );

        MapSqlParameterSource inparams = new MapSqlParameterSource()
                .addValue("p_batch_type", command.batchType(), Types.NUMERIC)
                .addValue("p_date", toSqlDate(command.postingDate()), Types.DATE)
                .addValue("p_branch_ext_ref", command.branchExtRef(), Types.VARCHAR)
                .addValue("p_product_id", command.productId(), Types.NUMERIC)
                .addValue("p_partition_type", command.partitionType(), Types.VARCHAR)
                .addValue("p_is_industrial", command.isIndustrial(), Types.NUMERIC)
                .addValue("p_rownum", EXPORT_LIMIT, Types.NUMERIC);

        try {
            Map<String, Object> out = simpleJdbcCall.execute(inparams);
            Object cursor = out.get(REF_CURSOR);
            if (cursor == null) {
                return List.of();
            }
            return (List<ActuaryPostingBatchInfoExcelRow>) cursor;
        } catch (DataAccessException ex) {
            String detail = getDetailMessage(ex);
            throw new ActuaryPostingBatchInfoFailedException(detail);
        }
    }

    protected SimpleJdbcCall createSimpleJdbcCall() {
        return new SimpleJdbcCall(jdbcTemplate);
    }

    private Date toSqlDate(LocalDate postingDate) {
        LocalDate monthEnd = postingDate.with(TemporalAdjusters.lastDayOfMonth());
        return Date.valueOf(monthEnd);
    }

    protected String findBatchName(Long batchType) {
        try {
            return jdbcTemplate.query(
                            "select description from alz_rci_processes where process_id = ?",
                            (rs, rowNum) -> trim(rs.getString("description")),
                            batchType
                    )
                    .stream()
                    .findFirst()
                    .filter(value -> !value.isBlank())
                    .orElse(DEFAULT_BATCH_NAME);
        } catch (DataAccessException ex) {
            return DEFAULT_BATCH_NAME;
        }
    }

    protected LocalDateTime currentTimestamp() {
        return LocalDateTime.now();
    }

    private String buildFileName(Long batchType) {
        String batchName = sanitizeFileName(findBatchName(batchType));
        return batchName + "_Fisi_" + currentTimestamp().format(FILE_NAME_TIMESTAMP) + ".xlsx";
    }

    private String trim(String value) {
        return value == null ? "" : value.trim();
    }

    private LocalDate toLocalDate(Date value) {
        return value == null ? null : value.toLocalDate();
    }

    private String sanitizeFileName(String value) {
        String sanitized = trim(value).replaceAll("[\\\\/:*?\"<>|]", "_");
        return sanitized.isBlank() ? DEFAULT_BATCH_NAME : sanitized;
    }

    private byte[] generateExcelFile(List<ActuaryPostingBatchInfoExcelRow> data) {
        try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
            Sheet sheet = workbook.createSheet("Batch Info");
            CellStyle headerStyle = createHeaderStyle(workbook);
            CellStyle amountStyle = createAmountStyle(workbook);
            CellStyle dateStyle = createDateStyle(workbook);

            writeHeader(sheet, headerStyle);
            writeDataRows(sheet, data, amountStyle, dateStyle);
            applyColumnWidths(sheet);

            workbook.write(baos);
            return baos.toByteArray();
        } catch (IOException ex) {
            throw new ActuaryPostingBatchInfoFailedException("Failed to generate Excel file: " + ex.getMessage());
        }
    }

    private void writeHeader(Sheet sheet, CellStyle headerStyle) {
        Row headerRow = sheet.createRow(0);
        for (int index = 0; index < HEADERS.length; index++) {
            var cell = headerRow.createCell(index);
            cell.setCellValue(HEADERS[index]);
            cell.setCellStyle(headerStyle);
        }
    }

    private void writeDataRows(Sheet sheet, List<ActuaryPostingBatchInfoExcelRow> data, CellStyle amountStyle, CellStyle dateStyle) {
        int rowNum = 1;
        for (ActuaryPostingBatchInfoExcelRow item : data) {
            Row row = sheet.createRow(rowNum++);
            int col = 0;
            writeStringCell(row, col++, item.accountNo());
            writeStringCell(row, col++, item.accountExp());
            writeStringCell(row, col++, item.explanation());
            writeAmountCell(row, col++, item.borc(), amountStyle);
            writeAmountCell(row, col++, item.alacak(), amountStyle);
            writeAmountCell(row, col++, item.tutar(), amountStyle);
            writeAmountCell(row, col++, item.dovizliBorc(), amountStyle);
            writeAmountCell(row, col++, item.dovizliAlacak(), amountStyle);
            writeAmountCell(row, col++, item.dovizliTutar(), amountStyle);
            writeDateCell(row, col++, item.postingDate(), dateStyle);
            writeStringCell(row, col++, item.swiftCode());
            writeAmountCell(row, col++, item.currExchgRate(), amountStyle);
            writeStringCell(row, col++, item.productName());
            writeStringCell(row, col++, item.partitionName());
            writeStringCell(row, col++, item.branchExtRef());
            writeStringCell(row, col++, item.branchName());
            writeStringCell(row, col++, item.isIndustrial());
            writeStringCell(row, col++, item.isEarthquake());
            writeStringCell(row, col++, item.accCoverGroup());
            writeStringCell(row, col++, item.accCoverGroupExp());
            writeStringCell(row, col++, item.arrangementId());
            writeStringCell(row, col++, item.arrangementExp());
            writeStringCell(row, col++, item.tradingCode());
            writeStringCell(row, col++, item.companyExp());
            writeStringCell(row, col++, item.sapDistChannelExp());
            writeStringCell(row, col++, item.layerExp());
            writeStringCell(row, col++, item.claimExtRef());
            writeStringCell(row, col++, item.transType());
            writeDateCell(row, col, item.dateOfLoss(), dateStyle);
        }
    }

    private void applyColumnWidths(Sheet sheet) {
        for (int index = 0; index < COLUMN_WIDTHS.length; index++) {
            sheet.setColumnWidth(index, COLUMN_WIDTHS[index] * 256);
        }
    }

    private CellStyle createHeaderStyle(Workbook workbook) {
        Font font = workbook.createFont();
        font.setBold(true);

        CellStyle style = workbook.createCellStyle();
        style.setFont(font);
        return style;
    }

    private CellStyle createAmountStyle(Workbook workbook) {
        DataFormat dataFormat = workbook.createDataFormat();
        CellStyle style = workbook.createCellStyle();
        style.setDataFormat(dataFormat.getFormat("#,##0.##########"));
        return style;
    }

    private CellStyle createDateStyle(Workbook workbook) {
        DataFormat dataFormat = workbook.createDataFormat();
        CellStyle style = workbook.createCellStyle();
        style.setDataFormat(dataFormat.getFormat("dd.MM.yyyy"));
        return style;
    }

    private void writeStringCell(Row row, int columnIndex, String value) {
        row.createCell(columnIndex).setCellValue(value == null ? "" : value);
    }

    private void writeAmountCell(Row row, int columnIndex, BigDecimal value, CellStyle style) {
        var cell = row.createCell(columnIndex);
        if (value != null) {
            cell.setCellValue(value.doubleValue());
            cell.setCellStyle(style);
        }
    }

    private void writeDateCell(Row row, int columnIndex, LocalDate value, CellStyle style) {
        var cell = row.createCell(columnIndex);
        if (value != null) {
            cell.setCellValue(value);
            cell.setCellStyle(style);
        }
    }

    private String getDetailMessage(DataAccessException ex) {
        return ex.getMostSpecificCause() == null ? ex.getMessage() : ex.getMostSpecificCause().getMessage();
    }
}
