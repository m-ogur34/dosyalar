package tr.com.allianz.accounting_services.assistance_accounting.interfaces.web;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import tr.com.allianz.accounting_services.assistance_accounting.application.usecases.ListAssistanceProductUseCase;
import tr.com.allianz.accounting_services.assistance_accounting.domain.valueobject.AssistanceProduct;
import tr.com.allianz.accounting_services.shared.api.ApiResponse;

import java.util.List;

@RestController
@RequestMapping("/api/v1/assistance-product")
@CrossOrigin
@RequiredArgsConstructor
public class AssistanceProductController {

    private final ListAssistanceProductUseCase listAssistanceProductUseCase;

    @GetMapping
    public ResponseEntity<ApiResponse<List<AssistanceProduct>>> listAssistanceProducts(
            @RequestParam(required = false) String accCoverCode
    ) {
        List<AssistanceProduct> products = listAssistanceProductUseCase.handle(accCoverCode);
        return ResponseEntity.ok(ApiResponse.ok("SUCCESS", "List retrieved successfully", products));
    }
}
