package tr.com.allianz.accounting_services.actuary.postings.interfaces.web;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import tr.com.allianz.accounting_services.actuary.application.usecases.ListActuaryProcessesUseCase;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.ActuaryProcess;
import tr.com.allianz.accounting_services.actuary.postings.application.usecases.ListActuaryPostingProcessesUseCase;
import tr.com.allianz.accounting_services.actuary.postings.interfaces.web.dto.ActuaryPostingProcessResponse;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/v1/actuary-posting-processes")
@RequiredArgsConstructor
@CrossOrigin
public class ActuaryPostingProcessController {

    private final ListActuaryPostingProcessesUseCase listActuaryPostingProcessesUseCase;
    private final ListActuaryProcessesUseCase listActuaryProcessesUseCase;

    @GetMapping
    public ResponseEntity<List<ActuaryPostingProcessResponse>> getAllProcesses() {
        Set<String> activeProcessNames = listActuaryProcessesUseCase.handle()
                .stream()
                .map(ActuaryProcess::processName)
                .collect(Collectors.toSet());

        var responses = listActuaryPostingProcessesUseCase.handle()
                .stream()
                .filter(p -> activeProcessNames.stream()
                        .anyMatch(name -> p.getDescription().toLowerCase().contains(name.toLowerCase())))
                .map(p -> new ActuaryPostingProcessResponse(p.getProcessId(), p.getDescription()))
                .toList();

        return ResponseEntity.ok(responses);
    }
}

