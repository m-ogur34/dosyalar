package tr.com.allianz.accounting_services.actuary.domain.valueobject;

public enum ActuaryLogType {
    QUERY,
    APPROVE,
    IN_PROGRESS,
    EXCEL_UPLOAD,
    AMOUNT_UPDATE,
    ERROR
}

