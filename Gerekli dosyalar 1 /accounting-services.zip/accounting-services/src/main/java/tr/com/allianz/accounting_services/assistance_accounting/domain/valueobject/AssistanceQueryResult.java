package tr.com.allianz.accounting_services.assistance_accounting.domain.valueobject;

import java.math.BigDecimal;

public record AssistanceQueryResult(
    Long accountNo,
    String accountExp,
    String sapLob,
    String sapDistChannelExp,
    Integer isIndustrial,
    BigDecimal tutarBorc,
    BigDecimal tutarAlacak
) {}
