package tr.com.allianz.accounting_services.cyclic_postings.infrastructure.persistence.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "ALZ_CYCLIC_ACCOUNT_MAPPING")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class AlzCyclicAccountMapping {


    @Id
    @Column(name = "GL_ACCT_REF_CODE")
    private String accountNo;

    @Column(name = "GL_CYCLIC_ACCT_REF_CODE")
    private String cyclicAccountNo;




}
