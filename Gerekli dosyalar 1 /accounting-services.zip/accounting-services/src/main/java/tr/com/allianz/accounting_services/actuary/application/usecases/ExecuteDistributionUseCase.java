package tr.com.allianz.accounting_services.actuary.application.usecases;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import tr.com.allianz.accounting_services.actuary.application.port.out.LoadActuaryPeriodStatusPort;
import tr.com.allianz.accounting_services.actuary.application.port.out.SaveActuaryPeriodStatusPort;
import tr.com.allianz.accounting_services.actuary.application.service.distribution.DistributionProcessContext;
import tr.com.allianz.accounting_services.actuary.application.service.distribution.DistributionProcessHandler;
import tr.com.allianz.accounting_services.actuary.application.service.distribution.DistributionProcessHook;
import tr.com.allianz.accounting_services.actuary.application.service.distribution.DistributionProcessHandlerResolver;
import tr.com.allianz.accounting_services.actuary.application.service.distribution.DistributionProcessHookResolver;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.ActuaryPeriodStatus;

import java.util.List;

@Service
@Transactional
public class ExecuteDistributionUseCase {

    private final DistributionProcessHandlerResolver handlerResolver;
    private final DistributionProcessHookResolver hookResolver;
    private final SaveActuaryPeriodStatusPort saveActuaryPeriodStatusPort;
    private final LoadActuaryPeriodStatusPort loadActuaryPeriodStatusPort;

    @Autowired
    public ExecuteDistributionUseCase(
            DistributionProcessHandlerResolver handlerResolver,
            DistributionProcessHookResolver hookResolver,
                SaveActuaryPeriodStatusPort saveActuaryPeriodStatusPort,
                LoadActuaryPeriodStatusPort loadActuaryPeriodStatusPort
    ) {
        this.handlerResolver = handlerResolver;
        this.hookResolver = hookResolver;
        this.saveActuaryPeriodStatusPort = saveActuaryPeriodStatusPort;
        this.loadActuaryPeriodStatusPort = loadActuaryPeriodStatusPort;
    }

    public ExecuteDistributionUseCase(DistributionProcessHandlerResolver handlerResolver) {
        this(handlerResolver, new DistributionProcessHookResolver(List.of()), null, null);
    }

    public ExecuteDistributionUseCase(
            DistributionProcessHandlerResolver handlerResolver,
            DistributionProcessHookResolver hookResolver
    ) {
        this(handlerResolver, hookResolver, null, null);
    }



    public void handle(String processId, Integer year, Integer month, String byUser) {
        validateInProgress(processId, year, month);
        DistributionProcessContext context = new DistributionProcessContext(processId, year, month, byUser);
        DistributionProcessHandler handler = handlerResolver.resolve(processId);
        List<DistributionProcessHook> hooks = hookResolver.resolve(processId);

        hooks.forEach(hook -> hook.beforeExecute(context));
        handler.execute(processId, year, month);
        hooks.forEach(hook -> hook.afterExecute(context));
    }

    private void validateInProgress(String processId, Integer year, Integer month) {
        if (saveActuaryPeriodStatusPort == null || loadActuaryPeriodStatusPort == null) {
            return;
        }

        ActuaryPeriodStatus currentStatus = loadActuaryPeriodStatusPort.getStatus(processId, year, month);
        if (currentStatus != ActuaryPeriodStatus.IN_PROGRESS
                && currentStatus != ActuaryPeriodStatus.ERROR_OCCURRED) {
            throw new IllegalArgumentException(
                    "Dağıtım başlatılabilmesi için statü 'In Progress' veya 'ErrorOccurred' olmalıdır. Mevcut statü: "
                            + (currentStatus != null ? currentStatus.getValue() : "yok")
            );
        }
    }
}
