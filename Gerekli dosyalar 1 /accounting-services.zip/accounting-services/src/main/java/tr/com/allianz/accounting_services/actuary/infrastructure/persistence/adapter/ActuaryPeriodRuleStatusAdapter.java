package tr.com.allianz.accounting_services.actuary.infrastructure.persistence.adapter;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import tr.com.allianz.accounting_services.actuary.application.port.out.SaveActuaryPeriodRuleStatusPort;
import tr.com.allianz.accounting_services.actuary.application.port.out.LoadActuaryPeriodRuleStatusPort;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.ActuaryPeriodRuleStatus;
import tr.com.allianz.accounting_services.actuary.infrastructure.persistence.entity.AlzActPeriodRules;
import tr.com.allianz.accounting_services.actuary.infrastructure.persistence.entity.AlzActPeriodRulesId;
import tr.com.allianz.accounting_services.actuary.infrastructure.persistence.repository.AlzActPeriodRulesRepository;

import java.util.Set;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class ActuaryPeriodRuleStatusAdapter implements SaveActuaryPeriodRuleStatusPort, LoadActuaryPeriodRuleStatusPort {

    private final AlzActPeriodRulesRepository repository;

    @Override
    public void markStarted(String processId, Integer year, Integer month, Integer ruleId) {
        AlzActPeriodRulesId id = new AlzActPeriodRulesId(processId, year, month, ruleId);
        if (repository.existsById(id)) {
            return;
        }
        saveWithStatus(processId, year, month, ruleId, ActuaryPeriodRuleStatus.STARTED);
    }

    @Override
    public void markExecuted(String processId, Integer year, Integer month, Integer ruleId) {
        saveWithStatus(processId, year, month, ruleId, ActuaryPeriodRuleStatus.EXECUTED);
    }

    @Override
    public Set<Integer> loadStartedRuleIds(String processId, Integer year, Integer month) {
        return repository.findByProcessIdAndYearAndMonthAndStatus(
                        processId, year, month, ActuaryPeriodRuleStatus.STARTED.getValue())
                .stream()
                .map(AlzActPeriodRules::getRuleId)
                .collect(Collectors.toSet());
    }

    private void saveWithStatus(String processId, Integer year, Integer month,
                                Integer ruleId, ActuaryPeriodRuleStatus status) {
        AlzActPeriodRulesId id = new AlzActPeriodRulesId(processId, year, month, ruleId);
        AlzActPeriodRules periodRule = repository.findById(id)
                .orElseGet(() -> new AlzActPeriodRules(processId, year, month, ruleId, null));
        periodRule.setStatusEnum(status);
        repository.save(periodRule);
    }
}

