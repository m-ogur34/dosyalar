package tr.com.allianz.accounting_services.actuary.postings.application.exception;

import org.springframework.http.HttpStatus;
import tr.com.allianz.accounting_services.shared.exception.BaseApplicationException;

public class CreateActuaryPostingBatchFailedException extends BaseApplicationException {

    public CreateActuaryPostingBatchFailedException(String detail) {
        super(
                "CREATE_ACTUARY_POSTING_BATCH_FAILED",
                "Actuary posting batch olusturulamadi.",
                detail,
                HttpStatus.INTERNAL_SERVER_ERROR
        );
    }
}
