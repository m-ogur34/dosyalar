package tr.com.allianz.accounting_services.cyclic_postings.interfaces.web.dto;

public record CreateAlzCyclicAccountMappingResponse(String accountNo, String cyclicAccountNo) {

}
