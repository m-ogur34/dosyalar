package tr.com.allianz.accounting_services.actuary.postings.domain.model;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;

public record ActuaryPostingBatchInfoExcelRow(
		String accountNo,
		String accountExp,
		String explanation,
		BigDecimal postingAmount,
		LocalDate postingDate,
		String swiftCode,
		BigDecimal currExchgRate,
		String productName,
		String partitionName,
		String branchExtRef,
		String branchName,
		String isIndustrial,
		String isEarthquake,
		String accCoverGroup,
		String accCoverGroupExp,
		String arrangementId,
		String arrangementExp,
		String tradingCode,
		String companyExp,
		String sapDistChannelExp,
		String layerExp,
		String claimExtRef,
		String transType,
		LocalDate dateOfLoss
) {

	private static final BigDecimal ZERO = BigDecimal.ZERO;
	private static final int FX_SCALE = 10;

	public BigDecimal borc() {
		if (postingAmount == null) {
			return ZERO;
		}
		return postingAmount.signum() < 0 ? postingAmount.abs() : ZERO;
	}

	public BigDecimal alacak() {
		if (postingAmount == null) {
			return ZERO;
		}
		return postingAmount.signum() < 0 ? ZERO : postingAmount;
	}

	public BigDecimal tutar() {
		return borc().subtract(alacak());
	}

	public BigDecimal dovizliBorc() {
		return divide(borc(), currExchgRate);
	}

	public BigDecimal dovizliAlacak() {
		return divide(alacak(), currExchgRate);
	}

	public BigDecimal dovizliTutar() {
		BigDecimal borc = dovizliBorc();
		BigDecimal alacak = dovizliAlacak();
		if (borc == null || alacak == null) {
			return null;
		}
		return borc.subtract(alacak);
	}

	private BigDecimal divide(BigDecimal amount, BigDecimal rate) {
		if (amount == null || rate == null || rate.signum() == 0) {
			return null;
		}
		return amount.divide(rate, FX_SCALE, RoundingMode.HALF_UP);
	}
}

