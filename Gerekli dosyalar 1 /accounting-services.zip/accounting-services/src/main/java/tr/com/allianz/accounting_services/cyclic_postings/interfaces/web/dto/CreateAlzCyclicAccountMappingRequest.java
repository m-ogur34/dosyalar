package tr.com.allianz.accounting_services.cyclic_postings.interfaces.web.dto;

import tr.com.allianz.accounting_services.cyclic_postings.application.usecases.CreateCyclicMappingCommand;

public record CreateAlzCyclicAccountMappingRequest(String accountNo, String cyclicAccountNo) {

    public CreateCyclicMappingCommand toCommand() {
        return new CreateCyclicMappingCommand(accountNo, cyclicAccountNo);
    }
}
