package tr.com.allianz.accounting_services.cyclic_postings.interfaces.web;

import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import tr.com.allianz.accounting_services.cyclic_postings.application.usecases.posting_process.*;
import tr.com.allianz.accounting_services.cyclic_postings.infrastructure.persistence.entity.AlzCyclicPostingProcess;
import tr.com.allianz.accounting_services.shared.api.ApiResponse;
import tr.com.allianz.accounting_services.cyclic_postings.interfaces.web.dto.*;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/v1/cyclic-accounting-process")
@RequiredArgsConstructor
public class AlzCyclicPostingProcessController {

    private final ProcessCyclicPostingUseCase processCyclicPostingUseCase;

    private final CreateCyclicPostingUseCase createCyclicPostingUseCase;

    private final ListCyclicPostingProcessUseCase listCyclicPostingProcessUseCase;

    private final RemoveCyclicPostingProcessUseCase removeCyclicPostingProcessUseCase;

    @PostMapping("/create")
    public ResponseEntity<ApiResponse<CreateCyclicPostingResponse>> createCyclicPostings(
            @RequestBody CreateCyclicPostingRequest request
    ) {
        List<CreateCyclicPostingUseCase.CreateCyclicPostingCommand> commands = request.getItems().stream()
            .map(item -> new CreateCyclicPostingUseCase.CreateCyclicPostingCommand(
                item.getBatchId(),
                item.getPostingDate()
            ))
            .collect(Collectors.toList());

        List<AlzCyclicPostingProcess> result = createCyclicPostingUseCase.handle(commands);

        CreateCyclicPostingResponse response = new CreateCyclicPostingResponse();
        response.setProcesses(result.stream()
                .map(process -> {
                    CreateCyclicPostingResponse.ProcessItem item = new CreateCyclicPostingResponse.ProcessItem();
                    item.setBatchId(process.getBatchId());
                    item.setPostingDate(process.getPostingDate());
                    item.setCyclicBatchId(process.getCyclicBatchId());
                    item.setStatus(process.getProcessStatusEnum());
                    item.setCreatedDate(process.getCreatedDate());
                    return item;
                })
                .collect(Collectors.toList()));
        response.setTotalCount(result.size());

        return ResponseEntity.ok(
                ApiResponse.ok(
                        "CYCLIC_POSTING_CREATED",
                        "Cyclic posting processes created successfully",
                        response
                )
        );
    }

    @GetMapping("/list")
    public ResponseEntity<ApiResponse<AlzCyclicPostingProcessListResponse>> listAlzCyclicPostingProcess(
            @RequestParam(value = "page",required = false) Optional<Integer> page,
            @RequestParam(value = "size",required = false) Optional<Integer> size,
            @RequestParam(required = false) Long batchId,
            @RequestParam(required = false)  Long cyclicBatchId,
            @RequestParam(required = false) String status
    ) {
        Pageable pageable = PageRequest.of(page.orElse(0), size.orElse(2000));

        List<AlzCyclicPostingProcessReadModel> cyclicPostingProcessReadModelList
                = listCyclicPostingProcessUseCase.handle(pageable,batchId,cyclicBatchId,status);
        ApiResponse<AlzCyclicPostingProcessListResponse> response = ApiResponse.ok("CYCLIC_POSTING_PROCESS_LIST",
                "Cyclic posting process list retrieved successfully",
                new AlzCyclicPostingProcessListResponse(cyclicPostingProcessReadModelList,cyclicPostingProcessReadModelList.size()) );
        return  ResponseEntity.ok(response);
    }

    @PostMapping("/remove-unprocessed")
    public ResponseEntity<ApiResponse<RemoveCyclicPostingProcessResponse>> removeUnprocessedCyclicPostings(
            @RequestBody RemoveCyclicPostingProcessRequest request
    ) {
        removeCyclicPostingProcessUseCase.handle(request.batchId());
        ApiResponse<RemoveCyclicPostingProcessResponse> response = ApiResponse.ok("UNPROCESSED_CYCLIC_POSTINGS_REMOVED",
                "Fiş işleme kaydı başarıyla silindi.", new RemoveCyclicPostingProcessResponse(request.batchId()) );
        return ResponseEntity.ok(response);
    }

    @PostMapping("/process")
    public ResponseEntity<ApiResponse<ProcessCyclicPostingResponse>> processCyclicPostings(
            @RequestBody ProcessCyclicPostingRequest request
    ) {
        List<ProcessCyclicPostingUseCase.ProcessCyclicPostingCommand> commands = request.getItems().stream()
            .map(item -> new ProcessCyclicPostingUseCase.ProcessCyclicPostingCommand(
                item.getBatchId()
            ))
            .collect(Collectors.toList());

        List<AlzCyclicPostingProcess> result = processCyclicPostingUseCase.handle(commands);

        ProcessCyclicPostingResponse response = new ProcessCyclicPostingResponse();
        response.setProcesses(result.stream()
                .map(process -> {
                    CreateCyclicPostingResponse.ProcessItem item = new CreateCyclicPostingResponse.ProcessItem();
                    item.setBatchId(process.getBatchId());
                    item.setCyclicBatchId(process.getCyclicBatchId());
                    item.setStatus(process.getProcessStatusEnum());
                    item.setCreatedDate(process.getCreatedDate());
                    return item;
                })
                .collect(Collectors.toList()));
        response.setTotalCount(result.size());

        return ResponseEntity.ok(
                ApiResponse.ok(
                        "CYCLIC_POSTING_PROCESSED",
                        "Cyclic posting processes completed successfully",
                        response
                )
        );
    }

}
