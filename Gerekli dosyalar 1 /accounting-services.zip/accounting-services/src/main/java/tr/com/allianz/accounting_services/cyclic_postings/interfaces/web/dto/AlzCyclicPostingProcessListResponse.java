package tr.com.allianz.accounting_services.cyclic_postings.interfaces.web.dto;

import tr.com.allianz.accounting_services.cyclic_postings.application.usecases.posting_process.AlzCyclicPostingProcessReadModel;

import java.util.List;

public record AlzCyclicPostingProcessListResponse(List<AlzCyclicPostingProcessReadModel> processes, int totalCount) {
}
