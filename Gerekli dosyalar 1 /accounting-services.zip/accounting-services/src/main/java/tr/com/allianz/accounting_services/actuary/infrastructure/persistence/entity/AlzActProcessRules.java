package tr.com.allianz.accounting_services.actuary.infrastructure.persistence.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@Entity
@Table(name = "ALZ_ACT_PROCESS_RULES")
@AllArgsConstructor
@NoArgsConstructor
@Getter
public class AlzActProcessRules {

    @EmbeddedId
    private AlzActProcessRulesId id;

    @Transient
    private String processId;

    @Transient
    private Integer ruleId;

    @Column(name = "RULE_NAME", length = 50)
    private String ruleName;

    @Column(name = "RULE_TEXT", length = 500)
    private String ruleText;

    @Column(name = "VALIDITY_START_DATE")
    private LocalDate validityStartDate;

    @Column(name = "VALIDITY_END_DATE")
    private LocalDate validityEndDate;

    @PostLoad
    @PostPersist
    @PostUpdate
    private void syncIdFields() {
        if (id != null) {
            this.processId = id.getProcessId();
            this.ruleId = id.getRuleId();
        }
    }

    public void setId(AlzActProcessRulesId id) {
        this.id = id;
    }

    public void setProcessId(String processId) {
        this.processId = processId;
        if (id == null) {
            id = new AlzActProcessRulesId();
        }
        id.setProcessId(processId);
    }

    public void setRuleId(Integer ruleId) {
        this.ruleId = ruleId;
        if (id == null) {
            id = new AlzActProcessRulesId();
        }
        id.setRuleId(ruleId);
    }

    public void setRuleName(String ruleName) {
        this.ruleName = ruleName;
    }

    public void setRuleText(String ruleText) {
        this.ruleText = ruleText;
    }

    public void setValidityStartDate(LocalDate validityStartDate) {
        this.validityStartDate = validityStartDate;
    }

    public void setValidityEndDate(LocalDate validityEndDate) {
        this.validityEndDate = validityEndDate;
    }

}

