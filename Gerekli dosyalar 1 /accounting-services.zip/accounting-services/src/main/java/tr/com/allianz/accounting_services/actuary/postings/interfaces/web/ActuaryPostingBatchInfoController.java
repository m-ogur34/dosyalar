package tr.com.allianz.accounting_services.actuary.postings.interfaces.web;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import tr.com.allianz.accounting_services.actuary.postings.application.usecases.ExportActuaryPostingBatchInfoExcelUseCase;
import tr.com.allianz.accounting_services.actuary.postings.application.usecases.GetActuaryPostingBatchInfoCommand;
import tr.com.allianz.accounting_services.actuary.postings.application.usecases.GetActuaryPostingBatchInfoUseCase;
import tr.com.allianz.accounting_services.actuary.postings.domain.model.ActuaryPostingBatchInfoExcelFile;
import tr.com.allianz.accounting_services.actuary.postings.interfaces.web.dto.ActuaryPostingBatchInfoLineResponse;
import tr.com.allianz.accounting_services.actuary.postings.interfaces.web.dto.ActuaryPostingBatchInfoRequest;
import tr.com.allianz.accounting_services.actuary.postings.interfaces.web.dto.ActuaryPostingBatchInfoResponse;
import tr.com.allianz.accounting_services.shared.api.ApiResponse;

import java.nio.charset.StandardCharsets;
import java.util.List;

@RestController
@RequestMapping("/api/v1/actuary-postings/batch-info")
@RequiredArgsConstructor
@CrossOrigin
public class ActuaryPostingBatchInfoController {

    private final GetActuaryPostingBatchInfoUseCase getActuaryPostingBatchInfoUseCase;
    private final ExportActuaryPostingBatchInfoExcelUseCase exportActuaryPostingBatchInfoExcelUseCase;

    @PostMapping
    public ResponseEntity<ApiResponse<ActuaryPostingBatchInfoResponse>> getBatchInfo(
            @Valid @RequestBody ActuaryPostingBatchInfoRequest request
    ) {
        GetActuaryPostingBatchInfoCommand command = new GetActuaryPostingBatchInfoCommand(
                request.batchType(),
                request.postingDate(),
                request.branchExtRef(),
                request.productId(),
                request.partitionType(),
                request.isIndustrial()
        );

        List<ActuaryPostingBatchInfoLineResponse> items = getActuaryPostingBatchInfoUseCase.handle(command)
                .stream()
                .map(line -> new ActuaryPostingBatchInfoLineResponse(
                        line.getAccountNo(),
                        line.getAccountExp(),
                        line.getExplanation(),
                        line.getBorc(),
                        line.getAlacak()
                ))
                .toList();

        return ResponseEntity.ok(
                ApiResponse.ok(
                        "ACTUARY_POSTING_BATCH_INFO_RETRIEVED",
                        "Actuary posting batch info retrieved successfully",
                        new ActuaryPostingBatchInfoResponse(items)
                )
        );
    }

    @PostMapping("/export/excel")
    public ResponseEntity<byte[]> exportBatchInfoToExcel(
            @Valid @RequestBody ActuaryPostingBatchInfoRequest request
    ) {
        GetActuaryPostingBatchInfoCommand command = new GetActuaryPostingBatchInfoCommand(
                request.batchType(),
                request.postingDate(),
                request.branchExtRef(),
                request.productId(),
                request.partitionType(),
                request.isIndustrial()
        );

        ActuaryPostingBatchInfoExcelFile excelFile = exportActuaryPostingBatchInfoExcelUseCase.handle(command);
        ContentDisposition contentDisposition = ContentDisposition.attachment()
                .filename(excelFile.fileName(), StandardCharsets.UTF_8)
                .build();

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, contentDisposition.toString())
                .contentType(MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
                .body(excelFile.content());
    }
}

