package tr.com.allianz.accounting_services.actuary.infrastructure.persistence.adapter;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;
import tr.com.allianz.accounting_services.actuary.application.port.out.LoadTrfsDistributionTotalsPort;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.TrfsDistributionTotals;
import tr.com.allianz.accounting_services.actuary.infrastructure.persistence.entity.AlzActProcessRules;
import tr.com.allianz.accounting_services.actuary.infrastructure.persistence.repository.AlzActProcessRulesRepository;

import java.math.BigDecimal;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * TRFS dağıtım toplamlarını hesaplayan adapter.
 * <p>
 * Satırlar Java heap'e çekilmez; SUM işlemi DB'de aggregate SQL şablonlarıyla yapılır.
 * Her aggregate query yalnızca 1 satır (gross_amount, net_amount) döndürür.
 */
@Component
@Slf4j
@RequiredArgsConstructor
public class TrfsDistributionTotalsAdapter implements LoadTrfsDistributionTotalsPort {

    private static final int QUERY_TIMEOUT_SECONDS = 120;
    private static final int FETCH_SIZE = 1_000;

    private static final String PERIOD_EXISTS_QUERY = """
            SELECT t.*
              FROM customer.alz_hp_data t
             WHERE t.year = :year
               AND t.month = :month
               AND t.code = 'W'
            """;

    private static final String LATEST_PERIOD_QUERY = """
            SELECT t.*
              FROM customer.alz_hp_data t
             WHERE t.code = 'W'
             ORDER BY t.year DESC, t.month DESC
            """;

    private static final String CURRENT_MONTH_ROWS_QUERY = """
            SELECT t.*,
                   DECODE(t.code,'WCRI',-1,1)*NVL(t.amount,0)+DECODE(t.code,'W',1,0)*NVL(t.prv_amount,0) gross_amount_component,
                   CASE WHEN t.is_pool=1 THEN 0 ELSE
                            DECODE(t.code,'WCRI',-1,1)*(NVL(t.amount,0)-NVL(t.reas_amount,0))
                           +DECODE(t.code,'W',1,0)*(NVL(t.prv_amount,0)-NVL(t.prv_reas_amount,0)) END net_amount_component
              FROM customer.alz_hp_data t
             WHERE t.year = :year
               AND t.month = :month
               AND t.code IN ('W','WCRI')
               AND t.product_id NOT IN (12,60)
               AND NVL(Koc_acc_utils.GET_LOB(t.acc_cover_code, t.product_id, t.partition_type, sysdate),'X') NOT IN ('600','601','604')
            """;

    private static final String JANUARY_ROWS_QUERY = """
            SELECT t.*,
                   NVL(t.prv_amount,0) gross_amount_component,
                   CASE WHEN t.is_pool=1 THEN 0 ELSE NVL(t.prv_amount,0)-NVL(t.prv_reas_amount,0) END net_amount_component
              FROM customer.alz_hp_data t
             WHERE t.year = :year
               AND t.month = 1
               AND t.code = 'WCRI'
               AND t.product_id NOT IN (12,60)
               AND NVL(Koc_acc_utils.GET_LOB(t.acc_cover_code, t.product_id, t.partition_type, sysdate),'X') NOT IN ('600','601','604')
            """;

    private final NamedParameterJdbcTemplate namedParameterJdbcTemplate;
    private final AlzActProcessRulesRepository alzActProcessRulesRepository;

    @Override
    public TrfsDistributionTotals loadTotals(String processId, Integer ruleId, Integer year, Integer month) {
        return loadTotalsByRuleIds(processId, Set.of(ruleId), year, month).get(ruleId);
    }

    @Override
    public Map<Integer, TrfsDistributionTotals> loadTotalsByRuleIds(String processId,
                                                                    Set<Integer> ruleIds,
                                                                    Integer year,
                                                                    Integer month) {
        if (ruleIds == null || ruleIds.isEmpty()) {
            return Map.of();
        }

        Map<Integer, AlzActProcessRules> rulesById = alzActProcessRulesRepository
                .findByProcessIdAndRuleIdIn(processId, List.copyOf(ruleIds))
                .stream()
                .collect(Collectors.toMap(r -> r.getId().getRuleId(), Function.identity()));

        for (Integer ruleId : ruleIds) {
            if (!rulesById.containsKey(ruleId)) {
                throw new IllegalArgumentException(
                        String.format(Locale.ROOT, "Rule tanımı bulunamadı. processId=%s, ruleId=%s", processId, ruleId));
            }
        }



        Map<Integer, TrfsDistributionTotals> totalsByRuleId = new HashMap<>();
        for (Map.Entry<Integer, AlzActProcessRules> entry : rulesById.entrySet()) {
            Integer ruleId = entry.getKey();
            SqlRulePredicateSupport.RulePredicate rulePredicate = SqlRulePredicateSupport.compile(
                    entry.getValue().getRuleText(), processId, ruleId, "Rule text");

            DistributionPeriod period = resolvePeriod(year, month, rulePredicate);
            BigDecimal[] current = queryCurrentMonthAggregates(period.year(), period.month(), rulePredicate);
            BigDecimal[] january = queryJanuaryAggregates(period.year(), rulePredicate);

            totalsByRuleId.put(ruleId, new TrfsDistributionTotals(
                    current[0].add(january[0]),
                    current[1].add(january[1])
            ));
        }

        return totalsByRuleId;
    }

    private DistributionPeriod resolvePeriod(Integer year, Integer month,
                                             SqlRulePredicateSupport.RulePredicate rulePredicate) {
        if (queryExists(year, month, rulePredicate)) {
            return new DistributionPeriod(year, month);
        }

        return queryLatestPeriod(rulePredicate)
                .orElse(new DistributionPeriod(year, month));
    }

    private boolean queryExists(Integer year, Integer month,
                                SqlRulePredicateSupport.RulePredicate rulePredicate) {
        MapSqlParameterSource params = new MapSqlParameterSource()
                .addValue("year", year)
                .addValue("month", month);
        return Boolean.TRUE.equals(namedParameterJdbcTemplate.execute(PERIOD_EXISTS_QUERY, params,
                ps -> {
                    ps.setQueryTimeout(QUERY_TIMEOUT_SECONDS);
                    ps.setFetchSize(FETCH_SIZE);
                    try (java.sql.ResultSet rs = ps.executeQuery()) {
                        ResultSetMetaData metaData = rs.getMetaData();
                        while (rs.next()) {
                            if (rulePredicate.matches(toRowMap(rs, metaData))) {
                                return true;
                            }
                        }
                        return false;
                    }
                }));
    }

    private Optional<DistributionPeriod> queryLatestPeriod(SqlRulePredicateSupport.RulePredicate rulePredicate) {
        return namedParameterJdbcTemplate.execute(LATEST_PERIOD_QUERY, new MapSqlParameterSource(),
                ps -> {
                    ps.setQueryTimeout(QUERY_TIMEOUT_SECONDS);
                    ps.setFetchSize(FETCH_SIZE);
                    try (java.sql.ResultSet rs = ps.executeQuery()) {
                        ResultSetMetaData metaData = rs.getMetaData();
                        while (rs.next()) {
                            Map<String, Object> row = toRowMap(rs, metaData);
                            if (rulePredicate.matches(row)) {
                                return Optional.of(new DistributionPeriod(
                                        toInteger(row.get("YEAR")), toInteger(row.get("MONTH"))));
                            }
                        }
                        return Optional.empty();
                    }
                });
    }

    private BigDecimal[] queryCurrentMonthAggregates(Integer year, Integer month,
                                                     SqlRulePredicateSupport.RulePredicate rulePredicate) {
        MapSqlParameterSource params = new MapSqlParameterSource()
                .addValue("year", year)
                .addValue("month", month);
        return namedParameterJdbcTemplate.execute(CURRENT_MONTH_ROWS_QUERY, params,
                ps -> {
                    ps.setQueryTimeout(QUERY_TIMEOUT_SECONDS);
                    ps.setFetchSize(FETCH_SIZE);
                    try (java.sql.ResultSet rs = ps.executeQuery()) {
                        ResultSetMetaData metaData = rs.getMetaData();
                        BigDecimal gross = BigDecimal.ZERO;
                        BigDecimal net = BigDecimal.ZERO;
                        while (rs.next()) {
                            if (!rulePredicate.matches(toRowMap(rs, metaData))) {
                                continue;
                            }
                            gross = gross.add(defaultZero(rs.getBigDecimal("gross_amount_component")));
                            net = net.add(defaultZero(rs.getBigDecimal("net_amount_component")));
                        }
                        return new BigDecimal[]{gross, net};
                    }
                });
    }

    private BigDecimal[] queryJanuaryAggregates(Integer year,
                                                SqlRulePredicateSupport.RulePredicate rulePredicate) {
        return namedParameterJdbcTemplate.execute(JANUARY_ROWS_QUERY,
                new MapSqlParameterSource().addValue("year", year),
                ps -> {
                    ps.setQueryTimeout(QUERY_TIMEOUT_SECONDS);
                    ps.setFetchSize(FETCH_SIZE);
                    try (java.sql.ResultSet rs = ps.executeQuery()) {
                        ResultSetMetaData metaData = rs.getMetaData();
                        BigDecimal gross = BigDecimal.ZERO;
                        BigDecimal net = BigDecimal.ZERO;
                        while (rs.next()) {
                            if (!rulePredicate.matches(toRowMap(rs, metaData))) {
                                continue;
                            }
                            gross = gross.add(defaultZero(rs.getBigDecimal("gross_amount_component")));
                            net = net.add(defaultZero(rs.getBigDecimal("net_amount_component")));
                        }
                        return new BigDecimal[]{gross, net};
                    }
                });
    }

    private Map<String, Object> toRowMap(java.sql.ResultSet rs, ResultSetMetaData metaData) throws SQLException {
        Map<String, Object> row = new LinkedHashMap<>();
        for (int i = 1; i <= metaData.getColumnCount(); i++) {
            row.put(metaData.getColumnLabel(i), rs.getObject(i));
        }
        return row;
    }

    private Integer toInteger(Object value) {
        return value instanceof Number number ? number.intValue() : null;
    }

    private BigDecimal defaultZero(BigDecimal value) {
        return value != null ? value : BigDecimal.ZERO;
    }

    private record DistributionPeriod(Integer year, Integer month) {
    }
}
