package tr.com.allianz.accounting_services.cyclic_postings.infrastructure.persistence.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import tr.com.allianz.accounting_services.cyclic_postings.infrastructure.persistence.entity.AlzCyclicAccountMapping;


public interface AlzCyclicAccountMappingRepository extends JpaRepository<AlzCyclicAccountMapping, String> {

    @Query(value = "SELECT  COUNT(*)  FROM koc_acx_postings" +
            " WHERE batch_id = :batch_id ",nativeQuery = true)
    int findPostingCountByBatchId(@Param("batch_id") Long batchId);


    @Query(value = "SELECT listagg(distinct  b.gl_acct_ref_code , ',') within group (order by  b.gl_acct_ref_code) accounts   \n" +
                    "       FROM koc_acx_postings d,  koc_acc_v_internal_accounts a,\n" +
                    "            ac_gl_system_refs b\n" +
                    "      WHERE d.batch_id = :batch_id \n" +
                    "       AND d.internal_account_id_ext = a.internal_account_id\n" +
                    "       AND a.gl_acct_ref_code =b.gl_acct_ref_code\n" +
                    "       and (b.gl_acct_ref_code like '7%' or b.gl_acct_ref_code like '6%')\n" +
                    "       and  not exists (select 1 from ALZ_CYCLIC_ACCOUNT_MAPPING m where m.gl_acct_ref_code = b.gl_acct_ref_code)",
            nativeQuery = true)
    String findNotMappedAccountsByBatchId(@Param("batch_id") Long batchId);

}
