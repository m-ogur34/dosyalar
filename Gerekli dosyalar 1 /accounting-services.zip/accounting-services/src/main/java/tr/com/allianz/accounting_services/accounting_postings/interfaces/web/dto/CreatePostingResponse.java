package tr.com.allianz.accounting_services.accounting_postings.interfaces.web.dto;

import java.io.Serial;
import java.io.Serializable;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

@RequiredArgsConstructor
@Getter
@Setter
public class CreatePostingResponse implements Serializable{
	
	@Serial
	private static final long serialVersionUID = 1L;
	
	private Long batchId;
}

