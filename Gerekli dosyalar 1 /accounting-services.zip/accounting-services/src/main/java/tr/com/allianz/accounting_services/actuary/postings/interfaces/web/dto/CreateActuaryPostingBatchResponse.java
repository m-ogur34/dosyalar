package tr.com.allianz.accounting_services.actuary.postings.interfaces.web.dto;
public record CreateActuaryPostingBatchResponse(
        Long batchId,
        boolean batchAlreadyExists,
        String message
) {}