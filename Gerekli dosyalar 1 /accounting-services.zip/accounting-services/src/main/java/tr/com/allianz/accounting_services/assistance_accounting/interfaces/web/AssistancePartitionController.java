package tr.com.allianz.accounting_services.assistance_accounting.interfaces.web;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import tr.com.allianz.accounting_services.assistance_accounting.application.usecases.ListAssistancePartitionUseCase;
import tr.com.allianz.accounting_services.assistance_accounting.domain.valueobject.AssistancePartition;
import tr.com.allianz.accounting_services.shared.api.ApiResponse;

import java.util.List;

@RestController
@RequestMapping("/api/v1/assistance-partition")
@CrossOrigin
@RequiredArgsConstructor
public class AssistancePartitionController {

    private final ListAssistancePartitionUseCase listAssistancePartitionUseCase;

    @PostMapping
    public ResponseEntity<ApiResponse<List<AssistancePartition>>> listAssistancePartitions(
            @RequestBody List<Long> productIds
    ) {
        List<AssistancePartition> partitions = listAssistancePartitionUseCase.handle(productIds);
        return ResponseEntity.ok(ApiResponse.ok("SUCCESS", "List retrieved successfully", partitions));
    }
}

