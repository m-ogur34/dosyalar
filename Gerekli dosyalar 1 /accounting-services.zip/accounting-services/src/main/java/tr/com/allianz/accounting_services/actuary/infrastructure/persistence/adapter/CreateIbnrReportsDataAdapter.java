package tr.com.allianz.accounting_services.actuary.infrastructure.persistence.adapter;

import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Component;
import tr.com.allianz.accounting_services.actuary.application.port.out.CreateIbnrReportsDataPort;

import java.sql.Types;

@Component
@RequiredArgsConstructor
public class CreateIbnrReportsDataAdapter implements CreateIbnrReportsDataPort {

    private final JdbcTemplate jdbcTemplate;

    @Override
    public void create(Integer year, Integer month, Integer ruleId) {
        SimpleJdbcCall call = createSimpleJdbcCall()
                .withSchemaName("CUSTOMER")
                .withCatalogName("ALZ_ACT_PROCESS_UTILS")
                .withProcedureName("CREATE_IBNR_REPORTS_DATA")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlParameter("p_year", Types.NUMERIC),
                        new SqlParameter("p_month", Types.NUMERIC),
                        new SqlParameter("p_rule_id", Types.NUMERIC)
                );

        MapSqlParameterSource parameters = new MapSqlParameterSource()
                .addValue("p_year", year, Types.NUMERIC)
                .addValue("p_month", month, Types.NUMERIC)
                .addValue("p_rule_id", ruleId, Types.NUMERIC);

        call.execute(parameters);
    }

    protected SimpleJdbcCall createSimpleJdbcCall() {
        return new SimpleJdbcCall(jdbcTemplate);
    }
}
