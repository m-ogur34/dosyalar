package tr.com.allianz.accounting_services.assistance_accounting.application.usecases;

import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
@RequiredArgsConstructor
public class CreateAssistancePostingCommand {
    private final String invoiceNo;
    private final LocalDate invoiceDate;
    private final String batchDescription;
    private final LocalDate accountingDate;
    private final Long agencyId;
    private final Integer year;
    private final Integer month;
    private final String accCoverCode;
    private final BigDecimal payableAmount;
    private final String ebType;
    private final String productId;
    private final String partitionType;
}
