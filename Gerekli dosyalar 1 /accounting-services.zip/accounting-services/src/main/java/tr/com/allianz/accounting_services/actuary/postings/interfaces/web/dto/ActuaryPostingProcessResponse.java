package tr.com.allianz.accounting_services.actuary.postings.interfaces.web.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@AllArgsConstructor
@NoArgsConstructor
public class ActuaryPostingProcessResponse {
    private String processId;
    private String description;
}

