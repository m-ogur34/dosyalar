package tr.com.allianz.accounting_services.actuary.infrastructure.persistence.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import tr.com.allianz.accounting_services.actuary.infrastructure.persistence.entity.AlzActProcessAmounts;
import tr.com.allianz.accounting_services.actuary.infrastructure.persistence.entity.AlzActProcessAmountsId;

import java.util.List;

public interface AlzActProcessAmountsRepository extends JpaRepository<AlzActProcessAmounts, AlzActProcessAmountsId> {

    @Query(value = "select pr.rule_name, " +
            "ra.year, " +
            "ra.month, " +
            "nvl(ra.process_id,pr.process_id) process_id, " +
            "nvl(ra.rule_id,pr.rule_id) rule_id, " +
            "ra.gross_cy_amount, " +
            "ra.re_cy_amount, " +
            "ra.net_cy_amount, " +
            "ra.gross_py_amount, " +
            "ra.re_py_amount, " +
            "ra.net_py_amount, " +
            "ra.ifrs_cy_gross, " +
            "ra.ifrs_cy_re, " +
            "ra.ifrs_cy_net, " +
            "ra.ifrs_py_gross, " +
            "ra.ifrs_py_re, " +
            "ra.ifrs_py_net, " +
            "ra.gross_cy_amount_rate, " +
            "ra.re_cy_amount_rate, " +
            "ra.net_cy_amount_rate, " +
            "ra.gross_py_amount_rate, " +
            "ra.re_py_amount_rate, " +
            "ra.net_py_amount_rate, " +
            "ra.ifrs_cy_gross_rate, " +
            "ra.ifrs_cy_re_rate, " +
            "ra.ifrs_cy_net_rate, " +
            "ra.ifrs_py_gross_rate, " +
            "ra.ifrs_py_re_rate, " +
            "ra.ifrs_py_net_rate " +
            "from alz_act_process_rules pr, alz_act_process_amounts ra " +
            "where pr.process_id = ra.process_id(+) " +
            "and pr.rule_id = ra.rule_id(+) " +
            "and pr.process_id = :p_process_id " +
            "and ra.year(+) = :p_year " +
            "and ra.month(+) = :p_month " +
            "order by ra.rule_id", nativeQuery = true)
    List<Object[]> queryActuaryProcessRuleAmounts(
            @Param("p_process_id") String processId,
            @Param("p_year") Integer year,
            @Param("p_month") Integer month
    );
}

