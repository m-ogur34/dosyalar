package tr.com.allianz.accounting_services.actuary.application.usecases;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import tr.com.allianz.accounting_services.actuary.application.port.out.SaveActuaryLogPort;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.ActuaryLog;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.ActuaryLogType;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
public class SaveActuaryLogUseCase {

    private static final int PROCESS_ID_MAX_LENGTH = 10;

    private final SaveActuaryLogPort saveActuaryLogPort;

    public void handle(
            Integer year,
            Integer month,
            String processId,
            Integer ruleId,
            ActuaryLogType logType,
            String logText,
            String byUser
    ) {
        if (logType == ActuaryLogType.AMOUNT_UPDATE && (processId == null || processId.isBlank())) {
            throw new IllegalArgumentException("processId is required for AMOUNT_UPDATE");
        }

        if (processId != null && processId.length() > PROCESS_ID_MAX_LENGTH) {
            throw new IllegalArgumentException("processId must be at most " + PROCESS_ID_MAX_LENGTH + " characters");
        }

        ActuaryLog log = new ActuaryLog(
                year,
                month,
                processId,
                ruleId,
                logType,
                logText,
                byUser,
                LocalDateTime.now()
        );

        saveActuaryLogPort.save(log);
    }
}

