package tr.com.allianz.accounting_services.cyclic_postings.infrastructure.persistence.adapter;

import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Component;
import tr.com.allianz.accounting_services.cyclic_postings.application.port.out.CyclicPostingProcessPort;
import tr.com.allianz.accounting_services.cyclic_postings.application.usecases.posting_process.AlzCyclicPostingProcessReadModel;
import tr.com.allianz.accounting_services.cyclic_postings.infrastructure.persistence.entity.AlzCyclicPostingProcess;
import tr.com.allianz.accounting_services.cyclic_postings.infrastructure.persistence.repository.AlzCyclicPostingProcessRepository;

import java.util.List;

@Component
@RequiredArgsConstructor
public class CyclicPostingProcessAdapter implements CyclicPostingProcessPort {

    private final AlzCyclicPostingProcessRepository repository;

    @Override
    public AlzCyclicPostingProcess findById(Long batchId) {
        return repository.findById(batchId).orElse(null);
    }

    @Override
    public AlzCyclicPostingProcess save(AlzCyclicPostingProcess process) {
        return repository.save(process);
    }

    @Override
    public void callCyclicPostingProcedure(Long batchId) {
        repository.callCyclicPostingProcedure(batchId);
      //  System.out.println(result);
    }

    @Override
    public List<AlzCyclicPostingProcessReadModel> listAllCyclicPostingProcesses(Pageable pageable, Long batchId, Long cyclicBatchId, String status) {
        AlzCyclicPostingProcess probe = new AlzCyclicPostingProcess();
        if (batchId != null) {
            probe.setBatchId(batchId);
        }
        if (cyclicBatchId != null) {
            probe.setCyclicBatchId(cyclicBatchId);
        }
        if (status != null) {
            try {
                // Convert the String status to the Domain Enum
                probe.setProcessStatusEnum(tr.com.allianz.accounting_services.cyclic_postings.domain.valueobject.ProcessStatus.valueOf(status));
            } catch (IllegalArgumentException e) {
                // If status string matches no known Enum, return empty list immediately
                return java.util.Collections.emptyList();
            }
        }
        // Create an Example that matches non-null fields in the probe
        Example<AlzCyclicPostingProcess> example = Example.of(probe);
        PageRequest pageRequest = PageRequest.of(pageable.getPageNumber(), pageable.getPageSize(),
                Sort.by(Sort.Direction.DESC, "createdDate"));

        return repository.findAll(example, pageRequest)
                .stream()
                .map(process -> new AlzCyclicPostingProcessReadModel(
                        process.getBatchId(),
                        process.getPostingDate(),
                        process.getCyclicBatchId(),
                        process.getProcessStatus(),
                        process.getErrText(),
                        process.getCreatedDate(),
                        process.getUpdatedDate()
                ))
                .toList();
    }

    @Override
    public void removeCyclicPostingProcess(Long batchId) {
        repository.deleteById(batchId);
    }

    @Override
    public List<AlzCyclicPostingProcess> saveAll(List<AlzCyclicPostingProcess> processes) {
        return repository.saveAll(processes);
    }
}