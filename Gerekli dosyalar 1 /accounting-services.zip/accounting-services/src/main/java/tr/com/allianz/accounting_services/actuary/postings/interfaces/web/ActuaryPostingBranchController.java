package tr.com.allianz.accounting_services.actuary.postings.interfaces.web;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import tr.com.allianz.accounting_services.actuary.postings.application.usecases.ListActuaryPostingBranchesUseCase;
import tr.com.allianz.accounting_services.actuary.postings.interfaces.web.dto.ActuaryPostingBranchResponse;

import java.util.List;

@RestController
@RequestMapping("/api/v1/actuary-posting-branches")
@RequiredArgsConstructor
@CrossOrigin
public class ActuaryPostingBranchController {

    private final ListActuaryPostingBranchesUseCase listActuaryPostingBranchesUseCase;

    @GetMapping
    public ResponseEntity<List<ActuaryPostingBranchResponse>> getAllBranches() {
        var branches = listActuaryPostingBranchesUseCase.handle();
        var responses = branches.stream()
                .map(b -> new ActuaryPostingBranchResponse(
                        b.getBranchId(),
                        b.getBranchName(),
                        b.getExtReference()
                ))
                .toList();
        return ResponseEntity.ok(responses);
    }
}

