package tr.com.allianz.accounting_services.cyclic_postings.infrastructure.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import tr.com.allianz.accounting_services.cyclic_postings.application.port.out.CyclicPostingMappingPort;
import tr.com.allianz.accounting_services.cyclic_postings.application.usecases.CreateCyclicMappingUseCase;
import tr.com.allianz.accounting_services.cyclic_postings.application.usecases.ListAlzCyclicAccountMappingUseCase;
import tr.com.allianz.accounting_services.cyclic_postings.application.usecases.RemoveAlzCyclicAccountMappingUseCase;

@Configuration
public class CyclicAccountMappingConfig {

    @Bean
    public CreateCyclicMappingUseCase createCyclicMappingUseCase(CyclicPostingMappingPort cyclicPostingMappingPort) {
        return new CreateCyclicMappingUseCase(cyclicPostingMappingPort);
    }

    @Bean
    public ListAlzCyclicAccountMappingUseCase listAlzCyclingAccountMappingUseCase(CyclicPostingMappingPort cyclicPostingMappingPort) {
        return new ListAlzCyclicAccountMappingUseCase(cyclicPostingMappingPort);
    }

    @Bean
    public RemoveAlzCyclicAccountMappingUseCase removeAlzCyclicAccountMappingUseCase(CyclicPostingMappingPort cyclicPostingMappingPort){
        return new RemoveAlzCyclicAccountMappingUseCase(cyclicPostingMappingPort);
    }


}
