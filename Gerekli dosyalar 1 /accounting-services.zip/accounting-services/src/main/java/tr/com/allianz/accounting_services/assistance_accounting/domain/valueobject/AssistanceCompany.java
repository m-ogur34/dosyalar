package tr.com.allianz.accounting_services.assistance_accounting.domain.valueobject;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AssistanceCompany {
    private Long intId;
    private String extReference;
    private String accountCode;
    private String agencyName;
}
