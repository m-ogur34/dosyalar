package tr.com.allianz.accounting_services.cyclic_postings.application.exception;


import tr.com.allianz.accounting_services.shared.exception.BaseApplicationException;
import lombok.Getter;
import org.springframework.http.HttpStatus;

@Getter
public class CyclicPostingProcessFailedException extends BaseApplicationException{

    private final Long batchId;

    public CyclicPostingProcessFailedException(Long batchId) {
        super("CYCLIC_POSTING_PROCESS_FAILED",
                "Muhasebeleştirme süreci başarısız oldu.",
                "Muhasebeleştirme " + batchId +
                        " nolu fiş için başarısız oldu. Lütfen alınan hata mesajını kontrol edin ve tekrar deneyin.",
                HttpStatus.UNPROCESSABLE_ENTITY);
        this.batchId = batchId;
    }
}
