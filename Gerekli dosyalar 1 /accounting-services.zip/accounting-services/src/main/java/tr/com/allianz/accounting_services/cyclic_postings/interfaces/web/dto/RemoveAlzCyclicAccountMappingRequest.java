package tr.com.allianz.accounting_services.cyclic_postings.interfaces.web.dto;

import java.io.Serializable;

public record RemoveAlzCyclicAccountMappingRequest(String accountNo) implements Serializable {
}
