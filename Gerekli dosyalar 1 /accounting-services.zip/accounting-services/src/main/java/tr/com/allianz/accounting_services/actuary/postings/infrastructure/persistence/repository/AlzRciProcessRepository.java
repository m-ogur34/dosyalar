package tr.com.allianz.accounting_services.actuary.postings.infrastructure.persistence.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import tr.com.allianz.accounting_services.actuary.postings.infrastructure.persistence.entity.AlzRciProcessEntity;

@Repository
public interface AlzRciProcessRepository extends JpaRepository<AlzRciProcessEntity, String> {
}

