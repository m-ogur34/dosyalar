package tr.com.allianz.accounting_services;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AccountingServicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(AccountingServicesApplication.class, args);
	}

}
