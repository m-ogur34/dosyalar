package tr.com.allianz.accounting_services.assistance_accounting.infrastructure.persistence.adapter;

import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;
import tr.com.allianz.accounting_services.assistance_accounting.application.port.out.LoadAssistanceProductPort;
import tr.com.allianz.accounting_services.assistance_accounting.domain.valueobject.AssistanceProduct;

import java.util.List;

@Component
@RequiredArgsConstructor
public class AssistanceProductPersistenceAdapter implements LoadAssistanceProductPort {

    private final NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    private static final String BASE_QUERY = """
        select PRODUCT_ID, EXT_REFERENCE, LONG_NAME
              from (SELECT A.PRODUCT_ID, EXT_REFERENCE, B.LONG_NAME
                      FROM OC_PRODUCTS A,
                           CUR_TRANSLATIONS B
                      WHERE A.DESC_INT_ID = B.DESC_INT_ID
                      AND B.SULA_ORA_NLS_CODE = 'TR') pv
        where exists (Select 1
                       from  koc_oc_prod_part_main_cov mc,
                             koc_rci_cover_group_Ref cg
                       where  mc.product_id = pv.product_id
                         and  mc.reins_cover_code = cg.reinsurance_cover_group
                         and nvl(cg.is_assistance,0) = 1
                         and mc.validity_end_date is null
    """;

    @Override
    public List<AssistanceProduct> loadAssistanceProducts(String accCoverCode) {
        StringBuilder query = new StringBuilder(BASE_QUERY);
        MapSqlParameterSource params = new MapSqlParameterSource();

        if (accCoverCode != null) {
            query.append(" and mc.acc_cover_code = :p_acc_cover_code");
            params.addValue("p_acc_cover_code", accCoverCode);
        }

        query.append(" )"); // Close exists subquery


        return namedParameterJdbcTemplate.query(query.toString(), params, (rs, rowNum) -> new AssistanceProduct(
                rs.getLong("PRODUCT_ID"),
                rs.getString("EXT_REFERENCE"),
                rs.getString("LONG_NAME")
        ));
    }
}

