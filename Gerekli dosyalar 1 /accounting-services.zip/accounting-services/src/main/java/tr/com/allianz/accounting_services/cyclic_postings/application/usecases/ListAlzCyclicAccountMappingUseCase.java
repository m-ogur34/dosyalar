package tr.com.allianz.accounting_services.cyclic_postings.application.usecases;

import tr.com.allianz.accounting_services.cyclic_postings.application.port.out.CyclicPostingMappingPort;

import java.util.List;

public class ListAlzCyclicAccountMappingUseCase {

    private final CyclicPostingMappingPort cyclicPostingMappingPort;

    public ListAlzCyclicAccountMappingUseCase(CyclicPostingMappingPort cyclicPostingMappingPort) {
        this.cyclicPostingMappingPort = cyclicPostingMappingPort;
    }

    public List<AlzCyclicAccountMappingReadModel> handle() {
        return cyclicPostingMappingPort.listCyclingAccountMapping();
    }
}
