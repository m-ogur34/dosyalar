package tr.com.allianz.accounting_services.actuary.postings.infrastructure.persistence.adapter;

import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;
import tr.com.allianz.accounting_services.actuary.postings.application.port.out.LoadActuaryPostingProductsPort;
import tr.com.allianz.accounting_services.actuary.postings.domain.model.ActuaryPostingProduct;

import java.util.List;

@Component
@RequiredArgsConstructor
public class ActuaryPostingProductPersistenceAdapter implements LoadActuaryPostingProductsPort {

    private static final String QUERY = """
            select a.product_id, a.ext_reference, b.long_name
              from oc_products a, cur_translations b, koc_oc_branch_prod_groups pb
             where a.desc_int_id = b.desc_int_id
               and b.sula_ora_nls_code = 'TR'
               and pb.product_group_id = a.product_group_id
               and pb.branch_id = :branch_id
            """;

    private final NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @Override
    public List<ActuaryPostingProduct> loadByBranchId(String branchId) {
        MapSqlParameterSource params = new MapSqlParameterSource()
                .addValue("branch_id", branchId);

        return namedParameterJdbcTemplate.queryForList(QUERY, params)
                .stream()
                .map(row -> new ActuaryPostingProduct(
                        toLong(row.get("product_id")),
                        stringValue(row.get("ext_reference")),
                        stringValue(row.get("long_name"))
                ))
                .toList();
    }

    private Long toLong(Object value) {
        if (value == null) {
            return null;
        }
        if (value instanceof Number number) {
            return number.longValue();
        }
        return Long.parseLong(value.toString().trim());
    }

    private String stringValue(Object value) {
        return value == null ? "" : value.toString().trim();
    }
}

