package tr.com.allianz.accounting_services.cyclic_postings.infrastructure.persistence.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import tr.com.allianz.accounting_services.cyclic_postings.domain.valueobject.ProcessStatus;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "ALZ_CYCLIC_POSTING_PROCESS")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@NamedStoredProcedureQuery(
        name = "AlzCyclicPostingProcess.callCyclicPostingProcedure",
        procedureName = "KOC_ACC_FIX_UTILS.Process_Accounting_Cyclic_Posting",
        parameters = {
                @StoredProcedureParameter(mode = ParameterMode.IN, name = "P_BATCH_ID", type = Long.class) // 1st Parameter
         }
)
public class AlzCyclicPostingProcess {

    @Id
    @Column(name = "BATCH_ID")
    private Long batchId;

    @Column(name = "POSTING_DATE")
    private LocalDate postingDate;

    @Column(name = "CYCLIC_BATCH_ID")
    private Long cyclicBatchId;

    @Column(name = "PROCESS_STATUS")
    private String processStatus;

    @Column(name = "ERR_TEXT")
    private String errText;

    @Column(name = "CREATED_DATE")
    private LocalDateTime createdDate;

    @Column(name = "UPDATED_DATE")
    private LocalDateTime updatedDate;

    public ProcessStatus getProcessStatusEnum() {
        return ProcessStatus.fromValue(this.processStatus);
    }

    public void setProcessStatusEnum(ProcessStatus status) {
        this.processStatus = status.getValue();
    }
}
