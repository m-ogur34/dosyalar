package tr.com.allianz.accounting_services.actuary.postings.infrastructure.persistence.adapter;

import lombok.RequiredArgsConstructor;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Component;
import tr.com.allianz.accounting_services.actuary.postings.application.exception.ActuaryPostingBatchInfoFailedException;
import tr.com.allianz.accounting_services.actuary.postings.application.port.out.LoadActuaryPostingBatchInfoPort;
import tr.com.allianz.accounting_services.actuary.postings.application.usecases.GetActuaryPostingBatchInfoCommand;
import tr.com.allianz.accounting_services.actuary.postings.domain.model.ActuaryPostingBatchInfoLine;

import java.sql.Date;
import java.sql.Types;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;
import java.util.List;
import java.util.Map;

@Component
@RequiredArgsConstructor
public class ActuaryPostingBatchInfoPersistenceAdapter implements LoadActuaryPostingBatchInfoPort {

    private static final String REF_CURSOR = "v_refcur";
    private static final int DEFAULT_LIMIT = 1000;

    private final JdbcTemplate jdbcTemplate;

    @Override
    @SuppressWarnings("unchecked")
    public List<ActuaryPostingBatchInfoLine> loadBatchInfo(GetActuaryPostingBatchInfoCommand command) {
        SimpleJdbcCall simpleJdbcCall = createSimpleJdbcCall()
                .withSchemaName("CUSTOMER")
                .withCatalogName("ALZ_RCI_POSTING_UTILS")
                .withProcedureName("GET_BATCH_INFO")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlParameter("p_batch_type", Types.NUMERIC),
                        new SqlParameter("p_date", Types.DATE),
                        new SqlParameter("p_branch_ext_ref", Types.VARCHAR),
                        new SqlParameter("p_product_id", Types.NUMERIC),
                        new SqlParameter("p_partition_type", Types.VARCHAR),
                        new SqlParameter("p_is_industrial", Types.NUMERIC),
                        new SqlParameter("p_rownum", Types.NUMERIC),
                        new SqlOutParameter(REF_CURSOR, Types.REF_CURSOR, (rs, rowNum) -> new ActuaryPostingBatchInfoLine(
                                trim(rs.getString("account_no")),
                                trim(rs.getString("account_exp")),
                                trim(rs.getString("explanation")),
                                toBorc(rs.getBigDecimal("posting_amount")),
                                toAlacak(rs.getBigDecimal("posting_amount"))
                        ))
                );

        MapSqlParameterSource inparams = new MapSqlParameterSource()
                .addValue("p_batch_type", command.batchType(), Types.NUMERIC)
                .addValue("p_date", toSqlDate(command.postingDate()), Types.DATE)
                .addValue("p_branch_ext_ref", command.branchExtRef(), Types.VARCHAR)
                .addValue("p_product_id", command.productId(), Types.NUMERIC)
                .addValue("p_partition_type", command.partitionType(), Types.VARCHAR)
                .addValue("p_is_industrial", command.isIndustrial(), Types.NUMERIC)
                .addValue("p_rownum", DEFAULT_LIMIT, Types.NUMERIC);

        try {
            Map<String, Object> out = simpleJdbcCall.execute(inparams);
            Object cursor = out.get(REF_CURSOR);
            if (cursor == null) {
                return List.of();
            }
            return (List<ActuaryPostingBatchInfoLine>) cursor;
        } catch (DataAccessException ex) {
            String detail = ex.getMostSpecificCause().getMessage();
            throw new ActuaryPostingBatchInfoFailedException(detail);
        }
    }

    protected SimpleJdbcCall createSimpleJdbcCall() {
        return new SimpleJdbcCall(jdbcTemplate);
    }

    private Date toSqlDate(LocalDate postingDate) {
        LocalDate monthEnd = postingDate.with(TemporalAdjusters.lastDayOfMonth());
        return Date.valueOf(monthEnd);
    }

    private String trim(String value) {
        return value == null ? "" : value.trim();
    }

    private BigDecimal toBorc(BigDecimal postingAmount) {
        if (postingAmount == null) {
            return BigDecimal.ZERO;
        }
        return postingAmount.signum() < 0 ? postingAmount.negate() : BigDecimal.ZERO;
    }

    private BigDecimal toAlacak(BigDecimal postingAmount) {
        if (postingAmount == null) {
            return BigDecimal.ZERO;
        }
        return postingAmount.signum() < 0 ? BigDecimal.ZERO : postingAmount;
    }
}

