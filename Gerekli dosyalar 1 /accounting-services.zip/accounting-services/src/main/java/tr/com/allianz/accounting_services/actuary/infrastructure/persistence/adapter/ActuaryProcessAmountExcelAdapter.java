package tr.com.allianz.accounting_services.actuary.infrastructure.persistence.adapter;

import lombok.RequiredArgsConstructor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.util.CellReference;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;
import tr.com.allianz.accounting_services.actuary.application.port.out.ParseActuaryProcessAmountExcelPort;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.ActuaryProcessAmountExcelRow;
import tr.com.allianz.accounting_services.actuary.infrastructure.persistence.entity.AlzActProcessRules;
import tr.com.allianz.accounting_services.actuary.infrastructure.persistence.repository.AlzActProcessRulesRepository;
import tr.com.allianz.accounting_services.actuary.support.ExcelFileValidationSupport;

import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Component
@RequiredArgsConstructor
public class ActuaryProcessAmountExcelAdapter implements ParseActuaryProcessAmountExcelPort {

    private static final String[] IDENTIFIER_HEADERS = {
            "PROCESS_ID", "RULE_ID", "RULE_NAME"
    };
    private static final String[] AMOUNT_HEADERS = {
            "GROSS_CY_AMOUNT", "RE_CY_AMOUNT", "NET_CY_AMOUNT",
            "GROSS_PY_AMOUNT", "RE_PY_AMOUNT", "NET_PY_AMOUNT"
    };
    private static final String[] IFRS_HEADERS = {
            "IFRS_CY_GROSS", "IFRS_CY_RE", "IFRS_CY_NET",
            "IFRS_PY_GROSS", "IFRS_PY_RE", "IFRS_PY_NET"
    };
    private static final String[] RATE_HEADERS = {
            "GROSS_CY_AMOUNT_RATE", "RE_CY_AMOUNT_RATE", "NET_CY_AMOUNT_RATE",
            "GROSS_PY_AMOUNT_RATE", "RE_PY_AMOUNT_RATE", "NET_PY_AMOUNT_RATE"
    };
    private static final String[] IFRS_RATE_HEADERS = {
            "IFRS_CY_GROSS_RATE", "IFRS_CY_RE_RATE", "IFRS_CY_NET_RATE",
            "IFRS_PY_GROSS_RATE", "IFRS_PY_RE_RATE", "IFRS_PY_NET_RATE"
    };

    private final AlzActProcessRulesRepository alzActProcessRulesRepository;

    private static final long MAX_FILE_SIZE = 5 * 1024 * 1024; // 5 MB

    private static final int PROCESS_ID_COL = 0;
    private static final int RULE_ID_COL = 1;
    private static final int RULE_NAME_COL = 2;

    private static final int COL_1 = 3;
    private static final int COL_2 = 4;
    private static final int COL_3 = 5;
    private static final int COL_4 = 6;
    private static final int COL_5 = 7;
    private static final int COL_6 = 8;


    @Override
    public List<ActuaryProcessAmountExcelRow> parse(MultipartFile file) {
        if (file == null || file.isEmpty()) {
            throw new IllegalArgumentException("Excel dosyasi bos olamaz");
        }

        // Validate file
        validateExcelFile(file);

        DataFormatter formatter = new DataFormatter();
        List<ActuaryProcessAmountExcelRow> rows = new ArrayList<>();

        try (InputStream is = file.getInputStream(); Workbook workbook = WorkbookFactory.create(is)) {
            for (int sheetIndex = 0; sheetIndex < workbook.getNumberOfSheets(); sheetIndex++) {
                Sheet sheet = workbook.getSheetAt(sheetIndex);
                if (sheet.getPhysicalNumberOfRows() == 0) {
                    continue;
                }
                ExcelType excelType = detectExcelType(sheet, formatter);

                for (int i = 1; i <= sheet.getLastRowNum(); i++) {
                    Row row = sheet.getRow(i);
                    if (row == null || isRowEmpty(row, formatter)) {
                        continue;
                    }

                    String processId = getCellValue(row, PROCESS_ID_COL, formatter);
                    Integer ruleId = toInteger(getCellValue(row, RULE_ID_COL, formatter));
                    String ruleName = getCellValue(row, RULE_NAME_COL, formatter);

                    if (processId == null || processId.isBlank()) {
                        throw new IllegalArgumentException("Process ID bos olamaz. Sheet: " + sheet.getSheetName() + ", Satir: " + (i + 1));
                    }

                    // If ruleId is empty, try to find it using ruleName and processId
                    if (ruleId == null) {
                        if (ruleName == null || ruleName.isBlank()) {
                            throw new IllegalArgumentException("Rule ID veya Rule Name bos olamaz. Sheet: " + sheet.getSheetName() + ", Satir: " + (i + 1));
                        }
                        ruleId = findRuleIdByNameAndProcessId(ruleName, processId, i + 1);
                    }

                    rows.add(new ActuaryProcessAmountExcelRow(
                            processId,
                            ruleId,
                            ruleName,
                            excelType == ExcelType.AMOUNT ? getCellNumericValue(row, COL_1) : null,
                            excelType == ExcelType.AMOUNT ? getCellNumericValue(row, COL_2) : null,
                            excelType == ExcelType.AMOUNT ? getCellNumericValue(row, COL_3) : null,
                            excelType == ExcelType.AMOUNT ? getCellNumericValue(row, COL_4) : null,
                            excelType == ExcelType.AMOUNT ? getCellNumericValue(row, COL_5) : null,
                            excelType == ExcelType.AMOUNT ? getCellNumericValue(row, COL_6) : null,
                            excelType == ExcelType.IFRS ? getCellNumericValue(row, COL_1) : null,
                            excelType == ExcelType.IFRS ? getCellNumericValue(row, COL_2) : null,
                            excelType == ExcelType.IFRS ? getCellNumericValue(row, COL_3) : null,
                            excelType == ExcelType.IFRS ? getCellNumericValue(row, COL_4) : null,
                            excelType == ExcelType.IFRS ? getCellNumericValue(row, COL_5) : null,
                            excelType == ExcelType.IFRS ? getCellNumericValue(row, COL_6) : null,
                            excelType == ExcelType.RATE ? getCellNumericValue(row, COL_1) : null,
                            excelType == ExcelType.RATE ? getCellNumericValue(row, COL_2) : null,
                            excelType == ExcelType.RATE ? getCellNumericValue(row, COL_3) : null,
                            excelType == ExcelType.RATE ? getCellNumericValue(row, COL_4) : null,
                            excelType == ExcelType.RATE ? getCellNumericValue(row, COL_5) : null,
                            excelType == ExcelType.RATE ? getCellNumericValue(row, COL_6) : null,
                            excelType == ExcelType.IFRS_RATE ? getCellNumericValue(row, COL_1) : null,
                            excelType == ExcelType.IFRS_RATE ? getCellNumericValue(row, COL_2) : null,
                            excelType == ExcelType.IFRS_RATE ? getCellNumericValue(row, COL_3) : null,
                            excelType == ExcelType.IFRS_RATE ? getCellNumericValue(row, COL_4) : null,
                            excelType == ExcelType.IFRS_RATE ? getCellNumericValue(row, COL_5) : null,
                            excelType == ExcelType.IFRS_RATE ? getCellNumericValue(row, COL_6) : null
                    ));
                }
            }

            if (rows.isEmpty()) {
                throw new IllegalArgumentException("Yuklenecek veri satiri bulunamadi");
            }

            return rows;
        } catch (IOException e) {
            throw new IllegalArgumentException("Excel dosyasi okunamadi", e);
        }
    }

    private Integer findRuleIdByNameAndProcessId(String ruleName, String processId, int rowNumber) {
        return alzActProcessRulesRepository.findByRuleNameAndProcessId(ruleName, processId)
                .map(AlzActProcessRules::getRuleId)
                .orElseThrow(() -> new IllegalArgumentException(
                        "Rule ID bulunamadi. Rule Name: " + ruleName + ", Process ID: " + processId + ", Satir: " + rowNumber
                ));
    }

    private String getCellValue(Row row, int index, DataFormatter formatter) {
        if (row.getCell(index) == null) {
            return null;
        }
        String value = formatter.formatCellValue(row.getCell(index));
        return value == null ? null : value.trim();
    }

    private BigDecimal getCellNumericValue(Row row, int index) {
        Cell cell = row.getCell(index);
        if (cell == null) {
            return null;
        }

        // Handle numeric cell type directly
        if (cell.getCellType() == CellType.NUMERIC) {
            return BigDecimal.valueOf(cell.getNumericCellValue());
        }

        // Handle string cell type - convert to number
        if (cell.getCellType() == CellType.STRING) {
            return parseNumericText(cell.getStringCellValue(), row, index);
        }

        // Handle formula cell type
        if (cell.getCellType() == CellType.FORMULA) {
            try {
                return BigDecimal.valueOf(cell.getNumericCellValue());
            } catch (Exception e) {
                return parseNumericText(cell.getStringCellValue(), row, index);
            }
        }

        return null;
    }

    private BigDecimal parseNumericText(String value, Row row, int index) {
        if (value == null || value.isEmpty()) {
            return null;
        }

        if (value.isBlank() || containsWhitespace(value)) {
            throw invalidNumericCell(row, index, value);
        }

        try {
            return new BigDecimal(value.replace(",", "."));
        } catch (NumberFormatException e) {
            throw invalidNumericCell(row, index, value);
        }
    }

    private boolean containsWhitespace(String value) {
        for (int i = 0; i < value.length(); i++) {
            if (Character.isWhitespace(value.charAt(i))) {
                return true;
            }
        }
        return false;
    }

    private IllegalArgumentException invalidNumericCell(Row row, int index, String value) {
        String sheetName = row.getSheet() != null ? row.getSheet().getSheetName() : "?";
        String headerName = resolveHeaderName(row, index);
        String columnLetter = CellReference.convertNumToColString(index);

        return new IllegalArgumentException(
                "Sayisal alanlarda sadece sayi olmalidir. Sheet: " + sheetName
                        + ", Satir: " + (row.getRowNum() + 1)
                        + ", Kolon: " + (index + 1) + " (" + columnLetter + ")"
                        + ", Baslik: " + headerName
                        + ", Deger: " + value
        );
    }

    private String resolveHeaderName(Row row, int index) {
        if (row.getSheet() == null) {
            return "?";
        }

        Row headerRow = row.getSheet().getRow(0);
        if (headerRow == null || headerRow.getCell(index) == null) {
            return "?";
        }

        String header = headerRow.getCell(index).toString();
        return header == null || header.isBlank() ? "?" : header.trim();
    }

    private Integer toInteger(String value) {
        if (value == null || value.isBlank()) {
            return null;
        }
        return new BigDecimal(value).intValue();
    }


    private boolean isRowEmpty(Row row, DataFormatter formatter) {
        for (int i = 0; i <= COL_6; i++) {
            String cellValue = getCellValue(row, i, formatter);
            if (cellValue != null && !cellValue.isBlank()) {
                return false;
            }
        }
        return true;
    }

    private ExcelType detectExcelType(Sheet sheet, DataFormatter formatter) {
        Row headerRow = sheet.getRow(0);
        if (headerRow == null) {
            throw new IllegalArgumentException("Excel header satiri bos olamaz");
        }

        validateIdentifierHeaders(headerRow, formatter, sheet.getSheetName());

        if (matchesHeaders(headerRow, formatter, AMOUNT_HEADERS)) {
            return ExcelType.AMOUNT;
        }
        if (matchesHeaders(headerRow, formatter, IFRS_HEADERS)) {
            return ExcelType.IFRS;
        }
        if (matchesHeaders(headerRow, formatter, RATE_HEADERS)) {
            return ExcelType.RATE;
        }
        if (matchesHeaders(headerRow, formatter, IFRS_RATE_HEADERS)) {
            return ExcelType.IFRS_RATE;
        }

        throw new IllegalArgumentException(
                "Beklenen Excel basliklari bulunamadi. Sheet: " + sheet.getSheetName()
                        + ". Desteklenen alan gruplari: AMOUNT, IFRS, RATE, IFRS_RATE"
        );
    }

    private void validateIdentifierHeaders(Row headerRow, DataFormatter formatter, String sheetName) {
        for (int i = 0; i < IDENTIFIER_HEADERS.length; i++) {
            String actualHeader = normalizeHeader(getCellValue(headerRow, i, formatter));
            if (!IDENTIFIER_HEADERS[i].equals(actualHeader)) {
                throw new IllegalArgumentException(
                        "Beklenen Excel basliklari bulunamadi. Sheet: " + sheetName
                                + ". Ilk uc baslik PROCESS_ID, RULE_ID, RULE_NAME olmalidir"
                );
            }
        }
    }

    private boolean matchesHeaders(Row headerRow, DataFormatter formatter, String[] expectedHeaders) {
        for (int i = 0; i < expectedHeaders.length; i++) {
            String actualHeader = normalizeHeader(getCellValue(headerRow, i + COL_1, formatter));
            if (!expectedHeaders[i].equals(actualHeader)) {
                return false;
            }
        }
        return true;
    }

    private String normalizeHeader(String value) {
        return value == null ? "" : value.trim().toUpperCase();
    }

    private enum ExcelType {
        AMOUNT,
        IFRS,
        RATE,
        IFRS_RATE
    }

    private void validateExcelFile(MultipartFile file) {
        if (file.getSize() > MAX_FILE_SIZE) {
            throw new IllegalArgumentException(
                    String.format("Dosya boyutu %d MB'ı geçemez. Yüklenen dosya: %.2f MB",
                            MAX_FILE_SIZE / (1024 * 1024),
                            (double) file.getSize() / (1024 * 1024))
            );
        }

        ExcelFileValidationSupport.validateExcelType(
                file,
                "Geçersiz dosya formatı. Lütfen Excel formatında dosya yükleyiniz (.xlsx, .xls)",
                "Geçersiz dosya türü. Lütfen Excel formatında dosya yükleyiniz."
        );
    }
}


