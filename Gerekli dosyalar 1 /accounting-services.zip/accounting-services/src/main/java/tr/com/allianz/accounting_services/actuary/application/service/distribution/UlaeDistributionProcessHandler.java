package tr.com.allianz.accounting_services.actuary.application.service.distribution;

import org.springframework.stereotype.Component;

@Component
public class UlaeDistributionProcessHandler implements DistributionProcessHandler {

    @Override
    public boolean supports(String processId) {
        return "ULAE".equals(processId);
    }

    @Override
    public void execute(String processId, Integer year, Integer month) {
        // Intentionally left blank.
    }
}

