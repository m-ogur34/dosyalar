package tr.com.allianz.accounting_services.actuary.domain.valueobject;

import java.math.BigDecimal;

public record IfrsDistributionTotals(
        BigDecimal grossAmountTotal,
        BigDecimal reAmountTotal,
        BigDecimal netAmountTotal
) {
}

