package tr.com.allianz.accounting_services.actuary.infrastructure.persistence.adapter;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import tr.com.allianz.accounting_services.actuary.application.port.out.SaveActuaryProcessAmountPort;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.ActuaryProcessAmount;
import tr.com.allianz.accounting_services.actuary.infrastructure.persistence.entity.AlzActProcessAmounts;
import tr.com.allianz.accounting_services.actuary.infrastructure.persistence.entity.AlzActProcessAmountsId;
import tr.com.allianz.accounting_services.actuary.infrastructure.persistence.repository.AlzActProcessAmountsRepository;

import java.util.List;
import java.util.Optional;

@Component
@RequiredArgsConstructor
public class ActuaryProcessAmountAdapter implements SaveActuaryProcessAmountPort {

	private final AlzActProcessAmountsRepository repository;

	@Override
	public void save(ActuaryProcessAmount processAmount) {
		repository.save(toEntity(processAmount));
	}

	@Override
	public void saveAll(List<ActuaryProcessAmount> processAmounts) {
		List<AlzActProcessAmounts> entities = processAmounts.stream()
				.map(this::toEntity)
				.toList();
		repository.saveAll(entities);
	}

	private AlzActProcessAmounts toEntity(ActuaryProcessAmount processAmount) {
		AlzActProcessAmounts incoming = new AlzActProcessAmounts(
				processAmount.year(),
				processAmount.month(),
				processAmount.processId(),
				processAmount.ruleId(),
				processAmount.grossCyAmount(),
				processAmount.reCyAmount(),
				processAmount.netCyAmount(),
				processAmount.grossPyAmount(),
				processAmount.rePyAmount(),
				processAmount.netPyAmount(),
				processAmount.ifrsCyGross(),
				processAmount.ifrsCyRe(),
				processAmount.ifrsCyNet(),
				processAmount.ifrsPyGross(),
				processAmount.ifrsPyRe(),
				processAmount.ifrsPyNet(),
				processAmount.grossCyAmountRate(),
				processAmount.reCyAmountRate(),
				processAmount.netCyAmountRate(),
				processAmount.grossPyAmountRate(),
				processAmount.rePyAmountRate(),
				processAmount.netPyAmountRate(),
				processAmount.ifrsCyGrossRate(),
				processAmount.ifrsCyReRate(),
				processAmount.ifrsCyNetRate(),
				processAmount.ifrsPyGrossRate(),
				processAmount.ifrsPyReRate(),
				processAmount.ifrsPyNetRate()
		);

		AlzActProcessAmountsId id = new AlzActProcessAmountsId(
				incoming.getYear(),
				incoming.getMonth(),
				incoming.getProcessId(),
				incoming.getRuleId()
		);

		Optional<AlzActProcessAmounts> existing = repository.findById(id);
		if (existing.isEmpty()) {
			return incoming;
		}

		AlzActProcessAmounts current = existing.get();
		incoming.setGrossCyAmount(coalesce(incoming.getGrossCyAmount(), current.getGrossCyAmount()));
		incoming.setReCyAmount(coalesce(incoming.getReCyAmount(), current.getReCyAmount()));
		incoming.setNetCyAmount(coalesce(incoming.getNetCyAmount(), current.getNetCyAmount()));
		incoming.setGrossPyAmount(coalesce(incoming.getGrossPyAmount(), current.getGrossPyAmount()));
		incoming.setRePyAmount(coalesce(incoming.getRePyAmount(), current.getRePyAmount()));
		incoming.setNetPyAmount(coalesce(incoming.getNetPyAmount(), current.getNetPyAmount()));
		incoming.setIfrsCyGross(coalesce(incoming.getIfrsCyGross(), current.getIfrsCyGross()));
		incoming.setIfrsCyRe(coalesce(incoming.getIfrsCyRe(), current.getIfrsCyRe()));
		incoming.setIfrsCyNet(coalesce(incoming.getIfrsCyNet(), current.getIfrsCyNet()));
		incoming.setIfrsPyGross(coalesce(incoming.getIfrsPyGross(), current.getIfrsPyGross()));
		incoming.setIfrsPyRe(coalesce(incoming.getIfrsPyRe(), current.getIfrsPyRe()));
		incoming.setIfrsPyNet(coalesce(incoming.getIfrsPyNet(), current.getIfrsPyNet()));
		incoming.setGrossCyAmountRate(coalesce(incoming.getGrossCyAmountRate(), current.getGrossCyAmountRate()));
		incoming.setReCyAmountRate(coalesce(incoming.getReCyAmountRate(), current.getReCyAmountRate()));
		incoming.setNetCyAmountRate(coalesce(incoming.getNetCyAmountRate(), current.getNetCyAmountRate()));
		incoming.setGrossPyAmountRate(coalesce(incoming.getGrossPyAmountRate(), current.getGrossPyAmountRate()));
		incoming.setRePyAmountRate(coalesce(incoming.getRePyAmountRate(), current.getRePyAmountRate()));
		incoming.setNetPyAmountRate(coalesce(incoming.getNetPyAmountRate(), current.getNetPyAmountRate()));
		incoming.setIfrsCyGrossRate(coalesce(incoming.getIfrsCyGrossRate(), current.getIfrsCyGrossRate()));
		incoming.setIfrsCyReRate(coalesce(incoming.getIfrsCyReRate(), current.getIfrsCyReRate()));
		incoming.setIfrsCyNetRate(coalesce(incoming.getIfrsCyNetRate(), current.getIfrsCyNetRate()));
		incoming.setIfrsPyGrossRate(coalesce(incoming.getIfrsPyGrossRate(), current.getIfrsPyGrossRate()));
		incoming.setIfrsPyReRate(coalesce(incoming.getIfrsPyReRate(), current.getIfrsPyReRate()));
		incoming.setIfrsPyNetRate(coalesce(incoming.getIfrsPyNetRate(), current.getIfrsPyNetRate()));

		return incoming;
	}

	private <T> T coalesce(T value, T fallback) {
		return value != null ? value : fallback;
	}
}

