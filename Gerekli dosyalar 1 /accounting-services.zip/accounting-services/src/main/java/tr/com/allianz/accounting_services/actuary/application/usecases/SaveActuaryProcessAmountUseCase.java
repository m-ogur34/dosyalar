package tr.com.allianz.accounting_services.actuary.application.usecases;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import tr.com.allianz.accounting_services.actuary.application.service.ActuaryLogService;
import tr.com.allianz.accounting_services.actuary.application.port.out.SaveActuaryProcessAmountPort;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.ActuaryProcessAmount;

@Service
@RequiredArgsConstructor
@Transactional
public class SaveActuaryProcessAmountUseCase {

    private final SaveActuaryProcessAmountPort saveActuaryProcessAmountPort;
    private final ActuaryLogService actuaryLogService;

    public void handle(ActuaryProcessAmount processAmount, String byUser) {
        saveActuaryProcessAmountPort.save(processAmount);
        actuaryLogService.logAmountUpdate(
                processAmount.processId(),
                processAmount.year(),
                processAmount.month(),
                processAmount.ruleId(),
                "Amount updated for rule ID: " + processAmount.ruleId(),
                byUser
        );
    }

    public void handle(ActuaryProcessAmount processAmount) {
        handle(processAmount, "SYSTEM");
    }
}

