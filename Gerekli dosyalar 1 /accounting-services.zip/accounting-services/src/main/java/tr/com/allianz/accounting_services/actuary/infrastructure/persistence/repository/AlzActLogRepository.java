package tr.com.allianz.accounting_services.actuary.infrastructure.persistence.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import tr.com.allianz.accounting_services.actuary.infrastructure.persistence.entity.AlzActLog;

public interface AlzActLogRepository extends JpaRepository<AlzActLog, Long> {}
