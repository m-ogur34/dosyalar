package tr.com.allianz.accounting_services.actuary.postings.interfaces.web.dto;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDate;
public record CreateActuaryPostingBatchRequest(
        @NotNull Long batchType,
        @NotNull LocalDate postingDate,
        String branchExtRef,
        Integer isIndustrial
) {}