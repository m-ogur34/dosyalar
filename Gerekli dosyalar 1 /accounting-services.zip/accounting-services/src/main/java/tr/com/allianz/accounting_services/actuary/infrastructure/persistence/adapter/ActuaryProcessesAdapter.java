package tr.com.allianz.accounting_services.actuary.infrastructure.persistence.adapter;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import tr.com.allianz.accounting_services.actuary.application.port.out.LoadActuaryProcessesPort;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.ActuaryProcess;
import tr.com.allianz.accounting_services.actuary.infrastructure.persistence.entity.AlzActProcesses;
import tr.com.allianz.accounting_services.actuary.infrastructure.persistence.repository.AlzActProcessesRepository;
import java.time.LocalDate;
import java.util.List;
@Component
@RequiredArgsConstructor
public class ActuaryProcessesAdapter implements LoadActuaryProcessesPort {
    private final AlzActProcessesRepository repository;
    @Override
    public List<ActuaryProcess> loadActiveProcesses(LocalDate today) {
        return repository.findActiveProcesses(today)
                .stream()
                .map(this::toDomain)
                .toList();
    }
    private ActuaryProcess toDomain(AlzActProcesses entity) {
        return new ActuaryProcess(
                entity.getProcessId(),
                entity.getProcessName(),
                entity.getExplanation(),
                entity.getValidityStartDate(),
                entity.getValidityEndDate()
        );
    }
}
