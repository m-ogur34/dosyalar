package tr.com.allianz.accounting_services.actuary.postings.interfaces.web;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import tr.com.allianz.accounting_services.actuary.postings.application.usecases.CreateActuaryPostingBatchCommand;
import tr.com.allianz.accounting_services.actuary.postings.application.usecases.CreateActuaryPostingBatchUseCase;
import tr.com.allianz.accounting_services.actuary.postings.domain.model.CreateActuaryPostingBatchResult;
import tr.com.allianz.accounting_services.actuary.postings.interfaces.web.dto.CreateActuaryPostingBatchRequest;
import tr.com.allianz.accounting_services.actuary.postings.interfaces.web.dto.CreateActuaryPostingBatchResponse;
import tr.com.allianz.accounting_services.shared.api.ApiResponse;
@RestController
@RequestMapping("/api/v1/actuary-postings/batch")
@RequiredArgsConstructor
@CrossOrigin
public class CreateActuaryPostingBatchController {
    private static final String ALREADY_EXISTS_MSG = "Fis zaten mevcuttur";
    private static final String CREATED_MSG = "Fis basariyla olusturuldu";
    private final CreateActuaryPostingBatchUseCase createActuaryPostingBatchUseCase;
    @PostMapping
    public ResponseEntity<ApiResponse<CreateActuaryPostingBatchResponse>> createBatch(
            @Valid @RequestBody CreateActuaryPostingBatchRequest request) {
        CreateActuaryPostingBatchCommand command = new CreateActuaryPostingBatchCommand(
                request.batchType(), request.postingDate(), request.branchExtRef(), request.isIndustrial());
        CreateActuaryPostingBatchResult result = createActuaryPostingBatchUseCase.handle(command);
        if (result.batchAlreadyExists()) {
            return ResponseEntity.ok(ApiResponse.ok("ACTUARY_POSTING_BATCH_ALREADY_EXISTS", ALREADY_EXISTS_MSG,
                    new CreateActuaryPostingBatchResponse(result.batchId(), true, ALREADY_EXISTS_MSG)));
        }
        return ResponseEntity.status(HttpStatus.CREATED).body(ApiResponse.ok("ACTUARY_POSTING_BATCH_CREATED", CREATED_MSG,
                new CreateActuaryPostingBatchResponse(result.batchId(), false, CREATED_MSG)));
    }
}