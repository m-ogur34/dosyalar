package tr.com.allianz.accounting_services.assistance_accounting.infrastructure.persistence.adapter;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import tr.com.allianz.accounting_services.assistance_accounting.application.port.out.LoadAssistanceCompanyPort;
import tr.com.allianz.accounting_services.assistance_accounting.domain.valueobject.AssistanceCompany;
import tr.com.allianz.accounting_services.assistance_accounting.infrastructure.persistence.entity.KocAcGenAccountRefs;
import tr.com.allianz.accounting_services.assistance_accounting.infrastructure.persistence.repository.KocAcGenAccountRefsRepository;

import java.util.List;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class AssistanceCompanyPersistenceAdapter implements LoadAssistanceCompanyPort {

    private final KocAcGenAccountRefsRepository repository;

    @Override
    public List<AssistanceCompany> loadAssistanceCompanies() {
        List<KocAcGenAccountRefs> entities = repository.findByIsAssistanceCompany(1);
        return entities.stream()
                .map(this::mapToDomain)
                .collect(Collectors.toList());
    }

    private AssistanceCompany mapToDomain(KocAcGenAccountRefs entity) {
        return AssistanceCompany.builder()
                .intId(entity.getIntId())
                .extReference(entity.getExtReference())
                .accountCode(entity.getAccountCode())
                .agencyName(entity.getName())
                .build();
    }
}

