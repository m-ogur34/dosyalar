package tr.com.allianz.accounting_services.actuary.infrastructure.persistence.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

@Entity
@Table(name = "ALZ_ACT_PROCESS_AMOUNTS")
@IdClass(AlzActProcessAmountsId.class)
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class AlzActProcessAmounts {

    @Id
    @Column(name = "YEAR", precision = 4)
    private Integer year;

    @Id
    @Column(name = "MONTH", precision = 2)
    private Integer month;

    @Id
    @Column(name = "PROCESS_ID", length = 10)
    private String processId;

    @Id
    @Column(name = "RULE_ID", precision = 5)
    private Integer ruleId;

    @Column(name = "GROSS_CY_AMOUNT", precision = 28, scale = 4)
    private BigDecimal grossCyAmount;

    @Column(name = "RE_CY_AMOUNT", precision = 28, scale = 4)
    private BigDecimal reCyAmount;

    @Column(name = "NET_CY_AMOUNT", precision = 28, scale = 4)
    private BigDecimal netCyAmount;

    @Column(name = "GROSS_PY_AMOUNT", precision = 28, scale = 4)
    private BigDecimal grossPyAmount;

    @Column(name = "RE_PY_AMOUNT", precision = 28, scale = 4)
    private BigDecimal rePyAmount;

    @Column(name = "NET_PY_AMOUNT", precision = 28, scale = 4)
    private BigDecimal netPyAmount;

    @Column(name = "IFRS_CY_GROSS", precision = 28, scale = 4)
    private BigDecimal ifrsCyGross;

    @Column(name = "IFRS_CY_RE", precision = 28, scale = 4)
    private BigDecimal ifrsCyRe;

    @Column(name = "IFRS_CY_NET", precision = 28, scale = 4)
    private BigDecimal ifrsCyNet;

    @Column(name = "IFRS_PY_GROSS", precision = 28, scale = 4)
    private BigDecimal ifrsPyGross;

    @Column(name = "IFRS_PY_RE", precision = 28, scale = 4)
    private BigDecimal ifrsPyRe;

    @Column(name = "IFRS_PY_NET", precision = 28, scale = 4)
    private BigDecimal ifrsPyNet;

    @Column(name = "GROSS_CY_AMOUNT_RATE", precision = 38, scale = 33)
    private BigDecimal grossCyAmountRate;

    @Column(name = "RE_CY_AMOUNT_RATE", precision = 38, scale = 33)
    private BigDecimal reCyAmountRate;

    @Column(name = "NET_CY_AMOUNT_RATE", precision = 38, scale = 33)
    private BigDecimal netCyAmountRate;

    @Column(name = "GROSS_PY_AMOUNT_RATE", precision = 38, scale = 33)
    private BigDecimal grossPyAmountRate;

    @Column(name = "RE_PY_AMOUNT_RATE", precision = 38, scale = 33)
    private BigDecimal rePyAmountRate;

    @Column(name = "NET_PY_AMOUNT_RATE", precision = 38, scale = 33)
    private BigDecimal netPyAmountRate;

    @Column(name = "IFRS_CY_GROSS_RATE", precision = 38, scale = 33)
    private BigDecimal ifrsCyGrossRate;

    @Column(name = "IFRS_CY_RE_RATE", precision = 38, scale = 33)
    private BigDecimal ifrsCyReRate;

    @Column(name = "IFRS_CY_NET_RATE", precision = 38, scale = 33)
    private BigDecimal ifrsCyNetRate;

    @Column(name = "IFRS_PY_GROSS_RATE", precision = 38, scale = 33)
    private BigDecimal ifrsPyGrossRate;

    @Column(name = "IFRS_PY_RE_RATE", precision = 38, scale = 33)
    private BigDecimal ifrsPyReRate;

    @Column(name = "IFRS_PY_NET_RATE", precision = 38, scale = 33)
    private BigDecimal ifrsPyNetRate;
}

