package tr.com.allianz.accounting_services.cyclic_postings.application.usecases.posting_process;

import lombok.extern.slf4j.Slf4j;
import tr.com.allianz.accounting_services.cyclic_postings.application.exception.CyclicPostingProcessAlreadyExistsException;
import tr.com.allianz.accounting_services.cyclic_postings.application.exception.CyclicPostingProcessNotFoundException;
import tr.com.allianz.accounting_services.cyclic_postings.application.port.out.CyclicPostingCheckPort;
import tr.com.allianz.accounting_services.cyclic_postings.application.port.out.CyclicPostingProcessPort;
import tr.com.allianz.accounting_services.cyclic_postings.domain.valueobject.ProcessStatus;
import tr.com.allianz.accounting_services.cyclic_postings.infrastructure.persistence.entity.AlzCyclicPostingProcess;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
public class CreateCyclicPostingUseCase {

    private final CyclicPostingProcessPort cyclicPostingProcessPort;
    private final CyclicPostingCheckPort cyclicPostingCheckPort;


    public CreateCyclicPostingUseCase(CyclicPostingProcessPort cyclicPostingProcessPort, CyclicPostingCheckPort cyclicPostingCheckPort) {
        this.cyclicPostingProcessPort = cyclicPostingProcessPort;
        this.cyclicPostingCheckPort = cyclicPostingCheckPort;
    }

    public List<AlzCyclicPostingProcess> handle(List<CreateCyclicPostingCommand> commands) {
        List<AlzCyclicPostingProcess> processes = commands.stream()
            .map(this::createProcess)
            .collect(Collectors.toList());

        return cyclicPostingProcessPort.saveAll(processes);
    }

    private AlzCyclicPostingProcess createProcess(CreateCyclicPostingCommand command) {

        AlzCyclicPostingProcess existingProcess = cyclicPostingProcessPort.findById(command.getBatchId());
        if(existingProcess != null) {
            throw new CyclicPostingProcessAlreadyExistsException(command.getBatchId());
        }
        int batchCount = cyclicPostingCheckPort.findBatchCount(command.getBatchId());
        if (batchCount == 0) {
            throw new CyclicPostingProcessNotFoundException( command.getBatchId());
        }
        AlzCyclicPostingProcess process = new AlzCyclicPostingProcess();
        String cyclicAccountNo = cyclicPostingCheckPort.findNotMappedCyclicAccountNo(command.getBatchId());
        process.setProcessStatusEnum(ProcessStatus.CREATED);
        if(cyclicAccountNo!=null && !cyclicAccountNo.isEmpty()){
            process.setErrText("Bazı devir hesapları eşleştirilmemiş.Önce eksik eşlemeleri tamamlayın" +
                    " Eşleştirilmeyen hesaplar: " + cyclicAccountNo);
            process.setProcessStatusEnum(ProcessStatus.ERROR_OCCURRED);
        }
        process.setBatchId(command.getBatchId());
        process.setPostingDate(command.getPostingDate());
        process.setCyclicBatchId(null);
        process.setCreatedDate(LocalDateTime.now());
        process.setUpdatedDate(LocalDateTime.now());
        return process;
    }

    public static class CreateCyclicPostingCommand {
        private final Long batchId;
        private final LocalDate postingDate;

        public CreateCyclicPostingCommand(Long batchId, LocalDate postingDate) {
            this.batchId = batchId;
            this.postingDate = postingDate;
        }

        public Long getBatchId() { return batchId; }
        public LocalDate getPostingDate() { return postingDate; }
    }
}