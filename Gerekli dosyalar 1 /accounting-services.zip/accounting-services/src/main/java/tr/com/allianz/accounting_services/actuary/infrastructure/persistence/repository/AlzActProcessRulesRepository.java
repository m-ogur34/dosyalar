package tr.com.allianz.accounting_services.actuary.infrastructure.persistence.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import tr.com.allianz.accounting_services.actuary.infrastructure.persistence.entity.AlzActProcessRules;
import tr.com.allianz.accounting_services.actuary.infrastructure.persistence.entity.AlzActProcessRulesId;

import java.util.List;
import java.util.Optional;

public interface AlzActProcessRulesRepository extends JpaRepository<AlzActProcessRules, AlzActProcessRulesId> {
    @Query("SELECT r FROM AlzActProcessRules r WHERE r.ruleName = :ruleName AND r.id.processId = :processId")
    Optional<AlzActProcessRules> findByRuleNameAndProcessId(@Param("ruleName") String ruleName, @Param("processId") String processId);

    @Query("SELECT r FROM AlzActProcessRules r WHERE r.id.processId = :processId AND r.id.ruleId = :ruleId")
    Optional<AlzActProcessRules> findByProcessIdAndRuleId(@Param("processId") String processId, @Param("ruleId") Integer ruleId);

    @Query("SELECT r FROM AlzActProcessRules r WHERE r.id.processId = :processId AND r.id.ruleId IN :ruleIds")
    List<AlzActProcessRules> findByProcessIdAndRuleIdIn(@Param("processId") String processId,
                                                        @Param("ruleIds") List<Integer> ruleIds);
}



