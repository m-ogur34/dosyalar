package tr.com.allianz.accounting_services.cyclic_postings.application.exception;


import tr.com.allianz.accounting_services.shared.exception.BaseApplicationException;
import lombok.Getter;
import org.springframework.http.HttpStatus;

@Getter
public class CyclicPostingProcessAlreadyExistsException extends BaseApplicationException{

    private final Long batchId;

    public CyclicPostingProcessAlreadyExistsException(Long batchId) {
        super("CYCLIC_POSTING_PROCESS_ALREADY_EXISTS",
                "Cyclic posting process is already exists.",
                "Cyclic posting process with " + batchId +
                        " already exists..",
                HttpStatus.CONFLICT);
        this.batchId = batchId;
    }

}
