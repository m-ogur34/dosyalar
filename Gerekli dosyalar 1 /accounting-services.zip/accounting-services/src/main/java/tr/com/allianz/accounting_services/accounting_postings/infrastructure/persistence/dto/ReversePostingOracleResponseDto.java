package tr.com.allianz.accounting_services.accounting_postings.infrastructure.persistence.dto;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import tr.com.allianz.accounting_services.accounting_postings.interfaces.web.dto.ReversePostingResponse;
import java.util.List;
@Getter
@Setter
public class ReversePostingOracleResponseDto {
    @JsonProperty("succeeded")
    private boolean success;
    private String errorCode;
    private String exception;
    private List<ReversePostingResponse> data;
}