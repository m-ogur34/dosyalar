package tr.com.allianz.accounting_services.actuary.infrastructure.persistence.adapter;

import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.PreparedStatementCallback;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import java.sql.Connection;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executor;

/**
 * IFRS PY ham verisini tek seferde DB'den çeken ve Caffeine cache'e alan bileşen.
 * Farklı ruleId'ler aynı sorgu sonucunu paylaşır; DB'ye tekrar gidilmez.
 */
// @Component devre dışı: ham satır cache'lemesi OOM'a yol açıyordu.
// Tüm SUM işlemleri artık DB tarafında IfrsDistributionTotalsAdapter aggregate SQL şablonlarıyla yapılır.
@RequiredArgsConstructor
public class IfrsRawDataCache {

    private static final int QUERY_TIMEOUT_SECONDS = 120;
    private static final int NETWORK_TIMEOUT_MILLIS = 120_000;
    private static final int FETCH_SIZE = 1_000;
    private static final Executor NETWORK_TIMEOUT_EXECUTOR = Runnable::run;

    private static final String YEAR_MINUS_1_QUERY = """
            SELECT t.*,
                   DECODE(t.code,'WCRI',-1,1)*NVL(t.amount,0)+DECODE(t.code,'W',1,0)*NVL(t.prv_amount,0) amount_component,
                   CASE WHEN t.is_pool=1 THEN 0 ELSE
                        DECODE(t.code,'WCRI',-1,1)*(NVL(t.amount,0)-NVL(t.reas_amount,0))
                       +DECODE(t.code,'W',1,0)*(NVL(t.prv_amount,0)-NVL(t.prv_reas_amount,0)) END net_amount_component
              FROM customer.alz_hp_data t
             WHERE t.year = :yearMinus1
               AND t.month = :month
               AND t.code IN ('W','WCRI')
               AND t.product_id NOT IN (12,60)
               AND NVL(Koc_acc_utils.GET_LOB(t.acc_cover_code,t.product_id,t.partition_type,sysdate),'X') NOT IN ('600','601','604')
            """;

    private static final String YEAR_RANGE_QUERY = """
            SELECT t.*,
                   NVL(t.amount,0)+NVL(t.prv_amount,0) amount_component,
                   CASE WHEN t.is_pool=1 THEN 0 ELSE
                        NVL(t.amount,0)-NVL(t.reas_amount,0)+(NVL(t.prv_amount,0)-NVL(t.prv_reas_amount,0)) END net_amount_component
              FROM customer.alz_hp_data t
             WHERE t.year BETWEEN :yearMinus3 AND :yearMinus2
               AND t.month = 12
               AND t.code = 'W'
               AND t.product_id NOT IN (12,60)
               AND NVL(Koc_acc_utils.GET_LOB(t.acc_cover_code,t.product_id,t.partition_type,sysdate),'X') NOT IN ('600','601','604')
            """;

    private static final String YEAR_MINUS_3_QUERY = """
            SELECT t.*,
                   NVL(t.prv_amount,0) amount_component,
                   CASE WHEN t.is_pool=1 THEN 0 ELSE NVL(t.prv_amount,0)-NVL(t.prv_reas_amount,0) END net_amount_component
              FROM customer.alz_hp_data t
             WHERE t.year = :yearMinus3
               AND t.month = 1
               AND t.code = 'WCRI'
               AND t.product_id NOT IN (12,60)
               AND NVL(Koc_acc_utils.GET_LOB(t.acc_cover_code,t.product_id,t.partition_type,sysdate),'X') NOT IN ('600','601','604')
            """;

    private final NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    /** year-1, verilen ay — IFRS kayıtları (cache'li). */
    /** Devre dışı: ham satır cache'lemesi OOM'a yol açıyordu. */
    public List<Map<String, Object>> loadYearMinus1Rows(Integer year, Integer month) {
        return streamToList(YEAR_MINUS_1_QUERY, new MapSqlParameterSource()
                .addValue("yearMinus1", year - 1)
                .addValue("month", month));
    }

    /** year-3 ile year-2 arası yıllar, Aralık ayı — IFRS kayıtları (cache'li). */
    /** Devre dışı: ham satır cache'lemesi OOM'a yol açıyordu. */
    public List<Map<String, Object>> loadYearRangeRows(Integer year) {
        return streamToList(YEAR_RANGE_QUERY, new MapSqlParameterSource()
                .addValue("yearMinus3", year - 3)
                .addValue("yearMinus2", year - 2));
    }

    /** year-3, Ocak ayı, code=WCRI — IFRS kayıtları (cache'li). */
    /** Devre dışı: ham satır cache'lemesi OOM'a yol açıyordu. */
    public List<Map<String, Object>> loadYearMinus3Rows(Integer year) {
        return streamToList(YEAR_MINUS_3_QUERY, new MapSqlParameterSource()
                .addValue("yearMinus3", year - 3));
    }

    private List<Map<String, Object>> streamToList(String sql, MapSqlParameterSource params) {
        return namedParameterJdbcTemplate.execute(sql, params,
                (PreparedStatementCallback<List<Map<String, Object>>>) ps -> {
                    Connection connection = ps.getConnection();
                    Integer previousNetworkTimeout = readNetworkTimeout(connection);
                    applyNetworkTimeout(connection);
                    ps.setQueryTimeout(QUERY_TIMEOUT_SECONDS);
                    ps.setFetchSize(FETCH_SIZE);
                    List<Map<String, Object>> rows = new ArrayList<>();
                    try (java.sql.ResultSet rs = ps.executeQuery()) {
                        while (rs.next()) {
                            rows.add(toRowMap(rs));
                        }
                    } finally {
                        restoreNetworkTimeout(connection, previousNetworkTimeout);
                    }
                    return rows;
                });
    }

    private void applyNetworkTimeout(Connection connection) {
        try {
            connection.setNetworkTimeout(NETWORK_TIMEOUT_EXECUTOR, NETWORK_TIMEOUT_MILLIS);
        } catch (SQLException ignored) {
        }
    }

    private Integer readNetworkTimeout(Connection connection) {
        try {
            return connection.getNetworkTimeout();
        } catch (SQLException ignored) {
            return null;
        }
    }

    private void restoreNetworkTimeout(Connection connection, Integer previousTimeoutMillis) {
        if (previousTimeoutMillis == null) {
            return;
        }
        try {
            connection.setNetworkTimeout(NETWORK_TIMEOUT_EXECUTOR, previousTimeoutMillis);
        } catch (SQLException ignored) {
        }
    }

    private Map<String, Object> toRowMap(java.sql.ResultSet rs) throws SQLException {
        ResultSetMetaData metaData = rs.getMetaData();
        Map<String, Object> row = new LinkedHashMap<>();
        for (int i = 1; i <= metaData.getColumnCount(); i++) {
            row.put(metaData.getColumnLabel(i), rs.getObject(i));
        }
        return row;
    }
}

