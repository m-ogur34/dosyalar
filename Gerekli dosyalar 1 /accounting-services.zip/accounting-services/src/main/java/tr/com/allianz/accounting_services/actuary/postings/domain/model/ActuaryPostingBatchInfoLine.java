package tr.com.allianz.accounting_services.actuary.postings.domain.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Getter
@AllArgsConstructor
@NoArgsConstructor
public class ActuaryPostingBatchInfoLine {
    private String accountNo;
    private String accountExp;
    private String explanation;
    private BigDecimal borc;
    private BigDecimal alacak;

}

