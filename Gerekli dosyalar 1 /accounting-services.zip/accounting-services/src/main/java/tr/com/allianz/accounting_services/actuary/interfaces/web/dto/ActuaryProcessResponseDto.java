package tr.com.allianz.accounting_services.actuary.interfaces.web.dto;
import java.time.LocalDate;
public record ActuaryProcessResponseDto(
        String processId,
        String processName,
        String explanation,
        LocalDate validityStartDate,
        LocalDate validityEndDate
) {
}
