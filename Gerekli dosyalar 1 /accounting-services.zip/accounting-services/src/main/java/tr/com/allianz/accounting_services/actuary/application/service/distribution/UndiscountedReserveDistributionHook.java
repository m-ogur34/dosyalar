package tr.com.allianz.accounting_services.actuary.application.service.distribution;

import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import tr.com.allianz.accounting_services.actuary.application.port.out.CleanupUndiscountedReserveReportsPort;
import tr.com.allianz.accounting_services.actuary.application.port.out.SaveActuaryPeriodStatusPort;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.ActuaryPeriodStatus;

import java.time.YearMonth;

@Component
@Order(100)
public class UndiscountedReserveDistributionHook implements DistributionProcessHook {

    private final CleanupUndiscountedReserveReportsPort cleanupUndiscountedReserveReportsPort;
    private final SaveActuaryPeriodStatusPort saveActuaryPeriodStatusPort;

    public UndiscountedReserveDistributionHook(
            CleanupUndiscountedReserveReportsPort cleanupUndiscountedReserveReportsPort,
            SaveActuaryPeriodStatusPort saveActuaryPeriodStatusPort
    ) {
        this.cleanupUndiscountedReserveReportsPort = cleanupUndiscountedReserveReportsPort;
        this.saveActuaryPeriodStatusPort = saveActuaryPeriodStatusPort;
    }

    @Override
    public boolean supports(String processId) {
        return "UNDISCRES".equals(processId);
    }

    @Override
    public void beforeExecute(DistributionProcessContext context) {
        cleanupUndiscountedReserveReportsPort.cleanup(
                YearMonth.of(context.year(), context.month()).atEndOfMonth()
        );
    }

    @Override
    public void afterExecute(DistributionProcessContext context) {
        saveActuaryPeriodStatusPort.upsertStatus(
                context.processId(),
                context.year(),
                context.month(),
                ActuaryPeriodStatus.APPROVED
        );
    }
}
