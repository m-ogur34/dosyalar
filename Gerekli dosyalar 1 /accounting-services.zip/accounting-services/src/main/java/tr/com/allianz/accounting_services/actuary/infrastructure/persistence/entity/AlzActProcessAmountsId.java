package tr.com.allianz.accounting_services.actuary.infrastructure.persistence.entity;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
public class AlzActProcessAmountsId implements Serializable {

    private Integer year;
    private Integer month;
    private String processId;
    private Integer ruleId;
}

