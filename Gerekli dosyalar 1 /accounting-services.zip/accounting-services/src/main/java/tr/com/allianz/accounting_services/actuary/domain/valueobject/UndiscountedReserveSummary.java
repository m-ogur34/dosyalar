package tr.com.allianz.accounting_services.actuary.domain.valueobject;

import java.math.BigDecimal;

public record UndiscountedReserveSummary(
        BigDecimal currentYearGrossAmount,
        BigDecimal priorYearGrossAmount,
        BigDecimal currentYearNetAmount,
        BigDecimal priorYearNetAmount
) {
}
