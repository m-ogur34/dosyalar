package tr.com.allianz.accounting_services.actuary.infrastructure.persistence.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.ActuaryPeriodStatus;

@Entity
@Table(name = "ALZ_ACT_PERIODS")
@IdClass(AlzActPeriodsId.class)
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class AlzActPeriods {

    @Id
    @Column(name = "PROCESS_ID", length = 10)
    private String processId;

    @Id
    @Column(name = "YEAR", precision = 4)
    private Integer year;

    @Id
    @Column(name = "MONTH", precision = 2)
    private Integer month;

    @Column(name = "STATUS", length = 200)
    private String status;

    public ActuaryPeriodStatus getStatusEnum() {
        return ActuaryPeriodStatus.fromValue(this.status);
    }

    public void setStatusEnum(ActuaryPeriodStatus status) {
        this.status = status.getValue();
    }
}

