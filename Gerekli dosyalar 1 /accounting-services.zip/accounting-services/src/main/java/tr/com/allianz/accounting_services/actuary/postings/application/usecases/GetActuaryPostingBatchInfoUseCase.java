package tr.com.allianz.accounting_services.actuary.postings.application.usecases;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import tr.com.allianz.accounting_services.actuary.postings.application.port.out.LoadActuaryPostingBatchInfoPort;
import tr.com.allianz.accounting_services.actuary.postings.domain.model.ActuaryPostingBatchInfoLine;

import java.util.List;

@Service
@RequiredArgsConstructor
public class GetActuaryPostingBatchInfoUseCase {

    private final LoadActuaryPostingBatchInfoPort loadActuaryPostingBatchInfoPort;

    public List<ActuaryPostingBatchInfoLine> handle(GetActuaryPostingBatchInfoCommand command) {
        return loadActuaryPostingBatchInfoPort.loadBatchInfo(command);
    }
}

