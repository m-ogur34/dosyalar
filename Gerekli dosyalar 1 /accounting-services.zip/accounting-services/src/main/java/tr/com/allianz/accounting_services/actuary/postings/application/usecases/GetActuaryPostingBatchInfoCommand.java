package tr.com.allianz.accounting_services.actuary.postings.application.usecases;

import java.time.LocalDate;

public record GetActuaryPostingBatchInfoCommand(
        Long batchType,
        LocalDate postingDate,
        String branchExtRef,
        Long productId,
        String partitionType,
        Integer isIndustrial
) {
}

