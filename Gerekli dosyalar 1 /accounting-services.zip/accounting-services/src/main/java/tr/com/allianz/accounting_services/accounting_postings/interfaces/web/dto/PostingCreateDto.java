package tr.com.allianz.accounting_services.accounting_postings.interfaces.web.dto;

import java.io.Serial;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

@RequiredArgsConstructor
@Getter
@Setter
public class PostingCreateDto implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    private String accountCategoryCode;
    private String eventTypeCode;
    private String postingType;
    private Long eventOrderNo;
    private String subfactor1Val;
    private String subfactor2Val;
    private String subfactor3Val;
    private String subfactor4Val;
    private BigDecimal postingAmount;
    private LocalDate postingDate;
    private String swiftCode;
    private BigDecimal currencyExchangeRate;
    private String explanation;  
    private String invoiceNo;
    private LocalDate invoiceDate;
    private String externalBankReferenceNo;
    private String internalBankReferenceNo;
    private Long relatedOrder;
    private Long agentIntId;
    private Long productId;
    private String partitionType;
    private String branchExtRef;
    private String accCoverGroup;
    private Long isIndustrial;
    private String sapLob;
    private String sapDistChannel;
    private Long claimId;
    private Long tradingCode;
    private String userName;
    private String sourceKey;
    private String costCenterCode;
    private String subItem;
    private String tradingPartnerCode;
    private String opusMasterCode;
    private String documentType;
    private String documentTypeExp;
    private Integer hasProgramPol;
}

