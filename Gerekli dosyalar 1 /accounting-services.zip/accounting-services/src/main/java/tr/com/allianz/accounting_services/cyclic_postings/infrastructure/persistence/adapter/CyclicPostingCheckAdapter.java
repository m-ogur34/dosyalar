package tr.com.allianz.accounting_services.cyclic_postings.infrastructure.persistence.adapter;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import tr.com.allianz.accounting_services.cyclic_postings.application.port.out.CyclicPostingCheckPort;
import tr.com.allianz.accounting_services.cyclic_postings.infrastructure.persistence.repository.AlzCyclicAccountMappingRepository;

@Component
@RequiredArgsConstructor
public class CyclicPostingCheckAdapter implements CyclicPostingCheckPort {

    private final AlzCyclicAccountMappingRepository mappingRepository;

    @Override
    public int findBatchCount(Long batchId) {
        return mappingRepository.findPostingCountByBatchId(batchId);
    }

    @Override
    public String findNotMappedCyclicAccountNo(Long batchId) {
        return mappingRepository.findNotMappedAccountsByBatchId(batchId);
    }
}