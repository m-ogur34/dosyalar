package tr.com.allianz.accounting_services.actuary.application.service.distribution;

import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import tr.com.allianz.accounting_services.actuary.application.port.out.SaveActuaryPeriodStatusPort;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.ActuaryPeriodStatus;

@Component
@Order(100)
public class UlaeDistributionHook implements DistributionProcessHook {

    private final SaveActuaryPeriodStatusPort saveActuaryPeriodStatusPort;

    public UlaeDistributionHook(
            SaveActuaryPeriodStatusPort saveActuaryPeriodStatusPort
    ) {
        this.saveActuaryPeriodStatusPort = saveActuaryPeriodStatusPort;
    }

    @Override
    public boolean supports(String processId) {
        return "ULAE".equals(processId);
    }


    @Override
    public void afterExecute(DistributionProcessContext context) {
        saveActuaryPeriodStatusPort.upsertStatus(
                context.processId(),
                context.year(),
                context.month(),
                ActuaryPeriodStatus.TO_BE_REPORTED
        );
    }

}
