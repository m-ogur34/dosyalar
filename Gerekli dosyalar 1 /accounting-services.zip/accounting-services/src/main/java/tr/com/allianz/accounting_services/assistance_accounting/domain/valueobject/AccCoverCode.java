package tr.com.allianz.accounting_services.assistance_accounting.domain.valueobject;

public record AccCoverCode(
    String accCoverCode,
    String explanation
) {}

