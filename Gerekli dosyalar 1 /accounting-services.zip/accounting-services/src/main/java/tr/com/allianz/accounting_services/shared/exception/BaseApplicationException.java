package tr.com.allianz.accounting_services.shared.exception;

import lombok.Getter;
import org.springframework.http.HttpStatus;

@Getter
public abstract class BaseApplicationException extends RuntimeException{
    private final String errorCode;
    private final String detail;
    private final HttpStatus httpStatus;

    protected BaseApplicationException(String errorCode, String message, String detail, HttpStatus httpStatus) {
        super(message);
        this.errorCode = errorCode;
        this.detail = detail;
        this.httpStatus = httpStatus;
    }
}
