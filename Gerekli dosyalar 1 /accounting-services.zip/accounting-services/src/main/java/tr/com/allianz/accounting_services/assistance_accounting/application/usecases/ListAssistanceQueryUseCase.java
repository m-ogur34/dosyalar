package tr.com.allianz.accounting_services.assistance_accounting.application.usecases;

import tr.com.allianz.accounting_services.assistance_accounting.application.port.out.LoadAssistanceQueryPort;
import tr.com.allianz.accounting_services.assistance_accounting.domain.valueobject.AssistanceQueryCriteria;
import tr.com.allianz.accounting_services.assistance_accounting.domain.valueobject.AssistanceQueryResult;

import java.util.List;

public class ListAssistanceQueryUseCase {

    private final LoadAssistanceQueryPort loadAssistanceQueryPort;

    public ListAssistanceQueryUseCase(LoadAssistanceQueryPort loadAssistanceQueryPort) {
        this.loadAssistanceQueryPort = loadAssistanceQueryPort;
    }

    public List<AssistanceQueryResult> handle(AssistanceQueryCriteria criteria) {
        return loadAssistanceQueryPort.loadAssistanceQueryResults(criteria);
    }
}
