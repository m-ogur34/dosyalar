package tr.com.allianz.accounting_services.actuary.infrastructure.persistence.adapter;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import tr.com.allianz.accounting_services.actuary.application.port.out.LoadActuaryQueryPort;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.ActuaryProcessRuleAmount;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.ActuaryQueryCriteria;
import tr.com.allianz.accounting_services.actuary.infrastructure.persistence.repository.AlzActProcessAmountsRepository;

import java.math.BigDecimal;
import java.util.List;

@Component
@Slf4j
@RequiredArgsConstructor
public class ActuaryQueryAdapter implements LoadActuaryQueryPort {

    private final AlzActProcessAmountsRepository repository;

    @Override
    public List<ActuaryProcessRuleAmount> loadActuaryQueryResults(ActuaryQueryCriteria criteria) {

        List<Object[]> results = repository.queryActuaryProcessRuleAmounts(
                criteria.processId(),
                criteria.year(),
                criteria.month()
        );

        return results.stream()
                .map(this::mapToActuaryProcessRuleAmount)
                .toList();
    }

    private ActuaryProcessRuleAmount mapToActuaryProcessRuleAmount(Object[] row) {
        return new ActuaryProcessRuleAmount(
                (String) row[0],      // ruleName
                (Integer) row[1],     // year
                (Integer) row[2],     // month
                row[3] == null ? null : String.valueOf(row[3]), // processId
                toInteger(row[4]),    // ruleId
                (BigDecimal) row[5],  // grossCyAmount
                (BigDecimal) row[6],  // reCyAmount
                (BigDecimal) row[7],  // netCyAmount
                (BigDecimal) row[8],  // grossPyAmount
                (BigDecimal) row[9],  // rePyAmount
                (BigDecimal) row[10], // netPyAmount
                (BigDecimal) row[11], // ifrsCyGross
                (BigDecimal) row[12], // ifrsCyRe
                (BigDecimal) row[13], // ifrsCyNet
                (BigDecimal) row[14], // ifrsPyGross
                (BigDecimal) row[15], // ifrsPyRe
                (BigDecimal) row[16], // ifrsPyNet
                (BigDecimal) row[17], // grossCyAmountRate
                (BigDecimal) row[18], // reCyAmountRate
                (BigDecimal) row[19], // netCyAmountRate
                (BigDecimal) row[20], // grossPyAmountRate
                (BigDecimal) row[21], // rePyAmountRate
                (BigDecimal) row[22], // netPyAmountRate
                (BigDecimal) row[23], // ifrsCyGrossRate
                (BigDecimal) row[24], // ifrsCyReRate
                (BigDecimal) row[25], // ifrsCyNetRate
                (BigDecimal) row[26], // ifrsPyGrossRate
                (BigDecimal) row[27], // ifrsPyReRate
                (BigDecimal) row[28]  // ifrsPyNetRate
        );
    }

    private Integer toInteger(Object value) {
        if (value == null) {
            return null;
        }
        return ((Number) value).intValue();
    }
}

