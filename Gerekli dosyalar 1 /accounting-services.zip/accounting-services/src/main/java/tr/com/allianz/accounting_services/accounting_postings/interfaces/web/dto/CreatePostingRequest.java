package tr.com.allianz.accounting_services.accounting_postings.interfaces.web.dto;

import java.io.Serializable;
import java.util.List;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

@RequiredArgsConstructor
@Getter
@Setter
public class CreatePostingRequest implements Serializable {
	
	private List<PostingCreateDto> postings;

	private String businessCompCode;

	private String drivMovementId;

	private String objectId;

	private String companyRef;
}

