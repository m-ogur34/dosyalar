package tr.com.allianz.accounting_services.actuary.postings.infrastructure.persistence.adapter;

import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;
import tr.com.allianz.accounting_services.actuary.postings.application.port.out.LoadActuaryPostingBranchesPort;
import tr.com.allianz.accounting_services.actuary.postings.domain.model.ActuaryPostingBranch;

import java.util.List;

@Component
@RequiredArgsConstructor
public class ActuaryPostingBranchPersistenceAdapter implements LoadActuaryPostingBranchesPort {

    private static final String QUERY = """
            select branch_id, branch_name, ext_reference
              from koc_oc_branches
            """;

    private final NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @Override
    public List<ActuaryPostingBranch> loadAll() {
        return namedParameterJdbcTemplate.queryForList(QUERY, new MapSqlParameterSource())
                .stream()
                .map(row -> new ActuaryPostingBranch(
                        stringValue(row.get("branch_id")),
                        stringValue(row.get("branch_name")),
                        stringValue(row.get("ext_reference"))
                ))
                .toList();
    }

    private String stringValue(Object value) {
        return value == null ? "" : value.toString().trim();
    }
}

