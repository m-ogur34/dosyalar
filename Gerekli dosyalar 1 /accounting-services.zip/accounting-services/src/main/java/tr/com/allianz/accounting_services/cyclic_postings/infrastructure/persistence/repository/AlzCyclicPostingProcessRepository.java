package tr.com.allianz.accounting_services.cyclic_postings.infrastructure.persistence.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;
import tr.com.allianz.accounting_services.cyclic_postings.infrastructure.persistence.entity.AlzCyclicPostingProcess;

public interface AlzCyclicPostingProcessRepository extends JpaRepository<AlzCyclicPostingProcess, Long> {

    @Procedure(name = "AlzCyclicPostingProcess.callCyclicPostingProcedure")
    void callCyclicPostingProcedure(@Param("P_BATCH_ID") Long batchId);

}