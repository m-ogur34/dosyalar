package tr.com.allianz.accounting_services.actuary.application.usecases;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import tr.com.allianz.accounting_services.actuary.application.port.out.LoadActuaryQueryPort;
import tr.com.allianz.accounting_services.actuary.application.port.out.SaveActuaryPeriodStatusPort;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.ActuaryProcessRuleAmount;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.ActuaryQueryCriteria;
import tr.com.allianz.accounting_services.actuary.infrastructure.persistence.entity.AlzActPeriods;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ListActuaryQueryUseCase {

    private final LoadActuaryQueryPort loadActuaryQueryPort;
    private final SaveActuaryPeriodStatusPort saveActuaryPeriodStatusPort;

    public ListActuaryQueryResponse handle(ActuaryQueryCriteria criteria) {
        List<ActuaryProcessRuleAmount> results = loadActuaryQueryPort.loadActuaryQueryResults(criteria);
        AlzActPeriods period = saveActuaryPeriodStatusPort.getOrCreateInProgress(
                criteria.processId(),
                criteria.year(),
                criteria.month()
        );
        return new ListActuaryQueryResponse(results, period);
    }
}

