package tr.com.allianz.accounting_services.cyclic_postings.interfaces.web;


import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import tr.com.allianz.accounting_services.cyclic_postings.application.usecases.CreateCyclicMappingUseCase;
import tr.com.allianz.accounting_services.cyclic_postings.application.usecases.ListAlzCyclicAccountMappingUseCase;
import tr.com.allianz.accounting_services.cyclic_postings.application.usecases.RemoveAlzCyclicAccountMappingUseCase;
import tr.com.allianz.accounting_services.cyclic_postings.infrastructure.persistence.entity.AlzCyclicAccountMapping;
import tr.com.allianz.accounting_services.shared.api.ApiResponse;
import tr.com.allianz.accounting_services.cyclic_postings.interfaces.web.dto.*;

@RestController
@RequestMapping("/api/v1/cyclic-account-mapping")
@CrossOrigin
public class AlzCyclicAccountMappingController {

    private final CreateCyclicMappingUseCase createCyclicMappingUseCase;
    private final ListAlzCyclicAccountMappingUseCase listAlzCyclicAccountMappingUseCase;
    private final RemoveAlzCyclicAccountMappingUseCase removeAlzCyclicAccountMappingUseCase;

    public AlzCyclicAccountMappingController(CreateCyclicMappingUseCase createCyclicMappingUseCase, ListAlzCyclicAccountMappingUseCase listAlzCyclicAccountMappingUseCase, RemoveAlzCyclicAccountMappingUseCase removeAlzCyclicAccountMappingUseCase) {
        this.createCyclicMappingUseCase = createCyclicMappingUseCase;
        this.listAlzCyclicAccountMappingUseCase = listAlzCyclicAccountMappingUseCase;
        this.removeAlzCyclicAccountMappingUseCase = removeAlzCyclicAccountMappingUseCase;
    }

    @PostMapping("/create")
    public ResponseEntity<ApiResponse<CreateAlzCyclicAccountMappingResponse>> createCyclicAccountMapping(@Valid @RequestBody CreateAlzCyclicAccountMappingRequest request) {

        AlzCyclicAccountMapping alzCyclicAccountMapping = createCyclicMappingUseCase.handle(request);
        CreateAlzCyclicAccountMappingResponse result = new CreateAlzCyclicAccountMappingResponse(alzCyclicAccountMapping.getAccountNo(), alzCyclicAccountMapping.getCyclicAccountNo());
        ApiResponse<CreateAlzCyclicAccountMappingResponse> response = ApiResponse.ok("CYCLIC_ACCOUNTS_MAPPING_CREATED","Cyclic accounts mapping created successfully",
                result);
        return  ResponseEntity.ok(response);
    }

    @GetMapping("/list")
    public ResponseEntity<ApiResponse<AlzCyclicAccountMappingListResponse>> listCyclicAccountMapping() {

        ApiResponse<AlzCyclicAccountMappingListResponse> response = ApiResponse.ok("CYCLIC_ACCOUNTS_MAPPING_LIST",
                "Cyclic accounts list",
                new AlzCyclicAccountMappingListResponse(listAlzCyclicAccountMappingUseCase.handle()) );
        return  ResponseEntity.ok(response);
    }

    @PostMapping("/remove")
    public ResponseEntity<ApiResponse<RemoveAlzCyclicAccountMappingResponse>> removeCyclicAccountMapping(@Valid @RequestBody RemoveAlzCyclicAccountMappingRequest request) {
        removeAlzCyclicAccountMappingUseCase.handle(request);
        ApiResponse<RemoveAlzCyclicAccountMappingResponse> response = ApiResponse.ok("CYCLIC_ACCOUNTS_MAPPING_DELETED",
                "Cyclic account removed",
                new RemoveAlzCyclicAccountMappingResponse(request.accountNo()) );
        return  ResponseEntity.ok(response);
    }

}
