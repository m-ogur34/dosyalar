package tr.com.allianz.accounting_services.cyclic_postings.application.usecases;

import tr.com.allianz.accounting_services.cyclic_postings.application.exception.CyclicAccountMappingAlreadyExistsException;
import tr.com.allianz.accounting_services.cyclic_postings.application.port.out.CyclicPostingMappingPort;
import tr.com.allianz.accounting_services.cyclic_postings.infrastructure.persistence.entity.AlzCyclicAccountMapping;
import tr.com.allianz.accounting_services.cyclic_postings.interfaces.web.dto.CreateAlzCyclicAccountMappingRequest;

import java.util.Optional;

public class CreateCyclicMappingUseCase {

    private final CyclicPostingMappingPort cyclicPostingMappingPort;

    public CreateCyclicMappingUseCase(CyclicPostingMappingPort cyclicPostingMappingPort) {
        this.cyclicPostingMappingPort = cyclicPostingMappingPort;
    }

    public AlzCyclicAccountMapping handle(CreateAlzCyclicAccountMappingRequest request) {
        Optional<AlzCyclicAccountMapping> existingMapping = cyclicPostingMappingPort.findByAccountNo(request.accountNo());
        if(existingMapping.isPresent())
            throw new CyclicAccountMappingAlreadyExistsException(request.accountNo());

        return cyclicPostingMappingPort.createCyclicPostingMapping(request.toCommand());
    }


}
