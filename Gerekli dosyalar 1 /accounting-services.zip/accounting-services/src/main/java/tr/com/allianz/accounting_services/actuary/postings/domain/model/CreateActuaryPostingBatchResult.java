package tr.com.allianz.accounting_services.actuary.postings.domain.model;

public record CreateActuaryPostingBatchResult(
        Long batchId,
        boolean batchAlreadyExists
) {
    public static CreateActuaryPostingBatchResult existing(Long batchId) {
        return new CreateActuaryPostingBatchResult(batchId, true);
    }

    public static CreateActuaryPostingBatchResult created(Long batchId) {
        return new CreateActuaryPostingBatchResult(batchId, false);
    }
}
