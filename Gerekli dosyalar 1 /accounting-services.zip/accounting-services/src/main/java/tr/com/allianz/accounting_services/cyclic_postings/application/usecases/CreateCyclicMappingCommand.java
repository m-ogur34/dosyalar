package tr.com.allianz.accounting_services.cyclic_postings.application.usecases;

public record CreateCyclicMappingCommand (String accountNo,String cyclicAccountNo){
}
