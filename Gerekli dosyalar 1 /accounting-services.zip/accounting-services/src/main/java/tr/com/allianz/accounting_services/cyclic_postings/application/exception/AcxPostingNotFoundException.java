package tr.com.allianz.accounting_services.cyclic_postings.application.exception;


import tr.com.allianz.accounting_services.shared.exception.BaseApplicationException;
import lombok.Getter;
import org.springframework.http.HttpStatus;

@Getter
public class    AcxPostingNotFoundException extends BaseApplicationException{

    private final Long batchId;

    public AcxPostingNotFoundException(Long batchId) {
        super("POSTING_NOT_FOUND",
                "Fiş sistemde bulunamadı",
                "Fiş nosu " + batchId +
                        " olan fiş sistemde bulunamadı.",
                HttpStatus.NOT_FOUND);
        this.batchId = batchId;
    }
}
