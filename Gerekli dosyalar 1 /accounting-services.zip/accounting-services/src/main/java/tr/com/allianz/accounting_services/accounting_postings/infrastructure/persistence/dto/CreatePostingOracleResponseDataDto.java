package tr.com.allianz.accounting_services.accounting_postings.infrastructure.persistence.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CreatePostingOracleResponseDataDto {
    private Long batchId;
}

