package tr.com.allianz.accounting_services.actuary.application.service.distribution;

import tr.com.allianz.accounting_services.actuary.domain.valueobject.ActuaryProcessRuleAmount;

import java.math.BigDecimal;
import java.util.List;
import java.util.Objects;
import java.util.function.Function;

record DistributionAmountTotals(
        BigDecimal grossCyAmount,
        BigDecimal reCyAmount,
        BigDecimal netCyAmount,
        BigDecimal grossPyAmount,
        BigDecimal rePyAmount,
        BigDecimal netPyAmount,
        BigDecimal ifrsCyGross,
        BigDecimal ifrsCyRe,
        BigDecimal ifrsCyNet,
        BigDecimal ifrsPyGross,
        BigDecimal ifrsPyRe,
        BigDecimal ifrsPyNet
) {

    static DistributionAmountTotals from(List<ActuaryProcessRuleAmount> rows) {
        return new DistributionAmountTotals(
                sum(rows, ActuaryProcessRuleAmount::grossCyAmount),
                sum(rows, ActuaryProcessRuleAmount::reCyAmount),
                sum(rows, ActuaryProcessRuleAmount::netCyAmount),
                sum(rows, ActuaryProcessRuleAmount::grossPyAmount),
                sum(rows, ActuaryProcessRuleAmount::rePyAmount),
                sum(rows, ActuaryProcessRuleAmount::netPyAmount),
                sum(rows, ActuaryProcessRuleAmount::ifrsCyGross),
                sum(rows, ActuaryProcessRuleAmount::ifrsCyRe),
                sum(rows, ActuaryProcessRuleAmount::ifrsCyNet),
                sum(rows, ActuaryProcessRuleAmount::ifrsPyGross),
                sum(rows, ActuaryProcessRuleAmount::ifrsPyRe),
                sum(rows, ActuaryProcessRuleAmount::ifrsPyNet)
        );
    }

    private static BigDecimal sum(List<ActuaryProcessRuleAmount> rows,
                                  Function<ActuaryProcessRuleAmount, BigDecimal> extractor) {
        return rows.stream()
                .map(extractor)
                .filter(Objects::nonNull)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }
}

