package tr.com.allianz.accounting_services.assistance_accounting.application.usecases;

import lombok.RequiredArgsConstructor;
import tr.com.allianz.accounting_services.assistance_accounting.application.port.out.LoadAssistanceCompanyPort;
import tr.com.allianz.accounting_services.assistance_accounting.domain.valueobject.AssistanceCompany;

import java.util.List;

@RequiredArgsConstructor
public class ListAssistanceCompanyUseCase {

    private final LoadAssistanceCompanyPort loadAssistanceCompanyPort;

    public List<AssistanceCompany> handle() {
        return loadAssistanceCompanyPort.loadAssistanceCompanies();
    }
}

