package tr.com.allianz.accounting_services.accounting_postings.interfaces.web;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import tr.com.allianz.accounting_services.accounting_postings.application.usecases.CreatePostingUseCase;
import tr.com.allianz.accounting_services.accounting_postings.application.usecases.ReversePostingUseCase;
import tr.com.allianz.accounting_services.accounting_postings.interfaces.web.dto.CreatePostingRequest;
import tr.com.allianz.accounting_services.accounting_postings.interfaces.web.dto.CreatePostingResponse;
import tr.com.allianz.accounting_services.accounting_postings.interfaces.web.dto.ReversePostingRequest;
import tr.com.allianz.accounting_services.accounting_postings.interfaces.web.dto.ReversePostingResponse;
import tr.com.allianz.accounting_services.shared.api.ApiResponse;

import java.util.List;

@RestController
@RequestMapping("/api/v1/accounting-postings")
@CrossOrigin
@RequiredArgsConstructor
public class AccountingPostingController {

    private final CreatePostingUseCase createPostingUseCase;
    private final ReversePostingUseCase reversePostingUseCase;

    @PostMapping("/create")
    public ResponseEntity<ApiResponse<CreatePostingResponse>> createPosting(
            @Valid @RequestBody CreatePostingRequest request
    ) {
        CreatePostingResponse response = createPostingUseCase.handle(request);

        return ResponseEntity.ok(
                ApiResponse.ok(
                        "ACCOUNTING_POSTING_CREATED",
                        "Accounting posting created successfully",
                        response
                )
        );
    }

    @PostMapping("/reverse")
    public ResponseEntity<ApiResponse<List<ReversePostingResponse>>> reversePosting(
            @RequestBody List<ReversePostingRequest> request
    ) {
        List<ReversePostingResponse> response = reversePostingUseCase.handle(request);

        return ResponseEntity.ok(
                ApiResponse.ok(
                        "ACCOUNTING_POSTING_REVERSED",
                        "Accounting posting reversed successfully",
                        response
                )
        );
    }
}
