package tr.com.allianz.accounting_services.cyclic_postings.application.usecases;

public record AlzCyclicAccountMappingReadModel(String accountNo, String cyclicAccountNo) {
}
