package tr.com.allianz.accounting_services.actuary.infrastructure.persistence.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import tr.com.allianz.accounting_services.actuary.infrastructure.persistence.entity.AlzActProcesses;
import java.time.LocalDate;
import java.util.List;
public interface AlzActProcessesRepository extends JpaRepository<AlzActProcesses, String> {
    @Query("""
            select p
            from AlzActProcesses p
            where (p.validityStartDate is null or p.validityStartDate <= :today)
              and (p.validityEndDate is null or p.validityEndDate >= :today)
            order by p.processId
            """)
    List<AlzActProcesses> findActiveProcesses(@Param("today") LocalDate today);
}
