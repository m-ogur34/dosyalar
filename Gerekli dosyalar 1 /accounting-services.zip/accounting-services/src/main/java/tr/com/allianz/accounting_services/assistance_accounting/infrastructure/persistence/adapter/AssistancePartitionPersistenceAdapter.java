package tr.com.allianz.accounting_services.assistance_accounting.infrastructure.persistence.adapter;

import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;
import tr.com.allianz.accounting_services.assistance_accounting.application.port.out.AssistancePartitionLoaderPort;
import tr.com.allianz.accounting_services.assistance_accounting.domain.valueobject.AssistancePartition;

import java.util.List;

@Component
@RequiredArgsConstructor
public class AssistancePartitionPersistenceAdapter implements AssistancePartitionLoaderPort {

    private final NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    private static final String QUERY = """
        SELECT distinct pv.partition_type, pv.LONG_NAME
          FROM (SELECT A.PARTITION_TYPE, B.LONG_NAME
        FROM KOC_OC_PARTITIONS A,
             CUR_TRANSLATIONS B
        WHERE A.DESC_INT_ID = B.DESC_INT_ID
        AND B.SULA_ORA_NLS_CODE = 'TR'
        AND (A.VALIDITY_END_DATE IS NULL OR
             A.VALIDITY_END_DATE = (SELECT MAX(VALIDITY_END_DATE)
                                 FROM KOC_OC_PARTITIONS AA
                 WHERE A.PARTITION_TYPE = AA.PARTITION_TYPE))) pv,
               koc_oc_prod_partition_rel ppr
         where ppr.product_id IN (:p_product_ids)
         and  ppr.partition_type = pv.partition_type
         and ppr.validity_end_date is null
    """;

    @Override
    public List<AssistancePartition> loadAssistancePartitions(List<Long> productIds) {
        MapSqlParameterSource params = new MapSqlParameterSource();
        params.addValue("p_product_ids", productIds);

        return namedParameterJdbcTemplate.query(QUERY, params, (rs, rowNum) -> new AssistancePartition(
                rs.getString("partition_type"),
                rs.getString("LONG_NAME")
        ));
    }
}

