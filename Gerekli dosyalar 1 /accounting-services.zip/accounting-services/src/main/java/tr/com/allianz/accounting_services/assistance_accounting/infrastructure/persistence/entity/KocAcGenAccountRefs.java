package tr.com.allianz.accounting_services.assistance_accounting.infrastructure.persistence.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "KOC_AC_GEN_ACCOUNT_REFS")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class KocAcGenAccountRefs {

    @Id
    @Column(name = "INT_ID")
    private Long intId;

    @Column(name = "EXT_REFERENCE")
    private String extReference;

    @Column(name = "ACCOUNT_CODE")
    private String accountCode;

    @Column(name = "NAME")
    private String  name;

    @Column(name = "IS_ASSISTANCE_COMPANY")
    private Integer isAssistanceCompany;

}

