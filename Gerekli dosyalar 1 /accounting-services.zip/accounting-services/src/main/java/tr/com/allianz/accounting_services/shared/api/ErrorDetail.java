package tr.com.allianz.accounting_services.shared.api;

public record ErrorDetail(String field, String message) {
}

