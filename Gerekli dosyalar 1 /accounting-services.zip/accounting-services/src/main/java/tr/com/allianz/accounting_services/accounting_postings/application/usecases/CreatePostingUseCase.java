package tr.com.allianz.accounting_services.accounting_postings.application.usecases;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import tr.com.allianz.accounting_services.accounting_postings.application.port.out.CreatePostingPort;
import tr.com.allianz.accounting_services.accounting_postings.interfaces.web.dto.CreatePostingRequest;
import tr.com.allianz.accounting_services.accounting_postings.interfaces.web.dto.CreatePostingResponse;

@Service
@RequiredArgsConstructor
public class CreatePostingUseCase {

    private final CreatePostingPort createPostingPort;

    public CreatePostingResponse handle(CreatePostingRequest request) {
        Long batchId = createPostingPort.createPosting(request);
        
        CreatePostingResponse response = new CreatePostingResponse();
        response.setBatchId(batchId);
        
        return response;
    }
}

