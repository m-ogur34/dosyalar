package tr.com.allianz.accounting_services.assistance_accounting.domain.valueobject;

public record AssistanceProduct(
    Long productId,
    String extReference,
    String longName
) {}

