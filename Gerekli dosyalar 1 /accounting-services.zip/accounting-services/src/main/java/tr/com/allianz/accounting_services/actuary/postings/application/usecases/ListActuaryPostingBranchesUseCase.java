package tr.com.allianz.accounting_services.actuary.postings.application.usecases;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import tr.com.allianz.accounting_services.actuary.postings.application.port.out.LoadActuaryPostingBranchesPort;
import tr.com.allianz.accounting_services.actuary.postings.domain.model.ActuaryPostingBranch;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ListActuaryPostingBranchesUseCase {

    private final LoadActuaryPostingBranchesPort loadActuaryPostingBranchesPort;

    public List<ActuaryPostingBranch> handle() {
        return loadActuaryPostingBranchesPort.loadAll();
    }
}

