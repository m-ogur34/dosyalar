package tr.com.allianz.accounting_services.actuary.application.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import tr.com.allianz.accounting_services.actuary.application.usecases.SaveActuaryLogUseCase;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.ActuaryLogType;

@Service
@RequiredArgsConstructor
public class ActuaryLogService {

    private final SaveActuaryLogUseCase saveActuaryLogUseCase;

    public void logQuery(String processId, Integer year, Integer month, String byUser) {
        saveActuaryLogUseCase.handle(
                year,
                month,
                processId,
                null,
                ActuaryLogType.QUERY,
                "Actuary query executed",
                byUser
        );
    }

    public void logApprove(String processId, Integer year, Integer month, String byUser) {
        saveActuaryLogUseCase.handle(
                year,
                month,
                processId,
                null,
                ActuaryLogType.APPROVE,
                "Actuary period approved",
                byUser
        );
    }

    public void logInProgress(String processId, Integer year, Integer month, String byUser) {
        saveActuaryLogUseCase.handle(
                year,
                month,
                processId,
                null,
                ActuaryLogType.IN_PROGRESS,
                "Actuary period set to In Progress",
                byUser
        );
    }

    public void logExcelUpload(String processId, Integer year, Integer month, Integer recordCount, String byUser) {
        saveActuaryLogUseCase.handle(
                year,
                month,
                processId,
                null,
                ActuaryLogType.EXCEL_UPLOAD,
                "Excel file uploaded with " + recordCount + " records",
                byUser
        );
    }

    public void logAmountUpdate(String processId, Integer year, Integer month, Integer ruleId, String changeDescription, String byUser) {
        saveActuaryLogUseCase.handle(
                year,
                month,
                processId,
                ruleId,
                ActuaryLogType.AMOUNT_UPDATE,
                changeDescription,
                byUser
        );
    }

    public void logError(String processId, Integer year, Integer month, String errorMessage, String byUser) {
        saveActuaryLogUseCase.handle(
                year,
                month,
                processId,
                null,
                ActuaryLogType.ERROR,
                errorMessage,
                byUser
        );
    }
}

