package tr.com.allianz.accounting_services.accounting_postings.application.usecases;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import tr.com.allianz.accounting_services.accounting_postings.application.port.out.ReversePostingPort;
import tr.com.allianz.accounting_services.accounting_postings.interfaces.web.dto.ReversePostingRequest;
import tr.com.allianz.accounting_services.accounting_postings.interfaces.web.dto.ReversePostingResponse;
import java.util.List;
@Service
@RequiredArgsConstructor
public class ReversePostingUseCase {
    private final ReversePostingPort reversePostingPort;
    public List<ReversePostingResponse> handle(List<ReversePostingRequest> requests) {
        return reversePostingPort.reversePosting(requests);
    }
}