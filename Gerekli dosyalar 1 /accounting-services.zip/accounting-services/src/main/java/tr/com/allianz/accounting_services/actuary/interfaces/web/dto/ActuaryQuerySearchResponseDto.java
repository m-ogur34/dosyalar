package tr.com.allianz.accounting_services.actuary.interfaces.web.dto;

import tr.com.allianz.accounting_services.actuary.infrastructure.persistence.entity.AlzActPeriods;

import java.util.List;

public record ActuaryQuerySearchResponseDto(
        List<ActuaryQueryResultDto> results,
        AlzActPeriods period
) {
}

