package tr.com.allianz.accounting_services.assistance_accounting.infrastructure.persistence.adapter;

import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;
import tr.com.allianz.accounting_services.assistance_accounting.application.port.out.LoadAssistanceQueryPort;
import tr.com.allianz.accounting_services.assistance_accounting.domain.valueobject.AssistanceQueryCriteria;
import tr.com.allianz.accounting_services.assistance_accounting.domain.valueobject.AssistanceQueryResult;

import java.sql.Types;
import java.util.List;

@Component
@RequiredArgsConstructor
public class AssistanceQueryPersistenceAdapter implements LoadAssistanceQueryPort {

    private final NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    private static final String QUERY = """
                select account_no,
                       account_exp,
                       null sap_lob,
                       null sap_dist_channel_exp,
                       is_industrial,
                       sum(case when posting_amount < 0 then abs(posting_Amount) end) tutar_borc,
                       sum(case when posting_amount > 0 then abs(posting_Amount) end) tutar_alacak
                 from table(ALZ_ACC_POSTING_UTILS.pipe_assistance_acc(:company_id,:p_year,:p_month,
                :p_acc_cover_code,:p_is_industrial,:p_product_id,:p_partition_type,:p_amount))
                group by account_no,account_exp,is_industrial
                order by case when to_char(account_no) like '3%' then 1 else 2 end, account_no
    """;

    @Override
    public List<AssistanceQueryResult> loadAssistanceQueryResults(AssistanceQueryCriteria criteria) {
        MapSqlParameterSource params = new MapSqlParameterSource();
        params.addValue("company_id", criteria.companyId(), Types.NUMERIC);
        params.addValue("p_amount", criteria.totalAmountParam(), Types.DECIMAL);
        params.addValue("p_acc_cover_code", criteria.accCoverCode(), Types.VARCHAR);
        params.addValue("p_year", criteria.year(), Types.NUMERIC);
        params.addValue("p_month", criteria.month(), Types.NUMERIC);
        params.addValue("p_is_industrial", criteria.isIndustrial(), Types.NUMERIC);
        params.addValue("p_product_id", criteria.productId(), Types.VARCHAR);
        params.addValue("p_partition_type", criteria.partitionType(), Types.VARCHAR);

        return namedParameterJdbcTemplate.query(QUERY, params, (rs, rowNum) -> new AssistanceQueryResult(
                rs.getLong("account_no"),
                rs.getString("account_exp"),
                rs.getString("sap_lob"),
                rs.getString("sap_dist_channel_exp"),
                rs.getInt("is_industrial"),
                rs.getBigDecimal("tutar_borc"),
                rs.getBigDecimal("tutar_alacak")
        ));
    }
}
