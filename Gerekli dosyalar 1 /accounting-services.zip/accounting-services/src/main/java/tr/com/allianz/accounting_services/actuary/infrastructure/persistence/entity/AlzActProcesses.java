package tr.com.allianz.accounting_services.actuary.infrastructure.persistence.entity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.time.LocalDate;
@Entity
@Table(name = "ALZ_ACT_PROCESSES")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class AlzActProcesses {
    @Id
    @Column(name = "PROCESS_ID", length = 10)
    private String processId;
    @Column(name = "PROCESS_NAME", length = 50)
    private String processName;
    @Column(name = "EXPLANATION", length = 100)
    private String explanation;
    @Column(name = "VALIDITY_START_DATE")
    private LocalDate validityStartDate;
    @Column(name = "VALIDITY_END_DATE")
    private LocalDate validityEndDate;
}
