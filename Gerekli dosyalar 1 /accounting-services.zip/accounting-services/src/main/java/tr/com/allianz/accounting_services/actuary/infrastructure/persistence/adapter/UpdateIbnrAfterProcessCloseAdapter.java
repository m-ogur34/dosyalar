package tr.com.allianz.accounting_services.actuary.infrastructure.persistence.adapter;

import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;
import tr.com.allianz.accounting_services.actuary.application.port.out.UpdateIbnrAfterProcessClosePort;

import java.sql.Date;
import java.sql.Types;
import java.time.LocalDate;

@Component
@RequiredArgsConstructor
public class UpdateIbnrAfterProcessCloseAdapter implements UpdateIbnrAfterProcessClosePort {

    private static final String UPDATE = """
            update koc_process_close
               set i_status_code = 2
             where agent_int_id = 12354
               and process_type = 'IBNR'
               and branch_id = 1
               and close_date = :close_date
               and status_code = 2
               and i_status_code is null
            """;

    private final NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @Override
    public void update(LocalDate closeDate) {
        MapSqlParameterSource parameters = new MapSqlParameterSource()
                .addValue("close_date", Date.valueOf(closeDate), Types.DATE);

        namedParameterJdbcTemplate.update(UPDATE, parameters);
    }
}
