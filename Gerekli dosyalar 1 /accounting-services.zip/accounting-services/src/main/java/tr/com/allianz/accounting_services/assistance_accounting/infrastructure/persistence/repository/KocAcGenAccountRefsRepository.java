package tr.com.allianz.accounting_services.assistance_accounting.infrastructure.persistence.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import tr.com.allianz.accounting_services.assistance_accounting.infrastructure.persistence.entity.KocAcGenAccountRefs;

import java.util.List;

@Repository
public interface KocAcGenAccountRefsRepository extends JpaRepository<KocAcGenAccountRefs, Long> {

    List<KocAcGenAccountRefs> findByIsAssistanceCompany(Integer isAssistanceCompany);
}
