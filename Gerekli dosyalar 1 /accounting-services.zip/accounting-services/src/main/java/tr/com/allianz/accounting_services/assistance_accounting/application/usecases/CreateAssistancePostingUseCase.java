package tr.com.allianz.accounting_services.assistance_accounting.application.usecases;

import lombok.RequiredArgsConstructor;
import tr.com.allianz.accounting_services.assistance_accounting.application.port.out.CreateAssistancePostingPort;

@RequiredArgsConstructor
public class CreateAssistancePostingUseCase {

    private final CreateAssistancePostingPort createAssistancePostingPort;

    public Long handle(CreateAssistancePostingCommand command) {
        return createAssistancePostingPort.createAssistancePosting(command);
    }
}
