package tr.com.allianz.accounting_services.actuary.application.usecases;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import tr.com.allianz.accounting_services.actuary.application.port.out.LoadActuaryProcessesPort;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.ActuaryProcess;
import java.time.LocalDate;
import java.util.List;
@Service
@RequiredArgsConstructor
public class ListActuaryProcessesUseCase {
    private final LoadActuaryProcessesPort loadActuaryProcessesPort;
    public List<ActuaryProcess> handle() {
        return loadActuaryProcessesPort.loadActiveProcesses(LocalDate.now());
    }
}
