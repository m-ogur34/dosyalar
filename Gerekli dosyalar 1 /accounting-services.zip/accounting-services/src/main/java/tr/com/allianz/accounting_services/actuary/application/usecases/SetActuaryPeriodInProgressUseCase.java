package tr.com.allianz.accounting_services.actuary.application.usecases;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import tr.com.allianz.accounting_services.actuary.application.service.ActuaryLogService;
import tr.com.allianz.accounting_services.actuary.application.port.out.SaveActuaryPeriodStatusPort;
import tr.com.allianz.accounting_services.actuary.application.port.out.LoadActuaryPeriodStatusPort;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.ActuaryPeriodStatus;

import java.time.YearMonth;

@Service
@RequiredArgsConstructor
@Transactional
public class SetActuaryPeriodInProgressUseCase {

    private final SaveActuaryPeriodStatusPort saveActuaryPeriodStatusPort;
    private final LoadActuaryPeriodStatusPort loadActuaryPeriodStatusPort;
    private final ActuaryLogService actuaryLogService;

    public void handle(String processId, Integer year, Integer month, String byUser) {
        validatePeriodNotTooOld(year, month);
        validateCurrentStatus(processId, year, month);
        saveActuaryPeriodStatusPort.upsertStatus(processId, year, month, ActuaryPeriodStatus.IN_PROGRESS);
        actuaryLogService.logInProgress(processId, year, month, byUser);
    }

    private void validatePeriodNotTooOld(Integer year, Integer month) {
        YearMonth requested = YearMonth.of(year, month);
        YearMonth oneMonthAgo = YearMonth.now().minusMonths(1);
        if (requested.isBefore(oneMonthAgo)) {
            throw new IllegalArgumentException("Seçilen ay ve yıl için işlem yapılamaz. En fazla 1 ay öncesi için işlem yapılabilir.");
        }
    }

    private void validateCurrentStatus(String processId, Integer year, Integer month) {
        ActuaryPeriodStatus currentStatus = loadActuaryPeriodStatusPort.getStatus(processId, year, month);
        if (currentStatus != ActuaryPeriodStatus.APPROVED) {
            throw new IllegalArgumentException("In Progress yapılabilmesi için statü 'Approved' olmalıdır. Mevcut statü: " + 
                (currentStatus != null ? currentStatus.getValue() : "yok"));
        }
    }

    public void handle(String processId, Integer year, Integer month) {
        handle(processId, year, month, "SYSTEM");
    }
}

