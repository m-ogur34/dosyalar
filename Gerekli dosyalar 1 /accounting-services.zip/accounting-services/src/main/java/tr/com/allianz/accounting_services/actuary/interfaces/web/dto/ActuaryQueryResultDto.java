package tr.com.allianz.accounting_services.actuary.interfaces.web.dto;

import java.math.BigDecimal;

public record ActuaryQueryResultDto(
        String ruleName,
        Integer year,
        Integer month,
        String processId,
        Integer ruleId,
        BigDecimal grossCyAmount,
        BigDecimal reCyAmount,
        BigDecimal netCyAmount,
        BigDecimal grossPyAmount,
        BigDecimal rePyAmount,
        BigDecimal netPyAmount,
        BigDecimal ifrsCyGross,
        BigDecimal ifrsCyRe,
        BigDecimal ifrsCyNet,
        BigDecimal ifrsPyGross,
        BigDecimal ifrsPyRe,
        BigDecimal ifrsPyNet,
        BigDecimal grossCyAmountRate,
        BigDecimal reCyAmountRate,
        BigDecimal netCyAmountRate,
        BigDecimal grossPyAmountRate,
        BigDecimal rePyAmountRate,
        BigDecimal netPyAmountRate,
        BigDecimal ifrsCyGrossRate,
        BigDecimal ifrsCyReRate,
        BigDecimal ifrsCyNetRate,
        BigDecimal ifrsPyGrossRate,
        BigDecimal ifrsPyReRate,
        BigDecimal ifrsPyNetRate
) {
}

