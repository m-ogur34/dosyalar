package tr.com.allianz.accounting_services.cyclic_postings.application.usecases;

import tr.com.allianz.accounting_services.cyclic_postings.application.port.out.CyclicPostingMappingPort;
import tr.com.allianz.accounting_services.cyclic_postings.interfaces.web.dto.RemoveAlzCyclicAccountMappingRequest;

public class RemoveAlzCyclicAccountMappingUseCase {

    private final CyclicPostingMappingPort cyclicPostingMappingPort;

    public RemoveAlzCyclicAccountMappingUseCase(CyclicPostingMappingPort cyclicPostingMappingPort) {
        this.cyclicPostingMappingPort = cyclicPostingMappingPort;
    }


    public void handle(RemoveAlzCyclicAccountMappingRequest request) {
         cyclicPostingMappingPort.removeCyclicPostingMapping(request);
    }

}
