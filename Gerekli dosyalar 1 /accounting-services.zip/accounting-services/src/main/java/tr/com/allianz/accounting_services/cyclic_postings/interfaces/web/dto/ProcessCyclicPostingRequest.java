package tr.com.allianz.accounting_services.cyclic_postings.interfaces.web.dto;

import lombok.Data;
import java.util.List;

@Data
public class ProcessCyclicPostingRequest {
    private List<ProcessItem> items;

    @Data
    public static class ProcessItem {
        private Long batchId;
    }
}