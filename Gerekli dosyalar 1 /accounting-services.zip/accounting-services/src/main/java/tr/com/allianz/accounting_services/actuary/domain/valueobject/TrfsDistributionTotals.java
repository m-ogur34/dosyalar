package tr.com.allianz.accounting_services.actuary.domain.valueobject;

import java.math.BigDecimal;

public record TrfsDistributionTotals(
        BigDecimal grossAmountTotal,
        BigDecimal netAmountTotal
) {
}

