package tr.com.allianz.accounting_services.cyclic_postings.interfaces.web.dto;

import lombok.Data;
import tr.com.allianz.accounting_services.cyclic_postings.domain.valueobject.ProcessStatus;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Data
public class ProcessCyclicPostingResponse {

    private List<CreateCyclicPostingResponse.ProcessItem> processes;
    private int totalCount;

    @Data
    public static class ProcessItem {
        private Long batchId;
        private LocalDate postingDate;
        private Long cyclicBatchId;
        private String accountNo;
        private String cyclicAccountNo;
        private ProcessStatus status;
        private LocalDateTime createdDate;
    }
}
