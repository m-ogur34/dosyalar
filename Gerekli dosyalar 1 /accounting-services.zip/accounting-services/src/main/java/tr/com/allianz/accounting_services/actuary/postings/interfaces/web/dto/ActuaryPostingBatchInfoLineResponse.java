package tr.com.allianz.accounting_services.actuary.postings.interfaces.web.dto;

import java.math.BigDecimal;

public record ActuaryPostingBatchInfoLineResponse(
        String accountNo,
        String accountExp,
        String explanation,
        BigDecimal borc,
        BigDecimal alacak
) {
}

