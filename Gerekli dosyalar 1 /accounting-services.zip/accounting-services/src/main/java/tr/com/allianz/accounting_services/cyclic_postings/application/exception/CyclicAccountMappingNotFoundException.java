package tr.com.allianz.accounting_services.cyclic_postings.application.exception;


import tr.com.allianz.accounting_services.shared.exception.BaseApplicationException;
import lombok.Getter;
import org.springframework.http.HttpStatus;

@Getter
public class CyclicAccountMappingNotFoundException extends BaseApplicationException {

    private final String accountNo;

    public CyclicAccountMappingNotFoundException(String accountNo) {
        super("CYCLIC_ACCOUNT_MAPPING_NOT_FOUND",
                "Cyclic account mapping not found",
                "Account with no " + accountNo +
                        " mapping not exists.",
                HttpStatus.NOT_FOUND);
        this.accountNo = accountNo;
    }
}
