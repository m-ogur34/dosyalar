package tr.com.allianz.accounting_services.actuary.infrastructure.persistence.adapter;

import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;
import tr.com.allianz.accounting_services.actuary.application.port.out.LoadUndiscountedReserveSummaryPort;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.UndiscountedReserveSummary;

import java.math.BigDecimal;

@Component
@RequiredArgsConstructor
public class UndiscountedReserveSummaryAdapter implements LoadUndiscountedReserveSummaryPort {


    private static final String QUERY = """
            select case when code like '%CY' then 'CURRENT' else 'PRIOR' end as period_type,
                   sum(amount) as gross_amount,
                   sum(nvl(amount, 0) - nvl(reas_amount, 0)) as net_amount
              from alz_hp_data h
             where year = :year
               and month = :month
               and h.code in ('IFCY', 'OCY', 'ULCY', 'RCCY', 'IFPY', 'OPY', 'ULPY', 'RCPY')
             group by case when code like '%CY' then 'CURRENT' else 'PRIOR' end
            """;

    private final NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @Override
    public UndiscountedReserveSummary load(Integer year, Integer month) {
        SummaryValues current = new SummaryValues();
        SummaryValues prior = new SummaryValues();

        MapSqlParameterSource params = new MapSqlParameterSource()
                .addValue("year", year)
                .addValue("month", month);

        namedParameterJdbcTemplate.query(QUERY, params, rs -> {
            SummaryValues target = "CURRENT".equals(rs.getString("period_type")) ? current : prior;
            target.grossAmount = rs.getBigDecimal("gross_amount");
            target.netAmount = rs.getBigDecimal("net_amount");
        });

        return new UndiscountedReserveSummary(
                current.grossAmount,
                prior.grossAmount,
                current.netAmount,
                prior.netAmount
        );
    }

    private static class SummaryValues {
        private BigDecimal grossAmount;
        private BigDecimal netAmount;
    }
}

