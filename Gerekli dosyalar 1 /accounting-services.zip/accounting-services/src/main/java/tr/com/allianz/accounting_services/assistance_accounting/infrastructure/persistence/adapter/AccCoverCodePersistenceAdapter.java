package tr.com.allianz.accounting_services.assistance_accounting.infrastructure.persistence.adapter;

import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import tr.com.allianz.accounting_services.assistance_accounting.application.port.out.LoadAccCoverCodePort;
import tr.com.allianz.accounting_services.assistance_accounting.domain.valueobject.AccCoverCode;

import java.util.List;

@Component
@RequiredArgsConstructor
public class AccCoverCodePersistenceAdapter implements LoadAccCoverCodePort {

    private final JdbcTemplate jdbcTemplate;

    private static final String QUERY = """
        Select  distinct acc_cover_code , ac.explanation
               from  koc_oc_prod_part_main_cov mc,
                     koc_rci_cover_group_Ref cg,
                     koc_ac_cover_group_ref ac
               where  mc.reins_cover_code = cg.reinsurance_cover_group
                 and nvl(cg.is_assistance,0) = 1
                 and mc.validity_end_Date is null
                 and ac.validity_end_date is null
                 and mc.acc_cover_code = ac.acc_cover_group
                 order by 1,2
    """;

    @Override
    public List<AccCoverCode> loadAccCoverCodes() {
        return jdbcTemplate.query(QUERY, (rs, rowNum) -> new AccCoverCode(
                rs.getString("acc_cover_code"),
                rs.getString("explanation")
        ));
    }
}

