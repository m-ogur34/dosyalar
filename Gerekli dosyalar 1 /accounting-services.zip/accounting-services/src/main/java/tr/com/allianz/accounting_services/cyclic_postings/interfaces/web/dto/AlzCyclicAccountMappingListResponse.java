package tr.com.allianz.accounting_services.cyclic_postings.interfaces.web.dto;

import tr.com.allianz.accounting_services.cyclic_postings.application.usecases.AlzCyclicAccountMappingReadModel;

import java.io.Serializable;
import java.util.List;

public record AlzCyclicAccountMappingListResponse(List<AlzCyclicAccountMappingReadModel> alzCyclicAccountMappingList) implements Serializable {
}
