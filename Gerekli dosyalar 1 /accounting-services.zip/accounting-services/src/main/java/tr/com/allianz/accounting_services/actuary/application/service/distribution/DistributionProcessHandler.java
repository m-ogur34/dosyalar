package tr.com.allianz.accounting_services.actuary.application.service.distribution;

public interface DistributionProcessHandler {

    boolean supports(String processId);

    void execute(String processId, Integer year, Integer month);
}

