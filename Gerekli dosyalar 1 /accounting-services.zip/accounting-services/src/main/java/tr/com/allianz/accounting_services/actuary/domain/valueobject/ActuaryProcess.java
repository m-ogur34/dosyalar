package tr.com.allianz.accounting_services.actuary.domain.valueobject;

import java.time.LocalDate;

public record ActuaryProcess(
        String processId,
        String processName,
        String explanation,
        LocalDate validityStartDate,
        LocalDate validityEndDate
) {
}

