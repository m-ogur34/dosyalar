package tr.com.allianz.accounting_services.actuary.postings.domain.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@AllArgsConstructor
@NoArgsConstructor
public class ActuaryPostingProduct {
    private Long productId;
    private String extReference;
    private String longName;
}

