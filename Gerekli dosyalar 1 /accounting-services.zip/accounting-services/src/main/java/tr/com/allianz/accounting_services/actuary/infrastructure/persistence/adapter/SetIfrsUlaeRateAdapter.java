package tr.com.allianz.accounting_services.actuary.infrastructure.persistence.adapter;

import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;
import tr.com.allianz.accounting_services.actuary.application.port.out.SetIfrsUlaeRatePort;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.ActuaryProcessRuleAmount;
import tr.com.allianz.accounting_services.actuary.infrastructure.persistence.repository.AlzActProcessRulesRepository;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Date;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Component
@RequiredArgsConstructor
public class SetIfrsUlaeRateAdapter implements SetIfrsUlaeRatePort {

    private static final int RATE_SCALE = 33;

    private static final int QUERY_TIMEOUT_SECONDS = 120;
    private static final int FETCH_SIZE = 1_000;

    private static final String CLAIM_AMOUNT_QUERY = """
            SELECT a.*, DECODE(a.sf_total_type, '6', -1, 1) * NVL(a.trans_amt, 0) amount_component
              FROM koc_clm_bordro_rep a
             WHERE a.ticket_date BETWEEN :start_date AND :end_date
               AND a.sf_no > 0
            """;

    private static final String CURRENT_RESERVE_AMOUNT_QUERY = """
            SELECT b.*, b.trans_amt amount_component
              FROM koc_clm_muallak_bordro_rep b
             WHERE b.ticket_date = :end_date
               AND b.sf_no > 0
               AND NVL(b.is_ibnr, 0) <> 1
               AND (get_clm_reserve_sign(b.sf_total_type) * b.trans_amt > 0)
            """;

    private static final String PREVIOUS_RESERVE_AMOUNT_QUERY = """
            SELECT b.*, b.trans_amt * -1 amount_component
              FROM koc_clm_muallak_bordro_rep b
             WHERE b.ticket_date = :previous_reserve_date
               AND b.sf_no > 0
               AND NVL(b.is_ibnr, 0) <> 1
               AND (get_clm_reserve_sign(b.sf_total_type) * b.trans_amt > 0)
            """;

    private static final String UPDATE_ACTUARY_PROCESS_AMOUNT_RATES = """
            UPDATE alz_act_process_amounts
               SET ifrs_cy_gross_rate = :ifrs_cy_gross_rate,
                   ifrs_py_gross_rate = :ifrs_py_gross_rate
             WHERE year = :year
               AND month = :month
               AND process_id = :process_id
               AND rule_id = :rule_id
            """;

    private final NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    private final AlzActProcessRulesRepository alzActProcessRulesRepository;

    @Override
    public void setRate(String processId, LocalDate opusDate, List<ActuaryProcessRuleAmount> rows) {
        LocalDate calculationDate = opusDate.minusMonths(1);
        int year = calculationDate.getYear();
        int month = calculationDate.getMonthValue();
        LocalDate previousReserveDate = opusDate.minusMonths(12)
                .with(java.time.temporal.TemporalAdjusters.lastDayOfMonth());
        LocalDate startDate = previousReserveDate.plusDays(1);
        LocalDate endDate = calculationDate.with(java.time.temporal.TemporalAdjusters.lastDayOfMonth());

        for (ActuaryProcessRuleAmount row : rows) {
            if (row.ruleId() == null) {
                continue;
            }
            String rawRuleText = alzActProcessRulesRepository
                    .findByProcessIdAndRuleId(processId, row.ruleId())
                    .orElseThrow(() -> new IllegalArgumentException(
                            "Rule tanımı bulunamadı. processId=" + processId + ", ruleId=" + row.ruleId()))
                    .getRuleText();
            SqlRulePredicateSupport.RulePredicate rulePredicate = SqlRulePredicateSupport.compile(
                    rawRuleText, processId, row.ruleId(), "ULAE rule text");
            BigDecimal total = loadAmount(rulePredicate, startDate, endDate, previousReserveDate);
            BigDecimal cyRate = null;
            BigDecimal pryRate = null;
            if (total != null && total.compareTo(BigDecimal.ZERO) != 0) {
                cyRate = divide(row.ifrsCyGross(), total);
                pryRate = divide(row.ifrsPyGross(), total);
            }

            MapSqlParameterSource parameters = new MapSqlParameterSource()
                    .addValue("year", year)
                    .addValue("month", month)
                    .addValue("process_id", processId)
                    .addValue("rule_id", row.ruleId())
                    .addValue("ifrs_cy_gross_rate", cyRate)
                    .addValue("ifrs_py_gross_rate", pryRate);
            namedParameterJdbcTemplate.update(UPDATE_ACTUARY_PROCESS_AMOUNT_RATES, parameters);
        }
    }

    private BigDecimal loadAmount(SqlRulePredicateSupport.RulePredicate rulePredicate,
                                  LocalDate startDate, LocalDate endDate,
                                  LocalDate previousReserveDate) {
        BigDecimal bordroAmount = loadClaimAmount(rulePredicate, startDate, endDate);
        BigDecimal currentReserveAmount = loadCurrentReserveAmount(rulePredicate, endDate);
        BigDecimal previousReserveAmount = loadPreviousReserveAmount(rulePredicate, previousReserveDate);
        return bordroAmount.add(currentReserveAmount).add(previousReserveAmount);
    }

    private BigDecimal loadClaimAmount(SqlRulePredicateSupport.RulePredicate rulePredicate,
                                       LocalDate startDate,
                                       LocalDate endDate) {
        MapSqlParameterSource parameters = new MapSqlParameterSource()
                .addValue("start_date", Date.valueOf(startDate))
                .addValue("end_date", Date.valueOf(endDate));
        return namedParameterJdbcTemplate.execute(CLAIM_AMOUNT_QUERY, parameters,
                ps -> sumMatchingAmounts(ps, rulePredicate));
    }

    private BigDecimal loadCurrentReserveAmount(SqlRulePredicateSupport.RulePredicate rulePredicate,
                                                LocalDate endDate) {
        MapSqlParameterSource parameters = new MapSqlParameterSource()
                .addValue("end_date", Date.valueOf(endDate));
        return namedParameterJdbcTemplate.execute(CURRENT_RESERVE_AMOUNT_QUERY, parameters,
                ps -> sumMatchingAmounts(ps, rulePredicate));
    }

    private BigDecimal loadPreviousReserveAmount(SqlRulePredicateSupport.RulePredicate rulePredicate,
                                                 LocalDate previousReserveDate) {
        MapSqlParameterSource parameters = new MapSqlParameterSource()
                .addValue("previous_reserve_date", Date.valueOf(previousReserveDate));
        return namedParameterJdbcTemplate.execute(PREVIOUS_RESERVE_AMOUNT_QUERY, parameters,
                ps -> sumMatchingAmounts(ps, rulePredicate));
    }

    private BigDecimal sumMatchingAmounts(java.sql.PreparedStatement ps,
                                          SqlRulePredicateSupport.RulePredicate rulePredicate) throws SQLException {
        ps.setQueryTimeout(QUERY_TIMEOUT_SECONDS);
        ps.setFetchSize(FETCH_SIZE);
        try (java.sql.ResultSet rs = ps.executeQuery()) {
            ResultSetMetaData metaData = rs.getMetaData();
            BigDecimal total = BigDecimal.ZERO;
            while (rs.next()) {
                if (!rulePredicate.matches(toRowMap(rs, metaData))) {
                    continue;
                }
                BigDecimal amount = rs.getBigDecimal("amount_component");
                total = total.add(amount != null ? amount : BigDecimal.ZERO);
            }
            return total;
        }
    }

    private Map<String, Object> toRowMap(java.sql.ResultSet rs, ResultSetMetaData metaData) throws SQLException {
        Map<String, Object> row = new LinkedHashMap<>();
        for (int i = 1; i <= metaData.getColumnCount(); i++) {
            row.put(metaData.getColumnLabel(i), rs.getObject(i));
        }
        return row;
    }

    private BigDecimal divide(BigDecimal value, BigDecimal total) {
        return normalizeRateForPersistence(
                value.divide(total, RATE_SCALE, RoundingMode.HALF_UP)
        );
    }

    private BigDecimal normalizeRateForPersistence(BigDecimal rate) {
        return rate.setScale(RATE_SCALE, RoundingMode.HALF_UP);
    }

}



