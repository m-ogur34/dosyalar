package tr.com.allianz.accounting_services.actuary.infrastructure.persistence.adapter;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import tr.com.allianz.accounting_services.actuary.application.port.out.SaveActuaryLogPort;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.ActuaryLog;
import tr.com.allianz.accounting_services.actuary.infrastructure.persistence.entity.AlzActLog;
import tr.com.allianz.accounting_services.actuary.infrastructure.persistence.repository.AlzActLogRepository;

@Component
@RequiredArgsConstructor
public class ActuaryLogAdapter implements SaveActuaryLogPort {

    private final AlzActLogRepository repository;

    @Override
    public void save(ActuaryLog log) {
        AlzActLog entity = AlzActLog.builder()
                .year(log.year())
                .month(log.month())
                .processId(log.processId())
                .ruleId(log.ruleId())
                .logType(log.logType().name())
                .logText(log.logText())
                .byUser(log.byUser())
                .dateCreated(log.dateCreated())
                .build();

        repository.save(entity);
    }
}

