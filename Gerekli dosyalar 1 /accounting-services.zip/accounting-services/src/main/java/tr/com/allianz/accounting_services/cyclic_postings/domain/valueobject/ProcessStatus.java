package tr.com.allianz.accounting_services.cyclic_postings.domain.valueobject;

public enum ProcessStatus {
    CREATED("CREATED"),
    PROCESSED("PROCESSED"),
    ERROR_OCCURRED("ERROR_OCCURRED");

    private final String value;

    ProcessStatus(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public static ProcessStatus fromValue(String value) {
        for (ProcessStatus status : ProcessStatus.values()) {
            if (status.value.equals(value)) {
                return status;
            }
        }
        throw new IllegalArgumentException("Invalid process status: " + value);
    }
}
