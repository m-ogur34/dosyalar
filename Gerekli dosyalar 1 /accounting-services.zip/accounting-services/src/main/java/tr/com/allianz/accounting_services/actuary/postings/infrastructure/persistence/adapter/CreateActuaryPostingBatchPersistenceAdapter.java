package tr.com.allianz.accounting_services.actuary.postings.infrastructure.persistence.adapter;

import lombok.RequiredArgsConstructor;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Component;
import tr.com.allianz.accounting_services.actuary.postings.application.exception.CreateActuaryPostingBatchFailedException;
import tr.com.allianz.accounting_services.actuary.postings.application.port.out.CreateActuaryPostingBatchPort;
import tr.com.allianz.accounting_services.actuary.postings.application.usecases.CreateActuaryPostingBatchCommand;
import tr.com.allianz.accounting_services.actuary.postings.domain.model.CreateActuaryPostingBatchResult;

import java.sql.Date;
import java.sql.Types;
import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;
import java.util.List;

@Component
@RequiredArgsConstructor
public class CreateActuaryPostingBatchPersistenceAdapter implements CreateActuaryPostingBatchPort {

    private static final String CHECK_BATCH_SQL = """
            select distinct e.batch_id
              from (select distinct acc_transaction_id
                      from alz_rci_transactions d
                     where d.acc_transaction_id is not null
                     start with d.transaction_id in
                                (select transaction_id
                                   from alz_rci_process_transactions i
                                  where i.process_id = :process_id
                                    and i.branch_ext_ref = nvl(:branch_ext_ref, 'ALL')
                                    and i.is_industrial  = nvl(:is_industrial, 2)
                                    and i.process_date   = :posting_date)
                    connect by prior d.transaction_id = d.related_transaction_id) t,
                   alz_rci_acc_transactions e
             where e.acc_transaction_id = t.acc_transaction_id
            """;

    private final JdbcTemplate jdbcTemplate;
    private final NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @Override
    public CreateActuaryPostingBatchResult createBatch(CreateActuaryPostingBatchCommand command) {
        try {
            LocalDate monthEnd = command.postingDate().with(TemporalAdjusters.lastDayOfMonth());

            Long existingBatchId = findExistingBatchId(command, monthEnd);

            if (existingBatchId != null) {
                return CreateActuaryPostingBatchResult.existing(existingBatchId);
            }

            runRciProcess(command, monthEnd);

            Long newBatchId = findExistingBatchId(command, monthEnd);
            if (newBatchId == null) {
                throw new CreateActuaryPostingBatchFailedException(
                        "Batch olusturuldu ancak batch_id bulunamadi.");
            }

            return CreateActuaryPostingBatchResult.created(newBatchId);

        } catch (CreateActuaryPostingBatchFailedException ex) {
            throw ex;
        } catch (DataAccessException ex) {
            String detail = ex.getMostSpecificCause() == null
                    ? ex.getMessage()
                    : ex.getMostSpecificCause().getMessage();
            throw new CreateActuaryPostingBatchFailedException(detail);
        }
    }

    protected Long findExistingBatchId(CreateActuaryPostingBatchCommand command, LocalDate monthEnd) {
        MapSqlParameterSource params = new MapSqlParameterSource()
                .addValue("process_id",     command.batchType(),    Types.NUMERIC)
                .addValue("branch_ext_ref", command.branchExtRef(), Types.VARCHAR)
                .addValue("is_industrial",  command.isIndustrial(), Types.NUMERIC)
                .addValue("posting_date",   Date.valueOf(monthEnd), Types.DATE);

        List<Long> results = namedParameterJdbcTemplate.queryForList(
                CHECK_BATCH_SQL, params, Long.class);

        return results.isEmpty() ? null : results.getFirst();
    }

    protected void runRciProcess(CreateActuaryPostingBatchCommand command, LocalDate monthEnd) {
        SimpleJdbcCall call = createSimpleJdbcCall()
                .withSchemaName("CUSTOMER")
                .withCatalogName("ALZ_RCI_POSTING_UTILS")
                .withProcedureName("RUNRCIPROCESS")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlParameter("p_process_id",      Types.NUMERIC),
                        new SqlParameter("p_branch_ext_ref",  Types.VARCHAR),
                        new SqlParameter("p_is_industrial",   Types.NUMERIC),
                        new SqlParameter("p_date",            Types.DATE)
                );

        MapSqlParameterSource params = new MapSqlParameterSource()
                .addValue("p_process_id",     command.batchType(),    Types.NUMERIC)
                .addValue("p_branch_ext_ref", command.branchExtRef(), Types.VARCHAR)
                .addValue("p_is_industrial",  command.isIndustrial(), Types.NUMERIC)
                .addValue("p_date",           Date.valueOf(monthEnd), Types.DATE);

        call.execute(params);
    }

    protected SimpleJdbcCall createSimpleJdbcCall() {
        return new SimpleJdbcCall(jdbcTemplate);
    }
}
