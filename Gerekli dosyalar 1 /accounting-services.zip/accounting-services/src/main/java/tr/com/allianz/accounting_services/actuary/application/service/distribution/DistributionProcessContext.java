package tr.com.allianz.accounting_services.actuary.application.service.distribution;

public record DistributionProcessContext(
        String processId,
        Integer year,
        Integer month,
        String byUser
) {
}

