package tr.com.allianz.accounting_services.actuary.infrastructure.persistence.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Entity
@Table(name = "ALZ_ACT_LOG")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Builder
public class AlzActLog {

    @Id
    @Column(name = "LOG_ID")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "alz_act_log_seq")
    @SequenceGenerator(name = "alz_act_log_seq", sequenceName = "ALZ_ACT_LOG_SEQ", allocationSize = 1)
    private Long logId;

    @Column(name = "YEAR", precision = 4)
    private Integer year;

    @Column(name = "MONTH", precision = 2)
    private Integer month;

    @Column(name = "PROCESS_ID", length = 10)
    private String processId;

    @Column(name = "RULE_ID", precision = 5)
    private Integer ruleId;

    @Column(name = "LOG_TYPE", length = 200)
    private String logType;

    @Column(name = "LOG_TEXT", length = 2000)
    private String logText;

    @Column(name = "BY_USER", length = 200)
    private String byUser;

    @Column(name = "DATE_CREATED")
    private LocalDateTime dateCreated;
}

