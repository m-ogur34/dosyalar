package tr.com.allianz.accounting_services.cyclic_postings.application.exception;


import tr.com.allianz.accounting_services.shared.exception.BaseApplicationException;
import lombok.Getter;
import org.springframework.http.HttpStatus;

@Getter
public class CyclicPostingProcessNotFoundException extends BaseApplicationException{

    private final Long batchId;

    public CyclicPostingProcessNotFoundException(Long batchId) {
        super("CYCLIC_POSTING_PROCESS_NOT_FOUND",
                "Devreden fiş işleme kaydı bulunamadı",
                "Fiş nosu " + batchId +
                        " olan devreden fiş işleme kaydı bulunamadı.",
                HttpStatus.NOT_FOUND);
        this.batchId = batchId;
    }
}
