package tr.com.allianz.accounting_services.accounting_postings.infrastructure.persistence.adapter;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Component;

import tr.com.allianz.accounting_services.accounting_postings.application.exception.CreatePostingFailedException;
import tr.com.allianz.accounting_services.accounting_postings.application.port.out.CreatePostingPort;
import tr.com.allianz.accounting_services.accounting_postings.application.port.out.ReversePostingPort;
import tr.com.allianz.accounting_services.accounting_postings.infrastructure.persistence.dto.CreatePostingOracleResponseDto;
import tr.com.allianz.accounting_services.accounting_postings.infrastructure.persistence.dto.ReversePostingOracleResponseDto;
import tr.com.allianz.accounting_services.accounting_postings.interfaces.web.dto.CreatePostingRequest;
import tr.com.allianz.accounting_services.accounting_postings.interfaces.web.dto.ReversePostingRequest;
import tr.com.allianz.accounting_services.accounting_postings.interfaces.web.dto.ReversePostingResponse;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Component
@RequiredArgsConstructor
public class AccountingPostingPersistenceAdapter implements CreatePostingPort, ReversePostingPort {

    private final JdbcTemplate jdbcTemplate;
    private final ObjectMapper objectMapper;

    @Override
    public Long createPosting(CreatePostingRequest request) {
        SimpleJdbcCall simpleJdbcCall = createSimpleJdbcCall()
                .withSchemaName("CUSTOMER")
                .withCatalogName("WEB_RECEIPT_UTILS") // Assuming standard package or replace as valid
                .withProcedureName("create_posting_api")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlParameter("p_request", java.sql.Types.CLOB),
                        new SqlOutParameter("p_response", java.sql.Types.CLOB)
                );

        String jsonRequest;
        try {
            jsonRequest = objectMapper.writeValueAsString(request);
        } catch (JsonProcessingException e) {
            log.error("Failed to serialize requested payload", e);
            throw new CreatePostingFailedException("JSON okuma hatası: " + e.getMessage());
        }

        MapSqlParameterSource inparams = new MapSqlParameterSource()
                .addValue("p_request", jsonRequest, java.sql.Types.CLOB);

        try {
            Map<String, Object> out = simpleJdbcCall.execute(inparams);

            Object rawResponse = out.get("p_response");
            if (rawResponse == null) {
                 throw new CreatePostingFailedException("Oracle procedure'den null cevap veya timeout alindi.");
            }

            String jsonResponse;
            if (rawResponse instanceof java.sql.Clob) {
                try {
                    java.sql.Clob clob = (java.sql.Clob) rawResponse;
                    jsonResponse = clob.getSubString(1, (int) clob.length());
                } catch (Exception ex) {
                    throw new CreatePostingFailedException("Clob verisi okunamadi: " + ex.getMessage());
                }
            } else {
                jsonResponse = rawResponse.toString();
            }

            log.info("RAW JSON RESPONSE FROM ORACLE: {}", jsonResponse);

            CreatePostingOracleResponseDto oracleResponse = objectMapper.readValue(jsonResponse, CreatePostingOracleResponseDto.class);

            if (!oracleResponse.isSuccess()) {
                 log.error("Create posting PL/SQL error code: {}, desc: {}", oracleResponse.getErrorCode(), oracleResponse.getException());
                 throw new CreatePostingFailedException(oracleResponse.getException() != null ? oracleResponse.getException() : "PL/SQL fırlatma hatası.");
            }

            if (oracleResponse.getData() == null || oracleResponse.getData().getBatchId() == null) {
                 throw new CreatePostingFailedException("Veritabanı başarılı döndü ama batchId bilgisi ulaşılamadı.");
            }

            return oracleResponse.getData().getBatchId();

        } catch (DataAccessException e) {
            String errorMessage = e.getCause() != null && e.getCause().getMessage() != null ? e.getCause().getMessage() : e.getMessage();
            log.error("Database error while creating posting", e);
            throw new CreatePostingFailedException(errorMessage);
        } catch (JsonProcessingException e) {
            log.error("Failed to deserialize oracle response payload", e);
            throw new CreatePostingFailedException("Veritabanı cevabı parse edilemedi: " + e.getMessage());
        }
    }

    @Override
    public List<ReversePostingResponse> reversePosting(List<ReversePostingRequest> requests) {
        SimpleJdbcCall simpleJdbcCall = createSimpleJdbcCall()
                .withSchemaName("CUSTOMER")
                .withCatalogName("WEB_RECEIPT_UTILS")
                .withProcedureName("reverse_posting_api")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlParameter("p_request", java.sql.Types.CLOB),
                        new SqlOutParameter("p_response", java.sql.Types.CLOB)
                );

        String jsonRequest;
        try {
            Map<String, Object> wrapper = new HashMap<>();
            wrapper.put("postings", requests);
            jsonRequest = objectMapper.writeValueAsString(wrapper);
        } catch (JsonProcessingException e) {
            log.error("Failed to serialize requested payload", e);
            throw new CreatePostingFailedException("JSON okuma hatası: " + e.getMessage());
        }

        MapSqlParameterSource inparams = new MapSqlParameterSource()
                .addValue("p_request", jsonRequest, java.sql.Types.CLOB);

        try {
            Map<String, Object> out = simpleJdbcCall.execute(inparams);

            Object rawResponse = out.get("p_response");
            if (rawResponse == null) {
                throw new CreatePostingFailedException("Oracle procedure'den null cevap veya timeout alindi.");
            }

            String jsonResponse;
            if (rawResponse instanceof java.sql.Clob) {
                try {
                    java.sql.Clob clob = (java.sql.Clob) rawResponse;
                    jsonResponse = clob.getSubString(1, (int) clob.length());
                } catch (Exception ex) {
                    throw new CreatePostingFailedException("Clob verisi okunamadi: " + ex.getMessage());
                }
            } else {
                jsonResponse = rawResponse.toString();
            }

            log.info("RAW JSON RESPONSE FROM ORACLE: {}", jsonResponse);

            ReversePostingOracleResponseDto oracleResponse = objectMapper.readValue(jsonResponse, ReversePostingOracleResponseDto.class);

            if (!oracleResponse.isSuccess()) {
                log.error("Reverse posting PL/SQL error code: {}, desc: {}", oracleResponse.getErrorCode(), oracleResponse.getException());
                throw new CreatePostingFailedException(oracleResponse.getException() != null ? oracleResponse.getException() : "PL/SQL fırlatma hatası.");
            }

            return oracleResponse.getData();

        } catch (DataAccessException e) {
            String errorMessage = e.getCause() != null && e.getCause().getMessage() != null ? e.getCause().getMessage() : e.getMessage();
            log.error("Database error while reversing posting", e);
            throw new CreatePostingFailedException(errorMessage);
        } catch (JsonProcessingException e) {
            log.error("Failed to deserialize oracle response payload", e);
            throw new CreatePostingFailedException("Veritabanı cevabı parse edilemedi: " + e.getMessage());
        }
    }

    protected SimpleJdbcCall createSimpleJdbcCall() {
        return new SimpleJdbcCall(jdbcTemplate);
    }
}
