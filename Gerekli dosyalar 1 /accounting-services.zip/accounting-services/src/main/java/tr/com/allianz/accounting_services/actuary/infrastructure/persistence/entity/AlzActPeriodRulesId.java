package tr.com.allianz.accounting_services.actuary.infrastructure.persistence.entity;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
public class AlzActPeriodRulesId implements Serializable {
    private String processId;
    private Integer year;
    private Integer month;
    private Integer ruleId;
}

