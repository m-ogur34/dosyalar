package tr.com.allianz.accounting_services.actuary.postings.interfaces.web.dto;

import java.util.List;

public record ActuaryPostingBatchInfoResponse(
        List<ActuaryPostingBatchInfoLineResponse> items
) {
}

