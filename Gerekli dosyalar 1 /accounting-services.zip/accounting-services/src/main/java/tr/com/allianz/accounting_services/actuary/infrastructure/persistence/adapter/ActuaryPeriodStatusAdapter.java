package tr.com.allianz.accounting_services.actuary.infrastructure.persistence.adapter;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import tr.com.allianz.accounting_services.actuary.application.port.out.SaveActuaryPeriodStatusPort;
import tr.com.allianz.accounting_services.actuary.application.port.out.LoadActuaryPeriodStatusPort;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.ActuaryPeriodStatus;
import tr.com.allianz.accounting_services.actuary.infrastructure.persistence.entity.AlzActPeriods;
import tr.com.allianz.accounting_services.actuary.infrastructure.persistence.entity.AlzActPeriodsId;
import tr.com.allianz.accounting_services.actuary.infrastructure.persistence.repository.AlzActPeriodsRepository;

@Component
@RequiredArgsConstructor
public class ActuaryPeriodStatusAdapter implements SaveActuaryPeriodStatusPort, LoadActuaryPeriodStatusPort {

    private final AlzActPeriodsRepository repository;

    @Override
    public AlzActPeriods getOrCreateInProgress(String processId, Integer year, Integer month) {
        AlzActPeriodsId id = new AlzActPeriodsId(processId, year, month);

        return repository.findById(id)
                .orElseGet(() -> {
                    AlzActPeriods period = new AlzActPeriods(processId, year, month, null);
                    period.setStatusEnum(ActuaryPeriodStatus.IN_PROGRESS);
                    return repository.save(period);
                });
    }

    @Override
    public AlzActPeriods upsertStatus(String processId, Integer year, Integer month, ActuaryPeriodStatus status) {
        AlzActPeriodsId id = new AlzActPeriodsId(processId, year, month);

        AlzActPeriods period = repository.findById(id)
                .orElseGet(() -> new AlzActPeriods(processId, year, month, null));

        period.setStatusEnum(status);
        return repository.save(period);
    }

    @Override
    public ActuaryPeriodStatus getStatus(String processId, Integer year, Integer month) {
        AlzActPeriodsId id = new AlzActPeriodsId(processId, year, month);
        return repository.findById(id)
                .map(AlzActPeriods::getStatusEnum)
                .orElse(null);
    }
}

