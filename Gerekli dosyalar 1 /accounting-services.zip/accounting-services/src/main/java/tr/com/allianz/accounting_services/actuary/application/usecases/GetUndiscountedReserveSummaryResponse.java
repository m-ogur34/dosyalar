package tr.com.allianz.accounting_services.actuary.application.usecases;

import tr.com.allianz.accounting_services.actuary.domain.valueobject.UndiscountedReserveSummary;
import tr.com.allianz.accounting_services.actuary.infrastructure.persistence.entity.AlzActPeriods;

public record GetUndiscountedReserveSummaryResponse(
        UndiscountedReserveSummary summary,
        AlzActPeriods period
) {
}
