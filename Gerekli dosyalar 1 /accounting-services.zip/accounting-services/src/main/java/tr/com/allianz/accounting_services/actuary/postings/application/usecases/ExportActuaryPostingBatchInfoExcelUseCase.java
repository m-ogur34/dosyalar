package tr.com.allianz.accounting_services.actuary.postings.application.usecases;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import tr.com.allianz.accounting_services.actuary.postings.application.port.out.ExportActuaryPostingBatchInfoExcelPort;
import tr.com.allianz.accounting_services.actuary.postings.domain.model.ActuaryPostingBatchInfoExcelFile;

@Service
@RequiredArgsConstructor
public class ExportActuaryPostingBatchInfoExcelUseCase {

    private final ExportActuaryPostingBatchInfoExcelPort exportPort;

    public ActuaryPostingBatchInfoExcelFile handle(GetActuaryPostingBatchInfoCommand command) {
        return exportPort.exportToExcel(command);
    }
}

