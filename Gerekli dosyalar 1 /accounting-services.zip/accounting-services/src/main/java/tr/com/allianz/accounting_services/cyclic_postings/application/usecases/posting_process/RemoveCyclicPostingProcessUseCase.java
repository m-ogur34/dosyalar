package tr.com.allianz.accounting_services.cyclic_postings.application.usecases.posting_process;

import tr.com.allianz.accounting_services.cyclic_postings.application.exception.CyclicPostingProcessNotFoundException;
import tr.com.allianz.accounting_services.cyclic_postings.application.port.out.CyclicPostingProcessPort;
import tr.com.allianz.accounting_services.cyclic_postings.domain.valueobject.ProcessStatus;
import tr.com.allianz.accounting_services.cyclic_postings.infrastructure.persistence.entity.AlzCyclicPostingProcess;

public class RemoveCyclicPostingProcessUseCase {

    private final CyclicPostingProcessPort cyclicPostingProcessPort;

    public RemoveCyclicPostingProcessUseCase(CyclicPostingProcessPort cyclicPostingProcessPort) {
        this.cyclicPostingProcessPort = cyclicPostingProcessPort;
    }

    public void handle(Long batchId){
        AlzCyclicPostingProcess alzCyclicPostingProcess = cyclicPostingProcessPort.findById(batchId);
        if(alzCyclicPostingProcess == null){

            throw new CyclicPostingProcessNotFoundException(batchId);
        }
        if(alzCyclicPostingProcess.getProcessStatusEnum() == ProcessStatus.PROCESSED){
            throw new IllegalStateException("Sadece Yeni ve Hata durumundaki kayıtlar silinebilir.");
        }
        cyclicPostingProcessPort.removeCyclicPostingProcess(batchId);
    }
}
