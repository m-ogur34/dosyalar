package tr.com.allianz.accounting_services.assistance_accounting.infrastructure.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import tr.com.allianz.accounting_services.assistance_accounting.application.port.out.AssistancePartitionLoaderPort;
import tr.com.allianz.accounting_services.assistance_accounting.application.port.out.CreateAssistancePostingPort;
import tr.com.allianz.accounting_services.assistance_accounting.application.port.out.LoadAccCoverCodePort;
import tr.com.allianz.accounting_services.assistance_accounting.application.port.out.LoadAssistanceCompanyPort;
import tr.com.allianz.accounting_services.assistance_accounting.application.port.out.LoadAssistanceProductPort;
import tr.com.allianz.accounting_services.assistance_accounting.application.port.out.LoadAssistanceQueryPort;

import tr.com.allianz.accounting_services.assistance_accounting.application.usecases.CreateAssistancePostingUseCase;
import tr.com.allianz.accounting_services.assistance_accounting.application.usecases.ListAccCoverCodeUseCase;
import tr.com.allianz.accounting_services.assistance_accounting.application.usecases.ListAssistanceCompanyUseCase;
import tr.com.allianz.accounting_services.assistance_accounting.application.usecases.ListAssistanceProductUseCase;
import tr.com.allianz.accounting_services.assistance_accounting.application.usecases.ListAssistancePartitionUseCase;
import tr.com.allianz.accounting_services.assistance_accounting.application.usecases.ListAssistanceQueryUseCase;

@Configuration
public class AssistanceAccountingConfig {

    @Bean
    public ListAssistanceProductUseCase listAssistanceProductUseCase(LoadAssistanceProductPort loadAssistanceProductPort) {
        return new ListAssistanceProductUseCase(loadAssistanceProductPort);
    }


    @Bean
    public ListAssistancePartitionUseCase listAssistancePartitionUseCase(AssistancePartitionLoaderPort assistancePartitionLoaderPort) {
        return new ListAssistancePartitionUseCase(assistancePartitionLoaderPort);
    }

    @Bean
    public ListAssistanceQueryUseCase listAssistanceQueryUseCase(LoadAssistanceQueryPort loadAssistanceQueryPort) {
        return new ListAssistanceQueryUseCase(loadAssistanceQueryPort);
    }

    @Bean
    public ListAccCoverCodeUseCase listAccCoverCodeUseCase(LoadAccCoverCodePort loadAccCoverCodePort) {
        return new ListAccCoverCodeUseCase(loadAccCoverCodePort);
    }

    @Bean
    public CreateAssistancePostingUseCase createAssistancePostingUseCase(CreateAssistancePostingPort createAssistancePostingPort) {
        return new CreateAssistancePostingUseCase(createAssistancePostingPort);
    }


    @Bean
    public ListAssistanceCompanyUseCase listAssistanceCompanyUseCase(LoadAssistanceCompanyPort loadAssistanceCompanyPort) {
        return new ListAssistanceCompanyUseCase(loadAssistanceCompanyPort);
    }
}
