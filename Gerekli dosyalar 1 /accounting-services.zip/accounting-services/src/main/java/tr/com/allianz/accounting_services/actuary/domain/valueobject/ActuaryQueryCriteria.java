package tr.com.allianz.accounting_services.actuary.domain.valueobject;

public record ActuaryQueryCriteria(
        String processId,
        Integer year,
        Integer month
) {
}

