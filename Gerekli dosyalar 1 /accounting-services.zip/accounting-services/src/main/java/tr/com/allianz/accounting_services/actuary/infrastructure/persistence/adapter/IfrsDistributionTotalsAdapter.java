package tr.com.allianz.accounting_services.actuary.infrastructure.persistence.adapter;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;
import tr.com.allianz.accounting_services.actuary.application.port.out.LoadIfrsDistributionTotalsPort;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.IfrsDistributionTotals;
import tr.com.allianz.accounting_services.actuary.infrastructure.persistence.entity.AlzActProcessRules;
import tr.com.allianz.accounting_services.actuary.infrastructure.persistence.repository.AlzActProcessRulesRepository;

import java.math.BigDecimal;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * IFRS PY dağıtım toplamlarını hesaplayan adapter.
 * <p>
 * Satırlar Java heap'e çekilmez; SUM işlemi DB'de 3 ayrı aggregate SQL şablonuyla yapılır.
 * Her query yalnızca 1 satır (gross_amount, re_amount, net_amount) döndürür.
 */
@Component
@Slf4j
@RequiredArgsConstructor
public class IfrsDistributionTotalsAdapter implements LoadIfrsDistributionTotalsPort {

    private static final int QUERY_TIMEOUT_SECONDS = 120;
    private static final int FETCH_SIZE = 1_000;

    private static final String PERIOD_EXISTS_QUERY = """
            SELECT t.*
              FROM customer.alz_hp_data t
             WHERE t.year = :year
               AND t.month = :month
               AND t.code = 'W'
            """;

    private static final String LATEST_PERIOD_QUERY = """
            SELECT t.*
              FROM customer.alz_hp_data t
             WHERE t.code = 'W'
             ORDER BY t.year DESC, t.month DESC
            """;

    private static final String YEAR_MINUS_1_ROWS_QUERY = """
            SELECT t.*,
                   DECODE(t.code,'WCRI',-1,1)*NVL(t.amount,0)+DECODE(t.code,'W',1,0)*NVL(t.prv_amount,0) gross_amount_component,
                   DECODE(t.code,'WCRI',-1,1)*NVL(t.reas_amount,0)+DECODE(t.code,'W',1,0)*NVL(t.prv_reas_amount,0) re_amount_component,
                   CASE WHEN t.is_pool=1 THEN 0 ELSE
                            DECODE(t.code,'WCRI',-1,1)*(NVL(t.amount,0)-NVL(t.reas_amount,0))
                           +DECODE(t.code,'W',1,0)*(NVL(t.prv_amount,0)-NVL(t.prv_reas_amount,0)) END net_amount_component
              FROM customer.alz_hp_data t
             WHERE t.year = :yearMinus1
               AND t.month = 12
               AND t.code IN ('W','WCRI')
               AND t.product_id NOT IN (12,60)
               AND NVL(Koc_acc_utils.GET_LOB(t.acc_cover_code,t.product_id,t.partition_type,sysdate),'X') NOT IN ('600','601','604')
            """;

    private static final String YEAR_RANGE_ROWS_QUERY = """
            SELECT t.*,
                   NVL(t.amount,0)+NVL(t.prv_amount,0) gross_amount_component,
                   NVL(t.reas_amount,0)+NVL(t.prv_reas_amount,0) re_amount_component,
                   CASE WHEN t.is_pool=1 THEN 0 ELSE
                            NVL(t.amount,0)-NVL(t.reas_amount,0)+(NVL(t.prv_amount,0)-NVL(t.prv_reas_amount,0)) END net_amount_component
              FROM customer.alz_hp_data t
             WHERE t.year BETWEEN :yearMinus3 AND :yearMinus2
               AND t.month = 12
               AND t.code = 'W'
               AND t.product_id NOT IN (12,60)
               AND NVL(Koc_acc_utils.GET_LOB(t.acc_cover_code,t.product_id,t.partition_type,sysdate),'X') NOT IN ('600','601','604')
            """;

    private static final String YEAR_MINUS_3_ROWS_QUERY = """
            SELECT t.*,
                   NVL(t.prv_amount,0) gross_amount_component,
                   NVL(t.prv_reas_amount,0) re_amount_component,
                   CASE WHEN t.is_pool=1 THEN 0 ELSE NVL(t.prv_amount,0)-NVL(t.prv_reas_amount,0) END net_amount_component
              FROM customer.alz_hp_data t
             WHERE t.year = :yearMinus3
               AND t.month = 1
               AND t.code = 'WCRI'
               AND t.product_id NOT IN (12,60)
               AND NVL(Koc_acc_utils.GET_LOB(t.acc_cover_code,t.product_id,t.partition_type,sysdate),'X') NOT IN ('600','601','604')
            """;

    private final NamedParameterJdbcTemplate namedParameterJdbcTemplate;
    private final AlzActProcessRulesRepository alzActProcessRulesRepository;

    @Override
    public IfrsDistributionTotals loadPyTotals(String processId, Integer ruleId, Integer year, Integer month) {
        return loadPyTotalsByRuleIds(processId, Set.of(ruleId), year, month).get(ruleId);
    }

    @Override
    public Map<Integer, IfrsDistributionTotals> loadPyTotalsByRuleIds(String processId,
                                                                      Set<Integer> ruleIds,
                                                                      Integer year,
                                                                      Integer month) {
        if (ruleIds == null || ruleIds.isEmpty()) {
            return Map.of();
        }

        Map<Integer, AlzActProcessRules> rulesById = alzActProcessRulesRepository
                .findByProcessIdAndRuleIdIn(processId, List.copyOf(ruleIds))
                .stream()
                .collect(Collectors.toMap(r -> r.getId().getRuleId(), Function.identity()));

        for (Integer ruleId : ruleIds) {
            if (!rulesById.containsKey(ruleId)) {
                throw new IllegalArgumentException(
                        String.format(Locale.ROOT, "IFRS rule tanımı bulunamadı. processId=%s, ruleId=%s", processId, ruleId));
            }
        }

        Map<Integer, IfrsDistributionTotals> totalsByRuleId = new HashMap<>();
        for (Map.Entry<Integer, AlzActProcessRules> entry : rulesById.entrySet()) {
            Integer ruleId = entry.getKey();
            SqlRulePredicateSupport.RulePredicate rulePredicate = SqlRulePredicateSupport.compile(
                    entry.getValue().getRuleText(), processId, ruleId, "IFRS rule text");

            DistributionPeriod period = resolvePeriod(year, month, rulePredicate);
            BigDecimal[] ym1 = queryYearMinus1Aggregates(period.year() - 1, rulePredicate);
            BigDecimal[] range = queryYearRangeAggregates(period.year() - 3, period.year() - 2, rulePredicate);
            BigDecimal[] ym3 = queryYearMinus3Aggregates(period.year() - 3, rulePredicate);

            totalsByRuleId.put(ruleId, new IfrsDistributionTotals(
                    ym1[0].add(range[0]).add(ym3[0]),
                    ym1[1].add(range[1]).add(ym3[1]),
                    ym1[2].add(range[2]).add(ym3[2])
            ));
        }
        return totalsByRuleId;
    }

    private DistributionPeriod resolvePeriod(Integer year, Integer month,
                                             SqlRulePredicateSupport.RulePredicate rulePredicate) {
        if (queryExists(year, month, rulePredicate)) {
            return new DistributionPeriod(year, month);
        }

        return queryLatestPeriod(rulePredicate)
                .orElse(new DistributionPeriod(year, month));
    }

    private boolean queryExists(Integer year, Integer month,
                                SqlRulePredicateSupport.RulePredicate rulePredicate) {
        MapSqlParameterSource params = new MapSqlParameterSource()
                .addValue("year", year)
                .addValue("month", month);
        return Boolean.TRUE.equals(namedParameterJdbcTemplate.execute(PERIOD_EXISTS_QUERY, params,
                ps -> {
                    ps.setQueryTimeout(QUERY_TIMEOUT_SECONDS);
                    ps.setFetchSize(FETCH_SIZE);
                    try (java.sql.ResultSet rs = ps.executeQuery()) {
                        ResultSetMetaData metaData = rs.getMetaData();
                        while (rs.next()) {
                            if (rulePredicate.matches(toRowMap(rs, metaData))) {
                                return true;
                            }
                        }
                        return false;
                    }
                }));
    }

    private Optional<DistributionPeriod> queryLatestPeriod(SqlRulePredicateSupport.RulePredicate rulePredicate) {
        return namedParameterJdbcTemplate.execute(LATEST_PERIOD_QUERY, new MapSqlParameterSource(),
                ps -> {
                    ps.setQueryTimeout(QUERY_TIMEOUT_SECONDS);
                    ps.setFetchSize(FETCH_SIZE);
                    try (java.sql.ResultSet rs = ps.executeQuery()) {
                        ResultSetMetaData metaData = rs.getMetaData();
                        while (rs.next()) {
                            Map<String, Object> row = toRowMap(rs, metaData);
                            if (rulePredicate.matches(row)) {
                                return Optional.of(new DistributionPeriod(
                                        toInteger(row.get("YEAR")), toInteger(row.get("MONTH"))));
                            }
                        }
                        return Optional.empty();
                    }
                });
    }

    private BigDecimal[] queryYearMinus1Aggregates(Integer yearMinus1,
                                                   SqlRulePredicateSupport.RulePredicate rulePredicate) {
        return namedParameterJdbcTemplate.execute(YEAR_MINUS_1_ROWS_QUERY,
                new MapSqlParameterSource().addValue("yearMinus1", yearMinus1),
                ps -> {
                    ps.setQueryTimeout(QUERY_TIMEOUT_SECONDS);
                    ps.setFetchSize(FETCH_SIZE);
                    try (java.sql.ResultSet rs = ps.executeQuery()) {
                        ResultSetMetaData metaData = rs.getMetaData();
                        BigDecimal gross = BigDecimal.ZERO;
                        BigDecimal re = BigDecimal.ZERO;
                        BigDecimal net = BigDecimal.ZERO;
                        while (rs.next()) {
                            if (!rulePredicate.matches(toRowMap(rs, metaData))) {
                                continue;
                            }
                            gross = gross.add(defaultZero(rs.getBigDecimal("gross_amount_component")));
                            re = re.add(defaultZero(rs.getBigDecimal("re_amount_component")));
                            net = net.add(defaultZero(rs.getBigDecimal("net_amount_component")));
                        }
                        return new BigDecimal[]{gross, re, net};
                    }
                });
    }

    private BigDecimal[] queryYearRangeAggregates(Integer yearMinus3, Integer yearMinus2,
                                                  SqlRulePredicateSupport.RulePredicate rulePredicate) {
        MapSqlParameterSource params = new MapSqlParameterSource()
                .addValue("yearMinus3", yearMinus3)
                .addValue("yearMinus2", yearMinus2);
        return namedParameterJdbcTemplate.execute(YEAR_RANGE_ROWS_QUERY, params,
                ps -> {
                    ps.setQueryTimeout(QUERY_TIMEOUT_SECONDS);
                    ps.setFetchSize(FETCH_SIZE);
                    try (java.sql.ResultSet rs = ps.executeQuery()) {
                        ResultSetMetaData metaData = rs.getMetaData();
                        BigDecimal gross = BigDecimal.ZERO;
                        BigDecimal re = BigDecimal.ZERO;
                        BigDecimal net = BigDecimal.ZERO;
                        while (rs.next()) {
                            if (!rulePredicate.matches(toRowMap(rs, metaData))) {
                                continue;
                            }
                            gross = gross.add(defaultZero(rs.getBigDecimal("gross_amount_component")));
                            re = re.add(defaultZero(rs.getBigDecimal("re_amount_component")));
                            net = net.add(defaultZero(rs.getBigDecimal("net_amount_component")));
                        }
                        return new BigDecimal[]{gross, re, net};
                    }
                });
    }

    private BigDecimal[] queryYearMinus3Aggregates(Integer yearMinus3,
                                                   SqlRulePredicateSupport.RulePredicate rulePredicate) {
        return namedParameterJdbcTemplate.execute(YEAR_MINUS_3_ROWS_QUERY,
                new MapSqlParameterSource().addValue("yearMinus3", yearMinus3),
                ps -> {
                    ps.setQueryTimeout(QUERY_TIMEOUT_SECONDS);
                    ps.setFetchSize(FETCH_SIZE);
                    try (java.sql.ResultSet rs = ps.executeQuery()) {
                        ResultSetMetaData metaData = rs.getMetaData();
                        BigDecimal gross = BigDecimal.ZERO;
                        BigDecimal re = BigDecimal.ZERO;
                        BigDecimal net = BigDecimal.ZERO;
                        while (rs.next()) {
                            if (!rulePredicate.matches(toRowMap(rs, metaData))) {
                                continue;
                            }
                            gross = gross.add(defaultZero(rs.getBigDecimal("gross_amount_component")));
                            re = re.add(defaultZero(rs.getBigDecimal("re_amount_component")));
                            net = net.add(defaultZero(rs.getBigDecimal("net_amount_component")));
                        }
                        return new BigDecimal[]{gross, re, net};
                    }
                });
    }

    private Map<String, Object> toRowMap(java.sql.ResultSet rs, ResultSetMetaData metaData) throws SQLException {
        Map<String, Object> row = new LinkedHashMap<>();
        for (int i = 1; i <= metaData.getColumnCount(); i++) {
            row.put(metaData.getColumnLabel(i), rs.getObject(i));
        }
        return row;
    }

    private Integer toInteger(Object value) {
        return value instanceof Number number ? number.intValue() : null;
    }

    private BigDecimal defaultZero(BigDecimal value) {
        return value != null ? value : BigDecimal.ZERO;
    }

    private record DistributionPeriod(Integer year, Integer month) {
    }
}
