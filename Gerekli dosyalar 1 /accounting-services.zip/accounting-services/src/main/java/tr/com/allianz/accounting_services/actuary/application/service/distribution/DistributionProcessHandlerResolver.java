package tr.com.allianz.accounting_services.actuary.application.service.distribution;

import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class DistributionProcessHandlerResolver {

    private final List<DistributionProcessHandler> handlers;

    public DistributionProcessHandlerResolver(List<DistributionProcessHandler> handlers) {
        this.handlers = List.copyOf(handlers);
    }

    public DistributionProcessHandler resolve(String processId) {
        return handlers.stream()
                .filter(handler -> handler.supports(processId))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException(
                        "Distribution handler is not defined for processId: " + processId));
    }
}

