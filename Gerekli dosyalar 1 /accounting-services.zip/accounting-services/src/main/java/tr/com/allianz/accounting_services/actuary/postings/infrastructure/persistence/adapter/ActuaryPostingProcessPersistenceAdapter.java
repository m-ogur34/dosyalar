package tr.com.allianz.accounting_services.actuary.postings.infrastructure.persistence.adapter;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import tr.com.allianz.accounting_services.actuary.postings.application.port.out.LoadActuaryPostingProcessesPort;
import tr.com.allianz.accounting_services.actuary.postings.domain.model.ActuaryPostingProcess;
import tr.com.allianz.accounting_services.actuary.postings.infrastructure.persistence.repository.AlzRciProcessRepository;

import java.util.List;

@Component
@RequiredArgsConstructor
public class ActuaryPostingProcessPersistenceAdapter implements LoadActuaryPostingProcessesPort {

    private final AlzRciProcessRepository repository;

    @Override
    public List<ActuaryPostingProcess> loadAll() {
        return repository.findAll()
                .stream()
                .map(entity -> new ActuaryPostingProcess(
                        entity.getProcessId(),
                        entity.getDescription() != null ? entity.getDescription().trim() : ""
                ))
                .sorted((a, b) -> a.getDescription().compareTo(b.getDescription()))
                .toList();
    }
}

