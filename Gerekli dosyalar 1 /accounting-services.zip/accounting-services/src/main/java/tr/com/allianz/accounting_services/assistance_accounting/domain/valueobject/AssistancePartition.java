package tr.com.allianz.accounting_services.assistance_accounting.domain.valueobject;

public record AssistancePartition(
    String partitionType,
    String longName
) {}

