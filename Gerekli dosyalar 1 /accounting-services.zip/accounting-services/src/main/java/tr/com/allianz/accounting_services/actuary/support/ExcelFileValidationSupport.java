package tr.com.allianz.accounting_services.actuary.support;

import org.springframework.web.multipart.MultipartFile;

import java.util.Locale;

public final class ExcelFileValidationSupport {

    public static final String XLSX_CONTENT_TYPE =
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
    public static final String XLS_CONTENT_TYPE = "application/vnd.ms-excel";

    private ExcelFileValidationSupport() {
    }

    public static void validateExcelType(
            MultipartFile file,
            String invalidExtensionMessage,
            String invalidContentTypeMessage
    ) {
        String filename = file.getOriginalFilename();
        if (filename == null || !hasAllowedExtension(filename)) {
            throw new IllegalArgumentException(invalidExtensionMessage);
        }

        String contentType = file.getContentType();
        if (!isAllowedContentType(contentType)) {
            throw new IllegalArgumentException(invalidContentTypeMessage);
        }
    }

    public static boolean hasAllowedExtension(String filename) {
        String lowerFilename = filename.toLowerCase(Locale.ROOT);
        return lowerFilename.endsWith(".xlsx") || lowerFilename.endsWith(".xls");
    }

    public static boolean isAllowedContentType(String contentType) {
        return contentType != null
                && (contentType.contains(XLSX_CONTENT_TYPE) || contentType.contains(XLS_CONTENT_TYPE));
    }
}

