package tr.com.allianz.accounting_services.actuary.interfaces.web.dto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.math.BigDecimal;

public record SaveActuaryProcessAmountRequestDto(

        @NotNull(message = "Year boş olamaz")
        @Min(value = 1900, message = "Year geçerli bir yıl olmalıdır")
        @Max(value = 2999, message = "Year geçerli bir yıl olmalıdır")
        Integer year,

        @NotNull(message = "Month boş olamaz")
        @Min(value = 1, message = "Month 1 ile 12 arasında olmalıdır")
        @Max(value = 12, message = "Month 1 ile 12 arasında olmalıdır")
        Integer month,

        @NotBlank(message = "Process ID boş olamaz")
        @Size(max = 10, message = "Process ID en fazla 10 karakter olabilir")
        String processId,

        @NotNull(message = "Rule ID boş olamaz")
        Integer ruleId,

        BigDecimal grossCyAmount,
        BigDecimal reCyAmount,
        BigDecimal netCyAmount,
        BigDecimal grossPyAmount,
        BigDecimal rePyAmount,
        BigDecimal netPyAmount,
        BigDecimal ifrsCyGross,
        BigDecimal ifrsCyRe,
        BigDecimal ifrsCyNet,
        BigDecimal ifrsPyGross,
        BigDecimal ifrsPyRe,
        BigDecimal ifrsPyNet,
        BigDecimal grossCyAmountRate,
        BigDecimal reCyAmountRate,
        BigDecimal netCyAmountRate,
        BigDecimal grossPyAmountRate,
        BigDecimal rePyAmountRate,
        BigDecimal netPyAmountRate,
        BigDecimal ifrsCyGrossRate,
        BigDecimal ifrsCyReRate,
        BigDecimal ifrsCyNetRate,
        BigDecimal ifrsPyGrossRate,
        BigDecimal ifrsPyReRate,
        BigDecimal ifrsPyNetRate
) {
}
