package tr.com.allianz.accounting_services.actuary.postings.domain.model;

public record ActuaryPostingBatchInfoExcelFile(
        String fileName,
        byte[] content
) {
}

