package tr.com.allianz.accounting_services.actuary.infrastructure.persistence.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import tr.com.allianz.accounting_services.actuary.infrastructure.persistence.entity.AlzActPeriods;
import tr.com.allianz.accounting_services.actuary.infrastructure.persistence.entity.AlzActPeriodsId;

public interface AlzActPeriodsRepository extends JpaRepository<AlzActPeriods, AlzActPeriodsId> {
}

