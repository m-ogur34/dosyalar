package tr.com.allianz.accounting_services.assistance_accounting.application.usecases;

import tr.com.allianz.accounting_services.assistance_accounting.application.port.out.LoadAccCoverCodePort;
import tr.com.allianz.accounting_services.assistance_accounting.domain.valueobject.AccCoverCode;

import java.util.List;

public class ListAccCoverCodeUseCase {

    private final LoadAccCoverCodePort loadAccCoverCodePort;

    public ListAccCoverCodeUseCase(LoadAccCoverCodePort loadAccCoverCodePort) {
        this.loadAccCoverCodePort = loadAccCoverCodePort;
    }

    public List<AccCoverCode> handle() {
        return loadAccCoverCodePort.loadAccCoverCodes();
    }
}
