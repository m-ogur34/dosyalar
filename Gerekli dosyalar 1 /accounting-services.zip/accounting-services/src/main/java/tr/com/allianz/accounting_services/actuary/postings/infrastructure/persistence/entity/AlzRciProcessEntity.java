package tr.com.allianz.accounting_services.actuary.postings.infrastructure.persistence.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "ALZ_RCI_PROCESSES")
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class AlzRciProcessEntity {

    @Id
    @Column(name = "PROCESS_ID")
    private String processId;

    @Column(name = "DESCRIPTION")
    private String description;
}

