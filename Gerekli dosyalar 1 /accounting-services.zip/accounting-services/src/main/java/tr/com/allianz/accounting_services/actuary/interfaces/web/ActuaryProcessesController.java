package tr.com.allianz.accounting_services.actuary.interfaces.web;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import tr.com.allianz.accounting_services.actuary.application.usecases.ListActuaryProcessesUseCase;
import tr.com.allianz.accounting_services.actuary.application.usecases.ApproveActuaryPeriodUseCase;
import tr.com.allianz.accounting_services.actuary.application.usecases.SetActuaryPeriodInProgressUseCase;
import tr.com.allianz.accounting_services.actuary.application.usecases.ExecuteDistributionUseCase;
import tr.com.allianz.accounting_services.actuary.application.service.ActuaryLogService;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.ActuaryProcess;
import tr.com.allianz.accounting_services.actuary.interfaces.web.dto.ActuaryProcessResponseDto;
import tr.com.allianz.accounting_services.actuary.interfaces.web.dto.ActuaryQueryRequestDto;
import tr.com.allianz.accounting_services.shared.api.ApiResponse;

import java.security.Principal;
import java.util.List;
@RestController
@RequestMapping("/api/v1/actuary-processes")
@CrossOrigin
@RequiredArgsConstructor
public class ActuaryProcessesController {
    private final ListActuaryProcessesUseCase listActuaryProcessesUseCase;
    private final ApproveActuaryPeriodUseCase approveActuaryPeriodUseCase;
    private final SetActuaryPeriodInProgressUseCase setActuaryPeriodInProgressUseCase;
    private final ExecuteDistributionUseCase executeDistributionUseCase;
    private final ActuaryLogService actuaryLogService;

    @GetMapping
    public ResponseEntity<ApiResponse<List<ActuaryProcessResponseDto>>> listActiveProcesses() {
        List<ActuaryProcessResponseDto> data = listActuaryProcessesUseCase.handle()
                .stream()
                .map(this::toDto)
                .toList();
        return ResponseEntity.ok(ApiResponse.ok("SUCCESS", "Actuary processes listed successfully", data));
    }
    private ActuaryProcessResponseDto toDto(ActuaryProcess process) {
        return new ActuaryProcessResponseDto(
                process.processId(),
                process.processName(),
                process.explanation(),
                process.validityStartDate(),
                process.validityEndDate()
        );
    }

    @PostMapping("/approve")
    public ResponseEntity<ApiResponse<Void>> approveActuaryPeriod(
            @RequestBody ActuaryQueryRequestDto request,
            Principal principal
    ) {
        String username = principal != null ? principal.getName() : "SYSTEM";
        
        try {
            approveActuaryPeriodUseCase.handle(request.processId(), request.year(), request.month(), username);

            return ResponseEntity.ok(
                    ApiResponse.ok(
                            "SUCCESS",
                            "Actuary period approved successfully",
                            null
                    )
            );
        } catch (IllegalArgumentException e) {
            actuaryLogService.logError(
                    request.processId(),
                    request.year(),
                    request.month(),
                    "Approval failed: " + e.getMessage(),
                    username
            );
            return ResponseEntity.badRequest().body(
                    ApiResponse.error(
                            "VALIDATION_ERROR",
                            e.getMessage(),
                            null
                    )
            );
        } catch (Exception e) {
            actuaryLogService.logError(
                    request.processId(),
                    request.year(),
                    request.month(),
                    "Approval failed: " + e.getMessage(),
                    username
            );
            throw e;
        }
    }

    @PostMapping("/in-progress")
    public ResponseEntity<ApiResponse<Void>> setActuaryPeriodInProgress(
            @RequestBody ActuaryQueryRequestDto request,
            Principal principal
    ) {
        String username = principal != null ? principal.getName() : "SYSTEM";
        
        try {
            setActuaryPeriodInProgressUseCase.handle(request.processId(), request.year(), request.month(), username);

            return ResponseEntity.ok(
                    ApiResponse.ok(
                            "SUCCESS",
                            "Actuary period set to In Progress successfully",
                            null
                    )
            );
        } catch (IllegalArgumentException e) {
            actuaryLogService.logError(
                    request.processId(),
                    request.year(),
                    request.month(),
                    "Setting In Progress failed: " + e.getMessage(),
                    username
            );
            return ResponseEntity.badRequest().body(
                    ApiResponse.error(
                            "VALIDATION_ERROR",
                            e.getMessage(),
                            null
                    )
            );
        } catch (Exception e) {
            actuaryLogService.logError(
                    request.processId(),
                    request.year(),
                    request.month(),
                    "Setting In Progress failed: " + e.getMessage(),
                    username
            );
            throw e;
        }
    }

    @PostMapping("/actuary-revoke-approval")
    public ResponseEntity<ApiResponse<Void>> revokeActuaryApproval(
            @RequestBody ActuaryQueryRequestDto request,
            Principal principal
    ) {
        String username = principal != null ? principal.getName() : "SYSTEM";

        try {
            // Revoke approval means moving period back to In Progress.
            setActuaryPeriodInProgressUseCase.handle(request.processId(), request.year(), request.month(), username);

            return ResponseEntity.ok(
                    ApiResponse.ok(
                            "SUCCESS",
                            "Actuary approval revoked and period set to In Progress successfully",
                            null
                    )
            );
        } catch (IllegalArgumentException e) {
            actuaryLogService.logError(
                    request.processId(),
                    request.year(),
                    request.month(),
                    "Revoke approval failed: " + e.getMessage(),
                    username
            );
            return ResponseEntity.badRequest().body(
                    ApiResponse.error(
                            "VALIDATION_ERROR",
                            e.getMessage(),
                            null
                    )
            );
        } catch (Exception e) {
            actuaryLogService.logError(
                    request.processId(),
                    request.year(),
                    request.month(),
                    "Revoke approval failed: " + e.getMessage(),
                    username
            );
            throw e;
        }
    }

    @PostMapping("/execute-distribution")
    public ResponseEntity<ApiResponse<Void>> executeDistribution(
            @RequestBody ActuaryQueryRequestDto request,
            Principal principal
    ) {
        String username = principal != null ? principal.getName() : "SYSTEM";

        try {
            executeDistributionUseCase.handle(request.processId(), request.year(), request.month(), username);

            return ResponseEntity.ok(
                    ApiResponse.ok(
                            "SUCCESS",
                            "Distribution executed successfully",
                            null
                    )
            );
        } catch (IllegalArgumentException e) {
            actuaryLogService.logError(
                    request.processId(),
                    request.year(),
                    request.month(),
                    "Execute distribution failed: " + e.getMessage(),
                    username
            );
            return ResponseEntity.badRequest().body(
                    ApiResponse.error(
                            "VALIDATION_ERROR",
                            e.getMessage(),
                            null
                    )
            );
        } catch (Exception e) {
            actuaryLogService.logError(
                    request.processId(),
                    request.year(),
                    request.month(),
                    "Execute distribution failed: " + e.getMessage(),
                    username
            );
            throw e;
        }
    }
}
