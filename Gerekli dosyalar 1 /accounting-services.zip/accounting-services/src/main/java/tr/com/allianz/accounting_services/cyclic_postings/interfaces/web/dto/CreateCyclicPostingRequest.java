package tr.com.allianz.accounting_services.cyclic_postings.interfaces.web.dto;

import lombok.Data;
import java.time.LocalDate;
import java.util.List;

@Data
public class CreateCyclicPostingRequest {
    private List<CyclicPostingItem> items;

    @Data
    public static class CyclicPostingItem {
        private Long batchId;
        private LocalDate postingDate;
    }
}