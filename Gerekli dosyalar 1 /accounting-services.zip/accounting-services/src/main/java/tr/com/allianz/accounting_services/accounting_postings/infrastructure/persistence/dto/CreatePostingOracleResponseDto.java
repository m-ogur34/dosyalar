package tr.com.allianz.accounting_services.accounting_postings.infrastructure.persistence.dto;

import lombok.Getter;
import lombok.Setter;
import com.fasterxml.jackson.annotation.JsonProperty;

@Getter
@Setter
public class CreatePostingOracleResponseDto {
    @JsonProperty("succeeded")
    private boolean success;
    private String errorCode;
    private String exception;
    private CreatePostingOracleResponseDataDto data;
}
