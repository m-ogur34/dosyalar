package tr.com.allianz.accounting_services.actuary.application.service.distribution;

import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class DistributionProcessHookResolver {

    private final List<DistributionProcessHook> hooks;

    public DistributionProcessHookResolver(List<DistributionProcessHook> hooks) {
        this.hooks = List.copyOf(hooks);
    }

    public List<DistributionProcessHook> resolve(String processId) {
        return hooks.stream()
                .filter(hook -> hook.supports(processId))
                .toList();
    }
}

