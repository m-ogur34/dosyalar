package tr.com.allianz.accounting_services.actuary.interfaces.web.dto;

public record ActuaryQueryRequestDto(
        String processId,
        Integer year,
        Integer month
) {
}

