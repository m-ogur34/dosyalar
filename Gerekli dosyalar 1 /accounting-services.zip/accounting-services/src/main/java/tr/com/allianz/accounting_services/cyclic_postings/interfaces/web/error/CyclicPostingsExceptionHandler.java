package tr.com.allianz.accounting_services.cyclic_postings.interfaces.web.error;


import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import tr.com.allianz.accounting_services.cyclic_postings.application.exception.*;
import tr.com.allianz.accounting_services.shared.api.ApiResponse;
import tr.com.allianz.accounting_services.shared.api.ErrorDetail;

import java.util.List;

@RestControllerAdvice
public class CyclicPostingsExceptionHandler {

    @ExceptionHandler(CyclicPostingProcessNotFoundException.class)
    public ResponseEntity<ApiResponse<List<ErrorDetail>>> handleAlzCyclicPostingProcessNotFoundException(
            CyclicPostingProcessNotFoundException ex
    ) {
        ErrorDetail detail = new ErrorDetail(
                "batchId",
                ex.getBatchId() + " nolu fiş bulunamadı. ");

        ApiResponse<List<ErrorDetail>> body = ApiResponse.error(
                "POSTING_NOT_FOUND",
                detail.message(),
                List.of(detail)
        );

        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(body);
    }

    @ExceptionHandler(value = CyclicPostingProcessAlreadyExistsException.class)
    public ResponseEntity<ApiResponse<List<ErrorDetail>>> handleAlzCyclicPostingProcessAlreadyExistsException(
            CyclicPostingProcessAlreadyExistsException ex
    ) {
        ErrorDetail detail = new ErrorDetail(
                "batchId",
                ex.getBatchId() +" nolu fiş zaten mevcut. ");

        ApiResponse<List<ErrorDetail>> body = ApiResponse.error(
                "CYCLIC_POSTING_PROCESS_ALREADY_EXISTS",
                detail.message(),
                List.of(detail)
        );

        return ResponseEntity.status(HttpStatus.CONFLICT).body(body);
    }

    @ExceptionHandler(CyclicPostingProcessFailedException.class)
    public ResponseEntity<ApiResponse<List<ErrorDetail>>> handleCyclicPostingProcessFailedException(
            CyclicPostingProcessFailedException ex
    ) {
        ErrorDetail detail = new ErrorDetail(
                "batchId",
                "Muhasebeleştirme " + ex.getBatchId() + " nolu fiş için başarısız oldu."
        );

        ApiResponse<List<ErrorDetail>> body = ApiResponse.error(
                "CYCLIC_POSTING_PROCESS_FAILED",
                "Muhasebeleştirme süreci başarısız oldu.",
                List.of(detail)
        );

        return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body(body);
    }


    @ExceptionHandler(value = CyclicAccountMappingAlreadyExistsException.class)
    public ResponseEntity<ApiResponse<List<ErrorDetail>>> handleAlzCyclicAccountMappingAlreadyExistsException(
            CyclicAccountMappingAlreadyExistsException ex
    ) {
        ErrorDetail detail = new ErrorDetail(
                "accountNo",
                ex.getAccountNo() +" nolu hesap önceden eklenmiş. ");

        ApiResponse<List<ErrorDetail>> body = ApiResponse.error(
                "CYCLIC_ACCOUNT_MAPPING_ALREADY_EXISTS",
                detail.message(),
                List.of(detail)
        );

        return ResponseEntity.status(HttpStatus.CONFLICT).body(body);
    }


    @ExceptionHandler(value = CyclicAccountMappingNotFoundException.class)
    public ResponseEntity<ApiResponse<List<ErrorDetail>>> handleAlzCyclicAccountMappingNotFoundException(CyclicAccountMappingNotFoundException ex) {

        ErrorDetail detail = new ErrorDetail(
                "accountNo",
                ex.getAccountNo() + " nolu fiş bulunamadı. ");

        ApiResponse<List<ErrorDetail>> body = ApiResponse.error(
                "CYCLIC_ACCOUNT_MAPPING_NOT_FOUND",
                detail.message(),
                List.of(detail)
        );

        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(body);
    }


}


