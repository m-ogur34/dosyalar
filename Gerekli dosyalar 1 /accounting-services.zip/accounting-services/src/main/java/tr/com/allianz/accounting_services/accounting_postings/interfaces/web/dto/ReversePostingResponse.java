package tr.com.allianz.accounting_services.accounting_postings.interfaces.web.dto;
import java.io.Serializable;
import java.time.LocalDate;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
@RequiredArgsConstructor
@Getter
@Setter
public class ReversePostingResponse implements Serializable {
    private static final long serialVersionUID = 1L;
    private Long batchId;
    private LocalDate postingDate;
    private Long reverseBatchId;
}