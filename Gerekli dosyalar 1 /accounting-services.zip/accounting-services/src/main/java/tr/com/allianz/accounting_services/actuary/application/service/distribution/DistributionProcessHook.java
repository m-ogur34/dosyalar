package tr.com.allianz.accounting_services.actuary.application.service.distribution;

public interface DistributionProcessHook {

    boolean supports(String processId);

    default void beforeExecute(DistributionProcessContext context) {
        // Optional process-specific action.
    }

    default void afterExecute(DistributionProcessContext context) {
        // Optional process-specific action.
    }
}

