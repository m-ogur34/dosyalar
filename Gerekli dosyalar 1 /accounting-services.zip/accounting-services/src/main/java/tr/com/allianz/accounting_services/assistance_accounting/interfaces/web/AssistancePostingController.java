package tr.com.allianz.accounting_services.assistance_accounting.interfaces.web;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import tr.com.allianz.accounting_services.assistance_accounting.application.usecases.CreateAssistancePostingCommand;
import tr.com.allianz.accounting_services.assistance_accounting.application.usecases.CreateAssistancePostingUseCase;
import tr.com.allianz.accounting_services.assistance_accounting.interfaces.web.dto.CreateAssistancePostingRequest;
import tr.com.allianz.accounting_services.shared.api.ApiResponse;

@RestController
@RequestMapping("/api/v1/assistance-posting")
@CrossOrigin
@RequiredArgsConstructor
public class AssistancePostingController {

    private final CreateAssistancePostingUseCase createAssistancePostingUseCase;

    @PostMapping("/create")
    public ResponseEntity<ApiResponse<Long>> createAssistancePosting(
            @RequestBody CreateAssistancePostingRequest request
    ) {
        CreateAssistancePostingCommand command = new CreateAssistancePostingCommand(
                request.getInvoiceNo(),
                request.getInvoiceDate(),
                request.getBatchDescription(),
                request.getAccountingDate(),
                request.getAgencyId(),
                request.getYear(),
                request.getMonth(),
                request.getAccCoverCode(),
                request.getPayableAmount(),
                request.getEbType(),
                request.getProductId(),
                request.getPartitionType()
        );

        Long batchId = createAssistancePostingUseCase.handle(command);
      
        return ResponseEntity.ok(
                ApiResponse.ok(
                        "ASSISTANCE_POSTING_CREATED",
                        "Assistance posting process created successfully",
                        batchId
                )
        );
    }
}
