package tr.com.allianz.accounting_services.actuary.postings.application.usecases;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import tr.com.allianz.accounting_services.actuary.postings.application.port.out.CreateActuaryPostingBatchPort;
import tr.com.allianz.accounting_services.actuary.postings.domain.model.CreateActuaryPostingBatchResult;
@Service
@RequiredArgsConstructor
public class CreateActuaryPostingBatchUseCase {
    private final CreateActuaryPostingBatchPort createActuaryPostingBatchPort;
    public CreateActuaryPostingBatchResult handle(CreateActuaryPostingBatchCommand command) {
        return createActuaryPostingBatchPort.createBatch(command);
    }
}