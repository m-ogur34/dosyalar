/**
 * Assistance Accounting module.
 */
package tr.com.allianz.accounting_services.assistance_accounting;

