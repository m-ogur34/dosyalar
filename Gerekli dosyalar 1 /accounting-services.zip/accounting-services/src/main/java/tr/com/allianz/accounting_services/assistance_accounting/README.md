# Assistance Accounting Module

This module handles assistance accounting specific logic.

## Structure
- `application`: Use cases, ports, and exceptions (Hexagonal Architecture / Clean Architecture).
- `domain`: Core business logic and entities.
- `infrastructure`: Adapters for database, configuration, etc.
- `interfaces`: Web controllers (REST API).

## Shared Components
Common components like `ApiResponse`, `ErrorDetail`, and `BaseApplicationException` are locatedin the `tr.com.allianz.accounting_services.shared` package.
Please use `SharedExceptionHandler` for consistent error handling.

