package tr.com.allianz.accounting_services.actuary.domain.valueobject;

import java.time.LocalDateTime;

public record ActuaryLog(
        Integer year,
        Integer month,
        String processId,
        Integer ruleId,
        ActuaryLogType logType,
        String logText,
        String byUser,
        LocalDateTime dateCreated
) {
}
