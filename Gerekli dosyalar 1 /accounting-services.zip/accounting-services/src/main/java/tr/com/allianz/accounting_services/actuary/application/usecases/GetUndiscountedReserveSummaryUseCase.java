package tr.com.allianz.accounting_services.actuary.application.usecases;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import tr.com.allianz.accounting_services.actuary.application.port.out.LoadUndiscountedReserveSummaryPort;
import tr.com.allianz.accounting_services.actuary.application.port.out.SaveActuaryPeriodStatusPort;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.ActuaryQueryCriteria;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.UndiscountedReserveSummary;
import tr.com.allianz.accounting_services.actuary.infrastructure.persistence.entity.AlzActPeriods;

@Service
@RequiredArgsConstructor
public class GetUndiscountedReserveSummaryUseCase {

    private static final String UNDISCRES_PROCESS_ID = "UNDISCRES";

    private final LoadUndiscountedReserveSummaryPort loadUndiscountedReserveSummaryPort;
    private final SaveActuaryPeriodStatusPort saveActuaryPeriodStatusPort;

    public GetUndiscountedReserveSummaryResponse handle(ActuaryQueryCriteria criteria) {
        if (!UNDISCRES_PROCESS_ID.equalsIgnoreCase(criteria.processId())) {
            throw new IllegalArgumentException("This query only supports processId: " + UNDISCRES_PROCESS_ID);
        }

        UndiscountedReserveSummary summary = loadUndiscountedReserveSummaryPort.load(criteria.year(), criteria.month());
        AlzActPeriods period = saveActuaryPeriodStatusPort.getOrCreateInProgress(
                UNDISCRES_PROCESS_ID,
                criteria.year(),
                criteria.month()
        );

        return new GetUndiscountedReserveSummaryResponse(summary, period);
    }
}
