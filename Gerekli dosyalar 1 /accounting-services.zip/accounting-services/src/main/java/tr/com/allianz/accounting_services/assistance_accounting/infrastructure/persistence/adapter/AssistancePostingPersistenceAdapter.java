package tr.com.allianz.accounting_services.assistance_accounting.infrastructure.persistence.adapter;

import java.sql.Types;
import java.util.Map;

import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Component;
import tr.com.allianz.accounting_services.assistance_accounting.application.port.out.CreateAssistancePostingPort;
import tr.com.allianz.accounting_services.assistance_accounting.application.usecases.CreateAssistancePostingCommand;

@Component
@RequiredArgsConstructor
public class AssistancePostingPersistenceAdapter implements CreateAssistancePostingPort {

    private final JdbcTemplate jdbcTemplate;

    @Override
    public Long createAssistancePosting(CreateAssistancePostingCommand command) {
        SimpleJdbcCall simpleJdbcCall = createSimpleJdbcCall()
                .withSchemaName("CUSTOMER")
                .withCatalogName("ALZ_ACC_POSTING_UTILS")
                .withProcedureName("create_assistance_posting_batch")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlParameter("p_invoice_no", java.sql.Types.VARCHAR),
                        new SqlParameter("p_invoice_date", java.sql.Types.DATE),
                        new SqlParameter("p_batch_description", java.sql.Types.VARCHAR),
                        new SqlParameter("p_accounting_date", java.sql.Types.DATE),
                        new SqlParameter("p_agency_id", java.sql.Types.NUMERIC),
                        new SqlParameter("p_year", java.sql.Types.NUMERIC),
                        new SqlParameter("p_month", java.sql.Types.NUMERIC),
                        new SqlParameter("p_acc_cover_code", java.sql.Types.VARCHAR),
                        new SqlParameter("p_payable_amount", java.sql.Types.NUMERIC),
                        new SqlParameter("p_eb_type", java.sql.Types.NUMERIC),
                        new SqlParameter("p_product_id", Types.VARCHAR),
                        new SqlParameter("p_partition_type", java.sql.Types.VARCHAR),
                        new SqlOutParameter("p_batch_id", java.sql.Types.NUMERIC)
                );

        Long ebTypeNum = null;
        if (command.getEbType() != null && !command.getEbType().trim().isEmpty()) {
            try {
                ebTypeNum = Long.valueOf(command.getEbType().trim());
            } catch (NumberFormatException e) {
                // Ignore or handle
            }
        }

        MapSqlParameterSource inparams = new MapSqlParameterSource()
                .addValue("p_invoice_no", command.getInvoiceNo(), java.sql.Types.VARCHAR)
                .addValue("p_invoice_date", command.getInvoiceDate() != null ? java.sql.Date.valueOf(command.getInvoiceDate()) : null, java.sql.Types.DATE)
                .addValue("p_batch_description", command.getBatchDescription(), java.sql.Types.VARCHAR)
                .addValue("p_accounting_date", command.getAccountingDate() != null ? java.sql.Date.valueOf(command.getAccountingDate()) : null, java.sql.Types.DATE)
                .addValue("p_agency_id", command.getAgencyId(), java.sql.Types.NUMERIC)
                .addValue("p_year", command.getYear(), java.sql.Types.NUMERIC)
                .addValue("p_month", command.getMonth(), java.sql.Types.NUMERIC)
                .addValue("p_acc_cover_code", command.getAccCoverCode(), java.sql.Types.VARCHAR)
                .addValue("p_payable_amount", command.getPayableAmount(), java.sql.Types.NUMERIC)
                .addValue("p_eb_type", ebTypeNum, java.sql.Types.NUMERIC)
                .addValue("p_product_id", command.getProductId(), java.sql.Types.VARCHAR)
                .addValue("p_partition_type", command.getPartitionType(), java.sql.Types.VARCHAR);

        Map<String, Object> out = simpleJdbcCall.execute(inparams);
        return ((Number) out.get("p_batch_id")).longValue();
    }

    protected SimpleJdbcCall createSimpleJdbcCall() {
        return new SimpleJdbcCall(jdbcTemplate);
    }
}
