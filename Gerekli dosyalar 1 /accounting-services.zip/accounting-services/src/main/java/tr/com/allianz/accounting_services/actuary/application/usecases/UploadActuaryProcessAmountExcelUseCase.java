package tr.com.allianz.accounting_services.actuary.application.usecases;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;
import tr.com.allianz.accounting_services.actuary.application.port.out.ParseActuaryProcessAmountExcelPort;
import tr.com.allianz.accounting_services.actuary.application.port.out.SaveActuaryProcessAmountPort;
import tr.com.allianz.accounting_services.actuary.application.service.ActuaryLogService;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.ActuaryProcessAmount;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.ActuaryProcessAmountExcelRow;

import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional
public class UploadActuaryProcessAmountExcelUseCase {

    private final ParseActuaryProcessAmountExcelPort parseActuaryProcessAmountExcelPort;
    private final SaveActuaryProcessAmountPort saveActuaryProcessAmountPort;
    private final ActuaryLogService actuaryLogService;

    public int handle(MultipartFile file, Integer year, Integer month, String byUser) {
        List<ActuaryProcessAmount> amounts = parseActuaryProcessAmountExcelPort.parse(file)
                .stream()
                .map(row -> toProcessAmount(row, year, month))
                .toList();

        saveActuaryProcessAmountPort.saveAll(amounts);

        actuaryLogService.logExcelUpload(
                null,
                year,
                month,
                amounts.size(),
                byUser
        );

        return amounts.size();
    }

    private ActuaryProcessAmount toProcessAmount(
            ActuaryProcessAmountExcelRow row,
            Integer year,
            Integer month
    ) {
        if ("RISKADJRTO".equals(row.processId())) {
            return new ActuaryProcessAmount(
                    year, month, row.processId(), row.ruleId(),
                    null, null, null,
                    null, null, null,
                    null, null, null,
                    null, null, null,
                    row.grossCyAmountRate(),
                    row.reCyAmountRate(),
                    row.netCyAmountRate(),
                    row.grossPyAmountRate(),
                    row.rePyAmountRate(),
                    row.netPyAmountRate(),
                    row.ifrsCyGrossRate(),
                    row.ifrsCyReRate(),
                    row.ifrsCyNetRate(),
                    row.ifrsPyGrossRate(),
                    row.ifrsPyReRate(),
                    row.ifrsPyNetRate()
            );
        }

        return new ActuaryProcessAmount(
                year, month, row.processId(), row.ruleId(),
                row.grossCyAmount(), row.reCyAmount(), row.netCyAmount(),
                row.grossPyAmount(), row.rePyAmount(), row.netPyAmount(),
                row.ifrsCyGross(), row.ifrsCyRe(), row.ifrsCyNet(),
                row.ifrsPyGross(), row.ifrsPyRe(), row.ifrsPyNet(),
                null, null, null, null, null, null,
                null, null, null, null, null, null
        );
    }

    public int handle(MultipartFile file, Integer year, Integer month) {
        return handle(file, year, month, "SYSTEM");
    }
}

