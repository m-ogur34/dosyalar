package tr.com.allianz.accounting_services.actuary.postings.application.usecases;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import tr.com.allianz.accounting_services.actuary.postings.application.port.out.LoadActuaryPostingProductsPort;
import tr.com.allianz.accounting_services.actuary.postings.domain.model.ActuaryPostingProduct;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ListActuaryPostingProductsUseCase {

    private final LoadActuaryPostingProductsPort loadActuaryPostingProductsPort;

    public List<ActuaryPostingProduct> handle(String branchId) {
        return loadActuaryPostingProductsPort.loadByBranchId(branchId);
    }
}

