package tr.com.allianz.accounting_services.assistance_accounting.application.usecases;

import tr.com.allianz.accounting_services.assistance_accounting.application.port.out.LoadAssistanceProductPort;
import tr.com.allianz.accounting_services.assistance_accounting.domain.valueobject.AssistanceProduct;

import java.util.List;

public class ListAssistanceProductUseCase {

    private final LoadAssistanceProductPort loadAssistanceProductPort;

    public ListAssistanceProductUseCase(LoadAssistanceProductPort loadAssistanceProductPort) {
        this.loadAssistanceProductPort = loadAssistanceProductPort;
    }

    public List<AssistanceProduct> handle(String accCoverCode) {
        return loadAssistanceProductPort.loadAssistanceProducts(accCoverCode);
    }
}
