package tr.com.allianz.accounting_services.actuary.interfaces.web;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import org.springframework.http.MediaType;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import tr.com.allianz.accounting_services.actuary.application.service.ActuaryLogService;
import tr.com.allianz.accounting_services.actuary.application.usecases.SaveActuaryProcessAmountUseCase;
import tr.com.allianz.accounting_services.actuary.application.usecases.UploadActuaryProcessAmountExcelUseCase;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.ActuaryProcessAmount;
import tr.com.allianz.accounting_services.actuary.interfaces.web.dto.SaveActuaryProcessAmountRequestDto;
import tr.com.allianz.accounting_services.actuary.support.ExcelFileValidationSupport;
import tr.com.allianz.accounting_services.shared.api.ApiResponse;

import java.security.Principal;

@RestController
@RequestMapping("/api/v1/actuary-process-amounts")
@CrossOrigin
@RequiredArgsConstructor
@Validated
public class ActuaryProcessAmountController {

    private final SaveActuaryProcessAmountUseCase saveActuaryProcessAmountUseCase;
    private final UploadActuaryProcessAmountExcelUseCase uploadActuaryProcessAmountExcelUseCase;
    private final ActuaryLogService actuaryLogService;

    @PostMapping
    public ResponseEntity<ApiResponse<Void>> save(
            @Valid @RequestBody SaveActuaryProcessAmountRequestDto request,
            Principal principal
    ) {
        String username = principal != null ? principal.getName() : "SYSTEM";
        
        try {
            ActuaryProcessAmount processAmount = new ActuaryProcessAmount(
                    request.year(),
                    request.month(),
                    request.processId(),
                    request.ruleId(),
                    request.grossCyAmount(),
                    request.reCyAmount(),
                    request.netCyAmount(),
                    request.grossPyAmount(),
                    request.rePyAmount(),
                    request.netPyAmount(),
                    request.ifrsCyGross(),
                    request.ifrsCyRe(),
                    request.ifrsCyNet(),
                    request.ifrsPyGross(),
                    request.ifrsPyRe(),
                    request.ifrsPyNet(),
                    request.grossCyAmountRate(),
                    request.reCyAmountRate(),
                    request.netCyAmountRate(),
                    request.grossPyAmountRate(),
                    request.rePyAmountRate(),
                    request.netPyAmountRate(),
                    request.ifrsCyGrossRate(),
                    request.ifrsCyReRate(),
                    request.ifrsCyNetRate(),
                    request.ifrsPyGrossRate(),
                    request.ifrsPyReRate(),
                    request.ifrsPyNetRate()
            );

            saveActuaryProcessAmountUseCase.handle(processAmount, username);

            return ResponseEntity.ok(ApiResponse.ok("SUCCESS", "Actuary process amount saved successfully", null));
        } catch (Exception e) {
            actuaryLogService.logError(
                    request.processId(),
                    request.year(),
                    request.month(),
                    "Amount save failed: " + e.getMessage(),
                    username
            );
            throw e;
        }
    }

    @PostMapping(value = "/upload-excel", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<ApiResponse<Void>> uploadExcel(
            @RequestPart("file") MultipartFile file,
            @RequestParam("year") @NotNull Integer year,
            @RequestParam("month") @NotNull @Min(1) @Max(12) Integer month,
            Principal principal
    ) {
        String username = principal != null ? principal.getName() : "SYSTEM";
        
        if (file == null || file.isEmpty()) {
            throw new IllegalArgumentException("Excel dosyasi secilmesi zorunludur");
        }

        validateExcelFile(file);

        try {
            uploadActuaryProcessAmountExcelUseCase.handle(file, year, month, username);
            
            return ResponseEntity.ok(ApiResponse.ok("SUCCESS", "Excel dosyasi basariyla yuklendi", null));
        } catch (Exception e) {
            actuaryLogService.logError(
                    null,
                    year,
                    month,
                    "Excel upload failed: " + e.getMessage(),
                    username
            );
            throw e;
        }
    }

    private void validateExcelFile(MultipartFile file) {
        ExcelFileValidationSupport.validateExcelType(
                file,
                "Sadece Excel formatinda dosya yuklenebilir (.xlsx, .xls)",
                "Sadece Excel formatinda dosya yuklenebilir (.xlsx, .xls)"
        );
    }
}

