package tr.com.allianz.accounting_services.actuary.postings.application.exception;

import org.springframework.http.HttpStatus;
import tr.com.allianz.accounting_services.shared.exception.BaseApplicationException;

public class ActuaryPostingBatchInfoFailedException extends BaseApplicationException {

    public ActuaryPostingBatchInfoFailedException(String detail) {
        super(
                "ACTUARY_POSTING_BATCH_INFO_FAILED",
                "Actuary posting batch info alınamadı.",
                detail,
                HttpStatus.INTERNAL_SERVER_ERROR
        );
    }
}

