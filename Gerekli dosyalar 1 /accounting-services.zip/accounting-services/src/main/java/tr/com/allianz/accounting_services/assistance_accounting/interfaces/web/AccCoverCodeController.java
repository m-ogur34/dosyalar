package tr.com.allianz.accounting_services.assistance_accounting.interfaces.web;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import tr.com.allianz.accounting_services.assistance_accounting.application.usecases.ListAccCoverCodeUseCase;
import tr.com.allianz.accounting_services.assistance_accounting.domain.valueobject.AccCoverCode;
import tr.com.allianz.accounting_services.shared.api.ApiResponse;

import java.util.List;

@RestController
@RequestMapping("/api/v1/acc-cover-code")
@CrossOrigin
@RequiredArgsConstructor
public class AccCoverCodeController {

    private final ListAccCoverCodeUseCase listAccCoverCodeUseCase;

    @GetMapping
    public ResponseEntity<ApiResponse<List<AccCoverCode>>> listAccCoverCodes() {
        List<AccCoverCode> result = listAccCoverCodeUseCase.handle();
        return ResponseEntity.ok(ApiResponse.ok("SUCCESS", "List retrieved successfully", result));
    }
}

