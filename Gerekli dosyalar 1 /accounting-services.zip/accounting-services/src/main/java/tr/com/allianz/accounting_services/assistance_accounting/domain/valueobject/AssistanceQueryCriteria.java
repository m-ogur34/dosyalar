package tr.com.allianz.accounting_services.assistance_accounting.domain.valueobject;

import java.math.BigDecimal;

public record AssistanceQueryCriteria(
    BigDecimal totalAmountParam, // p_tutar
    String accCoverCode, // p_Acc_cover_code
    Integer year, // p_year
    Integer month, // p_month
    Integer isIndustrial, // p_is_industrial
    String productId, // p_product_id
    String partitionType, // p_partition_Type
    Long companyId // for calculations
) {}
