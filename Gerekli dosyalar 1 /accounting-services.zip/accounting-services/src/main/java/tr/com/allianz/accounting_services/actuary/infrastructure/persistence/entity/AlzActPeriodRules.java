package tr.com.allianz.accounting_services.actuary.infrastructure.persistence.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.ActuaryPeriodRuleStatus;

@Entity
@Table(name = "ALZ_ACT_PERIOD_RULES")
@IdClass(AlzActPeriodRulesId.class)
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class AlzActPeriodRules {

    @Id
    @Column(name = "PROCESS_ID", length = 10)
    private String processId;

    @Id
    @Column(name = "YEAR", precision = 4)
    private Integer year;

    @Id
    @Column(name = "MONTH", precision = 2)
    private Integer month;

    @Id
    @Column(name = "RULE_ID", precision = 5)
    private Integer ruleId;

    @Column(name = "STATUS", length = 200)
    private String status;

    public ActuaryPeriodRuleStatus getStatusEnum() {
        return ActuaryPeriodRuleStatus.fromValue(this.status);
    }

    public void setStatusEnum(ActuaryPeriodRuleStatus status) {
        this.status = status.getValue();
    }
}

