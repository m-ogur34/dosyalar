#!/bin/sh
files=$(find /usr/share/nginx/html/${CONTEXT_PATH}/*.js -type f)

for i in $files
 do
   echo $i
    sed -i 's,__API_URL__,'"${API_URL}"',g' $i
    sed -i 's,__DEPLOY_URL__,'"${DEPLOY_URL}"',g' $i
    sed -i 's,__CAS_URL__,'"${CAS_URL}"',g' $i
done