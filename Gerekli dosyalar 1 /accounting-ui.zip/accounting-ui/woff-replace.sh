
#!/bin/bash
old_filename="dist/browser/media/Allianz-Icons-3HGPUV7H.woff2"
new_filename="dist/browser/media/Allianz-Icons.woff2"
mv "$old_filename" "$new_filename"

css_files=$(find dist/browser/*.css -type f)
for j in $css_files
do
   sed -i 's|./media/Allianz-Icons-3HGPUV7H.woff2|./media/Allianz-Icons.woff2|g' $j
done
