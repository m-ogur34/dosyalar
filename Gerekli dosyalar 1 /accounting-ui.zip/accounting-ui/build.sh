docker build -t harbor.allianz-tr.local/allianz-snapshot/accounting:$1 .
docker push harbor.allianz-tr.local/allianz-snapshot/accounting:$1
