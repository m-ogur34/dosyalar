import { ApplicationConfig, provideBrowserGlobalErrorListeners } from '@angular/core';
import { provideRouter } from '@angular/router';
import { provideAnimations } from '@angular/platform-browser/animations';
import { routes } from './app.routes';
import { provideTranslateService } from '@ngx-translate/core';
import { provideTranslateHttpLoader } from "@ngx-translate/http-loader";
import {HTTP_INTERCEPTORS, provideHttpClient, withInterceptorsFromDi} from "@angular/common/http";
import { NxMessageToastService } from '@aposin/ng-aquila/message';
import { NX_DATE_LOCALE } from "@aposin/ng-aquila/datefield";
import { CookieService } from 'ngx-cookie-service';
import { environment } from '../environments/environment';
import { CurrencyPipe, DatePipe } from '@angular/common';
import { TruncatePipe } from './core/pipe/truncate.pipe.';
import { SearchListPipe } from './core/pipe/search-list.pipe';
import { SpinnerService } from './core/services/spinner.service';
import { AuthInterceptor } from './core/interceptor/auth.interceptor';
import { HttpResponseInterceptor } from './core/interceptor/http-response.interceptor';
import { DEFAULT_TIMEOUT } from './core/interceptor/jwt.interceptor';
import { SessionStorageService } from './core/services/session-storage.service';
import { BaseRestService } from './services/base-rest.service';


export const PROVIDERS = [
  { provide: NX_DATE_LOCALE, useValue: "tr-TR" },
  CookieService,
  BaseRestService,
  CurrencyPipe,
  DatePipe,
  TruncatePipe,
  SearchListPipe,
  {
    provide: "environment.apiURL",
    useValue: environment.apiURL,
  },
  {
    provide: SpinnerService,
    useClass: SpinnerService,
  },
  {
    provide: "environment",
    useValue: environment,
  },
  {
    provide: HTTP_INTERCEPTORS,
    useClass: AuthInterceptor,
    multi: true
  },
  {
    provide: HTTP_INTERCEPTORS,
    useClass: HttpResponseInterceptor,
    multi: true,
  },
  // //{ provide: HTTP_INTERCEPTORS, useClass: JWTInterceptor, multi: true },
  //{ provide: HTTP_INTERCEPTORS, useClass: SpinnerInterceptor, multi: true },
  { provide: DEFAULT_TIMEOUT, useValue: 100000 },
  {
    provide: SessionStorageService,
    useClass: SessionStorageService,
  },
  provideHttpClient(withInterceptorsFromDi())
];


export const appConfig: ApplicationConfig = {
  providers: [
    PROVIDERS,
    provideBrowserGlobalErrorListeners(),
    provideAnimations(),
    provideHttpClient(withInterceptorsFromDi()),
    provideTranslateService({
      loader: provideTranslateHttpLoader({
        prefix: environment.assetsBasePath + 'i18n/',
        suffix: '.json?v=' + environment.version
      }),
      fallbackLang: 'tr',
      lang: 'tr'
    }),
    provideRouter(routes),
    NxMessageToastService
  ]
};



