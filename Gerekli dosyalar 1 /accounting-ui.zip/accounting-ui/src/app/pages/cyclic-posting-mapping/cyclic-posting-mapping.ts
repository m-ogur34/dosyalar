import { NxDialogService, NxModalRef } from "@allianz/ng-aquila/modal";
import { Component, OnInit, inject, signal, DestroyRef, ViewChild, TemplateRef } from "@angular/core";
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { SortEvent } from "@aposin/ng-aquila/table";
import { TranslateDirective, TranslatePipe, TranslateService } from "@ngx-translate/core";
import { DateFormatEnum } from "../../core/common/enum/date-format.enum";
import { DynamicTableColumnModel } from "../../core/models/dynamic-table-column.model";
import { CyclicPostingProcessService } from "../../services/cyclic-posting-process.service";
//import { AlertifyService } from  "../../core/services/alertify-service"
import { PageTitleComponent } from "../core/page-title/page-title.component";
import { CustomPanelComponent } from "../core/custom-panel/custom-panel.component";
import { NoRecordsComponent } from "../core/no-records/no-records.component";
import { CustomPaginationComponent } from "../core/custom-pagination/custom-pagination.component";
import { TableColumnsGenericComponent } from "../core/table-columns-generic/table-columns-generic.component";
import { TableHeadersGenericComponent } from "../core/table-headers-generic/table-headers-generic.component";
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from "@angular/forms";
import {  NxFormfieldModule,NxFormfieldComponent } from "@allianz/ng-aquila/formfield";
import { NxHeaderCellDirective, NxSortDirective, NxSortHeaderComponent } from "@allianz/ng-aquila/table";
import { NgStyle, SlicePipe } from "@angular/common";
import { SearchListPipe } from "../../core/pipe/search-list.pipe";
import { MODULES } from "../../shared/shared.module";
import { NxGridModule, NxRowComponent } from "@aposin/ng-aquila/grid";
import { NxLabelModule } from "@allianz/ng-aquila/base";
import { NxInputModule } from "@allianz/ng-aquila/input";
import { CyclicPostingMappingService } from "../../services/cyclic-posting-mapping.service";
import { AlertifyService } from "../../core/services/alertify-service";
import { ExcelService } from "../../core/services/excel-service";
import { ExportDataRequestModel } from "../../core/models/export-data-request-model";
import { SpinnerService } from '../../core/services/spinner.service';

@Component({
  selector: 'app-cyclic-posting-mapping',
  templateUrl: './cyclic-posting-mapping.html',
  styleUrls: ['./cyclic-posting-mapping.scss'],
  imports: [PageTitleComponent,CustomPaginationComponent,NoRecordsComponent,CustomPaginationComponent,
    TableHeadersGenericComponent,FormsModule,ReactiveFormsModule,TableColumnsGenericComponent,
    NxFormfieldModule,NxHeaderCellDirective,NxSortDirective,CustomPanelComponent,
    ...MODULES,TranslatePipe,NgStyle,NgStyle,   
     NxGridModule,NxLabelModule,NxInputModule,NxRowComponent,
     SearchListPipe,SlicePipe 
  ],
})
export class CyclicPostingMapping implements OnInit {

  // Fields
  cols: DynamicTableColumnModel[] = [];
  dataList: any[] = [];
  dateFormatEnum = DateFormatEnum;
  page = 1;
  pageSize = 5;
    // Signal-based reactive state
  searchText = signal<string>('');
  value1 = '';
  selectedItem: any = null;
  modalTitle = 'Yeni Mapping Ekle';
  mappingFormGroup!: FormGroup;
  searchFormGroup!: FormGroup;
  addDialogRef: any;
  deleteDialogRef: any;

  @ViewChild('modalAddMapping') modalAddMapping!: TemplateRef<any>;
  @ViewChild('modalDeleteConfirm') modalDeleteConfirm!: TemplateRef<any>;

  constructor(
    private translate: TranslateService,
    private alertifyService: AlertifyService,
    private excelService: ExcelService,
    private cyclicPostingMappingService: CyclicPostingMappingService,
    private fb: FormBuilder,
    private dialogService: NxDialogService,
    private spinnerService: SpinnerService
  ) {}

  ngOnInit(): void {
    const accountNoLabel = this.translate.instant('mapping.accountNo');
    const cyclicAccountNoLabel = this.translate.instant('mapping.cyclicAccountNo');
    this.getCols(accountNoLabel, cyclicAccountNoLabel);
    this.getData();
    this.mappingFormGroup = this.fb.group({
      accountNo: ['', Validators.required],
      cyclicAccountNo: ['', Validators.required]
    });
    this.searchFormGroup = this.fb.group({
      accountNo: ['']
    });
  }

  // Modal & CRUD Methods
  showCreateDialog() {
    this.modalTitle = 'Yeni Eşleştirme Ekle';
    if (this.addDialogRef) {
      this.addDialogRef.close();
      this.addDialogRef = undefined;
      this.mappingFormGroup.reset();
    } else {
      if (!this.modalAddMapping) {
        console.error('Add template reference not found');
        return;
      }
      this.addDialogRef = this.dialogService.open(this.modalAddMapping, {
        showCloseIcon: true
      });
    }
  }

  toggleCyclicMappingModal() {
    this.showCreateDialog();
  }

  addCyclicPostingMapping() {
    if (this.mappingFormGroup.invalid) {
      this.alertifyService.error('Hesap No ve Devir Hesap No zorunlu!');
      return;
    }
    const formValues = this.mappingFormGroup.value;
    this.spinnerService.showSpinner(true);
    this.cyclicPostingMappingService.createCyclicPostingMapping(formValues)
      .subscribe({
        next: (res) => {
          if (res.uiMessages && res.uiMessages.errors && res.uiMessages.errors.length !== 0) {
            let errorMessage = res.uiMessages.errors[0].message
            this.alertifyService.error(errorMessage);
            this.spinnerService.showSpinner(false);
            return
          }
          this.alertifyService.success('Eşleştirme başarıyla eklendi');
          this.getData();
          this.showCreateDialog();
          this.spinnerService.showSpinner(false);
        },
        error: (err) => {
          this.alertifyService.error('Eşleştirme eklenemedi.Bilinmeyen bir hata oluştu.');
          this.spinnerService.showSpinner(false);
        }
      });
  }

  showDeleteDialog(item: any) {
    this.selectedItem = item;
    if (this.deleteDialogRef) {
      this.deleteDialogRef.close();
      this.deleteDialogRef = undefined;
      this.selectedItem = null;
    } else {
      if (!this.modalDeleteConfirm) {
        console.error('Delete template reference not found');
        return;
      }
      this.deleteDialogRef = this.dialogService.open(this.modalDeleteConfirm, {
        showCloseIcon: true
      });
    }
  }

  toggleDeleteModal() {
    this.showDeleteDialog(null);
  }

  deleteCyclicPostingMapping() {
    if (!this.selectedItem) return;
    this.spinnerService.showSpinner(true);
    this.cyclicPostingMappingService.deleteCyclicPostingMapping(this.selectedItem.accountNo)
      .subscribe({
        next: () => {
          this.alertifyService.success('Kayıt başarıyla silindi');
          this.getData();
          this.showDeleteDialog(null);
          this.spinnerService.showSpinner(false);
        },
        error: () => {
          this.alertifyService.error('Kayıt silinemedi');
          this.spinnerService.showSpinner(false);
        }
      });
  }

  // Data & Table Methods
  getData() {
    this.spinnerService.showSpinner(true);
    this.cyclicPostingMappingService.getCyclicPostingMappingList().subscribe({
      next: (response:any) => {
        let arr = response?.data?.alzCyclicAccountMappingList;
        if (!Array.isArray(arr)) {
          arr = [];
        }
        this.dataList = arr;
        this.spinnerService.showSpinner(false);
      },
      error: () => {
        this.dataList = [];
        this.spinnerService.showSpinner(false);
      }
    });
  }

  search(accountNo: string) {
    if (!accountNo || accountNo.trim() === '') {
      this.getData();
      return;
    }
    this.spinnerService.showSpinner(true);
    this.cyclicPostingMappingService.getCyclicPostingMappingList().subscribe({
      next: (response: any) => {
        let arr = response?.data?.alzCyclicAccountMappingList;
        if (!Array.isArray(arr)) {
          arr = [];
        }
        this.dataList = arr.filter((item: any) =>
          item.accountNo && item.accountNo.toString().includes(accountNo)
        );
        this.page=1;
        this.spinnerService.showSpinner(false);
      },
      error: (err) => {
        this.dataList = [];
        this.spinnerService.showSpinner(false);
      }
    });
  }

  clear() {
    this.dataList = [];
  }

  sortTable(sort: SortEvent) {
    if (sort.direction == 'asc') {
      this.dataList.sortBy(sort.active);
    } else {
      this.dataList = this.dataList.sortByDesc(sort.active);
    }
  }

  getValue(obj: any, path: string) {
    return path.split('.').reduce((acc, k) => acc?.[k], obj);
  }

  exportExcel() {
    try {
      const request = new ExportDataRequestModel();
      // Use a meaningful file name, e.g. translated title or fallback
      request.fileName = this.translate.instant('mapping.exportFileName') || 'CyclicPostingMapping';
      request.data = this.dataList;
      // Ensure columns have at least field and header
      request.columns = (this.cols ?? []).map(col => ({
        field: col.field,
        header: col.header,
        ...col
      }));
      this.excelService.exportExcelWithTable(request);
    } catch (e: any) {
      this.alertifyService.error(e?.toString?.() ?? 'Export error');
    }
  }

  // Column Definition
  private getCols(accountNoLabel = 'Hesap No', cyclicAccountNoLabel = 'Devir Hesap No') {
    this.cols = [
      {
        field: 'accountNo',
        header: 'Hesap No',
      },
      {
        field: 'cyclicAccountNo',
        header: 'Devir Hesap No',
      },
    ];
  }
}
