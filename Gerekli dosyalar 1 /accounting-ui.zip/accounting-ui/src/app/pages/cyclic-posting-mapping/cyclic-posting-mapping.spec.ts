import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CyclicPostings } from './cyclic-postings';

describe('CyclicPostings', () => {
  let component: CyclicPostings;
  let fixture: ComponentFixture<CyclicPostings>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CyclicPostings]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CyclicPostings);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
