import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CyclicPostingProcess } from './cyclic-posting-process';

describe('CyclicPostingProcess', () => {
  let component: CyclicPostingProcess;
  let fixture: ComponentFixture<CyclicPostingProcess>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CyclicPostingProcess]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CyclicPostingProcess);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
