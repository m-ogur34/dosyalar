import { NxDialogService, NxModalRef } from "@allianz/ng-aquila/modal";
import { Component, OnInit, inject, signal, DestroyRef, ViewChild, TemplateRef } from "@angular/core";
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { SortEvent } from "@aposin/ng-aquila/table";
import { TranslateDirective, TranslatePipe, TranslateService } from "@ngx-translate/core";
import { DateFormatEnum } from "../../core/common/enum/date-format.enum";
import { DynamicTableColumnModel } from "../../core/models/dynamic-table-column.model";
import { CyclicPostingProcessService } from "../../services/cyclic-posting-process.service";
//import { AlertifyService } from  "../../core/services/alertify-service"
import { PageTitleComponent } from "../core/page-title/page-title.component";
import { CustomPanelComponent } from "../core/custom-panel/custom-panel.component";
import { NoRecordsComponent } from "../core/no-records/no-records.component";
import { CustomPaginationComponent } from "../core/custom-pagination/custom-pagination.component";
import { TableColumnsGenericComponent } from "../core/table-columns-generic/table-columns-generic.component";
import { TableHeadersGenericComponent } from "../core/table-headers-generic/table-headers-generic.component";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import {  NxFormfieldModule,NxFormfieldComponent } from "@allianz/ng-aquila/formfield";
import { NxHeaderCellDirective, NxSortDirective, NxSortHeaderComponent } from "@allianz/ng-aquila/table";
import { NgStyle, SlicePipe } from "@angular/common";
import { SearchListPipe } from "../../core/pipe/search-list.pipe";
import { MODULES } from "../../shared/shared.module";
import { NxGridModule, NxRowComponent } from "@aposin/ng-aquila/grid";
import { NxLabelModule } from "@allianz/ng-aquila/base";
import { NxInputModule } from "@allianz/ng-aquila/input";
import { AlertifyService } from "../../core/services/alertify-service";
import { SpinnerService } from '../../core/services/spinner.service';


@Component({
  selector: 'app-cyclic-posting-process',
  imports: [PageTitleComponent,CustomPanelComponent,NoRecordsComponent,CustomPaginationComponent,
    TableHeadersGenericComponent,FormsModule,ReactiveFormsModule,TableColumnsGenericComponent,
    NxFormfieldModule,NxHeaderCellDirective,NxSortDirective,
    ...MODULES,TranslatePipe,NgStyle,NgStyle,   
     NxGridModule,NxLabelModule,NxInputModule,NxRowComponent,
     SearchListPipe,SlicePipe
  ],
  templateUrl:  "./cyclic-posting-process.html",
  styleUrls: ["./cyclic-posting-process.scss"],
})
export class CyclicPostingProcess implements OnInit {

  // ...fields, constructor, lifecycle...
  // Fields
  cols?: DynamicTableColumnModel[];
  dataList: any[] = [];
  dateFormatEnum = DateFormatEnum;
  page = 1;
  pageSize = 5;
  searchBatchId = signal<string>('');
  searchCyclicBatchId = signal<string>('');
  searchText = signal<string>('');
  newProcess: any = {
    batchIdList: '',
    postingDate: new Date(new Date().getFullYear(), 0, 1).toLocaleDateString('en-CA')
  };
  selectedItem: any = null;
  templateDialogRef?: NxModalRef<any>;
  addDialogRef?: NxModalRef<any>;
  deleteDialogRef?: NxModalRef<any>;
  selectedStatus: string | null = null;

  // ViewChilds
  @ViewChild('modalAddPostingProcess') templateRef!: TemplateRef<any>;
  @ViewChild('modalDeleteConfirm') deleteTemplateRef!: TemplateRef<any>;

  // Constructor
  constructor(
    private readonly dialogService: NxDialogService,
    private translate: TranslateService,
    private cyclicPostingProcessService: CyclicPostingProcessService,
    private destroyRef: DestroyRef,
    private alertifyService:AlertifyService,
    private spinnerService: SpinnerService
  ) {}

  // Lifecycle
  ngOnInit(): void {
    this.getCols();
    this.getData();
  }

  // Methods
  processAccounting(item: any): void {
    
    this.spinnerService.showSpinner(true);
    try {
      this.cyclicPostingProcessService.processAccounting(item)
        .pipe(takeUntilDestroyed(this.destroyRef))
        .subscribe({
          next: (res: any) => {
            if (res?.uiMessages?.errors?.length) {
              const errorMsg = res.uiMessages.errors[0].message || 'Muhasebeleştirme sırasında hata oluştu.';
              this.alertifyService.error(errorMsg);
            } else {
              this.alertifyService.success('Kayıt başarıyla muhasebeleştirildi.');
              this.getData();
            }
            this.spinnerService.showSpinner(false);
          },
          error: (err) => {
            this.alertifyService.error('Muhasebeleştirme işlemi başarısız.');
            this.spinnerService.showSpinner(false);
          }
        });
    } catch (e) {
      this.spinnerService.showSpinner(false);
      throw e;
    }
  }

  // Methods
  processAll() {
    this.spinnerService.showSpinner(true);
    try {
      const itemsToProcess = this.dataList.filter(item => item.processStatus === 'CREATED');
      if (itemsToProcess.length === 0) {
        this.alertifyService?.info?.('Muhasebeleştirilecek uygun kayıt yok.');
        this.spinnerService.showSpinner(false);
        return;
      }
      // Toplu backend isteği: items dizisiyle gönder
      this.cyclicPostingProcessService.processAccountingAll(itemsToProcess)
        .pipe(takeUntilDestroyed(this.destroyRef))
        .subscribe({
          next: (res: any) => {
            if (res?.uiMessages?.errors?.length) {
              const errorMsg = res.uiMessages.errors[0].message || 'Toplu muhasebeleştirme sırasında hata oluştu.';
              this.alertifyService.error(errorMsg);
            } else {
              this.alertifyService.success('Tüm uygun kayıtlar başarıyla muhasebeleştirildi.');
              this.getData();
            }
            this.spinnerService.showSpinner(false);
          },
          error: (err) => {
            this.alertifyService.error('Toplu muhasebeleştirme işlemi başarısız.');
            this.spinnerService.showSpinner(false);
          }
        });
    } catch (e) {
      this.spinnerService.showSpinner(false);
      throw e;
    }
  }

  showDeleteDialog(item: any) {
    this.selectedItem = item;
    this.toggleDeleteModal();
  }

  toggleDeleteModal() {
    if (this.deleteDialogRef) {
      this.deleteDialogRef.close();
      this.deleteDialogRef = undefined;
      this.selectedItem = null;
    } else {
      if (!this.deleteTemplateRef) {
        console.error('Delete template reference not found');
        return;
      }
      this.deleteDialogRef = this.dialogService.open(this.deleteTemplateRef, {
        showCloseIcon: true
      });
    }
  }

  deleteCyclicPostingProcess() {
    if (!this.selectedItem) return;
    this.spinnerService.showSpinner(true);
    this.cyclicPostingProcessService.deleteCyclicPostingProcess(this.selectedItem.batchId)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (res: any) => {
          if (res?.uiMessages?.errors?.length) {
            const errorMsg = res.uiMessages.errors[0].message || 'Silme sırasında hata oluştu.';
            this.alertifyService.error(errorMsg);
          } else {
            this.alertifyService.success('Kayıt başarıyla silindi.');
            this.toggleDeleteModal();
            this.getData();
          }
          this.spinnerService.showSpinner(false);
        },
        error: (err) => {
          this.alertifyService.error('Silme işlemi başarısız.');
          this.spinnerService.showSpinner(false);
        }
      });
  }

  getData() {
    const params: any = {};
    const batchId = this.searchBatchId();
    const cyclicBatchId = this.searchCyclicBatchId();
    
    if (batchId) params.batchId = batchId;
    if (cyclicBatchId) params.cyclicBatchId = cyclicBatchId;
    if (this.selectedStatus) params.status = this.selectedStatus;

    this.spinnerService.showSpinner(true);
    this.cyclicPostingProcessService.getCyclicPostingProcessList(Object.keys(params).length ? params : undefined)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (response) => {
          let arr = response?.data?.processes;
          if (!Array.isArray(arr)) {
            arr = [];
          }
          this.dataList = arr;
          this.spinnerService.showSpinner(false);
        },
        error: (error) => {
          console.error('Error fetching cyclic posting process data:', error);
          this.dataList = [];
          this.spinnerService.showSpinner(false);
        }
      });
  }

  search() {
    this.getData();
  }

  clear() {
    this.dataList = [];
  }

  showCreateDialog() {
    this.toggleAddModal();
  }

  toggleAddModal() {
    if (this.addDialogRef) {
      this.addDialogRef.close();
      this.addDialogRef = undefined;
      this.resetNewProcess();
    } else {
      if (!this.templateRef) {
        console.error('Add template reference not found');
        return;
      }
      this.newProcess.postingDate = new Date(new Date().getFullYear(), 0, 1).toLocaleDateString('en-CA');
      this.addDialogRef = this.dialogService.open(this.templateRef, {
        showCloseIcon: true
      });
    }
  }

  resetNewProcess() {
    this.newProcess = {
      batchId: '',
      cyclicBatchId: '',
      processStatus: '',
      errText: '',
      processDate: ''
    };
  }

  createCyclicPostingProcess() {
    // batchIdList'i satırlara ayır ve her biri için CyclicPostingItem oluştur
    const batchIds = (this.newProcess.batchIdList as string)
      .split(/\r?\n/)
      .map((id: string) => id.trim())
      .filter((id: string) => id);

    const items = batchIds.map((batchId: string) => ({
      batchId,
      postingDate: this.newProcess.postingDate
    }));

    const createRequest = {
      items
    };

    this.spinnerService.showSpinner(true);
    // Servise gönder
    this.cyclicPostingProcessService.createCyclicPosting(createRequest)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (res) => {
           if (res.uiMessages && res.uiMessages.errors && res.uiMessages.errors.length !== 0) {
            let errorMessage = res.uiMessages.errors[0].message
            this.alertifyService.error(errorMessage);
            this.spinnerService.showSpinner(false);
            return
          }
          this.alertifyService.success('Fiş/Fişler başarıyla eklendi');
          this.toggleAddModal();
          this.getData();
          this.spinnerService.showSpinner(false);
        },
        error: (error) => {
          this.alertifyService.error('Fiş/Fişler eklenemedi. Bilinmeyen bir hata oluştu.'+
            error
          );
          this.spinnerService.showSpinner(false);
        }
      });
  }

  sortTable(sort: SortEvent) {
    if (sort.direction == "asc") {
      this.dataList.sortBy(sort.active);
    } else {
      this.dataList = this.dataList.sortByDesc(sort.active);
    }
  }

  getValue(obj: any, path: string) {
    return path.split('.').reduce((acc, k) => acc?.[k], obj);
  }

  private getCols() {
    this.cols = [
      {
        field: "batchId",
        header: "Fiş No"// this.translate.instant("accMap.batchId"),
      },
      {
        field: "postingDate",
        header: "Muhasebe Tarihi" //this.translate.instant( "accMap.postingDate"),
      },
      {
        field: "cyclicBatchId",
        header: "Devir Fiş No" //this.translate.instant( "accMap.cyclicBatchId"),
      },
      {
        field: "processStatus",
        header: "İşlem Durumu" //this.translate.instant( "accMap.processStatus"),
      },
      {
        field: "errText",
        header: "Hata Mesajı" //this.translate.instant( "accMap.errText"),
      }
    ];
  }
}
