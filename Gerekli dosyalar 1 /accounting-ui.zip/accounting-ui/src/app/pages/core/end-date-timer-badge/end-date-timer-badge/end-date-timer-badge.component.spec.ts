import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EndDateTimerBadgeComponent } from './end-date-timer-badge.component';

describe('EndDateTimerBadgeComponent', () => {
  let component: EndDateTimerBadgeComponent;
  let fixture: ComponentFixture<EndDateTimerBadgeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EndDateTimerBadgeComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EndDateTimerBadgeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
