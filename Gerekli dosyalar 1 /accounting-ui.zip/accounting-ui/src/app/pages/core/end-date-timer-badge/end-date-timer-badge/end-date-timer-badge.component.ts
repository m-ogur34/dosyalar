import { NxIconModule } from '@allianz/ng-aquila/icon';
import { NxTooltipModule } from '@allianz/ng-aquila/tooltip';
import { DatePipe } from '@angular/common';
import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-end-date-timer-badge',
  imports : [NxIconModule,NxTooltipModule,DatePipe],
  templateUrl: './end-date-timer-badge.component.html',
  styleUrls: ['./end-date-timer-badge.component.scss']
})
export class EndDateTimerBadgeComponent implements OnInit {

  @Input() data?: Date;
  @Input() format: any;
  @Input() status: any;
  ngOnInit(): void {
    this.getNow();
  }

  getNow() {
    return new Date();
  }
}
