import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-table-footer-columns-generic',
  templateUrl: './table-footer-columns-generic.component.html',
  styleUrls: ['./table-footer-columns-generic.component.scss']
})
export class TableFooterColumnsGenericComponent {

  @Input() col: any;
  @Input() dataList?: any[];
}
