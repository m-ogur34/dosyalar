import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TableFooterColumnsGenericComponent } from './table-footer-columns-generic.component';

describe('TableFooterColumnsGenericComponent', () => {
  let component: TableFooterColumnsGenericComponent;
  let fixture: ComponentFixture<TableFooterColumnsGenericComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TableFooterColumnsGenericComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TableFooterColumnsGenericComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
