import { NxButtonModule } from '@allianz/ng-aquila/button';
import { Component, Input } from '@angular/core';
import { NxGridModule } from '@aposin/ng-aquila/grid';

@Component({
  selector: 'app-page-title',
  imports : [NxGridModule,NxButtonModule],
  templateUrl: './page-title.component.html',
  styleUrls: ['./page-title.component.scss']
})
export class PageTitleComponent {
@Input() title?:string;
}
