import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TableColumnsGenericComponent } from './table-columns-generic.component';

describe('TableColumnsGenericComponent', () => {
  let component: TableColumnsGenericComponent;
  let fixture: ComponentFixture<TableColumnsGenericComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TableColumnsGenericComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TableColumnsGenericComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
