import { CommonModule, NgStyle } from '@angular/common';
import { Component, Input, OnInit } from '@angular/core';
import { EndDateTimerBadgeComponent } from '../end-date-timer-badge/end-date-timer-badge/end-date-timer-badge.component';
import { NxBadgeModule } from '@allianz/ng-aquila/badge';
import { NxIconComponent } from '@allianz/ng-aquila/icon';
import { ThousandSeparatorPipe } from '../../../core/pipe/thousand-separator.pipe';
import { ThousandSeparatorWithDecimalsPipe } from '../../../core/pipe/thousand-separator-with-decimals.pipe';
import { NxPaginationModule } from '@allianz/ng-aquila/pagination';
import { TruncatePipe } from '../../../core/pipe/truncate.pipe.';
import { NxPopoverModule } from "@aposin/ng-aquila/popover";

@Component({
  selector: 'app-table-columns-generic',
  imports : [CommonModule,NgStyle,EndDateTimerBadgeComponent,NxBadgeModule,NxIconComponent,TruncatePipe,
    ThousandSeparatorPipe,ThousandSeparatorWithDecimalsPipe,NxPaginationModule,NxPopoverModule],
  templateUrl: './table-columns-generic.component.html',
  styleUrls: ['./table-columns-generic.component.scss']
})
export class TableColumnsGenericComponent implements OnInit {

  @Input() format: any;
  @Input() data: any;
  @Input() status: any;
  constructor() { }

  ngOnInit(): void {
    if(this.data==null){
      this.data = this.data??this.format.defaultValue;
    }
  }

  public setStyle(): Record<string, string> | null {
  let value = this.format?.style;
  if (!value || value === "") return null;

  const properties = value.split(";");
  const keyValuePairs: Record<string, string> = {}; // Explicitly typing the object

  properties.forEach((o: string) => { // Explicitly typing `o` as string
    const [key, val] = o.split(":").map((s: string) => s.trim()); // Type annotation for `s`
    if (key.length > 0) {
      keyValuePairs[key] = val;
    }
  });

  return keyValuePairs;
}


 

}
