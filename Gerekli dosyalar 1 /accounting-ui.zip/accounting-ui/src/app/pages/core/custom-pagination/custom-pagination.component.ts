import { Component, CUSTOM_ELEMENTS_SCHEMA, EventEmitter, Input, Output, OnInit} from '@angular/core';
import { CommonConstants } from '../../../core/common/constant/common-constants';
import { NxFormfieldModule } from '@allianz/ng-aquila/formfield';
import { NxDropdownModule } from '@allianz/ng-aquila/dropdown';
// import { NxOverlayModule } from '@allianz/ng-aquila/overlay';
import { NxGridModule } from '@aposin/ng-aquila/grid';
import { NxPaginationModule } from '@allianz/ng-aquila/pagination';
@Component({
  selector: 'app-custom-pagination',
  imports : [NxFormfieldModule,NxGridModule,NxDropdownModule,NxPaginationModule
  ],
  templateUrl: './custom-pagination.component.html',
  styleUrls: ['./custom-pagination.component.scss'],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class CustomPaginationComponent implements OnInit {
  @Input() count!: number;
  @Input() page!: number;
  @Input() pageSize!: number;
  @Input() dataList: any
  @Output() pageChange = new EventEmitter<number>();
  @Output() pageSizeChange = new EventEmitter<number>();
  paginationOption: number[]= []

  ngOnInit(): void {
      this.paginationOption = CommonConstants.paginationOptions
   }

  trackByValue(index: number, value: number): number {
    return value;
  }

  // Trigger previous and next page changes
  prevPage() {
    this.pageChange.emit(this.page - 1);
  }

  nextPage() {
    this.pageChange.emit(this.page + 1);
  }

  goToPage(page:any) {
    this.pageChange.emit(page);
  }

  updatePage() {
    this.page = 1;
    this.pageChange.emit(this.page);
    this.pageSizeChange.emit(this.pageSize);
  }

}
