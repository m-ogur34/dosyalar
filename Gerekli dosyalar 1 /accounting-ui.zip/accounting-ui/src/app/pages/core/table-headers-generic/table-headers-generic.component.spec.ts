import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TableHeadersGenericComponent } from './table-headers-generic.component';

describe('TableHeadersGenericComponent', () => {
  let component: TableHeadersGenericComponent;
  let fixture: ComponentFixture<TableHeadersGenericComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TableHeadersGenericComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TableHeadersGenericComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
