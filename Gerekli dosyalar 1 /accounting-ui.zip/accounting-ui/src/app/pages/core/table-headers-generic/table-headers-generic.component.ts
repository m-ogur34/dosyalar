import { NgClass } from '@angular/common';
import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-table-headers-generic',
  imports : [NgClass],
  templateUrl: './table-headers-generic.component.html',
  styleUrls: ['./table-headers-generic.component.scss']
})
export class TableHeadersGenericComponent implements OnInit {

  @Input() col: any;
  constructor() { }

  ngOnInit(): void {
  }

}
