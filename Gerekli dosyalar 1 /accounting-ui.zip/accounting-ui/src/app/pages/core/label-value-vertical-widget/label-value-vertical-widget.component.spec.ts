import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LabelValueVerticalWidgetComponent } from './label-value-vertical-widget.component';

describe('LabelValueVerticalWidgetComponent', () => {
  let component: LabelValueVerticalWidgetComponent;
  let fixture: ComponentFixture<LabelValueVerticalWidgetComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LabelValueVerticalWidgetComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LabelValueVerticalWidgetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
