import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-label-value-vertical-widget',
  templateUrl: './label-value-vertical-widget.component.html',
  styleUrls: ['./label-value-vertical-widget.component.scss']
})
export class LabelValueVerticalWidgetComponent {

  @Input() title?: string;
  @Input() value?: string;
  @Input() isTranslate?: boolean;
  @Input() isImportant?: boolean;
  @Input() isHighlight?: boolean;
  @Input() isUnderlined?: boolean;

}

