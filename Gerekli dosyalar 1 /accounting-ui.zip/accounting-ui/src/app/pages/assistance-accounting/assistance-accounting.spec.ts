import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssistanceAccounting } from './assistance-accounting';

describe('AssistanceAccounting', () => {
  let component: AssistanceAccounting;
  let fixture: ComponentFixture<AssistanceAccounting>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AssistanceAccounting]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AssistanceAccounting);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
