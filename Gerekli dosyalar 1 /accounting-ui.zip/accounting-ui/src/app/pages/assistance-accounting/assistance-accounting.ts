import { Component, OnInit, signal } from '@angular/core';
import { ChangeDetectorRef } from '@angular/core';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';
import { FormBuilder, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SpinnerService } from '../../core/services/spinner.service';
import { AlertifyService } from '../../core/services/alertify-service';
import { CustomPanelComponent } from '../core/custom-panel/custom-panel.component';
import { NxInputModule } from '@allianz/ng-aquila/input';
import { NxButtonModule } from '@allianz/ng-aquila/button';
import { NxDropdownModule, NxDropdownSelectChange } from '@allianz/ng-aquila/dropdown';
import { BranchModel } from '../../models/assistance-accounting/branch-model';
import { ProductModel } from '../../models/assistance-accounting/product-model';
import { AssistanceAccountingService } from '../../services/assistance-accounting.service';
import { NxGridModule } from '@aposin/ng-aquila/grid';
import { NX_DATE_FORMATS, NX_DATE_LOCALE, NxDateAdapter, NxDatefieldModule, NxNativeDateModule } from '@allianz/ng-aquila/datefield';
import { SharedModule } from '../../shared/shared.module';
import { DynamicTableColumnModel } from '../../core/models/dynamic-table-column.model';
import { CustomPaginationComponent } from '../core/custom-pagination/custom-pagination.component';
import { TableHeadersGenericComponent } from '../core/table-headers-generic/table-headers-generic.component';
import { TableColumnsGenericComponent } from '../core/table-columns-generic/table-columns-generic.component';
import { NgStyle, SlicePipe } from '@angular/common';
import { SearchListPipe } from '../../core/pipe/search-list.pipe';
import { PageTitleComponent } from '../core/page-title/page-title.component';
import { DdMmYyyyDateAdapter } from '../../core/utils/ddmmyyyy-date-adapter';

const DD_MM_YYYY_DATE_FORMATS = {
  parse: {
    dateInput: null,
  },
  display: {
    dateInput: { year: 'numeric', month: '2-digit', day: '2-digit' },
    monthYearLabel: { year: 'numeric', month: 'short' },
    dateA11yLabel: { year: 'numeric', month: 'long', day: 'numeric' },
    monthYearA11yLabel: { year: 'numeric', month: 'long' },
  },
};

@Component({
  selector: 'app-assistance-accounting',
  providers: [
    { provide: NX_DATE_LOCALE, useValue: 'en-GB' },
    { provide: NxDateAdapter, useClass: DdMmYyyyDateAdapter },
    { provide: NX_DATE_FORMATS, useValue: DD_MM_YYYY_DATE_FORMATS },
  ],
  imports: [
    CustomPanelComponent,
    PageTitleComponent,
    TranslatePipe,
    FormsModule,
    ReactiveFormsModule,
    NxInputModule,
    NxButtonModule,
    NxDropdownModule,
    NxGridModule,
    NxNativeDateModule,
    NxDatefieldModule,
    SharedModule,
    CustomPaginationComponent,
    TableHeadersGenericComponent,
    TableColumnsGenericComponent,
    NgStyle,
    SlicePipe,
    SearchListPipe
  ],
  templateUrl: './assistance-accounting.html',
  styleUrl: './assistance-accounting.scss',
})
export class AssistanceAccounting implements OnInit {
  readonly selectAllProductsValue = '__ALL_PRODUCTS__';
  readonly selectAllPartitionsValue = '__ALL_PARTITIONS__';
  allProductsSelected = false;
  allPartitionsSelected = false;
    
  payableAmountRaw: string = '';
  createdBatchId: string = '';
  invoiceNo: string = '';
  invoiceDate: Date | null = null;
  batchDescription: string = '';
  showErrors = false;
  payableAmount: number | null = null;
  ebType: any;
  yearOptions: number[] = [];
  monthOptions = [
    { value: 1, label: 'Ocak' },
    { value: 2, label: 'Şubat' },
    { value: 3, label: 'Mart' },
    { value: 4, label: 'Nisan' },
    { value: 5, label: 'Mayıs' },
    { value: 6, label: 'Haziran' },
    { value: 7, label: 'Temmuz' },
    { value: 8, label: 'Ağustos' },
    { value: 9, label: 'Eylül' },
    { value: 10, label: 'Ekim' },
    { value: 11, label: 'Kasım' },
    { value: 12, label: 'Aralık' }
  ];
  selectedYear?: number;
  selectedMonth?: number;

      // Signal-based reactive state
  searchText = signal<string>('');
  cols: DynamicTableColumnModel[] = [];
  page = 1;
  pageSize = 5;
  private productDropdownLastScrollTop = 0;
  private partitionDropdownLastScrollTop = 0;

  onPayableAmountInput(val: string) {
    this.payableAmountRaw = val;
    this.payableAmount = this.parsePayableAmount(val);
  }

  onPayableAmountFocus() {
    if (this.payableAmountRaw) {
      this.payableAmountRaw = this.payableAmountRaw.replace(/\./g, '');
    }
  }

  onPayableAmountBlur() {
    const formattedAmount = this.formatPayableAmount(this.payableAmount);
    if (formattedAmount) {
      this.payableAmountRaw = formattedAmount;
    }
  }

  isTotalsBalanced(): boolean {
    const totalBorc = this.dataList.reduce((sum, item) => sum + (Number(item.tutarBorc) || 0), 0);
    const totalAlacak = this.dataList.reduce((sum, item) => sum + (Number(item.tutarAlacak) || 0), 0);
    return Number(totalBorc.toFixed(2)) === Number(totalAlacak.toFixed(2));
  }

  canAccounting(): boolean {
    const totalBorc = this.dataList.reduce((sum, item) => sum + (Number(item.tutarBorc) || 0), 0);
    const totalAlacak = this.dataList.reduce((sum, item) => sum + (Number(item.tutarAlacak) || 0), 0);
    const borc = Number(totalBorc.toFixed(2));
    const alacak = Number(totalAlacak.toFixed(2));
    const hasRequiredFields = !!this.invoiceNo?.trim() && !!this.invoiceDate && !!this.accountingDate;

    return borc === alacak && borc !== 0 && hasRequiredFields;
  }

  formatPayableAmount(val: any): string {
    if (val === null || val === undefined || val === '') return '';
    const num = typeof val === 'number' ? val : Number(val.toString().replace(/[^0-9,\.]/g, '').replace(',', '.'));
    if (isNaN(num)) return '';
    // Binlik ayraç için Intl.NumberFormat kullanımı
    return new Intl.NumberFormat('tr-TR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(num);
  }

  parsePayableAmount(val: string): number | null {
    if (!val) return null;
    // Sadece rakam ve virgül/nokta karakterlerini al
    const clean = val.replace(/[^0-9,\.]/g, '').replace(',', '.');
    const num = Number(clean);
    return isNaN(num) ? null : num;
  }

  accountingDate: Date | null = null;

  private formatDateForApi(date: Date | null): string | null {
    if (!date) {
      return null;
    }

    const year = date.getFullYear();
    const month = `${date.getMonth() + 1}`.padStart(2, '0');
    const day = `${date.getDate()}`.padStart(2, '0');

    return `${year}-${month}-${day}`;
  }

  private buildPrintPostingPayload(batchId : number) {
    return {
      reportParameters: {
        "PARAMFORM" : "NO",
        "P_BATCH_ID" : batchId
      },
      projectName: 'accounting-ui',
      reportName: 'KOCREPACC016',
      outputFileName: `print-posting-${batchId || Date.now()}`
    };
  }

  private downloadPdfFromPrintResponse(response: any): void {
    const printBase64 = response?.data?.printBase64;
    const rawFileName = response?.data?.fileName || `print-posting-${Date.now()}`;
    const fileName = rawFileName.toLowerCase().endsWith('.pdf') ? rawFileName : `${rawFileName}.pdf`;

    if (!printBase64) {
      this.alertifyService.error('Yazdırma verisi alınamadı.');
      return;
    }

    try {
      const binaryString = atob(printBase64);
      const bytes = new Uint8Array(binaryString.length);
      for (let i = 0; i < binaryString.length; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }

      const blob = new Blob([bytes], { type: 'application/pdf' });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = fileName;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
    } catch {
      this.alertifyService.error('PDF dosyası oluşturulamadı.');
    }
  }

  private requestAndDownloadPrintPosting(batchId: number): void {
    this.assistanceAccountingService.postPrintPosting(this.buildPrintPostingPayload(batchId)).subscribe({
      next: (printResponse: any) => {
        this.downloadPdfFromPrintResponse(printResponse);
        this.spinnerService.showSpinner(false);
      },
      error: (err: any) => {
        this.spinnerService.showSpinner(false);
        this.alertifyService.error('Kayıt muhasebeleştirildi ancak yazdırma isteği gönderilemedi.' + err);
      }
    });
  }

  copyCreatedBatchId(): void {
    if (!this.createdBatchId) {
      this.alertifyService.info('Kopyalanacak fiş no bulunamadı.');
      return;
    }

    const valueToCopy = this.createdBatchId;
    if (navigator?.clipboard?.writeText) {
      navigator.clipboard.writeText(valueToCopy)
        .then(() => this.alertifyService.success('Fiş no kopyalandı.'))
        .catch(() => this.fallbackCopyToClipboard(valueToCopy));
      return;
    }

    this.fallbackCopyToClipboard(valueToCopy);
  }

  private fallbackCopyToClipboard(value: string): void {
    const tempInput = document.createElement('input');
    tempInput.value = value;
    document.body.appendChild(tempInput);
    tempInput.select();

    const copied = document.execCommand('copy');
    document.body.removeChild(tempInput);

    if (copied) {
      this.alertifyService.success('Fiş no kopyalandı.');
    } else {
      this.alertifyService.error('Fiş no kopyalanamadı.');
    }
  }
  
  accounting() {
    if (!this.canAccounting()) {
      this.alertifyService.info('Muhasebeleştirme için Fatura No, Fatura Tarihi ve Muhasebe Tarihi alanları zorunludur.');
      return;
    }

    this.spinnerService.showSpinner(true);
    // Muhasebeleştir butonu tıklandığında API çağrısı yapılır
    const payload = {
      invoiceNo: this.invoiceNo,
      invoiceDate: this.formatDateForApi(this.invoiceDate),
      batchDescription: this.batchDescription,
      accountingDate: this.formatDateForApi(this.accountingDate),
      agencyId: this.selectedAssistanceCompanyId,
      year: this.selectedYear,
      month: this.selectedMonth,
      accCoverCode: this.selectedAccCoverCode,
      payableAmount: this.payableAmount,
      ebType: this.ebType === '' || this.ebType === undefined ? null : this.ebType,
      productId: this.selectedProductIds.length > 0 ? this.selectedProductIds.join(',') : null,
      partitionType: this.selectedPartitionTypes.length > 0 ? this.selectedPartitionTypes.join(',') : null
    };
    this.assistanceAccountingService.postCreateAssistancePosting(payload).subscribe({
      next: (response: any) => {
        if (response?.uiMessages?.errors?.length) {
          const errorMsg = response.uiMessages.errors[0].message || 'Muhasebeleştirme sırasında hata oluştu.';
          this.alertifyService.error(errorMsg);
          this.spinnerService.showSpinner(false);
        } else {
          const batchId = response?.data;
          this.createdBatchId = batchId !== null && batchId !== undefined ? String(batchId) : '-';
          this.alertifyService.success(`Kayıt başarıyla muhasebeleştirildi. Fiş No: ${batchId ?? '-'}`)
          this.spinnerService.showSpinner(false);
          this.clear(false);
        }
      },
      error: (err: any) => {
        this.spinnerService.showSpinner(false);
        this.alertifyService.error(this.translate.instant('Muhasebeleştirme başarısız!'));
      }
    });
  }

  // If you need to set these values programmatically, call detectChanges after assignment
  setSelectedYear(year: number) {
    this.selectedYear = year;
    this.cdr.detectChanges();
  }

  setSelectedMonth(month: number) {
    this.selectedMonth = month;
    this.cdr.detectChanges();
  }

  setEbType(type: any) {
    this.ebType = type;
    this.cdr.detectChanges();
  }

  selectedAccCoverCode?: string ;
  selectedProductIds: number[] = [];
  selectedProductDropdownValues: Array<number | string> = [];
  selectedPartitionTypes: string[] = [];
  selectedPartitionDropdownValues: string[] = [];
  selectedAssistanceCompanyId?: number ;

  dataList: any[] = [];
  assitanceCompanies: any[] = [];
  accCodes: any[] = [];
  branches: BranchModel[] = [];
  products: ProductModel[] = [];
  partitions: any[] = [];
  selectedYearMonth = new Date();

  // --- Constructor ---
  constructor(
    private translate: TranslateService,
    private alertifyService: AlertifyService,
    private fb: FormBuilder,
    private spinnerService: SpinnerService,
    private assistanceAccountingService: AssistanceAccountingService,
    private cdr: ChangeDetectorRef
  ) {}

  // --- Lifecycle ---
  ngOnInit(): void {
    this.getCols();
    // Yıl seçeneklerini oluştur: önceki 2 yıl, mevcut yıl, sonraki 1 yıl
    const currentYear = new Date().getFullYear();
    this.setSelectedYear(currentYear);
    this.setSelectedMonth(new Date().getMonth() + -1);
    this.setEbType('');
    this.yearOptions = [currentYear - 2, currentYear - 1, currentYear, currentYear + 1];
    this.getAssistanceCompanies();
    this.getAccCodes();
  }

  // --- Event Handlers ---

  // --- UI Helpers ---
  showRequiredFieldsWarning(): void {
    this.alertifyService.info(this.translate.instant('Lütfen tüm zorunlu alanları doldurun.'));
  }

  // --- Main Actions ---
  getFilteredData() {
    this.createdBatchId = '';
    this.showErrors = false;
    if (!this.selectedAssistanceCompanyId || 
        !this.selectedYear ||
        !this.selectedMonth ||
         !this.selectedAccCoverCode ||
         this.payableAmount === null ||
         this.payableAmount === undefined ||
         this.payableAmount <= 0) {
      this.showErrors = true;
      this.showRequiredFieldsWarning();
      return;
    }
    this.spinnerService.showSpinner(true);
    const requestBody = {
      totalAmountParam: this.payableAmount!,
      accCoverCode: this.selectedAccCoverCode!,
      year: this.selectedYear!,
      month: this.selectedMonth!,
      isIndustrial: typeof this.ebType === 'number' ? this.ebType : null,
      productId: this.selectedProductIds.length > 0 ? this.selectedProductIds.join(',') : null,
      partitionType: this.selectedPartitionTypes.length > 0 ? this.selectedPartitionTypes.join(',') : null,
      companyId: this.selectedAssistanceCompanyId!
    };
    this.assistanceAccountingService.postAssistanceQueryResult(requestBody).subscribe({
      next: (response: any) => {  
        if (response && response.data && Array.isArray(response.data)) {
          this.dataList = response.data;
        } else {
          console.log('Unexpected response format:', response);
          this.dataList = [];
        } 
        this.spinnerService.showSpinner(false);
        this.cdr.detectChanges();
      },
      error: (err: any) => {
        console.log('Data fetch error:', err);
        this.spinnerService.showSpinner(false);
        this.alertifyService.error(this.translate.instant('ERROR.DATA_LOAD'));
      }
    });
  }

  // --- Service Methods ---
  getAssistanceCompanies() {
    
    this.spinnerService.showSpinner(true);
    this.assistanceAccountingService.getAssistanceCompanies().subscribe({
      next: (response: any) => {
        if (response && response.data && Array.isArray(response.data)) {
          this.assitanceCompanies = response.data;
        } else {
          this.assitanceCompanies = [];
        }

     

        this.spinnerService.showSpinner(false);
        if (this.assitanceCompanies.length > 0) {
          this.selectedAssistanceCompanyId = this.assitanceCompanies[0].intId;
        }
        this.cdr.detectChanges();
      },
      error: (err: any) => {
        console.log('Agencies error:', err);
        this.spinnerService.showSpinner(false);
        this.alertifyService.error(this.translate.instant('ERROR.AGENCIES_LOAD'));
      }
    });

       
  }

  getAccCodes() {
    this.spinnerService.showSpinner(true);
    this.assistanceAccountingService.getAccCodes().subscribe({
        next: (response: any) => {
          if (response && response.data && Array.isArray(response.data)) {
            this.accCodes = response.data;
          } else {
            this.accCodes = [];
          } 
          if (this.accCodes.length > 0) {
            this.selectedAccCoverCode = this.accCodes[0].accCoverCode;
            this.cdr.detectChanges();
            this.getProducts(this.selectedAccCoverCode!);
          }
          this.spinnerService.showSpinner(false);
        },
        error: (err: any) => {
          console.log('Accounting Codes error:', err);
          this.spinnerService.showSpinner(false);
          this.alertifyService.error(this.translate.instant('ERROR.ACC_CODES_LOAD'));
        }
      });
  }

  getProducts(accCoverCode: string) {
    this.spinnerService.showSpinner(true);
    this.assistanceAccountingService.getProducts(accCoverCode).subscribe({
      next: (response: any) => {
        // Eğer API response'u bir array ise doğrudan ata
        if (response && response.data && Array.isArray(response.data)) {
          this.products = response.data;
        } else {
          this.products = [];
        }
        this.spinnerService.showSpinner(false);
        this.cdr.detectChanges();
      },
      error: (err: any) => {
        console.log('Products error:', err);
        this.spinnerService.showSpinner(false);
        this.alertifyService.error(this.translate.instant('ERROR.PRODUCTS_LOAD'));
      }
    });

  }

  getPartitions(productIds: number[]) {
    this.spinnerService.showSpinner(true);
    this.assistanceAccountingService.getPartitions(productIds).subscribe({
      next: (response: any) => {
        // Eğer API response'u bir array ise doğrudan ata
        if (response && response.data && Array.isArray(response.data)) {
          this.partitions = response.data;
        } else {
          this.partitions = [];
        }
        this.spinnerService.showSpinner(false);
        this.cdr.detectChanges();
      },
      error: (err: any) => {
        console.log('Partitions error:', err);
        this.spinnerService.showSpinner(false);
        this.alertifyService.error(this.translate.instant('ERROR.PARTITIONS_LOAD'));
      }
    });
  }

  onProductChange($event: NxDropdownSelectChange<any>) {
    this.productDropdownLastScrollTop = this.getProductDropdownScrollTop();
    const wasAllSelected = this.allProductsSelected;

    const rawValues = Array.isArray($event.value)
      ? $event.value
      : ($event.value !== null && $event.value !== undefined ? [$event.value] : []);

    const hasSelectAll = rawValues.includes(this.selectAllProductsValue);
    const productIds = this.products
      .map((item) => item.productId)
      .filter((value): value is number => typeof value === 'number');
    const values = rawValues.filter((value): value is number => typeof value === 'number');

    if ((wasAllSelected && hasSelectAll) || (wasAllSelected && !hasSelectAll && values.length === productIds.length)) {
      this.selectedProductIds = [];
      this.selectedProductDropdownValues = [];
      this.allProductsSelected = false;
      this.selectedPartitionTypes = [];
      this.selectedPartitionDropdownValues = [];
      this.allPartitionsSelected = false;
      this.partitions = [];

      setTimeout(() => {
        this.restoreProductDropdownScrollTop(this.productDropdownLastScrollTop);
      }, 0);
      return;
    }

    if (hasSelectAll && !wasAllSelected) {
      this.selectedProductIds = productIds;
      this.selectedProductDropdownValues = [this.selectAllProductsValue, ...productIds];
      this.allProductsSelected = true;
    } else {
      this.selectedProductIds = values;
      this.allProductsSelected = values.length > 0 && values.length === productIds.length;
      this.selectedProductDropdownValues = this.allProductsSelected
        ? [this.selectAllProductsValue, ...values]
        : [...values];
    }

    this.selectedPartitionTypes = [];
    this.selectedPartitionDropdownValues = [];
    this.allPartitionsSelected = false;

    if (this.selectedProductIds.length > 0) {
      this.getPartitions(this.selectedProductIds);
      setTimeout(() => {
        this.restoreProductDropdownScrollTop(this.productDropdownLastScrollTop);
      }, 0);
      return;
    }

    this.partitions = [];

    setTimeout(() => {
      this.restoreProductDropdownScrollTop(this.productDropdownLastScrollTop);
    }, 0);
  }

  onAccCoverCodeChange($event: NxDropdownSelectChange<any>) {
    this.selectedProductIds = [];
    this.selectedProductDropdownValues = [];
    this.allProductsSelected = false;

    this.selectedPartitionTypes = [];
    this.selectedPartitionDropdownValues = [];
    this.allPartitionsSelected = false;
    this.partitions = [];

    this.getProducts($event.value);
  }

  onPartitionSelectionChange($event: NxDropdownSelectChange<any>): void {
    this.partitionDropdownLastScrollTop = this.getPartitionDropdownScrollTop();
    const wasAllSelected = this.allPartitionsSelected;

    const rawValues = Array.isArray($event.value)
      ? $event.value
      : ($event.value !== null && $event.value !== undefined ? [$event.value] : []);

    const hasSelectAll = rawValues.includes(this.selectAllPartitionsValue);
    const partitionTypes = this.partitions
      .map((item) => item.partitionType)
      .filter((value): value is string => typeof value === 'string');
    const values = rawValues.filter((value): value is string => typeof value === 'string');

    if ((wasAllSelected && hasSelectAll) || (wasAllSelected && !hasSelectAll && values.length === partitionTypes.length)) {
      this.selectedPartitionTypes = [];
      this.selectedPartitionDropdownValues = [];
      this.allPartitionsSelected = false;

      setTimeout(() => {
        this.restorePartitionDropdownScrollTop(this.partitionDropdownLastScrollTop);
      }, 0);
      return;
    }

    if (hasSelectAll && !wasAllSelected) {
      this.selectedPartitionTypes = partitionTypes;
      this.selectedPartitionDropdownValues = [this.selectAllPartitionsValue, ...partitionTypes];
      this.allPartitionsSelected = true;
    } else {
      this.selectedPartitionTypes = values;
      this.allPartitionsSelected = values.length > 0 && values.length === partitionTypes.length;
      this.selectedPartitionDropdownValues = this.allPartitionsSelected
        ? [this.selectAllPartitionsValue, ...values]
        : [...values];
    }

    setTimeout(() => {
      this.restorePartitionDropdownScrollTop(this.partitionDropdownLastScrollTop);
    }, 0);
  }

  private getPartitionDropdownScrollTop(): number {
    const scrollable = this.findOpenDropdownScrollableElement();
    return scrollable ? scrollable.scrollTop : 0;
  }

  private getProductDropdownScrollTop(): number {
    const scrollable = this.findOpenDropdownScrollableElement();
    return scrollable ? scrollable.scrollTop : 0;
  }

  private restorePartitionDropdownScrollTop(scrollTop: number): void {
    const scrollable = this.findOpenDropdownScrollableElement();
    if (scrollable) {
      scrollable.scrollTop = scrollTop;
    }
  }

  private restoreProductDropdownScrollTop(scrollTop: number): void {
    const scrollable = this.findOpenDropdownScrollableElement();
    if (scrollable) {
      scrollable.scrollTop = scrollTop;
    }
  }

  private findOpenDropdownScrollableElement(): HTMLElement | null {
    const overlayPane = document.querySelector('.cdk-overlay-pane:last-of-type') as HTMLElement | null;
    if (!overlayPane) {
      return null;
    }

    const candidates = Array.from(overlayPane.querySelectorAll<HTMLElement>('[role="listbox"], .nx-dropdown-results, .nx-dropdown-list'));
    for (const candidate of candidates) {
      if (candidate.scrollHeight > candidate.clientHeight) {
        return candidate;
      }
    }

    return null;
  }

  getProductSelectAllLabel(): string {
    return this.allProductsSelected ? 'Tümünü Kaldır' : 'Tümünü Seç';
  }

  formatProductDropdownValue = (value: any): string => {
    const values = Array.isArray(value) ? value : [];
    const filteredValues = values.filter((item) => item !== this.selectAllProductsValue);

    if (filteredValues.length === 0) {
      return '';
    }

    return filteredValues
      .map((productId) => {
        const product = this.products.find((item) => item.productId === productId);
        return product ? `${product.productId}-${product.longName}` : String(productId);
      })
      .join(', ');
  };

  getProductClosedLabel(): string {
    return this.selectedProductIds
      .map((productId) => {
        const product = this.products.find((item) => item.productId === productId);
        return product ? `${product.productId}-${product.longName}` : String(productId);
      })
      .join(', ');
  }

  getPartitionSelectAllLabel(): string {
    return this.allPartitionsSelected ? 'Tümünü Kaldır' : 'Tümünü Seç';
  }

  formatPartitionDropdownValue = (value: any): string => {
    const values = Array.isArray(value) ? value : [];
    const filteredValues = values.filter((item) => item !== this.selectAllPartitionsValue);

    if (filteredValues.length === 0) {
      return '';
    }

    return filteredValues
      .map((partitionType) => {
        const partition = this.partitions.find((item) => item.partitionType === partitionType);
        return partition ? `${partition.partitionType}-${partition.longName}` : String(partitionType);
      })
      .join(', ');
  };

  getPartitionClosedLabel(): string {
    return this.selectedPartitionTypes
      .map((partitionType) => {
        const partition = this.partitions.find((item) => item.partitionType === partitionType);
        return partition ? `${partition.partitionType}-${partition.longName}` : String(partitionType);
      })
      .join(', ');
  }

  clear(resetCreatedBatchId: boolean = true) {
    this.payableAmount = null;
    this.payableAmountRaw = '';
    this.dataList = [];
    this.batchDescription = '';
    this.invoiceNo = '';
    this.invoiceDate = null;
    this.accountingDate = null;
    this.selectedAccCoverCode = this.accCodes.length > 0 ? this.accCodes[0].accCoverCode : undefined;
    this.selectedProductIds = [];
    this.selectedProductDropdownValues = [];
    this.allProductsSelected = false;
    this.selectedPartitionTypes = [];
    this.selectedPartitionDropdownValues = [];
    this.allPartitionsSelected = false;
    const currentYear = new Date().getFullYear();
    this.setSelectedYear(currentYear);
    this.setSelectedMonth(new Date().getMonth() + -1);
    this.ebType = '';

    if (resetCreatedBatchId) {
      this.createdBatchId = '';
    }
  }

  getValue(obj: any, path: string) {
    const value = path.split('.').reduce((acc, k) => acc?.[k], obj);
    // Eğer isTotal ise ve değer sayısal ise 4 hane göster
    const col = this.cols.find(c => c.field === path);
    if (col && col.isTotal && typeof value === 'number') {
      return value.toFixed(4);
    }
    return value;
  }

  // Column Definition
  private getCols() {
    const baseCols = [
      {
        field: 'accountNo',
        header: 'Hesap No',
        isTotal: false
      },
      {
        field: 'accountExp',
        header: 'Hesap Açıklama',
        isTotal: false
      },
      /*{
        field: 'sapLob',
        header: 'SAP LOB',
        isTotal: false
      },
      {
        field: 'sapDistChannelExp',
        header: 'SAP Dağıtım Kanalı',
        isTotal: false
      },*/
      {
        field: 'isIndustrial',
        header: 'E/B',
        isTotal: false
      },
      {
        field: 'tutarBorc',
        header: 'Tutar Borç',
        isTotal: true
      },
      {
        field: 'tutarAlacak',
        header: 'Tutar Alacak',
        isTotal: true
      }
    ];
    // isTotal olanlar en sağda
    this.cols = [
      ...baseCols.filter(col => !col.isTotal),
      ...baseCols.filter(col => col.isTotal)
    ];
  }

  getTotal(field: string): any {
    // Sadece sayısal alanlar için toplam hesaplanır
    if (!this.dataList || this.dataList.length === 0) return '0,00';
    if (field === 'tutarBorc' || field === 'tutarAlacak') {
      const total = this.dataList.reduce((sum, item) => sum + (item[field] || 0), 0);
      if (typeof total === 'number') {
        // 2 ondalık, 3'lü bloklar nokta, ondalık virgül
        return total
          .toFixed(2)
          .replace('.', ',')
          .replace(/\B(?=(\d{3})+(?!\d))/g, '.');
      }
      return total;
    }
    return '';
  }

}
