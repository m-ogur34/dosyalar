import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NxHeaderModule } from '@allianz/ng-aquila/header';
import { NxLinkModule } from '@allianz/ng-aquila/link';
import { environment } from '../../../../environments/environment.prod';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule, NxHeaderModule, NxLinkModule],
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
})
export class HeaderComponent implements OnInit {

  assetsBasePath = environment.assetsBasePath;
  constructor() {}

  ngOnInit() {}
}
