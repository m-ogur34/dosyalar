import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeaderComponent } from './components/header/header.component';
import { NxHeaderModule } from '@allianz/ng-aquila/header';
import { NxLinkModule } from '@allianz/ng-aquila/link';
import { NxTableModule } from '@allianz/ng-aquila/table';
import { NxBadgeModule } from '@allianz/ng-aquila/badge';
import { NxIconModule } from '@allianz/ng-aquila/icon';
import { NxButtonModule } from '@allianz/ng-aquila/button';
import { NxHeadlineModule } from '@allianz/ng-aquila/headline';
import { NxSpinnerModule } from '@allianz/ng-aquila/spinner';
import { LoaderService } from './../core/services/loader.service';
import { NxFormfieldModule } from '@allianz/ng-aquila/formfield';
import { NxDropdownModule } from '@allianz/ng-aquila/dropdown';
import { NxModalModule } from '@allianz/ng-aquila/modal';
import { NxInputModule } from '@allianz/ng-aquila/input';
import { NxPaginationModule } from '@allianz/ng-aquila/pagination';
import { NgxFileDropModule } from 'ngx-file-drop';

export const COMPONENTS = [];

/**
 * Ortak modülleri standalone component'lerde kullanmak için:
 * import { MODULES } from '../shared/shared.module';
 * imports: [CommonModule, FormsModule, ...MODULES]
 */
export const MODULES = [
  NxHeaderModule,
  NxLinkModule,
  NxTableModule,
  NxBadgeModule,
  NxIconModule,
  NxButtonModule,
  NxHeadlineModule,
  NxSpinnerModule,
  NxFormfieldModule,
  NxDropdownModule,
  NxInputModule,
  NgxFileDropModule,
  NxPaginationModule,
];

@NgModule({
  imports: [CommonModule, ...MODULES, NxModalModule.forRoot()],
  exports: [
    NxHeaderModule,
    NxLinkModule,
    NxTableModule,
    NxBadgeModule,
    NxIconModule,
    NxButtonModule,
    NxHeadlineModule,
    NxSpinnerModule,
    NxFormfieldModule,
    NxDropdownModule,
    NxInputModule,
    NxPaginationModule,
  ],
  providers: [LoaderService],
})
export class SharedModule {}
