import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CyclicPostingMapping } from './pages/cyclic-posting-mapping/cyclic-posting-mapping';
import { CyclicPostingProcess } from './pages/cyclic-posting-process/cyclic-posting-process';
import { LoginComponent } from './core/component/login/login.component';
import { AuthGuard } from './core/guard/auth.guard';
import { AssistanceAccounting } from './pages/assistance-accounting/assistance-accounting';

export const routes: Routes = [
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: '',
    component: CyclicPostingProcess,
    canActivate: [AuthGuard]
  },
  {
    path: 'cyclic-posting-mapping',
    component: CyclicPostingMapping,
    canActivate: [AuthGuard]
  },
  {
    path: 'cyclic-posting-process',
    component: CyclicPostingProcess,
    canActivate: [AuthGuard]
  },
  {
    path: 'assistance-accounting',
    component: AssistanceAccounting,
    canActivate: [AuthGuard]
  }
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
