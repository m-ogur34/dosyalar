import { UiMessages } from "./ui-messages";

export class RestResponse<T> {
    data!: T;
    uiMessages!: UiMessages;
}
