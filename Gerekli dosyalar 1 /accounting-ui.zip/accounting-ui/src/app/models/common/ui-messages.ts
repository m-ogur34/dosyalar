import { UiMessage } from "./ui-message";

export class UiMessages {
    errors?: UiMessage[];
    warnings?: UiMessage[];
    infos?: UiMessage[];
}
