export class UiMessage {
    code?: string;
    message?: string;
    severity?: string;
}
