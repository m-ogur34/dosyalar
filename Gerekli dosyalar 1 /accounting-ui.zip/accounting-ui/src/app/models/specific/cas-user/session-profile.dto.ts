
export class SessionProfileDto {

    // partnerId?: any;
    userName?: string;
    // name?: any;
    agentIntId?: number;
    agencyCode?: any;
    // agencyTitle?: any;
    userType?: string;
    // startDate?: any;
    // endDate?: any;
    // active?: any;
    // passwordExpired?: any;
    // isIndustrialUser?: any;
    // subAgent?: any;
    // subAgentCode?: any;
    // subAgentTitle?: any;
    subUserType?: string;
    // vkno?: any;
    // agencyCodeLife?: number;
    // hsbcRegisterNo?: any;
    // hsbcRegionCode?: any;
    // expirationMessage?: any;
    // ipRestrictionMessage?: any;
    // salesPersonEmpId?: any;
    // email?: any;
    // companyCode?: string;
    // technicalStaff?: any;
    // bgdUser?: any;
    callCenterUser?: any;
    // uwUser?: any;
    // absUser?: any;
    // hlthInstituteCode?: number;
    // profileType?: any;
    // jwtToken?: any;
    profileInformations?: any;
    // isFordUser?: boolean;
}
