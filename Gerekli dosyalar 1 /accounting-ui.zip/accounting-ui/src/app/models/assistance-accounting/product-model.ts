export class ProductModel {
  productId?: number;
  longName?: string;
}
