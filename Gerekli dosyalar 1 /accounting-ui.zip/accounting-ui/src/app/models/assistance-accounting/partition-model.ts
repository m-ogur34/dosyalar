export class PartitionModel {
  partitionType?: string;
  digitallDesc?: string;
}
