export class BranchModel {
  branchId?: number;
  branchName?: string;
  extReference?: string;
}
