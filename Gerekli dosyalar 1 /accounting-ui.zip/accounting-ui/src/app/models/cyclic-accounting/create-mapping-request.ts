export class CreateMappingRequest {
    accountNo?: string
    cyclicAccountNo?: string
}