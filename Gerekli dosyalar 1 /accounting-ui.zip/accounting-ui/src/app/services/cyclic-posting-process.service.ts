import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { BaseRestService } from './base-rest.service';
import { HttpParams } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class CyclicPostingProcessService extends BaseRestService {

  deleteCyclicPostingProcess(batchId: string): Observable<any> {
    // Backend POST bekliyor, body'de batchId gönderiliyor
    return this.basePost('/cyclic-posting-process/remove-unprocessed', { batchId });
  }

  processAccounting(item: any): Observable<any> {
    // Backend ProcessCyclicPostingRequest formatına uygun gönderim
    const requestBody = { items: [item] };
    return this.basePost('/cyclic-posting-process/process', requestBody);
  }

  processAccountingAll(items: any): Observable<any> {
    // Backend ProcessCyclicPostingRequest formatına uygun gönderim
    const requestBody = { items: items };
    return this.basePost('/cyclic-posting-process/process', requestBody);
  }
  
  getCyclicPostingProcessList(params?: { batchId?: string; cyclicBatchId?: string; status?: string }): Observable<any> {
    let httpParams: HttpParams | undefined = undefined;
    if (params) {
      httpParams = new HttpParams();
      if (params.batchId) httpParams = httpParams.set('batchId', params.batchId);
      if (params.cyclicBatchId) httpParams = httpParams.set('cyclicBatchId', params.cyclicBatchId);
      if (params.status) httpParams = httpParams.set('status', params.status);
    }
    return this.baseGet('/cyclic-posting-process/list', httpParams);
  }

  createCyclicPosting(createRequest: any): Observable<any> {
    return this.basePost('/cyclic-posting-process/create', createRequest);
  }
}
