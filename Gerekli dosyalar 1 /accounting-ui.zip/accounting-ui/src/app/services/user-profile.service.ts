import { Injectable } from "@angular/core";
import { BehaviorSubject } from "rxjs";
import { SessionProfileDto } from "../models/specific/cas-user/session-profile.dto";
import { GlobalRuntime } from "../core/config/global.runtime";

@Injectable({
    providedIn: 'root',
  })
  export class UserProfileService {
    private sessionProfile = new BehaviorSubject<SessionProfileDto>(GlobalRuntime.getUserProfile());
    sessionProfileObservable = this.sessionProfile.asObservable();
  
    setVariableValue(value: SessionProfileDto) {
      this.sessionProfile.next(value);
    }
  }