import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
import { BaseRestService } from './base-rest.service';
import { CreateMappingRequest } from '../models/cyclic-accounting/create-mapping-request';

@Injectable({
  providedIn: 'root',
})
export class AssistanceAccountingService extends BaseRestService {


  postCreateAssistancePosting(payload: any) {
    return this.basePost('/assistance-accounting/create-posting', payload);
  }

  postPrintPosting(payload: {
    reportParameters: Record<string, unknown>;
    projectName: string;
    reportName: string;
    outputFileName: string;
  }) {
    return this.basePost('/assistance-accounting/print-posting', payload);
  }

    
  postAssistanceQueryResult(body: {
    totalAmountParam: number;
    accCoverCode: string;
    year: number;
    month: number;
    isIndustrial: number | null;
    productId: number | string | null;
    partitionType: string | null;
    companyId: number;
  }) {
    return this.basePost('/assistance-accounting/assistance-query', body);
  }
  
  getAssistanceCompanies() {
    return this.baseGet('/assistance-accounting/assistance-company');
  }

  getAccCodes() {
    return this.baseGet('/assistance-accounting/acc-cover-code');
  }
  
  getProducts(accCoverCode: string): Observable<any> {
    return this.baseGet(`/assistance-accounting/assistance-product?accCoverCode=${accCoverCode}`);
  }

  getPartitions(productIds: number[]): Observable<any> {
    return this.basePost('/assistance-accounting/assistance-partition', productIds);
  }
  


}
