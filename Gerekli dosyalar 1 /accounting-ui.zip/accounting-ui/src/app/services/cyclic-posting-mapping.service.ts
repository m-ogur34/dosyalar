import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { BaseRestService } from './base-rest.service';
import { CreateMappingRequest } from '../models/cyclic-accounting/create-mapping-request';

@Injectable({
  providedIn: 'root',
})
export class CyclicPostingMappingService extends BaseRestService {
  
  getCyclicPostingMappingList(): Observable<any> {
    return this.baseGet('/cyclic-account-mapping/list');
  }

  createCyclicPostingMapping(createMappingRequest: CreateMappingRequest): Observable<any> {
    return this.basePost('/cyclic-account-mapping/create', createMappingRequest);
  }

  deleteCyclicPostingMapping(accountNo: string): Observable<any> {
    return this.basePost('/cyclic-account-mapping/remove', { accountNo });
  }
}
