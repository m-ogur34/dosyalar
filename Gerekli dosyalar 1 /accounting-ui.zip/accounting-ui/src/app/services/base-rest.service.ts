import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { UiMessages } from '../models/common/ui-messages';

@Injectable({
  providedIn: 'root',
})
export class BaseRestService {
  constructor(private http: HttpClient) {}

  get headers(): HttpHeaders {
    let headers = new HttpHeaders();
    headers = headers.set('Accept', '*/*');
    headers = headers.set('Access-Control-Allow-Origin', '*');
    headers = headers.set(
      'Access-Control-Allow-Methods',
      'POST, GET, OPTIONS, HEAD'
    );
    headers = headers.set('Content-Type', 'application/json');
    headers = headers.set('Access-Control-Allow-Headers', '*');
    headers = headers.set('Accept-Language', 'tr');

    return headers;
  }

  baseGet(url: string, params: HttpParams = new HttpParams()): Observable<any> {
    return this.http.get<any>(`${environment.apiURL}api/v1${url}`, {
      headers: this.headers,
      params,
    });
  }

  basePost(url: string, data: any): Observable<any> {
    return this.http.post(`${environment.apiURL}api/v1${url}`, data, {
      headers: this.headers,
    });
  }

  basePut(url: string, data: any): Observable<any> {
    return this.http.put(`${environment.apiURL}api/v1${url}`, data, {
      headers: this.headers,
    });
  }

  baseDelete(url: string): Observable<any> {
    return this.http.delete(`${environment.apiURL}api/v1${url}`, {
      headers: this.headers,
    });
  }

  handleUiMessagesObject(uiMessages: UiMessages, errorMessage?: string): string {
    if (uiMessages.errors && uiMessages.errors.length > 0 && uiMessages.errors[0].message) {
      return uiMessages.errors[0].message;
    } else {
      return errorMessage || '';
    }
  }
}
