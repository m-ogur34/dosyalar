import { BehaviorSubject } from 'rxjs/internal/BehaviorSubject';
import { Injectable } from '@angular/core';
import { GlobalRuntime } from '../config/global.runtime';
import { SessionProfileDto } from '../../models/specific/cas-user/session-profile.dto';

@Injectable({
  providedIn: 'root',
})
export class UserProfileService {
  private sessionProfile = new BehaviorSubject<SessionProfileDto>(GlobalRuntime.getUserProfile());
  sessionProfileObservable = this.sessionProfile.asObservable();

  setVariableValue(value: SessionProfileDto) {
    this.sessionProfile.next(value);
  }
}
