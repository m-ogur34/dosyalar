import { Injectable } from '@angular/core';

import { Observable, Subject } from 'rxjs';
import { BehaviorSubject } from 'rxjs/internal/BehaviorSubject';

@Injectable({
  providedIn: 'root'
})
export class SpinnerService {

  private loadBehaviour: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  public spinnerLoader: Observable<boolean> = this.loadBehaviour.asObservable();

  constructor() {
    this.showSpinner(false);
  }

  public showSpinner(show: boolean) {
    this.loadBehaviour.next(show);
  }

}