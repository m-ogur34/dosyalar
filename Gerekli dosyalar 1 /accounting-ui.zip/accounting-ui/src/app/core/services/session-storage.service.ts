import { Injectable } from "@angular/core";

@Injectable()
export class SessionStorageService {
    constructor() {
    }

    getItem(key: string) {
        return sessionStorage.getItem(key);
    }

    setItem(key: string, value: any) {
        sessionStorage.setItem(key, value);
    }

    clearAll() {
        sessionStorage.clear();
    }

    clearItem(key: string) {
        sessionStorage.removeItem(key);
    }
}