// session-profile-facade.service.ts
import { Injectable } from '@angular/core';
import { BehaviorSubject, Subscription } from 'rxjs';
import { filter, distinctUntilChanged } from 'rxjs/operators';
import { CommonConstants } from '../common/constant/common-constants';
import { ProfileContext } from '../models/profile-context';
import { GenericStorageService } from '../models/generic-storage-service';
import { UserProfileService } from './user-profile';
import { SessionProfileDto } from '../../models/specific/cas-user/session-profile.dto';

@Injectable({ providedIn: 'root' })
export class SessionProfileFacadeService {

    private profileSubject = new BehaviorSubject<SessionProfileDto | null>(null);
    profile$ = this.profileSubject.asObservable();

    // Root servis olduğu için tek subscription açıp bırakacağız
    private syncStarted = false;
    private syncSub?: Subscription;

    private readonly SESSION_KEYS = [
        CommonConstants.USER_PROFILE_KEY,
        CommonConstants.USER_TYPE,
        CommonConstants.CAS_USER_NAME
    ] as const;

    constructor(
        private genericStorageService: GenericStorageService,
        private userProfileService: UserProfileService
    ) { }

    initIfNeeded(): void {
        // 1) Önce session’dan hızlıca yükle (UI boş kalmasın)
        const savedProfile = this.genericStorageService
            .getItem<SessionProfileDto>(CommonConstants.USER_PROFILE_KEY, 'session');

        console.log(savedProfile);
        if (savedProfile) {
            this.profileSubject.next(savedProfile);
        }

        // 2) Sonra canlı kaynaktan sync etmeye başla (user değişimini yakalamak için)
        if (this.syncStarted) return;
        this.syncStarted = true;

        this.syncSub = this.userProfileService.sessionProfileObservable
            .pipe(filter((v): v is SessionProfileDto => !!v))
            .subscribe((incomingProfile) => {
                // MISMATCH KONTROLÜ (kritik nokta)
                const savedUserName = this.genericStorageService.getItem<string>(
                    CommonConstants.CAS_USER_NAME, 'session'
                );

                // session’da bir user var ama gelen user farklıysa → eski user’ı temizle
                if (savedUserName && savedUserName !== incomingProfile.userName) {
                    this.clearSessionProfileOnly();
                }

                // Yeni user’ı yaz (overwrite)
                this.genericStorageService.setItem(
                    CommonConstants.USER_PROFILE_KEY, incomingProfile, 'session'
                );
                this.genericStorageService.setItem(
                    CommonConstants.USER_TYPE, incomingProfile.userType, 'session'
                );
                this.genericStorageService.setItem(
                    CommonConstants.CAS_USER_NAME, incomingProfile.userName, 'session'
                );

                this.profileSubject.next(incomingProfile);
            });
    }

    /** Sadece session key’lerini temizler (sync subscription devam eder) */
    private clearSessionProfileOnly(): void {
        this.genericStorageService.removeItems([...this.SESSION_KEYS], 'session');
        this.profileSubject.next(null);
    }

    /**
     * Eğer bir gün senin tarafta çağırman gerekirse (opsiyonel):
     * tamamen sıfırlar, bir daha init çalışsın istersen diye.
     */
    resetFacadeCompletely(): void {
        this.clearSessionProfileOnly();
        this.syncSub?.unsubscribe();
        this.syncSub = undefined;
        this.syncStarted = false;
    }

    applyProfileTo(target: ProfileContext, user: SessionProfileDto): void {
        target.agentIntId = user.agentIntId!;
        target.userName = user.userName!;
        target.agencyCode = user.agencyCode;

        if (!target.userType) {
            target.userType = this.genericStorageService.getItem<string>(
                CommonConstants.USER_TYPE, 'session'
            );
        }

        if (target.userType === '1') {
            target.isPartajDisabled = true;
        }

        target.activeReferenceCode = target.agencyCode;

        if (!target.insertUser) {
            target.insertUser = target.userName;
        }
    }
}