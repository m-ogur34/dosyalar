import {Injectable} from '@angular/core';
import {NxMessageToastService} from '@aposin/ng-aquila/message';

@Injectable({
  providedIn: 'root'
})
export class AlertifyService {
  constructor(private messageToastService: NxMessageToastService) {
  }
  success(message: string) {
    this.messageToastService.open(message , {context: 'success', duration: 3000});
    // alertify.success(message);
  }
  info(message: string) {
    // alertify.warning(message);

    this.messageToastService.open(message , {context: 'info', duration: 5000});
  }

  error(message: string) {
    // alertify.warning(message);

    this.messageToastService.open(message , {context: 'info', duration: 5000});
  }
}
