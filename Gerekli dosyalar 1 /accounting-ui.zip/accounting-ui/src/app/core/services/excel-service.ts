import { ElementRef, Injectable } from '@angular/core';
import FileSaver from 'file-saver';
import { TranslateService } from '@ngx-translate/core';
import { ExportDataRequestModel } from '../models/export-data-request-model';
import { ExcelConstant } from '../common/constant/excel-constant';
import { DateFormatEnum } from '../common/enum/date-format.enum';
import { DynamicTableColumnModel } from '../models/dynamic-table-column.model';

const EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
const EXCEL_EXTENSION = '.xlsx';
import Excel from 'exceljs';

@Injectable({
    providedIn: 'root'
})
export class ExcelService {


    constructor(private translate: TranslateService
    ) { }


    exportExcelWithTable(request: ExportDataRequestModel) {
        if (!request.fileName) {
            throw new Error('Filename not found');
        }

        request.columns = (request?.columns ?? []).filter((x: any) => (x.isExportExcel || x.isExportExcel == null));

        // console.log('fileName:' + fileName);
        const workbook = new Excel.Workbook();

        let worksheet = workbook.addWorksheet(request.fileName, {
            properties: {
                // tabColor: { argb: 'FF00FF00' },
                defaultColWidth: ExcelConstant.DEFAULT_WIDTH,
                defaultRowHeight: 30
            }
        });

        // worksheet.views = [
        //   { state: 'frozen', xSplit: 2, ySplit: 3, topLeftCell: 'G10', activeCell: 'A1' }
        // ];

        let rows: any[]  = [];
        let tableColumns: any[] = [];
        let hasTotalRows = false;
        let hasMerge = false;

        let colIndex = 0;
        request?.columns?.forEach(c => {
            colIndex++;
            tableColumns.push({
                name: c.header,
                totalsRowLabel: 'Totals:',
                totalsRowFunction: c.totalsRowFunction,
                filterButton: true
            });

            if (c.excelWidth)
                worksheet.getColumn(colIndex).width = c.excelWidth;
            if (c.totalsRowFunction)
                hasTotalRows = true;
            if (c.isMerge)
                hasMerge = true;
            if (c.excelAlignment) {
                const allowedAlignments = ["left", "center", "right", "fill", "justify", "centerContinuous", "distributed"] as const;
                const align = allowedAlignments.includes(c.excelAlignment as typeof allowedAlignments[number]) ? c.excelAlignment as typeof allowedAlignments[number] : undefined;
                worksheet.getColumn(colIndex).alignment = { horizontal: align };
            }
        });



        (request?.data ?? []).forEach((e: Record<string, any>) => {
            const cols: any[] = [];
            (request?.columns ?? []).forEach((c: any) => {
                const field = c.field ?? '';
                const value = field ? e[field] : undefined;
                if (c.dateFormat && value) {
                    const date = new Date(value);
                    cols.push(isNaN(date.getTime()) ? '' : date.toLocaleString());
                } else if (c.translateKey) {
                    cols.push((value !== undefined && value !== null) ? this.translate.instant(c.translateKey + "." + value) : "");
                } else if (c.isBoolean) {
                    cols.push(value === 1 ? c.booleanTrueExp ?? "Evet" : c.booleanFalseExp ?? "Hayır");
                } else if (c.dataType == 'decimal') {
                    const num = Number(value ?? 0);
                    const decimals = c.roundDecimal ?? 2;
                    cols.push(!isNaN(num) ? Number(num.toFixed(decimals)) : '');
                } else if (c.dataType == 'boolean') {
                    cols.push(this.translate.instant('boolean.' + (value ?? '')));
                } else {
                    cols.push(value ?? '');
                }
            });
            rows.push(cols);
        });

        if (hasTotalRows && request.addTotalRows) {
            let cols: any[] = [];
            colIndex = 0;
            request?.columns?.forEach(c => {
                colIndex++;
                if (colIndex == 1 && !c.totalsRowFunction)
                    cols.push(this.translate.instant('common.total'));
                else if (c.totalsRowFunction && c.totalsRowFunction == 'sum')
                    cols.push(request?.data?.sumByField(c?.field?? ''));
                else if (c.totalsRowFunction && c.totalsRowFunction == 'count')
                    cols.push(request?.data?.length);
                else
                    cols.push('');

            });

            rows.push(cols);

        }

        if (hasMerge) {
            let startRowIndex = 1;
            let endRowIndex = 1;
            let counter = -1;
            let rowsCount = rows.length;
            let lastValue: any;

            rows.forEach(x => {
                counter++;


                if (counter == 0) {
                    startRowIndex = 2;
                    lastValue = rows[counter][0];
                }
                else if (counter < rowsCount && lastValue != rows[counter][0]) {
                    lastValue = rows[counter][0];
                    endRowIndex = counter + 1;

                    colIndex = 0;
                    request?.columns?.forEach(c => {
                        colIndex++;
                        if (c.isMerge)
                            worksheet.mergeCells(startRowIndex, colIndex, endRowIndex, colIndex);
                    });

                    startRowIndex = endRowIndex + 1;
                }
                else if (counter + 1 == rowsCount) {
                    endRowIndex = counter + 2;
                    colIndex = 0;

                    request?.columns?.forEach(c => {
                        colIndex++;
                        if (c.isMerge)
                            worksheet.mergeCells(startRowIndex, colIndex, endRowIndex, colIndex);
                    });
                }
            });
        }



        // worksheet.autoFilter = {
        //   from: {
        //     row: 1,
        //     column: 1
        //   },
        //   to: {
        //     row: 1,
        //     column: tableColumns.length
        //   }
        // }

        worksheet.addTable({
            name: 'Data',
            ref: 'A1',
            headerRow: true,
            totalsRow: false,
            // style: {
            //     // theme: 'TableStyleDark3',
            //     showRowStripes: true,
            // },
            columns: tableColumns,
            rows: rows,
        });

        workbook.xlsx.writeBuffer().then((data) => {
            let blob = new Blob([data], { type: EXCEL_TYPE });
            FileSaver.saveAs(blob, request?.fileName?.replace(' ', '_') + '_' + new Date().toISOString() + EXCEL_EXTENSION);
        })

    }

    exportExcelWithTableMultiSheets(requests: ExportDataRequestModel[]) {
        if (!requests || requests.length === 0) {
            console.error('Requests not found:', requests);
            return;
        }

        const workbook = new Excel.Workbook();

        requests.forEach((request, index) => {
            this.addWorkSheetToWorkbook(workbook, request, index);
        });

        workbook.xlsx.writeBuffer().then((data) => {
            const blob = new Blob([data], { type: EXCEL_TYPE });
            
            const filename = requests[0]?.fileName?.replace(/\s+/g, '_') || 'aznet_excel';

            FileSaver.saveAs(blob, filename + '_' + new Date().toISOString() + EXCEL_EXTENSION);
        }).catch((error) => {
            console.error('Error writing Excel buffer:', error);
        });
    }

    addWorkSheetToWorkbook(workbook: any, request: ExportDataRequestModel, sheetIndex: number) {
        try {
            const worksheet = workbook.addWorksheet(request.title || request.fileName, {
                properties: {
                    defaultColWidth: ExcelConstant.DEFAULT_WIDTH,
                    defaultRowHeight: 30
                }
            });
    
            // Add title to the worksheet
            const title = request.title || request.fileName;
            const columnCount = request?.columns?.length || 0;
            worksheet.addRow([title]);
            const mergeRange = `A1:${String.fromCharCode(65 + columnCount - 1)}1`;
            worksheet.mergeCells(mergeRange);
            worksheet.getCell('A1').font = { size: 16, bold: true };
            worksheet.getCell('A1').alignment = { horizontal: 'center' };
            
            request.columns = request?.columns?.filter(x => x.isExportExcel || x.isExportExcel == null) || [];
    
            const rows: any[] = [];
            const tableColumns: any[] = [];
            let hasTotalRows = false;
            let hasMerge = false;
    
            request?.columns?.forEach((c, index) => {
                const colIndex = index + 1;
                tableColumns.push({
                    name: c.header,
                    totalsRowLabel: 'Totals:',
                    totalsRowFunction: c.totalsRowFunction,
                    filterButton: true
                });
    
                if (c.excelWidth) worksheet.getColumn(colIndex).width = c.excelWidth;
                if (c.totalsRowFunction) hasTotalRows = true;
                if (c.isMerge) hasMerge = true;
                if (c.excelAlignment) {
                    const allowedAlignments = ["left", "center", "right", "fill", "justify", "centerContinuous", "distributed"];
                    worksheet.getColumn(colIndex).alignment = { horizontal: allowedAlignments.includes(c.excelAlignment) ? c.excelAlignment : undefined };
                }
            });
    
            request?.data?.forEach(e => {
                const cols: any[] = [];
                (request.columns ?? []).forEach((c: any) => {
                    const field = c.field ?? '';
                    const value = field ? e[field] : undefined;
                    if (c.dateFormat && value) {
                        const date = new Date(value);
                        cols.push(isNaN(date.getTime()) ? '' : date.toLocaleString());
                    } else if (c.translateKey) {
                        cols.push((value !== undefined && value !== null) ? this.translate.instant(c.translateKey + "." + value) : "");
                    } else if (c.isBoolean) {
                        cols.push(value === 1 ? c.booleanTrueExp ?? "Evet" : c.booleanFalseExp ?? "Hayır");
                    } else if (c.dataType === 'decimal') {
                        const num = Number(value ?? 0);
                        const decimals = c.roundDecimal ?? 2;
                        cols.push(!isNaN(num) ? Number(num.toFixed(decimals)) : '');
                    } else if (c.dataType === 'boolean') {
                        cols.push(this.translate.instant('boolean.' + (value ?? '')));
                    } else {
                        cols.push(value ?? '');
                    }
                });
                rows.push(cols);
            });

            request.columns.forEach((c, index) => {
                if (c.excelFormat === 'currency') {
                    worksheet.getColumn(index + 1).numFmt = '#,##0.00';
                }
            });
    
            if (hasTotalRows && request.addTotalRows) {
                const cols: any[] = [];
                (request.columns ?? []).forEach((c: any, index: number) => {
                    const colIndex = index + 1;
                    if (colIndex === 1 && !c.totalsRowFunction) {
                        cols.push(this.translate.instant('common.total'));
                    } else if (c.totalsRowFunction === 'sum') {
                        cols.push((request.data && c.field) ? request.data.sumByField(c.field) : 0);
                    } else if (c.totalsRowFunction === 'count') {
                        cols.push((request.data ?? []).length);
                    } else {
                        cols.push('');
                    }
                });
                rows.push(cols);
            }
    
            if (hasMerge) {
                let startRowIndex = 2; // Adjusted for title row
                let endRowIndex = 2; // Adjusted for title row
                let lastValue: any;
                rows.forEach((row, index) => {
                    if (index === 0) {
                        startRowIndex = 3; // Adjusted for title row
                        lastValue = row[0];
                    } else if (lastValue !== row[0]) {
                        endRowIndex = index + 2; // Adjusted for title row
                        this.mergeCells(worksheet, (request.columns ?? []), startRowIndex, endRowIndex);
                        startRowIndex = endRowIndex + 1;
                        lastValue = row[0];
                    } else if (index + 1 === rows.length) {
                        endRowIndex = index + 3; // Adjusted for title row
                        this.mergeCells(worksheet, (request.columns ?? []), startRowIndex, endRowIndex);
                    }
                });
            }
    
            worksheet.addTable({
                name: `Data_${sheetIndex}`, // Ensure unique table name
                ref: 'A2', // Adjusted for title row
                headerRow: true,
                totalsRow: false,
                columns: tableColumns,
                rows: rows,
            });
        } catch (error) {
            console.error('Error adding worksheet to workbook:', error);
        }
    }

    mergeCells(worksheet: any, columns: any[], startRowIndex: number, endRowIndex: number) {
        columns.forEach((c, index) => {
            const colIndex = index + 1;
            if (c.isMerge) {
                worksheet.mergeCells(startRowIndex, colIndex, endRowIndex, colIndex);
            }
        });
    }

    public exportArrayToExcel(jsonArrayData: any[], fileName: string): void {
        if (!fileName) {
            throw new Error('Filename not found');
        }

        if (!jsonArrayData) {
            throw new Error('Data not found');
        }

        const workbook = new Excel.Workbook();
        const worksheet = workbook.addWorksheet('data');

        if (jsonArrayData.length > 0 && !Array.isArray(jsonArrayData[0])) {
            const headers = Object.keys(jsonArrayData[0] ?? {});
            worksheet.addRow(headers);
            jsonArrayData.forEach((row: any) => {
                worksheet.addRow(headers.map((header) => row?.[header] ?? null));
            });
        } else {
            jsonArrayData.forEach((row: any) => {
                worksheet.addRow(Array.isArray(row) ? row : [row]);
            });
        }

        workbook.xlsx.writeBuffer().then((data) => {
            this.saveAsExcelFile(data, fileName);
        });
    }

    private saveAsExcelFile(buffer: any, fileName: string): void {
        const data: Blob = new Blob([buffer], {
            type: EXCEL_TYPE
        });
        FileSaver.saveAs(data, this.cleanString(fileName) + '_' + new Date().toISOString() + EXCEL_EXTENSION);
    }
    private cleanString(input: string): string {
        var output = "";
        for (var i = 0; i < input.length; i++) {
            if (input.charCodeAt(i) <= 127) {
                output += input.charAt(i);
            }
        }
        return output;
    }
    
    exportExcelTemplateWithDropdowns(request: ExportDataRequestModel, dropdownOptions: { [field: string]: string[] }): void {
        if (!request.fileName) {
            throw new Error('Filename not found');
        }
        
        request.columns = (request.columns ?? []).filter((x: any) => (x.isExportExcel || x.isExportExcel == null));
        
        const workbook = new Excel.Workbook();

        let worksheet = workbook.addWorksheet(request.fileName, {
            properties: {
                defaultColWidth: ExcelConstant.DEFAULT_WIDTH,
                defaultRowHeight: 30
            }
        });
        
        const tableColumns: any[] = [];
        
        let colIndex = 0;
        (request.columns ?? []).forEach((c: any) => {
            colIndex++;
            tableColumns.push({
                name: c.header,
                totalsRowLabel: 'Totals:',
                totalsRowFunction: c.totalsRowFunction,
                filterButton: true
            });
            if (c.excelWidth)
                worksheet.getColumn(colIndex).width = c.excelWidth;
            if (c.excelAlignment) {
                const allowedAlignments = ["left", "center", "right", "fill", "justify", "centerContinuous", "distributed"];
                worksheet.getColumn(colIndex).alignment = { horizontal: allowedAlignments.includes(c.excelAlignment) ? c.excelAlignment : undefined };
            }
        });
        
        const hiddenSheetNames = {};
        
        (request.columns ?? []).forEach((column: any, index: number) => {
            const colIndex = index + 1;
            const colLetter = this.getColumnLetter(colIndex);
            if (column.field && dropdownOptions[column.field] && dropdownOptions[column.field].length > 0) {
                const options = dropdownOptions[column.field];
                if (options.join(',').length > 255) {
                    const hiddenSheetName = `${column.field}_data`;
                    (hiddenSheetNames as Record<string, string>)[column.field] = hiddenSheetName;
                    const hiddenSheet = workbook.addWorksheet(hiddenSheetName, {
                        state: 'hidden' // Hide this sheet
                    });
                    options.forEach((option: any, idx: number) => {
                        hiddenSheet.getCell(`A${idx + 1}`).value = option;
                    });
                    worksheet.getCell(`${colLetter}2`).dataValidation = {
                        type: 'list',
                        allowBlank: true,
                        formulae: [`'${hiddenSheetName}'!$A$1:$A$${options.length}`]
                    };
                } else {
                    worksheet.getCell(`${colLetter}2`).dataValidation = {
                        type: 'list',
                        allowBlank: true,
                        formulae: [`"${options.join(',')}"`]
                    };
                }
            }
            
            if (column.dataType === 'date' && column.excelFormat) {
                worksheet.getCell(`${colLetter}2`).numFmt = column.excelFormat;
            }
            
            if (column.dataType === 'decimal' || column.excelFormat === 'currency') {
                worksheet.getCell(`${colLetter}2`).numFmt = '#,##0.00';
            }
        });
        
        worksheet.addTable({
            name: 'Data',
            ref: 'A1',
            headerRow: true,
            totalsRow: false,
            columns: tableColumns,
            rows: [new Array(request.columns.length).fill('')], // Add one empty row
        });
        
        workbook.xlsx.writeBuffer().then((data) => {
            let blob = new Blob([data], { type: EXCEL_TYPE });
            FileSaver.saveAs(blob, (request.fileName ?? 'export').replace(' ', '_') + '_' + new Date().toISOString() + EXCEL_EXTENSION);
        })
    }
    
    /**
     * Helper method to convert column index to letter
     * @param columnIndex The 1-based column index
     * @returns Column letter(s) for the Excel column
     */
    private getColumnLetter(columnIndex: number): string {
        let dividend = columnIndex;
        let columnName = '';
        let modulo;

        while (dividend > 0) {
            modulo = (dividend - 1) % 26;
            columnName = String.fromCharCode(65 + modulo) + columnName;
            dividend = Math.floor((dividend - modulo) / 26);
        }

        return columnName;
    }

    static exportTableToExcel(fileName: string, table: ElementRef) {
        if (!fileName) {
            throw new Error('Filename not found');
        }

        if (!table) {
            throw new Error('Table not found');
        }

        const workbook = new Excel.Workbook();
        const worksheet = workbook.addWorksheet(fileName || 'Sheet1');
        const tableEl: HTMLElement = table.nativeElement;
        const rows = Array.from(tableEl.querySelectorAll('tr'));

        rows.forEach((row) => {
            const values = Array.from(row.querySelectorAll('th,td')).map((cell) =>
                (cell.textContent ?? '').trim()
            );
            worksheet.addRow(values);
        });

        workbook.xlsx.writeBuffer().then((data) => {
            const blob = new Blob([data], { type: EXCEL_TYPE });
            FileSaver.saveAs(blob, fileName.endsWith(EXCEL_EXTENSION) ? fileName : `${fileName}${EXCEL_EXTENSION}`);
        });

    }

    static async importExcelToArray(data: string): Promise<any[]> {
        const workbook = new Excel.Workbook();
        const buffer = this.binaryStringToArrayBuffer(data);
        await workbook.xlsx.load(buffer);

        const worksheet = workbook.worksheets[0];
        if (!worksheet) {
            return [];
        }

        const rows: any[] = [];
        worksheet.eachRow((row) => {
            const values = Array.isArray(row.values) ? row.values.slice(1) : [];
            rows.push(values);
        });

        return rows;
    }

    public async importFromFile(bstr: string): Promise<any[]> {
        return ExcelService.importExcelToArray(bstr);
    }

    private static binaryStringToArrayBuffer(binary: string): ArrayBuffer {
        const len = binary.length;
        const bytes = new Uint8Array(len);
        for (let i = 0; i < len; i++) {
            bytes[i] = binary.charCodeAt(i) & 0xff;
        }
        return bytes.buffer;
    }

    public getRowDataWithCols(dataList: any, columns: DynamicTableColumnModel[]) {
        let headers = dataList[0];
        return dataList.slice(1).map((rowExcel: any) => {
            const obj: Record<string, any> = {};
            for (let i = 0; i < headers.length; i++) {
                const colHeader = headers[i];
                let colData = rowExcel[i];
                const colProperties = columns.filter(x => x.isImportExcel && (x.header == colHeader || x.field == colHeader))[0];
                let fieldName = colHeader;
                if (colProperties) {
                    fieldName = colProperties.field;
                }
                if (colData == 'NULL')
                    colData = null;
                if (colData != undefined) {
                    if (colProperties) {
                        if (colProperties.dataType == 'date') {
                            obj[fieldName] = new Date((colData - 25569) * 24 * 60 * 60 * 1000);
                            if (obj[fieldName] == 'Invalid Date')
                                obj[fieldName] = this.getDateFromString(colData);
                        }
                        else {
                            obj[fieldName] = colData;
                        }
                    } else {
                        obj[fieldName] = colData;
                    }
                }
            }
            return obj as any;
        });
    }


    getDateFromString(str: string): Date | null {

        const [dateComponents, timeComponents] = str.split(' ');

        const [day, month, year] = dateComponents.split('.');
        const [hours, minutes, seconds] = timeComponents ? timeComponents.split(':') : [0, 0, 0];

        const date = new Date(+year, +month - 1, +day, +hours, +minutes, +seconds);

        return date;
    }


}