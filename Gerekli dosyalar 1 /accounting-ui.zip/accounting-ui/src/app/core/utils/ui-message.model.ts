export class UIMessage {
  code: string;
  field?: string;
  message: string;
  severity: string;

  public constructor(err?: any) {
    console.log(err);
    if (typeof err.succeeded !== 'undefined') {
      console.log('error type 1 ');
      this.code = err.error.code;
      this.message = err.error.message + ' traceId: ' + err.error.traceId;
      this.severity = 'error';
    } else if (typeof err === 'string') {
      this.code = '';
      this.message = err;
      this.severity = 'error';
    } else {
      console.log('error type 2 ');
      this.code = '';
      this.message = err.error.message ?? err.statusText ?? err.error;
      this.severity = 'error';
    }
  }
}
