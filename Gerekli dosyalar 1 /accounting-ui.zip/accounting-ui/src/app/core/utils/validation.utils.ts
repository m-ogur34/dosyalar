import { FormGroup } from "@angular/forms";

export default class ValidationUtils {

    static isNull(data: any): boolean {
        return data === undefined || data === null;
    }

    static isString(data: any): boolean {
        return typeof data === 'string';
    }

    static isEmpty(a: any): boolean {
        return this.isNull(a) || (this.isString(a) && a.trim().length === 0);
    }
  
    static isNumerical(value: string): boolean {
      if (this.isNull(value)) {
        return false;
      }
      const number = parseInt(value.toString());
      return !isNaN(number);
    }
  
    static isDateString(value: string): boolean {
      let regexp = /^(0?[1-9]|[12]\d|3[01])-(0?[1-9]|1[012])-\d{4}$/;
      return regexp.test(value);
    }
  }