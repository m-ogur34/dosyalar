import { Moment } from 'moment';
export class AlzType {
  private static BOOLEAN_VALUES: string[] = ['T', 'Y', 'on', '1'];
  private static id = 0;

  static nextId(): number {
    AlzType.id++;
    return AlzType.id;
  }
  static isEmpty(value: any): boolean {
    return value === null || value === undefined;
  }
  static toJson(value: any, native: boolean = true): string {
    // to protect any circular dependency, infinite loops etc
    try {
      value = AlzType.toJsonInner(value);
    } catch (e) {
    }
    return JSON.stringify(value);
  }
  private static toJsonInner(obj: any, level: number = 0, visited = new WeakSet()): any {
    if (!AlzType.isObject(obj)) {
      return obj;
    }
      if (visited.has(obj)) {
      return { alzState: 'com.yelmer.CircularDependency' };
    }
    visited.add(obj);
    if (Array.isArray(obj)) {
      const arrayResult = obj.map(item => 
        AlzType.toJsonInner(item, level + 1, visited)
      );
      visited.delete(obj);
      return arrayResult;
    }
    const result: Record<string, any> = {};
    Object.entries(obj).forEach(([key, value]) => {
      result[key] = AlzType.toJsonInner(value, level + 1, visited);
    });
    visited.delete(obj);
    return result;
  }
  
  static isObject(value: any): boolean {
    return !(typeof value !== 'object' || AlzType.isEmpty(value));
  }
  static getMember(value: any, key: any): any {
    if (!AlzType.isObject(value)) { return null; }
    const type = typeof key;
    let member: any;
    switch (typeof key) {
      case 'string':
        key = AlzType.checkString(key);
        member = (key != null) ? value[key] : null;
        return (member !== undefined) ? member : null;
      case 'number':
        key = AlzType.checkInt(key);
        member = (key != null) ? value[key] : null;
        return (member !== undefined) ? member : null;
    }
    return null;
  }
  static checkDate(value: Date | string | Moment, nullable: boolean = false): Date | null {
    if (value instanceof Date) {
        return value;
    }

    if (typeof value === 'object' && 'toDate' in value) {
        // Eğer value bir Moment ise
        return (value as Moment).toDate();
    }

    if (Array.isArray(value)) {
        // Eğer value bir dizi ise
        const [year, month, day] = value.map(v => parseInt(v, 10));
        return new Date(year, month - 1, day);
    }

    if (typeof value === 'string') {
        // Eğer value bir string ise
        let dt: Date;
        const separators = ['/', '.'];
        for (const sep of separators) {
            if (value.includes(sep)) {
                const [day, month, year] = value.split(sep).map(v => parseInt(v, 10));
                dt = new Date(year, month - 1, day);
                return dt;
            }
        }
        dt = new Date(Date.parse(value));
        if (!isNaN(dt.getTime())) {
            return dt;
        }
    }

    // Eğer yukarıdaki kontrollerden hiçbiri geçerli değilse
    return nullable ? null : new Date();
}

  static checkDateArray(vals: any): Date[] {
    if (AlzType.isEmpty(vals)) { return []; }
    if (!AlzType.isObject(vals)) { return []; }
    if (!Array.isArray(vals)) { vals = Object.values(vals); }
    // tslint:disable-next-line:forin
    for (const i in vals) {
      vals[i] = AlzType.checkDate(vals[i]);
    }
    return vals;
  }
  static checkObject(value: any): object {
    if (AlzType.isEmpty(value)) { return {}; }
    const type = typeof value;
    if (type === 'object') {
      return value;
    } else if (type === 'string') {
      value = value.trim();
      try {
        return (value === '') ? {} : JSON.parse(value);
      } catch (e) {
        return {};
      }
    }
    return {};
  }
  static cloneObject(val: any): any {
    const res: any = {};
    if (AlzType.isObject(val)) {
      for (const key in val) {
        if (typeof val[key] === 'function') { continue; }
        res[key] = val[key];
      }
    }
    return res;
  }

  static checkString(value: any): string | null {
    if (AlzType.isEmpty(value)) { return null; }
    const type = typeof value;
    if (type === 'string') {
      value = value.trim();
      return (value === '') ? null : value;
    } else if (type === 'number') {
      return value.toString();
    }
    return null;
  }
  static checkStringArray(vals: any): string[] {
    if (AlzType.isEmpty(vals)) { return []; }
    if (!AlzType.isObject(vals)) { return []; }
    if (!Array.isArray(vals)) { vals = Object.values(vals); }
    // tslint:disable-next-line:forin
    for (const i in vals) {
      vals[i] = AlzType.checkString(vals[i]);
    }
    return vals;
  }
  static checkBoolean(value: any, def: boolean = false): boolean | null {
    if (AlzType.isEmpty(value)) { return def; }
    const type = typeof value;
    if (type === 'boolean') {
      return value === true;
    } else if (type === 'string') {
      return AlzType.BOOLEAN_VALUES.indexOf(value.trim()) >= 0;
    } else if (type === 'number') {
      return value > 0;
    }
    return def;
  }
  static checkBooleanArray(vals: any): boolean[] {
    if (AlzType.isEmpty(vals)) { return []; }
    if (!AlzType.isObject(vals)) { return []; }
    if (!Array.isArray(vals)) { vals = Object.values(vals); }
    // tslint:disable-next-line:forin
    for (const i in vals) {
      vals[i] = AlzType.checkBoolean(vals[i]);
    }
    return vals;
  }
  static checkInt(value: any, def: number | null = null): number | null {
    if (AlzType.isEmpty(value)) {
      return def;
    }
    const type = typeof value;
    if (type === 'string') {
      const parsedValue = parseInt(value.replace(/,/g, '').trim(), 10);
      return isNaN(parsedValue) ? def : parsedValue;
    }
    if (type === 'number') {
      return isNaN(value) ? def : Math.floor(value);
    }
    if (type === 'boolean') {
      return value ? 1 : 0;
    }
    return def;
  }
  static checkIntArray(vals: any): number[] {
    if (AlzType.isEmpty(vals)) { return []; }
    if (!AlzType.isObject(vals)) { return []; }
    if (!Array.isArray(vals)) { vals = Object.values(vals); }
    // tslint:disable-next-line:forin
    for (const i in vals) {
      vals[i] = AlzType.checkInt(vals[i]);
    }
    return vals;
  }
  static checkFloat(value: any, def: number | null = null): number | null {
    if (AlzType.isEmpty(value)) {
      return def;
    }
    const type = typeof value;
    if (type === 'string') {
      const parsedValue = parseFloat(value.replace(/,/g, '').trim());
      return isNaN(parsedValue) ? def : parsedValue;
    }
    if (type === 'number') {
      return isNaN(value) ? def : value;
    }
    return def;
  }
  static checkFloatArray(vals: any): number[] {
    if (AlzType.isEmpty(vals)) { return []; }
    if (!AlzType.isObject(vals)) { return []; }
    if (!Array.isArray(vals)) { vals = Object.values(vals); }
    // tslint:disable-next-line:forin
    for (const i in vals) {
      vals[i] = AlzType.checkFloat(vals[i]);
    }
    return vals;
  }
  static showDate(val: Date) {
    const tmp = {
      fullStr: val.toString(),
      utcStr: val.toUTCString(),
      timeStr: val.toTimeString(),
      dateStr: val.toDateString(),
      localeStr: val.toLocaleString(),
      localeDateStr: val.toLocaleDateString(),
      localeTimeStr: val.toLocaleTimeString(),
      isoStr: val.toISOString(),
      date: val.getDate(),
      time: val.getTime(),
      fullYear: val.getFullYear(),
      utcFullYear: val.getUTCFullYear(),
      month: val.getMonth(),
      utcMonth: val.getUTCMonth(),
      utcDate: val.getUTCDate(),
      day: val.getDay(),
      utcDay: val.getUTCDay(),
      hour: val.getHours(),
      utcHour: val.getUTCHours(),
      minute: val.getMinutes(),
      utcMinute: val.getUTCMinutes(),
      second: val.getSeconds(),
      utcSecond: val.getUTCSeconds(),
      millisecond: val.getMilliseconds(),
      utcMillisecond: val.getUTCMilliseconds(),
      timezone: val.getTimezoneOffset()
    };
  }
  static td(val: number): string {
    return (val < 10) ? '0' + val.toString() : val.toString();
  }
  static toDateStr(value: Date, nullable: boolean = false): string | null {
    const date = AlzType.checkDate(value, nullable);
    if (!date) return null;
  
    return `${date.getFullYear()}-${AlzType.td(date.getMonth() + 1)}-${AlzType.td(date.getDate())}`;
  }
  
  static toViewDate(value: Date): string | null {
    const date = AlzType.checkDate(value, true);
    if (!date) return null;
  
    return `${AlzType.td(date.getDate())}.${AlzType.td(date.getMonth() + 1)}.${date.getFullYear()}`;
  }
  
  static toDatetimeStr(value: Date, setNow: boolean = false): string | null {
    const date = AlzType.checkDate(value, true);
    if (!date) return null;
  
    if (setNow) {
      const now = new Date();
      date.setHours(now.getHours(), now.getMinutes(), now.getSeconds());
    }
  
    return `${date.getFullYear()}-${AlzType.td(date.getMonth() + 1)}-${AlzType.td(date.getDate())}T` +
      `${AlzType.td(date.getHours())}:${AlzType.td(date.getMinutes())}:${AlzType.td(date.getSeconds())}`;
  }
  
  static toDatetimeFile(name: string, ext: string): string {
    const now = new Date();
  
    return `${name}.${now.getFullYear()}-${AlzType.td(now.getMonth() + 1)}-${AlzType.td(now.getDate())}-` +
      `${AlzType.td(now.getHours())}-${AlzType.td(now.getMinutes())}-${AlzType.td(now.getSeconds())}.${ext}`;
  }
  
  static toViewDatetime(value: Date): string | null {
    const date = AlzType.checkDate(value, true);
    if (!date) return null;
  
    return `${AlzType.td(date.getDate())}.${AlzType.td(date.getMonth() + 1)}.${date.getFullYear()} ` +
      `${AlzType.td(date.getHours())}:${AlzType.td(date.getMinutes())}:${AlzType.td(date.getSeconds())}`;
  }
  
}