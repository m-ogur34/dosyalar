import { Inject, Injectable, Optional } from '@angular/core';
import { Platform } from '@angular/cdk/platform';
import { NX_DATE_LOCALE, NxNativeDateAdapter } from '@allianz/ng-aquila/datefield';

@Injectable()
export class DdMmYyyyDateAdapter extends NxNativeDateAdapter {
  constructor(
    @Optional() @Inject(NX_DATE_LOCALE) dateLocale: string | null,
    platform: Platform
  ) {
    super(dateLocale, platform);
  }

  override parse(value: any): Date | null {
    if (value === null || value === undefined) {
      return null;
    }

    if (value instanceof Date) {
      return this.isValid(value) ? this.clone(value) : this.invalid();
    }

    if (typeof value === 'number') {
      const date = new Date(value);
      return this.isValid(date) ? date : this.invalid();
    }

    if (typeof value !== 'string') {
      return super.parse(value);
    }

    const trimmedValue = value.trim();
    if (!trimmedValue) {
      return null;
    }

    // Strict dd/MM/yyyy parsing for manual keyboard input.
    const match = /^(\d{2})\/(\d{2})\/(\d{4})$/.exec(trimmedValue);
    if (!match) {
      return this.invalid();
    }

    const day = Number(match[1]);
    const month = Number(match[2]);
    const year = Number(match[3]);

    if (month < 1 || month > 12 || day < 1 || day > 31) {
      return this.invalid();
    }

    const parsedDate = new Date(year, month - 1, day);
    const validDate =
      parsedDate.getFullYear() === year &&
      parsedDate.getMonth() === month - 1 &&
      parsedDate.getDate() === day;

    return validDate ? parsedDate : this.invalid();
  }
}