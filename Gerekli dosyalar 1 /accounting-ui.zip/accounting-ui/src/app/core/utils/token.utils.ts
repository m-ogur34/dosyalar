/**
 * Token Management Utility
 * Centralized token management with Bearer prefix support
 *
 * @description
 * This utility provides a single source of truth for token management across the application.
 * It automatically handles Bearer prefix addition and removal, ensuring consistent token format
 * in storage and HTTP headers.
 *
 * @example
 * // Set token
 * TokenUtils.setToken('abc123');
 *
 * // Get Bearer token for Authorization header
 * const authHeader = TokenUtils.getBearerToken(); // "Bearer abc123"
 *
 * // Get raw token
 * const token = TokenUtils.getToken(); // "abc123"
 *
 * // Check authentication
 * if (TokenUtils.isAuthenticated()) {
 *   // User is logged in
 * }
 *
 * // Clear token on logout
 * TokenUtils.clearToken();
 */
export class TokenUtils {
    private static readonly TOKEN_KEY = 'token';
    private static readonly BEARER_PREFIX = 'Bearer ';
    private static readonly REDIRECT_URL_KEY = 'redirectUrl';

    /**
     * Get raw token from session storage
     * @returns Token string without Bearer prefix, or null if not found/invalid
     */
    public static getToken(): string | null {
        const token = sessionStorage.getItem(this.TOKEN_KEY);

        // Handle invalid token values
        if (!token || token === 'undefined' || token === 'null' || token === '') {
            return null;
        }

        // If token has Bearer prefix, remove it before returning
        if (token.startsWith(this.BEARER_PREFIX)) {
            return token.substring(this.BEARER_PREFIX.length);
        }

        return token;
    }

    /**
     * Get token with Bearer prefix for Authorization header
     * @returns Token with "Bearer " prefix, or null if token not found
     */
    public static getBearerToken(): string | null {
        const token = this.getToken();

        if (!token) {
            return null;
        }

        return `${this.BEARER_PREFIX}${token}`;
    }

    /**
     * Set token in session storage
     * Automatically removes Bearer prefix if present before storing
     * @param token - Token string (with or without Bearer prefix)
     */
    public static setToken(token: string): void {
        if (!token || token === 'undefined' || token === 'null') {
            return;
        }

        // Remove Bearer prefix if present before storing
        const cleanToken = token.startsWith(this.BEARER_PREFIX)
            ? token.substring(this.BEARER_PREFIX.length)
            : token;

        sessionStorage.setItem(this.TOKEN_KEY, cleanToken);
    }

    /**
     * Remove token from session storage
     */
    public static clearToken(): void {
        sessionStorage.removeItem(this.TOKEN_KEY);
    }

    /**
     * Check if a valid token exists
     * @returns true if valid token exists, false otherwise
     */
    public static hasToken(): boolean {
        return this.getToken() !== null;
    }

    /**
     * Check if user is authenticated
     * Alias for hasToken() for better semantic meaning
     * @returns true if user is authenticated, false otherwise
     */
    public static isAuthenticated(): boolean {
        return this.hasToken();
    }

    /**
     * Remove specific item from session storage
     * @param key - The key to remove
     */
    public static removeSessionItem(key: string): void {
        sessionStorage.removeItem(key);
    }

    /**
     * Store the URL user was trying to access before login redirect
     * @param url - The URL to store for later redirect
     */
    public static setRedirectUrl(url: string): void {
        if (url && url !== '/login') {
            sessionStorage.setItem(this.REDIRECT_URL_KEY, url);
        }
    }

    /**
     * Get the stored redirect URL
     * @returns The stored URL or null if not found
     */
    public static getRedirectUrl(): string | null {
        return sessionStorage.getItem(this.REDIRECT_URL_KEY);
    }

    /**
     * Clear the stored redirect URL
     */
    public static clearRedirectUrl(): void {
        sessionStorage.removeItem(this.REDIRECT_URL_KEY);
    }

    /**
     * Check if token string is valid
     * @param token - Token to validate
     * @returns true if token is valid
     */
    public static isValidToken(token: string | null): boolean {
        return token !== null &&
            token !== undefined &&
            token !== 'undefined' &&
            token !== 'null' &&
            token !== '' &&
            token.length > 10;
    }
}