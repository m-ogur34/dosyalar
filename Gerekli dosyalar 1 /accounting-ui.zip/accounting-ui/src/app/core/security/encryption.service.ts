import { Injectable } from "@angular/core";
import { firstValueFrom } from "rxjs";
import { BaseRestService } from "../../services/base-rest.service";

@Injectable({ providedIn: 'root' })
export class EncryptionService extends BaseRestService {

  private publicKey?: CryptoKey;
  private keyLoadingPromise?: Promise<void>;


  loadPublicKey(): Promise<void> {
    // If already loaded, return immediately
    if (this.publicKey) {
      return Promise.resolve();
    }

    // If currently loading, wait for that to complete
    if (this.keyLoadingPromise) {
      return this.keyLoadingPromise;
    }

    // Start loading
    this.keyLoadingPromise = firstValueFrom(
      this.baseGet('/crypto/public-key')
    ).then(async res => {
      const keyBytes = Uint8Array.from(
        atob(res.key),
        c => c.charCodeAt(0)
      );

      this.publicKey = await crypto.subtle.importKey(
        'spki',
        keyBytes,
        {
          name: 'RSA-OAEP',
          hash: 'SHA-256',
        },
        true,
        ['encrypt']
      );
      console.log('RSA public key loaded');
    }).finally(() => {
      this.keyLoadingPromise = undefined;
    });

    return this.keyLoadingPromise;
  }

  async encrypt(value: string): Promise<string> {
    // Automatically load key if not loaded yet
    if (!this.publicKey) {
      await this.loadPublicKey();
    }

    if (!this.publicKey) {
      throw new Error('Failed to load public key');
    }

    const enc = new TextEncoder().encode(value);

    const cipherBuffer = await crypto.subtle.encrypt(
      { name: 'RSA-OAEP' },
      this.publicKey,
      enc
    );

    const cipherBytes = new Uint8Array(cipherBuffer);
    const cipherStr = String.fromCharCode(...cipherBytes);
    return btoa(cipherStr);
  }
}
