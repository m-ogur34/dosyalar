import { EncryptionService } from "./encryption.service";


export async function encryptModel<T>(
  model: any,
  modelType: new () => T,
  encryptionService: EncryptionService
): Promise<T> {
  const copy = { ...model };
  const instance = Object.assign({}, new modelType(), copy);

  const encryptedFields = instance.__encryptedFields || [];

  for (const key of encryptedFields) {
    if (instance[key]) {
      instance[key] = await encryptionService.encrypt(instance[key]);
    }
  }

  return instance;
}


export function EncryptedField(target: any, propertyKey: string) {
  if (!target.__encryptedFields) {
    target.__encryptedFields = [];
  }

  target.__encryptedFields.push(propertyKey);
}

