export class ExportDataResponseModel {
    data?: string;
    fileName?: string;
    fileType?: string;
}