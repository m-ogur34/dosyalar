export class UIMessage {
    code: string;
    field?: string;
    message: string;
    severity: string;
    public constructor(err?: any) {
      if ((typeof err.succeeded) !== 'undefined') {
        this.code = err.error.code;
        this.message = err.error.message;
        this.severity = 'error';
      } else if ((typeof err) === "string") {
        this.code = '';
        this.message = err;
        this.severity = 'error';
      } else {
        this.code = '';
        this.message = err && err.error && err.error.message ? err.error.message : (err.statusText ? err.statusText : err.error);
        this.severity = 'error';
      }
    }
  }
