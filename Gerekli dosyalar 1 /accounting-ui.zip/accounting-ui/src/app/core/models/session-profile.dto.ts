
export class SessionProfileDto {

    partnerId?: any;
    userName: string | null;
    name?: any;
    agentIntId: number | null;
    agencyCode?: any;
    agencyTitle?: any;
    userType: string | null;
    startDate?: any;
    endDate?: any;
    active?: any;
    passwordExpired?: any;
    isIndustrialUser?: any;
    subAgent?: any;
    subAgentCode?: any;
    subAgentTitle?: any;
    subUserType: string | null;
    vkno?: any;
    agencyCodeLife: number | null;
    hsbcRegisterNo?: any;
    hsbcRegionCode?: any;
    expirationMessage?: any;
    ipRestrictionMessage?: any;
    salesPersonEmpId?: any;
    email?: any;
    companyCode: string | null;
    technicalStaff?: any;
    bgdUser?: any;
    callCenterUser?: any;
    uwUser?: any;
    absUser?: any;
    hlthInstituteCode: number | null;
    profileType?: any;
    jwtToken?: any;
    profileInformations?: any;
    isFordUser?: boolean;

    constructor() {
        this.partnerId = null;
        this.userName = null;
        this.name = null;
        this.agentIntId = null;
        this.agencyCode = null;
        this.agencyTitle = null;
        this.userType = null;
        this.startDate = null;
        this.endDate = null;
        this.active = null;
        this.passwordExpired = null;
        this.isIndustrialUser = null;
        this.subAgent = null;
        this.subAgentCode = null;
        this.subAgentTitle = null;
        this.subUserType = null;
        this.vkno = null;
        this.agencyCodeLife = null;
        this.hsbcRegisterNo = null;
        this.hsbcRegionCode = null;
        this.expirationMessage = null;
        this.ipRestrictionMessage = null;
        this.salesPersonEmpId = null;
        this.email = null;
        this.companyCode = null;
        this.technicalStaff = null;
        this.bgdUser = null;
        this.callCenterUser = null;
        this.uwUser = null;
        this.absUser = null;
        this.hlthInstituteCode = null;
        this.profileType = null;
        this.jwtToken = null;
        this.profileInformations = null;
        this.isFordUser = false;
    }
}