import { Injectable } from '@angular/core';
import { CommonConstants } from '../common/constant/common-constants';

export type StorageType = 'local' | 'session';

@Injectable({ providedIn: 'root' })
export class GenericStorageService {
    private engine(type: StorageType): Storage {
        return type === 'local' ? localStorage : sessionStorage;
    }

    setItem<T>(key: string, value: T, type: StorageType = 'session'): void {
        try {
            this.engine(type).setItem(key, JSON.stringify(value));
        } catch (e) {
            console.error('Storage setItem error', e);
        }
    }

    getItem<T>(key: string, type: StorageType = 'session'): T | null {
        try {
            const raw = this.engine(type).getItem(key);
            return raw ? (JSON.parse(raw) as T) : null;
        } catch (e) {
            console.error('Storage getItem error', e);
            return null;
        }
    }

    removeItem(key: string, type: StorageType = 'session'): void {
        try {
            this.engine(type).removeItem(key);
        } catch (e) {
            console.error('Storage removeItem error', e);
        }
    }

    removeItems(keys: string[], type: StorageType = 'session'): void {
        try {
            const storage = this.engine(type);
            keys.forEach(k => sessionStorage.removeItem(k));
        } catch (e) {
            console.error('Remove item error on remove items');
        }

    }

    clear(type: StorageType = 'session'): void {
        try {
            this.engine(type).clear();
        } catch (e) {
            console.error('Storage clear error', e);
        }
    }

    clearSessionProfile() {
        this.removeItem(CommonConstants.USER_PROFILE_KEY, 'session');
        this.removeItem(CommonConstants.USER_TYPE, 'session');
    }
}