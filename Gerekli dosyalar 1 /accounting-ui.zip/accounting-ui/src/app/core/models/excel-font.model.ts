export class ExcelFontModel {
  name?: string;
  size?: number;
  bold?: boolean;
  strike?: boolean;
}
