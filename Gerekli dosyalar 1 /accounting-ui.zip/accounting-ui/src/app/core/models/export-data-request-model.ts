import { DynamicTableColumnModel } from "./dynamic-table-column.model";

export class ExportDataRequestModel {
    fileName?: string;
    data?: any[];
    columns?: DynamicTableColumnModel[];
    addTotalRows: boolean = false;
    customerId?: number;
    isDateActive?: Boolean;
    startDate?: Date;
    endDate?: Date;
    currencyCode?: string;
    fileType?: string;
    isLandscape?: boolean;
    title?: string;
}