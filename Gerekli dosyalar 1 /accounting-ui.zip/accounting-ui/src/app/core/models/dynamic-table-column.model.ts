import { ExcelStyleModel } from "./excel-style.model";

// import { ExcelStyleModel } from "../dto/excelStyle.model";
export class DynamicTableColumnModel {

  field?: string;
  header?: string;
  align?: string;
  width?: string;
  dataType?: string;
  dateFormat?: string;
  excelFormat?: string;
  isBold?: boolean;
  isSelected?: boolean;
  isHidden?: boolean;
  roundDecimal?: number;
  style?:string;

  isExportExcel?: boolean;
  excelWidth?: number;
  excelStyle?: ExcelStyleModel;
  totalsRowFunction?: string;
  imageBaseUrl?: string;
  reportType?: any[];
  translateKey?: string;
  isImportExcel?: boolean;
  isMerge?: boolean;
  headerStye?: string;
  maxDisplayLength?: number;
  isPrivateData?: boolean;
  defaultValue?: any;
  isBoolean?: boolean;
  booleanTrueExp?: string;
  booleanFalseExp?: string;
  excelAlignment?: string
  formatter?: (item: any) => string;

  // Tablo dip toplamı için
  isTotal?: boolean;

}
