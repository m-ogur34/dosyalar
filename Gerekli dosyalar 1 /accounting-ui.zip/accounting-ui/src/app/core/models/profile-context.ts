// profile-context.ts
export interface ProfileContext {
    agentIntId?: number;
    userName?: string;
    agencyCode?: string;
    userType?: string | null;
    isPartajDisabled?: boolean;
    activeReferenceCode?: string;
    insertUser?: string;
}