import { ExcelFontModel } from "./excel-font.model";

export class ExcelStyleModel {
  font?: ExcelFontModel
}
