export class TokenRequest {
  userName?: string;
}
