import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { environment } from '../../../environments/environment';
import { TokenUtils } from '../utils/token.utils';

@Injectable({
    providedIn: 'root'
})
export class AuthGuard implements CanActivate {

    constructor(private router: Router) { }

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
        if (TokenUtils.isAuthenticated()) {
            return true;
        }

        // Store the attempted URL for redirecting after login
        TokenUtils.setRedirectUrl(state.url);

        // Redirect to CAS login
        this.redirectToLogin();
        return false;
    }

    private redirectToLogin(): void {
        const loginUrl = environment.deployUrl + 'login';
        const fullRedirectUrl = environment.casLoginUrl + encodeURIComponent(loginUrl);

        window.location.href = fullRedirectUrl;
    }
}