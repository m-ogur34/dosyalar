
import { SessionProfileDto } from "../../models/specific/cas-user/session-profile.dto";
import { AlzType } from "../utils/alz.type";


export class GlobalRuntime {

  static objId = 0;
  private static userProfile: SessionProfileDto;
  private static userProfileLoaded = false;
  private static token: string;
  static lang: string;
  private static vkno: string;
  static url: string;
  private static userAdmin:boolean;

  static newId(): number {
    return GlobalRuntime.objId++;
  }

  static getUserProfile(): SessionProfileDto {
    return this.userProfile;
  }



  /*Sessionda bulunan kullanicinin yonetici olup olmadigini belirtir.*/
  static getUserAdmin(): boolean {
    return this.userAdmin;

  }
  static setUserAdmin(value :boolean): boolean {
    return this.userAdmin=value;

  }

  static isUserProfileLoaded(): boolean {
    return GlobalRuntime.userProfileLoaded;
  }

  static setUserProfile(userProfile: SessionProfileDto | any) {
    this.userProfile = userProfile;
    this.userProfileLoaded = AlzType.isObject(userProfile);
  }

  static getToken() {
    return GlobalRuntime.token;
  }

  static setToken(token: any) {
    GlobalRuntime.token = token;
  }



  private static changedAddToList(id: number, ids: number[]): number[] {
    if (id !== null) {
      ids.push(id);
      ids = [...new Set(ids)];
    }
    return ids;
  }
}