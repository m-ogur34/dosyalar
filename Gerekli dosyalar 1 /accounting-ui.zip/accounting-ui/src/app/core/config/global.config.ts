export class GlobalConfig {
    static CAS_ENABLED = true;
    static CAS_COOKIE = 'AuthorizationCookie';
    static CAS_TOKEN = 'Authorization';
    static VOYAGE_HOME = 'TR';
    static CURRENCY_DOMESTIC = 'TL';
    static CURRENCY_DEFAULT = 'TL';
    static I18N_DEFAULT = 'tr';
    static CAS_REDIRECT_PATH_NAME = 'CasRedirectPathName';

    // Scopes
    static SCOPE_DOMESTIC = '3';
    static SCOPE_EXPORT = '2';
    static SCOPE_IMPORT = '1';
    static SCOPE_TRANSIT = '5';

    // Dates
    static DATE_VIEW_PATTERN = 'dd.MM.yyyy';
    static DATE_EDIT_PATTERN = 'MM/DD/YYYY';

    // Locales
    static LOCALE_FOR_NUMBER = 'en-US';

    // Number pipe pattern for viewed values
    static EXCHANGE_RATE_PATTERN = '1.1-5';
    static INSURED_AMOUNT_PATTERN = '1.0-2';
    static PREMIUM_AMOUNT_PATTERN = '1.2-5';
    static PREMIUM_PERCENT_PATTERN = '1.4-4';
    static ADDITIONAL_RATE_PATTERN = '1.1-2';

    // Ajax options
    static HTTP_METHODS: string[] = ['LOCAL', 'GET', 'POST', 'PUT', 'DELETE'];
    static VALUE_PLACES: string[] = ['INBODY', 'QUERY', 'PATH', 'HEADER'];

    static IDM_MAIN = 'MainPolicy';

        static DECIMAL: { [key: string]: DecimalFormatter } = {
      standard: { min: 1, max: 10, locale: GlobalConfig.LOCALE_FOR_NUMBER },
      integer: { min: 0, max: 0, locale: GlobalConfig.LOCALE_FOR_NUMBER },
      exchangeRate: { min: 1, max: 5, locale: GlobalConfig.LOCALE_FOR_NUMBER },
      insuredAmount: { min: 0, max: 2, locale: GlobalConfig.LOCALE_FOR_NUMBER },
      premiumAmount: { min: 2, max: 5, locale: GlobalConfig.LOCALE_FOR_NUMBER },
      premiumPercent: { min: 4, max: 4, locale: GlobalConfig.LOCALE_FOR_NUMBER, pipe: GlobalConfig.PREMIUM_PERCENT_PATTERN },
      additionalRate: { min: 0, max: 0, locale: GlobalConfig.LOCALE_FOR_NUMBER }
    };

  }