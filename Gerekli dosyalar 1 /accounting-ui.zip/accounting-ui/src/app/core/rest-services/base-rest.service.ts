import { Observable } from 'rxjs';
import { HttpHeaders, HttpClient, HttpParams } from '@angular/common/http';
import { environment } from '../../../environments/environment';

export class BaseRestService {
  constructor(protected httpClient: HttpClient) {}

  protected httpGet(url: string, params?: HttpParams): Observable<any> {
    return this.httpClient.get<any>(environment.apiURL + '/api/v1' + url, this.getOptions(params));
  }

  protected httpPost(url: string, data?: any): Observable<any> {
    return this.httpClient.post<any>(environment.apiURL + '/api/v1' + url, data, this.getOptions());
  }

  protected httpDelete(url: string): Observable<any> {
    return this.httpClient.delete<any>(environment.apiURL + '/api/v1' + url, this.getOptions());
  }

  protected httpPut(url: string, data: any): Observable<any> {
    return this.httpClient.put<any>(environment.apiURL + '/api/v1' + url, data, this.getOptions());
  }

  private getOptions(params?: HttpParams) {
    const options = {
      headers: this.headers,
      params: params,
    };

    return options;
  }

  get headers(): HttpHeaders {
    let headers = new HttpHeaders();
    headers = headers.set('Accept', '*/*');
    headers = headers.set('Access-Control-Allow-Origin', '*');
    headers = headers.set('Access-Control-Allow-Methods', 'POST, GET, OPTIONS, HEAD');
    headers = headers.set('Content-Type', 'application/json');
    headers = headers.set('Access-Control-Allow-Headers', '*');
    headers = headers.set('Accept-Language', 'tr');
    headers = headers.set('timeout', '180000');
    return headers;
  }
}
