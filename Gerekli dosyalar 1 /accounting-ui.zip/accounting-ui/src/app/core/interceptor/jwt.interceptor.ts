import { Inject, Injectable, InjectionToken } from '@angular/core';
import { HttpErrorResponse, HttpEvent, HttpHandler, HttpInterceptor, HttpRequest, HttpResponse } from '@angular/common/http';
import { Observable, throwError, of } from 'rxjs';
import { catchError, map, timeout } from 'rxjs/operators';
import { CookieService } from 'ngx-cookie-service';
import { GlobalConfig } from '../config/global.config';
import { AlzType } from '../utils/alz.type';

export const DEFAULT_TIMEOUT = new InjectionToken<number>('defaultTimeout');

const allowedDomains = [
  'cas.allianz.com.tr',
  'sc-uat-cas.allianz.com.tr',
  'sc-test-cas.allianz.com.tr',
  'prep-cas.allianz.com.tr'
];

@Injectable()
export class JWTInterceptor implements HttpInterceptor {

    constructor(@Inject(DEFAULT_TIMEOUT) protected defaultTimeout: number,
        private cookie: CookieService, @Inject('environment') private environment: any) {
    }

    // JWT comments will open when Token getting shorter
    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {

        const timeoutValue = request.headers.get('timeout') || this.defaultTimeout;
        const timeoutValueNumeric = Number(timeoutValue);
        let authorization = sessionStorage.getItem('token');

        if (!authorization) {
            this.prepareCasStuff();
            authorization = sessionStorage.getItem('token');
        }


        if (authorization) {
            request = request.clone({ headers: request.headers.set('Authorization', authorization) });
        }

        return next.handle(request).pipe(timeout(timeoutValueNumeric),
            map((event: HttpEvent<any>) => {

                if (event instanceof HttpResponse) {
                    const url = event.url;

                    const responseToken = event.headers.get('Authorization');

                    if (responseToken && responseToken !== '') {

                        sessionStorage.setItem('token', responseToken);
                    }

                    if (event && event.body && event.body['uiMessages']) {
                        /**
                         * Severity Message List Set and Show in Message Panel
                         */
                        // this.handleUiMessages(event.body);
                    }

                }
                return event;
            }),
            catchError((err: any) => {

                if (err instanceof HttpErrorResponse) {
                    const responseToken = err.headers.get('Authorization');

                    if (err.status === 401) {
                        const errorMessage = err.error['message'];
                        //const casLoginControl = errorMessage ? errorMessage.split('cas/login') : '';
                        if (err.error.error != null && err.error.error != undefined && err.error.error == 'Unauthorized') {
                            let casUrl = '';

                            // TODO: Derleme esnasında ortam vermekte bamboo tarafında sıkıntı yaşıyoruz. Aşağıdaki workaround çözüm, bu problemin gerçek çözümüne kadar geçici olarak kullanılacak.



                            let safePath = window.location.pathname ?? '';
                            let checkedPath = AlzType.checkString(safePath) ?? '';
                            let redirectPath = checkedPath.replace('/accounting-ui', '');

                            if(window.location.search) {
                               redirectPath = redirectPath + AlzType.checkString(window.location.search);
                            }

                            if (this.environment.production && !window.location.href.includes('http://localhost')) {
                                let casServiceUrl = '';
                                const domainName = 'allianz.com.tr';
                                const backendContextPath = '/accounting-ui-backend/api/v1/authentication/success';
                                const subDomainEnvironment = window.location.href.split('allianz.com.tr')[0];

                                let subDomainName = 'finance';

                                if (subDomainEnvironment.includes('uat-')) {
                                  casServiceUrl = 'https://sc-uat-cas.allianz.com.tr/cas/login?service='
                                  subDomainName = 'sc-uat-' + subDomainName + '.';
                                }
                                else if (subDomainEnvironment.includes('test-')) {
                                  casServiceUrl = 'https://sc-test-cas.allianz.com.tr/cas/login?service='
                                  subDomainName = 'sc-test-' + subDomainName + '.';
                                } else if (subDomainEnvironment.includes('prep-')) {
                                    subDomainName = 'prep-' + subDomainName + '.';
                                    casServiceUrl = 'https://prep-cas.allianz.com.tr/cas/login?service=';
                                }else {
                                  casServiceUrl = 'https://cas.allianz.com.tr/cas/login?service=';
                                  subDomainName =  subDomainName + '.';
                                }

                                const encodedURI = encodeURI(`https://${subDomainName}${domainName}${backendContextPath}${redirectPath}`);

                                casUrl = `${casServiceUrl}${encodedURI}`;

                            } else {
                                if(window.location.href.includes('7001'))
                                    casUrl = `https://sc-uat-cas.allianz.com.tr/cas/login?service=http://localhost:7001/accounting-ui-backend/api/v1/authentication/success${window.location.pathname}${window.location.search}`;
                                else
                                    casUrl = `https://sc-uat-cas.allianz.com.tr/cas/login?service=http://localhost:8090/accounting-ui-backend/api/v1/authentication/success${redirectPath}`;
                            }

                            this.cookie.set(GlobalConfig.CAS_REDIRECT_PATH_NAME, redirectPath);

                            try {
                                const urlObj = new URL(casUrl);
                                const allowed = allowedDomains.some(d => {
                                    const dom = d.toLowerCase();
                                    const host = urlObj.hostname.toLowerCase();
                                    return host === dom || host.endsWith(`.${dom}`);
                                });

                                const allowedProtocol = urlObj.protocol === 'https:' || urlObj.protocol === 'http:';

                                if (allowed && allowedProtocol) {
                                    window.location.assign(urlObj.href);
                                }
                            } catch (e) {
                                // ignore invalid redirect URL to avoid leaking auth flow details in console
                            }

                            return throwError(() => err);
                        }
                    }

                    if (responseToken && responseToken !== '') {
                        sessionStorage.setItem('token', responseToken);
                        sessionStorage.removeItem('ticket');
                    }

                    if (err.status === 403) {
                        const errorMessage = err.error.message;
                        const tokenControl = errorMessage ? errorMessage.split('JWT') : '';
                        if (tokenControl && tokenControl.length > 1 && err.error && err.error.error === 'Forbidden') {
                            // this.router.navigate(['error']);
                        }
                    }

                    /**
                     * Severity Message List Set and Show in Message Panel
                     */
                    if (err.error && err.error.errors) {
                        // this.commonCoreFacade.setMessageListToSeverityMessageList(err.error.errors);
                    }

                    if (err && err.error && err.error['uiMessages']) {
                        /**
                         * Severity Message List Set and Show in Message Panel
                         */
                        // this.handleUiMessages(err.error);
                    }
                }
                // return of(err);
                return throwError(err);

            }));
    }

    prepareCasStuff() {
        const bUrl = window.location.hash;
        const token = this.getParameterByName("token", bUrl);

        if (token && token.length > 1) {
            sessionStorage.setItem('token', token);
        }
    }

    getParameterByName(pramName: string, url: string) {
        if (pramName === 'token') {
            const hashCut = window.location.hash && window.location.hash.substr(1) ? window.location.hash.substr(1) : '';
            const token = hashCut ? hashCut.split('token=')[1] : '';
            return token;
        } else {
            const match = RegExp('[?&]' + pramName + '=([^&]*)').exec(url);
            return match && decodeURIComponent(match[1].replace(/\+/g, ' '));
        }
    }
}
