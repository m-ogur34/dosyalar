import { Injectable } from '@angular/core';
import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { finalize, tap } from 'rxjs/operators';

import { LoaderService } from '../services/loader.service';

@Injectable()
export class LoaderInterceptor implements HttpInterceptor {

	apiCallCount = 0;
	filter = 'get-all-jobs';

	constructor(public loaderService: LoaderService) { }

	intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
		if (req.url.indexOf(this.filter) < 0) {
			this.apiCallCount++;
			this.loaderService.show();
		}

		return next.handle(req).pipe(tap((event: HttpEvent<any>) => {
			if (event instanceof HttpResponse && req.url.indexOf(this.filter) < 0) {
				this.apiCallCount--;
				if (this.apiCallCount === 0) {
					this.loaderService.hide();
				}
			}
		},
			(err: any) => {
				if (req.url.indexOf(this.filter) < 0) {
					this.apiCallCount--;
					if (this.apiCallCount === 0) {
						this.loaderService.hide();
					}
				}
			}
		));
	}
}
