
import { HttpErrorResponse, HttpEvent, HttpHandler, HttpInterceptor, HttpRequest, HttpResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, map, retry } from 'rxjs/operators';
import { Injectable } from '@angular/core';

@Injectable()
export class HttpResponseInterceptor implements HttpInterceptor {
  constructor() { }
  private _isoDateFormat = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}/;

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    return next.handle(req).pipe(
      map((val: HttpEvent<any>) => {
        if (val instanceof HttpResponse) {
          try {
            const body = val.body;
            this.convert(body);
          } catch (error) {
            console.error('HttpResponseInterceptor - Error during conversion:', error);
            // Don't throw - return original response
          }
        }
        return val;
      }),
      catchError((error: HttpErrorResponse) => {
        console.error('HttpResponseInterceptor - HTTP Error:', error);
        return throwError(() => error);
      })
    );
  }
  isIsoDateString(value: any): boolean {
    if (value === null || value === undefined) {
      return false;
    }
    if (typeof value === 'string') {
      return this._isoDateFormat.test(value);
    } return false;
  }
  convert(body: any, visited = new WeakSet()) {
    if (body === null || body === undefined) {
      return body;
    }
    if (typeof body !== 'object') {
      return body;
    }

    // Prevent infinite recursion on circular references
    if (visited.has(body)) {
      return body;
    }
    visited.add(body);

    try {
      for (const key of Object.keys(body)) {
        const value = body[key];
        if (this.isIsoDateString(value)) {
          body[key] = new Date(value);
        } else if (value && typeof value === 'object') {
          this.convert(value, visited);
        }
      }
    } catch (error) {
      console.error('Error converting body at key:', error);
      throw error;
    }
  }
}
// private errorWithBody(body: RestResponseStringModel, self) {

//     if (body.uiMessages) {
//         const tracingId = body.tracingId;
//         const traceMessage = tracingId ? ", " + self.translate.instant("common.ui.errorTracingMsg").replace("{tracingId}", tracingId) : "";
//         body.uiMessages.errors.forEach(function (err) {
//             self.messageService.error(err.message + traceMessage, err.code);
//             throw new Error("service.uimessage.err");
//         });
//         body.uiMessages.infos.forEach(function (info) {
//             self.messageService.info(info.message, info.code);
//         });
//         body.uiMessages.warnings.forEach(function (warning) {
//             self.messageService.warning(warning.message, warning.code,);
//         });
//     }
// }
