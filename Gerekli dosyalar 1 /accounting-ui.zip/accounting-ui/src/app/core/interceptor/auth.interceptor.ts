import {
    HttpErrorResponse,
    HttpEvent,
    HttpHandler,
    HttpInterceptor,
    HttpRequest,
    HttpResponse,
} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { catchError, throwError } from 'rxjs';
import { map } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { TokenUtils } from '../utils/token.utils';

@Injectable()
export class AuthInterceptor implements HttpInterceptor {
    private readonly STATUS_UNAUTHORIZED = 401;

    constructor(private router: Router) { }

    intercept(req: HttpRequest<any>, next: HttpHandler) {
        const token = TokenUtils.getBearerToken();

        if (token) {
            req = this.addAuthorizationHeader(req, token);
        }

        return next.handle(req).pipe(
            map((event: HttpEvent<any>) => this.handleResponse(event)),
            catchError((error: HttpErrorResponse) => this.handleError(error))
        );
    }

    private addAuthorizationHeader(req: HttpRequest<any>, token: string): HttpRequest<any> {
        const headers: { [key: string]: string } = {
            Authorization: token,
        };

        // Add ClientIP header only for local development
        if (environment.clientIP) {
            headers['ClientIP'] = environment.clientIP;
        }

        return req.clone({
            setHeaders: headers,
        });
    }

    private handleResponse(event: HttpEvent<any>): HttpEvent<any> {
        if (event instanceof HttpResponse) {
            const responseToken = event.headers.get('Authorization') ?? '';
            if (TokenUtils.isValidToken(responseToken)) {
                TokenUtils.setToken(responseToken);
            }
        }
        return event;
    }

    private handleError(error: HttpErrorResponse) {
        if (error.status === this.STATUS_UNAUTHORIZED) {
            this.clearAuthenticationAndRedirect();
            return throwError(
                () =>
                    new Error(
                        'Oturumunuz sonlanmıştır. Tekrar giriş yaparak işlemlerinize devam edebilirsiniz.'
                    )
            );
        }

        return throwError(() => error);
    }

    private clearAuthenticationAndRedirect(): void {
        const currentUrl = this.router.url;
        TokenUtils.setRedirectUrl(currentUrl);
        TokenUtils.clearToken();

        const loginUrl = environment.deployUrl + 'login';
        const fullUrl = environment.casLoginUrl + encodeURIComponent(loginUrl);

        setTimeout(() => {
            window.location.href = fullUrl;
        }, 15000);
    }
}