import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor
} from '@angular/common/http';
import { Observable } from 'rxjs';
import { HttpConstants } from '../common/constant/http-constants';
import { finalize } from 'rxjs/operators';
import { SpinnerService } from '../services/spinner.service';

@Injectable()
export class SpinnerInterceptor implements HttpInterceptor {

  private requestCount = 0;

  constructor(private spinnerService: SpinnerService) {
  }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    if (req.headers.get(HttpConstants.SKIP_SPINNER_INTERCEPTOR_HEADER_NAME)) {
      req.headers.delete(HttpConstants.SKIP_SPINNER_INTERCEPTOR_HEADER_NAME);
      return next.handle(req);
    }
    this.requestCount++;
    this.spinnerService.showSpinner(true);
    return next.handle(req).pipe(
      finalize(() => {

        this.requestCount--;
        if (this.requestCount === 0) {
          this.spinnerService.showSpinner(false);
        }
      })
    );
  }
}