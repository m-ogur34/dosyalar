import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { TokenUtils } from '../../utils/token.utils';
import { EncryptionService } from '../../security/encryption.service';

@Component({
  selector: 'app-login',
  standalone: true,
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private encryptionService: EncryptionService
  ) { }

  ngOnInit(): void {
    this.handleLogin();
  }

  private handleLogin(): void {
    this.route.queryParams.subscribe(async params => {
      const token = params['token'];

      if (token && TokenUtils.isValidToken(token)) {
        TokenUtils.setToken(token);

        // Load RSA public key after token is available
        try {
          await this.encryptionService.loadPublicKey();
        } catch (error) {
          console.error('Failed to load RSA public key:', error);
        }

        const redirectUrl = TokenUtils.getRedirectUrl();
        TokenUtils.clearRedirectUrl();

        if (redirectUrl && redirectUrl !== '/login') {
          this.router.navigateByUrl(redirectUrl);
        } else {
          this.router.navigate(['/']);
        }
      } else if (TokenUtils.isAuthenticated()) {
        // Also load key if user is already authenticated
        try {
          await this.encryptionService.loadPublicKey();
        } catch (error) {
          console.error('Failed to load RSA public key:', error);
        }
        this.router.navigate(['/']);
      }
    });
  }
}