import { Component, Input, OnInit } from '@angular/core';
import { UIMessage } from '../../../models/ui-message.model';
import { NxMessageBannerComponent, NxMessageModule } from '@aposin/ng-aquila/message';
import { BANNER_CONTEXT } from '@allianz/ng-aquila/message';




@Component({
  selector: 'app-show-ui-message',
  imports: [NxMessageModule],
  templateUrl: './show-ui-message.component.html',
  styleUrls: ['./show-ui-message.component.scss']
})
export class ShowUiMessageComponent implements OnInit {

  @Input() messages: Array<UIMessage> | undefined;
  constructor() { }

  ngOnInit(): void {
  }

  deleteMessage(): void {
    this.messages = new Array<UIMessage>();
  }

  getBannerContext(severity: string): BANNER_CONTEXT {
    const sev = (severity || '').toLowerCase();
    if (sev === 'error' || sev === 'danger') return 'error';
    if (sev === 'warning' || sev === 'warn') return 'warning';
    return 'info';
  }

}
