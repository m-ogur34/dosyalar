import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowUiMessageComponent } from './show-ui-message.component';

describe('ShowUiMessageComponent', () => {
  let component: ShowUiMessageComponent;
  let fixture: ComponentFixture<ShowUiMessageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ShowUiMessageComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ShowUiMessageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
