import { Pipe, PipeTransform } from '@angular/core';
import '../../extention/string.extensions';

@Pipe({
  name: 'searchList'
})
export class SearchListPipe implements PipeTransform {
  transform(list: any[], filterText: string, fieldName: string = 'name'): any {
    if (!filterText || !list) {
      return list;
    }
 
    filterText = filterText.turkishtoEnglish().toUpperCase();
 
    return list.filter(item => { 
      return  Object.keys(item).some(x => String(item[x]).turkishtoEnglish().toUpperCase().includes(filterText));
    }); 
 
  }
}