import { Directive, HostListener, ElementRef, Input } from '@angular/core';

@Directive({
  selector: '[onetypeonlyinput]'
})
export class OneTypeOnlyInputDirective {

  @Input() inputType?: string;

  element: ElementRef;

  constructor(private el: ElementRef) {
    this.element = el;
  }


  @HostListener('keydown', ['$event'])
  onKeyDown(event: KeyboardEvent) {
    const allowedKeys = [
      'Backspace', 'Tab', 'ArrowLeft', 'ArrowRight', 'Delete'
    ];
    if (allowedKeys.includes(event.key)) {
      return; // Allow navigation and editing keys
    }
    if (this.inputType === "number") {
      if (!/^[0-9]$/.test(event.key)) {
        event.preventDefault();
      }
    }
    else if (this.inputType === "letter") {
      if (!/^[a-zA-Z]$/.test(event.key)) {
        event.preventDefault();
      }
    }
  }


  @HostListener('paste', ['$event'])
  onPaste(event: ClipboardEvent) {
    const clipboardData = event.clipboardData?.getData('text') || '';
    if (this.inputType === "number") {
      if (!/^[0-9]+$/.test(clipboardData)) {
        event.preventDefault();
      }
    }
    else if (this.inputType === "letter") {
      if (!/^[a-zA-Z]+$/.test(clipboardData)) {
        event.preventDefault();
      }
    }
  }
}

