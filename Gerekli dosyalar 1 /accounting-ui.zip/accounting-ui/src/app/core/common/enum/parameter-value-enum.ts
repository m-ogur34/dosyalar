export enum ParameterValueEnum {
  MUST = 'MUST',
  OPTIONAL = 'OPTIONAL',
  NONE = 'NONE'
}
