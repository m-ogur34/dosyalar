export enum ProfitProcessTypeEnum {

    APPROVE = 'APPROVE',
    DECLINE = 'DECLINE'
}