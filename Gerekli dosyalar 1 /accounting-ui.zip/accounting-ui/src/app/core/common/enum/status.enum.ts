export enum StatusEnum {

    SUCCESSFUL = 'S',
    FAIL = 'F'
  }