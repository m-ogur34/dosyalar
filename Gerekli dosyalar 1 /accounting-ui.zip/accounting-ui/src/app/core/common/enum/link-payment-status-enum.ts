export enum LinkPaymentStatusEnum {
    PENDING = 'PENDING',
    SUCCESS = 'SUCCESS',
    FAIL = 'FAIL',
    VOIDSUCCESS = 'VOIDSUCCESS',
    VOIDFAIL = 'VOIDFAIL',
    PROCESSING = 'PROCESSING'
}