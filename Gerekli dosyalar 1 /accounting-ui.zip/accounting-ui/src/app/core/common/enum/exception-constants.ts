export enum ExceptionConstants {
  EXCEPTION_GENERAL= 'Hata oluştu.Lütfen sayfayı yenileyerek tekrar deneyiniz.',
  EXCEPTION_VALIDATION= 'Geçersiz karakter kullanımlarını kaldırınız!'
}
