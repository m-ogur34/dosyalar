export enum LinkActionsEnum {
  PICK = 'PICK',
  NEWLINK = 'NEWLINK'
}
