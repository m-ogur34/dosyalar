export class ExcelConstant {
  static DEFAULT_WIDTH = 20;
  static DEFAULT_STYLE = { font: { size: 10 } };
  static BOLD_STYLE = { font: { bold: true, size: 10 } };
}
