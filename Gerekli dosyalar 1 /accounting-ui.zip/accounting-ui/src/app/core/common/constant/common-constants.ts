export class CommonConstants {
  static paginationOptions: number[] = [5, 10, 25, 50, 100, 200];
  static URL_ONLY_SMS_FLOW: string = 'URL_ONLY_SMS_FLOW';
  static COLLECT_CC: string = 'COLLECTCC';
  static INVALID_START_END_DATE = 'Lütfen başlangıç ve bitiş tarihleri ile veya askı no ile arama yapınız.';
  static EMPTY_STRING = '';
  static INVALID_START_DATE = 'Başlangıç tarihi Bitiş tarihinden büyük olamaz.';
  static INVALID_LINK_STATUS = '"Ödeme Başarılı" statüsünde bulunan işler için yeni link gönderimi yapılamaz.';
  static COMPANY_CODE_AZS = 'AZS';
  static readonly USER_PROFILE_KEY = 'agentUserProfileInfo';
  static readonly USER_TYPE = 'userType';
  static readonly CAS_USER_NAME = 'casUserName';
}
