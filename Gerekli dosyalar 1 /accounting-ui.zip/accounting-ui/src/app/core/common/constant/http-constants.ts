export class HttpConstants {

    public static readonly SKIP_SPINNER_INTERCEPTOR_HEADER_NAME = 'X-Skip-Spinner-Interceptor';

}