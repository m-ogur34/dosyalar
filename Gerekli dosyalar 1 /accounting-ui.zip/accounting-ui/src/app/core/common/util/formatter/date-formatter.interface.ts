interface DateFormatter {
    pipe: string;
    box: string;
  }
  