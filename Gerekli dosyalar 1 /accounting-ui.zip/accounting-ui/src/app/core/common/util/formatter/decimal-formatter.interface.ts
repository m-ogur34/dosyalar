interface DecimalFormatter {
    min: number;
    max: number;
    locale: string;
    pipe?: string;
  }
  