import { Component, OnDestroy, OnInit } from '@angular/core';
import { GlobalRuntime } from './core/config/global.runtime';
import { environment } from '../environments/environment';
import { CookieService } from 'ngx-cookie-service';
import { HttpClient } from '@angular/common/http';
import { NavigationEnd, NavigationStart, Router, RouterOutlet } from '@angular/router';
import { GlobalConfig } from './core/config/global.config';
import { SessionProfileDto } from './models/specific/cas-user/session-profile.dto'
import { UserProfileService } from './services/user-profile.service'
import { AlzType } from './core/utils/alz.type';
import { NxSpinnerModule } from '@allianz/ng-aquila/spinner';
import { SpinnerService } from './core/services/spinner.service';
import { AsyncPipe } from '@angular/common';

@Component({
  selector: 'app-root',
  templateUrl: './app.html',
  imports: [RouterOutlet,NxSpinnerModule,AsyncPipe
  ],
  styleUrls: ['./app.scss'],
})
export class App implements OnInit, OnDestroy {
  title = 'accounting-ui';
  loadable?: boolean;
  runtime = GlobalRuntime;
  env = environment;
  screen?: string;
  tokenValue?: string | null;
  userName?: string;
  agencyCode?: string;
  callCenterUser?: string;
  profileInformations?: any[];
  private loaderSub: any;
  spinnerShowStatus = false;

  constructor(
    private cookie: CookieService,
    private httpClient: HttpClient,
    private router: Router,
    private userProfileService: UserProfileService,
    public spinnerService: SpinnerService
  ) {
    this.loaderSub = spinnerService.spinnerLoader.subscribe(show => this.spinnerShowStatus = show);
    this.runtime.url = environment.apiURL;
    this.runtime.setUserProfile(null);
  }

  fetchUserProfile() {
    const path = this.runtime.url + 'cas/user-profile';
    return this.httpClient.get(path).subscribe(
      (data: SessionProfileDto | null) => {
        if (!AlzType.isObject(data)) {
          data = null;
        }
        this.runtime.setUserProfile(data);
        if (data) {
          this.userProfileService.setVariableValue(data);
        }
        if (this.runtime.getUserProfile() !== null) {
          this.runtime.setUserAdmin(
            this.runtime.getUserProfile().userType === '0' &&
              this.runtime.getUserProfile().subUserType === '0'
          );
        }
        this.userName = data === null ? '' : data.userName;
        this.agencyCode = data === null ? '' : data.agencyCode;
        this.callCenterUser = data === null ? '': data.callCenterUser;
        this.profileInformations = data === null ? '': data.profileInformations;
        console.log(data);
        setTimeout(() => {
          this.fetchUserProfile();
        }, 1000 * 60 * 5);
      },
      (err) => {
        // this.tokenValue = null;
        // sessionStorage.setItem(GlobalConfig.CAS_COOKIE, this.tokenValue);
      }
    );
  }

  tokenRefresh() {
    this.tokenValue = AlzType.checkString(
      this.cookie.get(GlobalConfig.CAS_COOKIE)
    );
    if (this.tokenValue !== null) {
      sessionStorage.setItem(
        GlobalConfig.CAS_COOKIE,
        this.tokenValue as string
      );
      this.cookie.delete(GlobalConfig.CAS_COOKIE);
    } else {
      this.tokenValue = AlzType.checkString(
        sessionStorage.getItem(GlobalConfig.CAS_COOKIE)
      );
      sessionStorage.setItem(
        GlobalConfig.CAS_COOKIE,
        this.tokenValue as string
      );
    }
  }

  ngOnInit(): void {
    return
    this.router.events.subscribe((event) => {
      // Default redirect hack
      if (event instanceof NavigationStart) {
        if (!!event.url && event.url.indexOf('#') > -1) {
          this.prepareCasStuff();
          const redirectPathName = AlzType.checkString(
            this.cookie.get(GlobalConfig.CAS_REDIRECT_PATH_NAME)
          );
          // this.cookie.delete(GlobalConfig.CAS_REDIRECT_PATH_NAME);
          this.router.navigate([redirectPathName]);
        }
      }

      if (event instanceof NavigationEnd) {
        // this.appFacade.setHeaderButtonsVisibility(HEADER_BUTTON_STATUS_FROM_ROUTES[event.urlAfterRedirects.split('?')[0]]);
      }
    });
    
  }

  prepareCasStuff() {
    const bUrl = window.location.hash;
    const token = this.getParameterByName('token', bUrl);

    if (token && token.length > 1) {
      sessionStorage.setItem('token', token);
    }
  }

  getParameterByName(pramName: string, url: string) {
    if (pramName === 'token') {
      const hashCut =
        window.location.hash && window.location.hash.substr(1)
          ? window.location.hash.substr(1)
          : '';
      const token = hashCut ? hashCut.split('token=')[1] : '';
      return token;
    } else {
      const match = RegExp('[?&]' + pramName + '=([^&]*)').exec(url);
      return match && decodeURIComponent(match[1].replace(/\+/g, ' '));
    }
  }


  ngOnDestroy() {
    this.loaderSub.unsubsribe();
  }
}
