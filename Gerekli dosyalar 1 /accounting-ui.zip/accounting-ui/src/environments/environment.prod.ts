import {BUILD_ARGS} from '../../BUILD_ARGS';
import packageJson from '../../package.json';

export const environment = {
  production: true,
  deployUrl: BUILD_ARGS['deploy-url'],
  apiURL: '__API_URL__',
  isNavigateShow: false,
  version: packageJson.version,
  assetsBasePath: `/accounting-ui/assets/`,
  casLoginUrl: '__CAS_URL__/cas/login?service=',
  clientIP: '',
};
