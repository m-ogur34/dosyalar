// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

import {BUILD_ARGS} from '../../BUILD_ARGS';
import packageJson from '../../package.json';
export const environment = {
  production: false,
  deployUrl: 'http://localhost:4200/',
  apiURL:  'http://localhost:8083/accounting-ui-backend/',
  isNavigateShow: true,
  version: packageJson.version,
  assetsBasePath: './assets/',  
  casLoginUrl: 'https://sc-uat-digitall.allianz.com.tr/user-admin-service-ui/cas/login?service=',
  clientIP: ''
};


/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
