package tr.com.allianz.ekgb.service.filenet;

import com.cs.csap.service.SigortaKomisyonWebService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import tr.com.allianz.ekgb.service.EkgbGibServiceImpl;

import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.BDDMockito.given;
import static org.mockito.BDDMockito.then;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@PrepareForTest(FilenetServiceImpl.class)
public class FilenetServiceTest {
    @InjectMocks
    private FilenetServiceImpl filenetServiceImpl;

    @Mock
    private  RestTemplate filenetRestTemplate;

    @Value("${filenet.hostCreate}")
    private String filenetHostCreate;

    @Value("${filenet.hostRead}")
    private String filenetHostRead;


    @Value("${filenet.username}")
    private String filenetUsername;

//    @Value("${filenet.password}")
//    private String filenetPassword;


    @Test
    public void createDocument_Success(){
        CreateDocumentInput createDocumentInput = new CreateDocumentInput();
        when(filenetRestTemplate.postForObject(filenetHostCreate, createDocumentInput, CreateDocumentOutput.class)).thenReturn(null);
        filenetServiceImpl.createDocument(createDocumentInput);
        verify(filenetRestTemplate,times(1)).postForObject(filenetHostCreate, createDocumentInput, CreateDocumentOutput.class);
    }

    @Test
    public void createDocument_Exception(){
        CreateDocumentInput createDocumentInput = new CreateDocumentInput();
        when(filenetRestTemplate.postForObject(null, createDocumentInput, CreateDocumentOutput.class)).thenThrow(new RestClientException(""));
        CreateDocumentOutput createDocumentOutput =  filenetServiceImpl.createDocument(createDocumentInput);
        assertNull(createDocumentOutput);
    }

    @Test
    public void getDocument_Success(){
        GetDocumentInput getDocumentInput = new GetDocumentInput();
        when(filenetRestTemplate.postForObject(filenetHostRead, getDocumentInput, GetDocumentOutput.class)).thenReturn(null);
        filenetServiceImpl.getDocument(getDocumentInput);
        verify(filenetRestTemplate,times(1)).postForObject(filenetHostRead, getDocumentInput, GetDocumentOutput.class);
    }



}
