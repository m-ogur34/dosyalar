package tr.com.allianz.ekgb.controller;

import tools.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.http.MediaType;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import tr.com.allianz.ekgb.entity.Commission;
import tr.com.allianz.ekgb.entity.enums.AllianzCompany;
import tr.com.allianz.ekgb.model.*;
import tr.com.allianz.ekgb.service.CommissionService;
import tr.com.allianz.ekgb.util.EkgbConstants;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)
@PrepareForTest(CommissionControllerV3.class)
public class CommissionControllerV3Test {
    private static final String COMMISSION_ENDPOINT = "/api/v3/commission/";


    @InjectMocks
    private CommissionControllerV3 commissionControllerV3;


    private MockMvc mvc;

    private ObjectMapper objectMapper;

    private static LocalDateTime localDateTime;


    @Mock
    private  CommissionService commissionService;


    private String apiKey="TEST API KEY";


    @BeforeEach
    public void setUp() {
        CommissionControllerV3 cv3 = new CommissionControllerV3(commissionService);
        ReflectionTestUtils.setField(cv3, "apiKey", apiKey);

        objectMapper = new ObjectMapper();
        mvc = MockMvcBuilders
                .standaloneSetup(cv3)
                .build();
        localDateTime = LocalDateTime.now();

    }


    @Test
    public void getEkgByCompanyAgencyYearMonth_NoApiKey() throws Exception {

        EkgbPdfRequest ekgbPdfRequest = new EkgbPdfRequest();
        ekgbPdfRequest.setAgencyCode(793);
        ekgbPdfRequest.setCompany(AllianzCompany.ALLIANZ_SIGORTA.getValue());
        ekgbPdfRequest.setYear(2024);
        ekgbPdfRequest.setMonth(1);
        ekgbPdfRequest.setKey(null);


        ResponseBaseContract  responseBaseContractSuccess = new ResponseBase();
        responseBaseContractSuccess.setStatus( ResponseMessageStatus.SUCCESS);
        String requestStr = objectMapper.writeValueAsString(ekgbPdfRequest);

        //Act
        MvcResult mvcResult = mvc.perform(post(COMMISSION_ENDPOINT + "getEkgByCompanyAgencyYearMonth")
                        .content(requestStr)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isUnauthorized())
                .andReturn();

        String contentAsString = mvcResult.getResponse().getContentAsString();
        ResponseBase result = objectMapper.readValue(contentAsString,  ResponseBase.class);

        //Assert
        assertEquals(ResponseMessageStatus.UNAUTHORIZED,result.getStatus());
    }



    @Test
    public void getEkgByCompanyAgencyYearMonth_Success() throws Exception {

        EkgbPdfRequest ekgbPdfRequest = new EkgbPdfRequest();
        ekgbPdfRequest.setAgencyCode(793);
        ekgbPdfRequest.setCompany(AllianzCompany.ALLIANZ_SIGORTA.getValue());
        ekgbPdfRequest.setYear(2024);
        ekgbPdfRequest.setMonth(1);
        ekgbPdfRequest.setKey(apiKey);


        ResponseBaseContract  responseBaseContractSuccess = new ResponseBase();
        responseBaseContractSuccess.setStatus( ResponseMessageStatus.SUCCESS);

        Commission commission = new Commission();
        commission.setFilenetDocumentID("FilenetDocumentID");

        byte[] filenetDocument = "Filenet Doc Content".getBytes();

        when(commissionService.getCommissionByAgencyYearMonth(anyString(),anyInt(),anyInt(),anyInt())).thenReturn(commission);
        when(commissionService.getFilenetDocumentPDF(anyString())).thenReturn(filenetDocument);

        String requestStr = objectMapper.writeValueAsString(ekgbPdfRequest);

        //Act
        MvcResult mvcResult = mvc.perform(post(COMMISSION_ENDPOINT + "getEkgByCompanyAgencyYearMonth")
                        .content(requestStr)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String contentAsString = mvcResult.getResponse().getContentAsString();
        GetEkgbByCompanyAgencyYearMonthResponse result = objectMapper.readValue(contentAsString,  GetEkgbByCompanyAgencyYearMonthResponse.class);

        //Assert
        assertEquals(ResponseMessageStatus.SUCCESS,result.getStatus());
    }


    @Test
    public void getEkgByCompanyAgencyYearMonth_NoCommission() throws Exception {

        EkgbPdfRequest ekgbPdfRequest = new EkgbPdfRequest();
        ekgbPdfRequest.setAgencyCode(793);
        ekgbPdfRequest.setCompany(AllianzCompany.ALLIANZ_SIGORTA.getValue());
        ekgbPdfRequest.setYear(2024);
        ekgbPdfRequest.setMonth(1);
        ekgbPdfRequest.setKey(apiKey);


        ResponseBaseContract  responseBaseContractSuccess = new ResponseBase();
        responseBaseContractSuccess.setStatus( ResponseMessageStatus.SUCCESS);

        Commission commission = new Commission();
        commission.setFilenetDocumentID("FilenetDocumentID");

        byte[] filenetDocument = "Filenet Doc Content".getBytes();

        when(commissionService.getCommissionByAgencyYearMonth(anyString(),anyInt(),anyInt(),anyInt())).thenReturn(null);

        String requestStr = objectMapper.writeValueAsString(ekgbPdfRequest);

        //Act
        MvcResult mvcResult = mvc.perform(post(COMMISSION_ENDPOINT + "getEkgByCompanyAgencyYearMonth")
                        .content(requestStr)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String contentAsString = mvcResult.getResponse().getContentAsString();
        GetEkgbByCompanyAgencyYearMonthResponse result = objectMapper.readValue(contentAsString,  GetEkgbByCompanyAgencyYearMonthResponse.class);

        //Assert
        assertEquals(ResponseMessageStatus.SUCCESS,result.getStatus());
        assertTrue(result.getMessage()[0].getCode().equals(EkgbConstants.EKGB_COMMISSION_NOTFOUND_CODE));
        assertTrue(result.getMessage()[0].getMessage() !=null);

    }


    @Test
    public void getEkgByCompanyAgencyYearMonth_NoFilenetDocument() throws Exception {

        EkgbPdfRequest ekgbPdfRequest = new EkgbPdfRequest();
        ekgbPdfRequest.setAgencyCode(793);
        ekgbPdfRequest.setCompany(AllianzCompany.ALLIANZ_SIGORTA.getValue());
        ekgbPdfRequest.setYear(2024);
        ekgbPdfRequest.setMonth(1);
        ekgbPdfRequest.setKey(apiKey);


        ResponseBaseContract  responseBaseContractSuccess = new ResponseBase();
        responseBaseContractSuccess.setStatus( ResponseMessageStatus.SUCCESS);

        Commission commission = new Commission();
        commission.setFilenetDocumentID("FilenetDocumentID");

        byte[] filenetDocument = "Filenet Doc Content".getBytes();

        when(commissionService.getCommissionByAgencyYearMonth(anyString(),anyInt(),anyInt(),anyInt())).thenReturn(commission);
        when(commissionService.getFilenetDocumentPDF(anyString())).thenReturn(null);

        String requestStr = objectMapper.writeValueAsString(ekgbPdfRequest);

        //Act
        MvcResult mvcResult = mvc.perform(post(COMMISSION_ENDPOINT + "getEkgByCompanyAgencyYearMonth")
                        .content(requestStr)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String contentAsString = mvcResult.getResponse().getContentAsString();
        GetEkgbByCompanyAgencyYearMonthResponse result = objectMapper.readValue(contentAsString,  GetEkgbByCompanyAgencyYearMonthResponse.class);

        //Assert
        assertEquals(ResponseMessageStatus.SUCCESS,result.getStatus());
        assertTrue(result.getMessage()[0].getCode().equals(EkgbConstants.EKGB_PDF_NOTFOUND_CODE));
        assertTrue(result.getMessage()[0].getMessage() !=null);
    }

}
