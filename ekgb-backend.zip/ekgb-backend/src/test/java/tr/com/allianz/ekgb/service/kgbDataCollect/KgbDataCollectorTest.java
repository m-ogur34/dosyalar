package tr.com.allianz.ekgb.service.kgbDataCollect;

import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.springframework.web.client.RestTemplate;
import tr.com.allianz.ekgb.repository.EkgbMonthRepository;
import tr.com.allianz.ekgb.service.CommissionServiceImpl;


@ExtendWith(MockitoExtension.class)
@PrepareForTest(KgbDataCollectorImpl.class)
public class KgbDataCollectorTest {
    @InjectMocks
    private KgbDataCollectorImpl kgbDataCollectorImpl;


    @Mock
    private RestTemplate kgbDataRestTemplate;




}
