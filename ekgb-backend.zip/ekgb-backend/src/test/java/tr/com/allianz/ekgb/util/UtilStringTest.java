package tr.com.allianz.ekgb.util;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.powermock.core.classloader.annotations.PrepareForTest;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(MockitoExtension.class)
@PrepareForTest(UtilString.class)
public class UtilStringTest {


    @Test
    public void isNullOrEmpty_Success()
    {
        assertTrue(UtilString.isNullOrEmpty(null));
        assertTrue(UtilString.isNullOrEmpty(""));
    }
}
