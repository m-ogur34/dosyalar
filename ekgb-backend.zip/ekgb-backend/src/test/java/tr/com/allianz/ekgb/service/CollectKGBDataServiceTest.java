package tr.com.allianz.ekgb.service;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.powermock.core.classloader.annotations.PrepareForTest;
import tr.com.allianz.ekgb.model.ResponseBaseContract;
import tr.com.allianz.ekgb.model.ResponseMessageStatus;
import tr.com.allianz.ekgb.repository.CommissionDetailTempRepository;
import tr.com.allianz.ekgb.repository.EkgbMonthRepository;
import tr.com.allianz.ekgb.service.kgbDataCollect.GetKgbDataNonOpusOutput;
import tr.com.allianz.ekgb.service.kgbDataCollect.KgbDataCollector;
import tr.com.allianz.ekgb.service.kgbDataCollect.KgbDataItemOutput;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@PrepareForTest(CollectKGBDataServiceImpl.class)
public class CollectKGBDataServiceTest {

    @InjectMocks
    private CollectKGBDataServiceImpl collectKGBDataService;

    @Mock
    private  EkgbMonthRepository ekgbMonthRepository;
    @Mock
    private  KgbDataCollector kgbDataCollector;
    @Mock
    private  CommissionDetailTempRepository commissionDetailTempRepository;


/*
    @Test
    public void getKgbDataOpus_ErrorNull(){

        PmcRestClient pmcRestClient = Mockito.mock(PmcRestClient.class);
        when(pmcRestClientService.getPmcRestClient()).thenReturn(pmcRestClient);

        AgentCommissionControllerApiEndPoint restAgentCommissionControllerApi = Mockito.mock(AgentCommissionControllerApiEndPoint.class);

        ReflectionTestUtils.setField(pmcRestClient, "restAgentCommissionControllerApi", restAgentCommissionControllerApi);

        when(restAgentCommissionControllerApi.getAgentCommissionsUsingPOST(any(),anyString(),anyString())).thenReturn(null);

        ResponseBaseContract result = collectKGBDataService.getKgbDataOpus(2024,1);

        Assertions.assertEquals(ResponseMessageStatus.FAILURE, result.getStatus());

    }
*/

    @Test
    public void getKgbDataNonOPUSAll_ServiceErrorNull()
    {
        doNothing().when(ekgbMonthRepository).updateMonthLastOperation(anyInt(),anyInt(),anyString());

        when(kgbDataCollector.getNonOpusData(any())).thenReturn(null);

        ResponseBaseContract result = collectKGBDataService.getKgbDataNonOPUSAll(2024,1);

        Assertions.assertSame(result.getStatus(), ResponseMessageStatus.FAILURE);
    }

    @Test
    public void getKgbDataNonOPUSAll_Success()
    {

        GetKgbDataNonOpusOutput kgbDataOutput = new GetKgbDataNonOpusOutput();
        kgbDataOutput.setSuccess(true);
        List<KgbDataItemOutput> kgbDataOutputData =new ArrayList<>();

        KgbDataItemOutput kgbDataItem = new KgbDataItemOutput();

        kgbDataItem.setCompany("");
        kgbDataItem.setAgencyNo(1);
        kgbDataItem.setBranch("");
        kgbDataItem.setProductionAmount((kgbDataItem.getProductionAmount() == null ? new BigDecimal(0) : kgbDataItem.getProductionAmount()));
        kgbDataItem.setCancellationAmount((kgbDataItem.getCancellationAmount() == null ? new BigDecimal(0) : kgbDataItem.getCancellationAmount()));
        kgbDataOutputData.add(kgbDataItem);

        kgbDataOutput.setData(kgbDataOutputData);

        doNothing().when(ekgbMonthRepository).updateMonthLastOperation(anyInt(),anyInt(),anyString());
        when(commissionDetailTempRepository.saveAll(any())).thenReturn(null);

        when(kgbDataCollector.getNonOpusData(any())).thenReturn(kgbDataOutput);

        ResponseBaseContract result = collectKGBDataService.getKgbDataNonOPUSAll(2024,1);

        Assertions.assertSame(ResponseMessageStatus.SUCCESS, result.getStatus() );
    }


    @Test
    public void getKgbDataNonOPUSAll_NoSuccess()
    {
        GetKgbDataNonOpusOutput kgbDataOutput = new GetKgbDataNonOpusOutput();
        kgbDataOutput.setSuccess(false);

        doNothing().when(ekgbMonthRepository).updateMonthLastOperation(anyInt(),anyInt(),anyString());

        when(kgbDataCollector.getNonOpusData(any())).thenReturn(kgbDataOutput);

        ResponseBaseContract result = collectKGBDataService.getKgbDataNonOPUSAll(2024,1);

        Assertions.assertSame(ResponseMessageStatus.FAILURE, result.getStatus() );
    }

}
