package tr.com.allianz.ekgb.service;

import kepUetsRetrieve.OutgoingMailResult;
import lombok.SneakyThrows;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.EnumSource;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.springframework.data.domain.*;
import tr.com.allianz.ekgb.entity.Commission;
import tr.com.allianz.ekgb.entity.CommissionDetail;
import tr.com.allianz.ekgb.entity.EkgbMonth;
import tr.com.allianz.ekgb.entity.enums.*;
import tr.com.allianz.ekgb.model.*;
import tr.com.allianz.ekgb.repository.CommissionDetailRepository;
import tr.com.allianz.ekgb.repository.CommissionRepository;
import tr.com.allianz.ekgb.repository.EkgbMonthRepository;
import tr.com.allianz.ekgb.service.email.NotifierImpl;
import tr.com.allianz.ekgb.service.filenet.CreateDocumentDocContentInput;
import tr.com.allianz.ekgb.service.filenet.CreateDocumentOutput;
import tr.com.allianz.ekgb.service.filenet.FilenetServiceImpl;
import tr.com.allianz.ekgb.service.filenet.GetDocumentOutput;
import tr.com.allianz.ekgb.service.kep.KEPService;
import tr.com.allianz.ekgb.util.EkgbConstants;
import tr.com.cs.uut.earsiv.service.BelgeDTO;
import tr.com.cs.uut.earsiv.service.EarsivServiceResult;

import javax.xml.ws.Holder;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@PrepareForTest(CommissionServiceImpl.class)
public class CommissionServiceTest {

    @InjectMocks
    private CommissionServiceImpl commissionService;


    @Mock
    private EkgbMonthRepository ekgbMonthRepository;

    @Mock
    private CommissionRepository commissionRepository;

    @Mock
    private CommissionDetailRepository commissionDetailRepository;


    @Mock
    private EkgbGibService ekgbGibService;

    @Mock
    private  KEPService kEPService;

    @Mock
    private FilenetServiceImpl filenetServiceImpl;

    @Mock
    private NotifierImpl notifier;

    @Mock
    private  CollectKGBDataService collectKGBDataService;



    @Test
    public void getFilteredCommissionsPaged_ItemExists() {
        //Arrange
        List<Commission> cList = new ArrayList();
        cList.add(new Commission());
        final Page<Commission> resPages = new PageImpl<>(cList);

        FilteredCommissionsRequest filteredCommissionsRequest= new FilteredCommissionsRequest();
        filteredCommissionsRequest.setPage(0);
        filteredCommissionsRequest.setPageSize(10);
        filteredCommissionsRequest.setSortBy("agency");
        filteredCommissionsRequest.setSortOrder("asc");

        Sort sort = Sort.by("agency").ascending();

        Pageable pageable = PageRequest.of(filteredCommissionsRequest.getPage(),
                filteredCommissionsRequest.getPageSize(),sort);


        when(commissionRepository.findFilteredPaged(
            false,
                filteredCommissionsRequest.getCompany(),
            false,
                filteredCommissionsRequest.getKepStatus(),
            false,
                filteredCommissionsRequest.getGibStatus(),
                filteredCommissionsRequest.getAgency(),
                filteredCommissionsRequest.getAgencyTaxNo(),
                filteredCommissionsRequest.getYear(),
                filteredCommissionsRequest.getMonth(),
                pageable)).thenReturn(resPages);

        //Act
        Page<Commission> pages = commissionService.getFilteredCommissionsPaged(filteredCommissionsRequest);
        //Assert
        assertEquals(1, pages.getTotalElements());
        verify(commissionRepository, times(1)).findFilteredPaged(false, null, false, null, false, null, null, null, 0, 0, pageable);
    }


    @Test
    public void getFilteredCommissionsPaged_NoItemExists() {
        //Arrange
        List<Commission> cList = new ArrayList();
        final Page<Commission> resPages = new PageImpl<>(cList);


        FilteredCommissionsRequest filteredCommissionsRequest= new FilteredCommissionsRequest();
        filteredCommissionsRequest.setPage(0);
        filteredCommissionsRequest.setPageSize(10);
        filteredCommissionsRequest.setSortBy("agency");
        filteredCommissionsRequest.setSortOrder("asc");

        Sort sort = Sort.by("agency").ascending();

        Pageable pageable = PageRequest.of(filteredCommissionsRequest.getPage(),
                filteredCommissionsRequest.getPageSize(),sort);

        when(commissionRepository.findFilteredPaged(false,
            filteredCommissionsRequest.getCompany(),
            false,
                filteredCommissionsRequest.getKepStatus(),
            false,
                filteredCommissionsRequest.getGibStatus(),
                filteredCommissionsRequest.getAgency(),
                filteredCommissionsRequest.getAgencyTaxNo(),
                filteredCommissionsRequest.getYear(),
                filteredCommissionsRequest.getMonth(),
                pageable)).thenReturn(resPages);

        //Act
        Page<Commission> pages = commissionService.getFilteredCommissionsPaged(filteredCommissionsRequest);
        //Assert
        assertEquals(0, pages.getTotalElements());
        verify(commissionRepository, times(1)).findFilteredPaged(false, null, false, null, false, null, null, null, 0, 0, pageable);

    }


    @Test
    public void getFilteredCommissionIds_ItemExists() {
        //Arrange
        List<Integer> idList = new ArrayList();
        idList.add(555);

        FilteredCommissionsRequest filteredCommissionsRequest= new FilteredCommissionsRequest();
        filteredCommissionsRequest.setPage(0);
        filteredCommissionsRequest.setPageSize(10);

        when(commissionRepository.findFilteredIds(false,
            filteredCommissionsRequest.getCompany(),
            false,
                filteredCommissionsRequest.getKepStatus(),
            false,
                filteredCommissionsRequest.getGibStatus(),
                filteredCommissionsRequest.getAgency(),
                filteredCommissionsRequest.getAgencyTaxNo(),
                filteredCommissionsRequest.getYear(),
                filteredCommissionsRequest.getMonth())).thenReturn(idList);

        //Act
        List<Integer> result = commissionService.getFilteredCommissionIds(filteredCommissionsRequest);
        //Assert
        assertEquals(1, result.size());
        verify(commissionRepository, times(1)).findFilteredIds(false, null, false, null, false, null, null, null, 0, 0);

    }

    @Test
    public void getFilteredCommissionIds_NoItemExists() {
        //Arrange
        List<Integer> idList = new ArrayList();

        FilteredCommissionsRequest filteredCommissionsRequest= new FilteredCommissionsRequest();
        filteredCommissionsRequest.setPage(0);
        filteredCommissionsRequest.setPageSize(10);

        when(commissionRepository.findFilteredIds(false,
            filteredCommissionsRequest.getCompany(),
            false,
                filteredCommissionsRequest.getKepStatus(),
            false,
                filteredCommissionsRequest.getGibStatus(),
                filteredCommissionsRequest.getAgency(),
                filteredCommissionsRequest.getAgencyTaxNo(),
                filteredCommissionsRequest.getYear(),
                filteredCommissionsRequest.getMonth())).thenReturn(idList);

        //Act
        List<Integer> result = commissionService.getFilteredCommissionIds(filteredCommissionsRequest);
        //Assert
        assertEquals(0, result.size());
        verify(commissionRepository, times(1)).findFilteredIds(false, null, false, null, false, null, null, null, 0, 0);

    }


    @Test
    public void getFilteredCommissions_ItemExists() {
        //Arrange
        List<CommissionXlsDto> cList = new ArrayList();
        cList.add(new CommissionXlsDto());


        FilteredCommissionsRequest filteredCommissionsRequest= new FilteredCommissionsRequest();
        filteredCommissionsRequest.setPage(0);
        filteredCommissionsRequest.setPageSize(10);

        when(commissionRepository.findFiltered(false,
            filteredCommissionsRequest.getCompany(),
            false,
                filteredCommissionsRequest.getKepStatus(),
            false,
                filteredCommissionsRequest.getGibStatus(),
                filteredCommissionsRequest.getAgency(),
                filteredCommissionsRequest.getAgencyTaxNo(),
                filteredCommissionsRequest.getYear(),
                filteredCommissionsRequest.getMonth())).thenReturn(cList);

        //Act
        List<CommissionXlsDto> getFilteredCommissions = commissionService.getFilteredCommissions(filteredCommissionsRequest);
        //Assert
        assertEquals(1, getFilteredCommissions.size());
        verify(commissionRepository, times(1)).findFiltered(false, null, false, null, false, null, null, null, 0, 0);
    }

    @Test
    public void getFilteredCommissions_NoItemExists() {
        //Arrange
        List<CommissionXlsDto> cList = new ArrayList();

        FilteredCommissionsRequest filteredCommissionsRequest= new FilteredCommissionsRequest();
        filteredCommissionsRequest.setPage(0);
        filteredCommissionsRequest.setPageSize(10);

        when(commissionRepository.findFiltered(false,
            filteredCommissionsRequest.getCompany(),
            false,
                filteredCommissionsRequest.getKepStatus(),
            false,
                filteredCommissionsRequest.getGibStatus(),
                filteredCommissionsRequest.getAgency(),
                filteredCommissionsRequest.getAgencyTaxNo(),
                filteredCommissionsRequest.getYear(),
                filteredCommissionsRequest.getMonth())).thenReturn(cList);

        //Act
        List<CommissionXlsDto> getFilteredCommissions = commissionService.getFilteredCommissions(filteredCommissionsRequest);
        //Assert
        assertEquals(0, getFilteredCommissions.size());
        verify(commissionRepository, times(1)).findFiltered(false, null, false, null, false, null, null, null, 0, 0);
    }



    @Test
    public void getCommission() {

        //Arrange
        final Commission commission = Mockito.mock(Commission.class);
        when(commissionRepository.findById(any())).thenReturn(Optional.of(commission));

        //act
        Optional<Commission> optionalCommission = commissionService.getCommission(2);

        Assertions.assertNotNull(optionalCommission);
    }

    @Test
    public void getCommissionByAgencyYearMonth_NoItem() {

        List<Commission> cListEmpty =  new ArrayList<Commission>();

        when(commissionRepository.findByAgencyYearMonth(anyString(), anyInt(),anyInt(),anyInt())).thenReturn(cListEmpty);

        Commission commission = commissionService.getCommissionByAgencyYearMonth("AZS", 793, 2024,1);

        Assertions.assertNull(commission);
    }

    @Test
    public void getCommissionByAgencyYearMonth_WithItem() {

        List<Commission> cListItems =  new ArrayList<Commission>();
        cListItems.add(new Commission());

        when(commissionRepository.findByAgencyYearMonth(anyString(), anyInt(),anyInt(),anyInt())).thenReturn(cListItems);

        Commission commission = commissionService.getCommissionByAgencyYearMonth("AZS", 793, 2024,1);

        Assertions.assertNotNull(commission);

    }


    @Test
    public void getCommissionListRemoteByDate_NoVat() {

        String nonExistingCompany="MY_COMPANY";
        ResponseBaseContract responseBaseContract = commissionService.getCommissionListRemoteByDate(nonExistingCompany, LocalDate.now(), LocalDate.now());

        Assertions.assertSame(responseBaseContract.getStatus(), ResponseMessageStatus.FAILURE);

    }

    @Test
    public void getCommissionListRemoteByDate_QNBService_Fail() {

        final EarsivServiceResult earsivServiceResultNotSuccess = Mockito.mock(EarsivServiceResult.class);
        earsivServiceResultNotSuccess.setResultCode(EkgbConstants.QNB_RESULT_SUCCESS_CODE);

        //when(ekgbGibService.sigortaKomisyonListe( any(),any())).thenReturn(earsivServiceResultNotSuccess);

        ResponseBaseContract result= commissionService.getCommissionListRemoteByDate("", LocalDate.now(), LocalDate.now());

        Assertions.assertSame(result.getStatus(), ResponseMessageStatus.FAILURE);

    }

    @Test
    public void getCommissionListRemoteByDate_Success() {

        EarsivServiceResult earsivServiceResultSuccess = Mockito.mock(EarsivServiceResult.class);



        List<BelgeDTO> belgeDTOList = new ArrayList<>();
        BelgeDTO belgeDTO = new BelgeDTO();
        belgeDTO.setBelgeNo("");
        belgeDTO.setIslemId("");
        belgeDTO.setIstihsalKomisyonu(new BigDecimal(0));
        belgeDTO.setIptalKomisyonu(new BigDecimal(0));
        belgeDTO.setIptalTarihi(null);
        belgeDTO.setReceiverContact(null);
        belgeDTO.setReceiverName(null);
        belgeDTO.setIssueDate("20240101");
        belgeDTO.setCreationTime("10:00");

        Holder<List<BelgeDTO>> output = new Holder<List<BelgeDTO>>(belgeDTOList);

        EarsivServiceResult earsivServiceResult = new EarsivServiceResult();

        EarsivServiceResult.ResultExtra  resultExtra = new EarsivServiceResult.ResultExtra();

        EarsivServiceResult.ResultExtra.Entry entry = new EarsivServiceResult.ResultExtra.Entry();
        entry.setKey(EkgbConstants.QNB_EKGB_TOTALCOUNT_FIELD);
        entry.setValue(0);

        resultExtra.getEntry().add(entry);

        earsivServiceResult.setResultCode(EkgbConstants.QNB_RESULT_SUCCESS_CODE);
        earsivServiceResult.setResultExtra(resultExtra);


        //String input = "{\"mukellefVkn\":\"8000013270\",\"belgeTarihiBaslangic\":\"20240101\",\"pagingLimit\":\"10\",\"pagingStart\":\"0\",\"belgeTarihiBitis\":\"20240101\"}";
        //when(ekgbGibService.sigortaKomisyonListe(input,output)).thenReturn(earsivServiceResult);
        when(ekgbGibService.sigortaKomisyonListe(anyString(),any())).thenReturn(earsivServiceResult);

        ResponseBaseContract result= commissionService.getCommissionListRemoteByDate("AZS", LocalDate.parse("2024-01-01"), LocalDate.parse("2024-01-01"));

        Assertions.assertSame( ResponseMessageStatus.SUCCESS, result.getStatus());

    }

    @Test
    public void getCommissionListRemoteByDate_Failure() {

        EarsivServiceResult earsivServiceResultSuccess = Mockito.mock(EarsivServiceResult.class);

        Holder<List<BelgeDTO>> output = new Holder<List<BelgeDTO>>();

        EarsivServiceResult earsivServiceResult = new EarsivServiceResult();

        EarsivServiceResult.ResultExtra  resultExtra = new EarsivServiceResult.ResultExtra();


        earsivServiceResult.setResultCode("FAILURE_CODE");
        earsivServiceResult.setResultExtra(resultExtra);

        when(ekgbGibService.sigortaKomisyonListe(anyString(),any())).thenReturn(earsivServiceResult);

        ResponseBaseContract result= commissionService.getCommissionListRemoteByDate("AZS", LocalDate.now(), LocalDate.now());

        Assertions.assertSame( ResponseMessageStatus.FAILURE, result.getStatus());

    }

    private static Stream<Arguments> createEkgbParameters() {


        Commission commissionALZ = createTestCommission();
        Commission commissionALZ2 = createTestCommission();

        Commission commissionALZMissingData = new Commission();
        commissionALZMissingData.setGibStatusId(GibStatus.GONDERIM_BEKLENIYOR.getValue());
        commissionALZMissingData.setCompany(AllianzCompany.ALLIANZ_SIGORTA.getValue());
        commissionALZMissingData.setAgency(100);
        commissionALZMissingData.setYear(2024);
        commissionALZMissingData.setMonth(1);

        Commission commissionALZGONDERILDI = createTestCommission();
        commissionALZGONDERILDI.setGibStatusId(GibStatus.GONDERILDI.getValue());

        Commission commissionALZGONDERILDI2 =createTestCommission();
        commissionALZGONDERILDI2.setGibStatusId(GibStatus.GONDERILDI.getValue());

        Commission commissionAZHE = createTestCommission();
        commissionAZHE.setCompany(AllianzCompany.HAYAT_EMEKLILIK.getValue());

        Commission commissionAZHEGonderildi = createTestCommission();
        commissionAZHEGonderildi.setGibStatusId(GibStatus.GONDERILDI.getValue());
        commissionAZHEGonderildi.setCompany(AllianzCompany.HAYAT_EMEKLILIK.getValue());

        Commission commissionAZYE = createTestCommission();
        commissionAZYE.setCompany(AllianzCompany.YASAM_EMEKLILIK.getValue());

        Commission commissionAZYEGonderildi = createTestCommission();
        commissionAZYEGonderildi.setGibStatusId(GibStatus.GONDERILDI.getValue());
        commissionAZYEGonderildi.setCompany(AllianzCompany.YASAM_EMEKLILIK.getValue());

        Commission commissionTCKN = createTestCommission();
        commissionTCKN.setAgencyTaxNo("1234567890");

        CommissionDetail commissionDetailALZ = new CommissionDetail();
        commissionDetailALZ.setCompany(AllianzCompany.ALLIANZ_SIGORTA.getValue());
        commissionDetailALZ.setAgency(100);
        commissionDetailALZ.setYear(2024);
        commissionDetailALZ.setMonth(1);
        commissionDetailALZ.setCancelAmount(new BigDecimal(0));
        commissionDetailALZ.setProductionAmount (new BigDecimal(0));
        commissionDetailALZ.setBranch("Branch");
        commissionDetailALZ.setDataSource("OPUS");

        List<CommissionDetail> commissionDetailALZList = new ArrayList<>();
        commissionDetailALZList.add(commissionDetailALZ);

        CommissionDetail commissionDetailAZHE = new CommissionDetail();
        commissionDetailAZHE.setCompany(AllianzCompany.HAYAT_EMEKLILIK.getValue());
        commissionDetailAZHE.setAgency(100);
        commissionDetailAZHE.setYear(2024);
        commissionDetailAZHE.setMonth(1);
        commissionDetailAZHE.setCancelAmount(new BigDecimal(0));
        commissionDetailAZHE.setProductionAmount (new BigDecimal(0));
        commissionDetailAZHE.setBranch("Branch");
        commissionDetailAZHE.setDataSource("ABS");


        List<CommissionDetail> commissionDetailAZHEList = new ArrayList<>();
        commissionDetailAZHEList.add(commissionDetailAZHE);

        EarsivServiceResult earsivServiceResultSuccess =new EarsivServiceResult();
        Holder<List<BelgeDTO>> output = new Holder<List<BelgeDTO>>();
        EarsivServiceResult.ResultExtra  resultExtra = new EarsivServiceResult.ResultExtra();
        EarsivServiceResult.ResultExtra.Entry entry = new EarsivServiceResult.ResultExtra.Entry();
        entry.setKey("belgeNo");
        entry.setValue("BELGENO0001");
        resultExtra.getEntry().add(entry);
        earsivServiceResultSuccess.setResultCode(EkgbConstants.QNB_RESULT_SUCCESS_CODE);
        earsivServiceResultSuccess.setResultExtra(resultExtra);


        EarsivServiceResult earsivServiceResultFailure  =new EarsivServiceResult();
        earsivServiceResultFailure.setResultCode("QNB_RESULT_FAILURE_CODE");
        earsivServiceResultFailure.setResultText("Some error message");


        return Stream.of(

                Arguments.of(commissionALZMissingData,commissionDetailALZList,earsivServiceResultSuccess,earsivServiceResultSuccess,true),
                Arguments.of(commissionALZ,commissionDetailALZList,earsivServiceResultSuccess,earsivServiceResultSuccess,true),
                Arguments.of(commissionALZ2,commissionDetailALZList,earsivServiceResultFailure,earsivServiceResultSuccess,false),
                Arguments.of(commissionAZHE,commissionDetailAZHEList,earsivServiceResultSuccess,earsivServiceResultSuccess,true),
                Arguments.of(commissionAZYE,commissionDetailALZList,earsivServiceResultSuccess,earsivServiceResultSuccess,true),
                Arguments.of(commissionTCKN,commissionDetailALZList,earsivServiceResultSuccess,earsivServiceResultSuccess,true),
                Arguments.of(commissionAZHEGonderildi,commissionDetailALZList,earsivServiceResultSuccess,earsivServiceResultSuccess,true),
                Arguments.of(commissionAZYEGonderildi,commissionDetailALZList,earsivServiceResultSuccess,earsivServiceResultSuccess,true),
                Arguments.of(commissionALZGONDERILDI,commissionDetailALZList,earsivServiceResultSuccess,earsivServiceResultSuccess,true),
                Arguments.of(commissionALZGONDERILDI2,commissionDetailALZList,earsivServiceResultSuccess,earsivServiceResultFailure,false)


        );

    }

    @SneakyThrows
    @ParameterizedTest
    @MethodSource("createEkgbParameters")
    public void createEkgb_Test(
            Commission commission,
            List<CommissionDetail> commissionDetail,
            EarsivServiceResult earsivServiceResultKomisyonOlustur,
            EarsivServiceResult earsivServiceResultKomisyonSorgula,
            boolean expectedResult
            ) {

        //Arrange
        commissionService.getEkgbGIBTemplate();
        CommissionServiceImpl.IsCreateCommissionError = false;

        Optional<Commission> opC = Optional.of(commission);

        lenient().when(commissionRepository.findById(any())).thenReturn(opC);

        lenient().when(ekgbGibService.sigortaKomisyonOlustur(anyString(), any(), any())).thenReturn(earsivServiceResultKomisyonOlustur);
        lenient().when(ekgbGibService.sigortaKomisyonSorgula(anyString(), any())).thenReturn(earsivServiceResultKomisyonSorgula);
        lenient().doNothing().when(ekgbMonthRepository).updateMonthLastError(anyInt(), anyInt(), anyString());

        CreateDocumentOutput createDocumentOutput = new CreateDocumentOutput();
        createDocumentOutput.setDoc_ID("Filenet Document Id");
        createDocumentOutput.setResultCode("");
        createDocumentOutput.setResultMessage("Everything OK");
        lenient().when(filenetServiceImpl.createDocument(any())).thenReturn(createDocumentOutput);

        lenient().doNothing().when(ekgbMonthRepository).updateMonthStatisticsKGB(anyInt(), anyInt());
        lenient().when(commissionRepository.saveAndFlush(any())).thenReturn(null);
        lenient().when(commissionDetailRepository.findByCompanyAgencyYearMonth(anyString(),anyInt(),anyInt(),anyInt())).thenReturn(commissionDetail);
        lenient().doNothing().when(ekgbMonthRepository).flush();

        List<Long> commissionList=new ArrayList<>();
        commissionList.add(1L);

        //Act

        CompletableFuture<Boolean>  createEkgbResult = commissionService.createEkgb(commissionList);


        //Assert
        boolean result = false;
//        try {
            result  = createEkgbResult.get();
//        }catch (Exception ex)
//        {
//            result = !expectedResult;
//        }

        Assertions.assertEquals(expectedResult, result);
    }




    @Test
    public void kepSend() {

        Assertions.assertTrue(true);

    }

    @Test
    public void cancelEkgb_MonthClosed() {

        Commission c = new Commission();
        c.setId(1);
        c.setYear(2024);
        c.setMonth(1);
        Optional<Commission> commission = Optional.of(c);

        when(commissionRepository.findById(any())).thenReturn(commission);

        EkgbMonth month = new EkgbMonth();
        month.setStatus(MonthStatus.CLOSED.getValue());
        when(ekgbMonthRepository.getMonth(anyInt(),anyInt())).thenReturn(month);

        ResponseBaseContract result = commissionService.cancelEkgb(c.getId());

        Assertions.assertSame(result.getStatus(), ResponseMessageStatus.FAILURE);

    }

    @Test
    public void cancelEkgb_GibStatusKaydedildi_Degil() {

        Commission c = new Commission();
        c.setId(1);
        c.setYear(2024);
        c.setMonth(1);
        c.setGibStatusId(GibStatus.GONDERILDI.getValue());
        Optional<Commission> commission = Optional.of(c);

        when(commissionRepository.findById(any())).thenReturn(commission);

        EkgbMonth month = new EkgbMonth();
        month.setStatus(MonthStatus.OPEN.getValue());
        when(ekgbMonthRepository.getMonth(anyInt(),anyInt())).thenReturn(month);

        ResponseBaseContract result = commissionService.cancelEkgb(c.getId());

        Assertions.assertSame(result.getStatus(), ResponseMessageStatus.SUCCESS);

    }

    @ParameterizedTest
    @EnumSource(AllianzCompany.class)
    public void cancelEkgb_GibStatusKaydedildi_Success(AllianzCompany company) {

        Commission c = new Commission();
        c.setId(1);
        c.setYear(2024);
        c.setMonth(1);
        c.setCompany(company.getValue());
        c.setKgbUUID("");
        c.setGibStatusId(GibStatus.KAYDEDILDI.getValue());
        Optional<Commission> commission = Optional.of(c);

        when(commissionRepository.findById(any())).thenReturn(commission);

        EkgbMonth month = new EkgbMonth();
        month.setStatus(MonthStatus.OPEN.getValue());
        when(ekgbMonthRepository.getMonth(anyInt(),anyInt())).thenReturn(month);

        EarsivServiceResult earsivServiceResultSuccess = new EarsivServiceResult();
        earsivServiceResultSuccess.setResultCode(EkgbConstants.QNB_RESULT_SUCCESS_CODE);
        when(ekgbGibService.sigortaKomisyonIptalEt(anyString())).thenReturn(earsivServiceResultSuccess);
        when(commissionRepository.save(any())).thenReturn(null);

        ResponseBaseContract result = commissionService.cancelEkgb(c.getId());

        Assertions.assertSame(result.getStatus(), ResponseMessageStatus.SUCCESS);

    }

    @Test
    public void cancelEkgb_GibStatusKaydedildi_Failure() {

        Commission c = new Commission();
        c.setId(1);
        c.setYear(2024);
        c.setMonth(1);
        c.setCompany(AllianzCompany.ALLIANZ_SIGORTA.getValue());
        c.setKgbUUID("");
        c.setGibStatusId(GibStatus.KAYDEDILDI.getValue());
        Optional<Commission> commission = Optional.of(c);

        when(commissionRepository.findById(any())).thenReturn(commission);

        EkgbMonth month = new EkgbMonth();
        month.setStatus(MonthStatus.OPEN.getValue());
        when(ekgbMonthRepository.getMonth(anyInt(),anyInt())).thenReturn(month);

        EarsivServiceResult earsivServiceResultSuccess = new EarsivServiceResult();
        earsivServiceResultSuccess.setResultCode(EkgbConstants.QNB_RESULT_SUCCESS_CODE+"F");
        when(ekgbGibService.sigortaKomisyonIptalEt(anyString())).thenReturn(earsivServiceResultSuccess);

        ResponseBaseContract result = commissionService.cancelEkgb(c.getId());

        Assertions.assertSame(result.getStatus(), ResponseMessageStatus.FAILURE);

    }

    @Test
    public void EkgbMonth() {
        when(ekgbMonthRepository.save(any())).thenReturn(null);
        EkgbMonth month = commissionService.createMonth(2024,1);
        verify(ekgbMonthRepository, times(1)).save(any());
    }

    @Test
    public void getAllMonths() {

        List<EkgbMonth> months = new ArrayList<>();
        EkgbMonth month = new EkgbMonth();
        months.add(month);
        when(ekgbMonthRepository.getAllMonths()).thenReturn(months);

        List<EkgbMonth>  result = commissionService.getAllMonths();

        verify(ekgbMonthRepository,times(1)).getAllMonths();
        Assertions.assertEquals(1,result.size());
    }

    @Test
    public void collectCommissionMonthData_ClosedMonth() {

        EkgbMonth closedMonth = new EkgbMonth();
        closedMonth.setStatus(MonthStatus.CLOSED.getValue());

        when(ekgbMonthRepository.findEkgbMonthByYearMonth(anyInt(),anyInt())).thenReturn(closedMonth);

        ResponseBaseContract result = commissionService.collectCommissionMonthData(anyInt(),anyInt());

        Assertions.assertSame(result.getStatus(), ResponseMessageStatus.FAILURE);

    }

    @Test
    public void collectCommissionMonthData_BusyMonth() {

        EkgbMonth closedMonth = new EkgbMonth();
        closedMonth.setStatus(MonthStatus.OPEN.getValue());
        closedMonth.setCurrentOperation(MonthCurrentOperation.COLLECTING_DATA.getValue());

        when(ekgbMonthRepository.findEkgbMonthByYearMonth(anyInt(),anyInt())).thenReturn(closedMonth);

        ResponseBaseContract result = commissionService.collectCommissionMonthData(anyInt(),anyInt());

        Assertions.assertSame(result.getStatus(), ResponseMessageStatus.FAILURE);

    }

    @Test
    public void collectCommissionMonthData_MonthNotFound() {

        EkgbMonth closedMonth = new EkgbMonth();

        when(ekgbMonthRepository.findEkgbMonthByYearMonth(anyInt(),anyInt())).thenReturn(null);

        ResponseBaseContract result = commissionService.collectCommissionMonthData(anyInt(),anyInt());

        Assertions.assertSame(result.getStatus(), ResponseMessageStatus.FAILURE);

    }

    @Test
    public void collectCommissionMonthData_Success() {

        EkgbMonth closedMonth = new EkgbMonth();
        closedMonth.setStatus(MonthStatus.OPEN.getValue());
        closedMonth.setCurrentOperation(MonthCurrentOperation.IDLE.getValue());

        when(ekgbMonthRepository.findEkgbMonthByYearMonth(anyInt(),anyInt())).thenReturn(closedMonth);
        doNothing().when(ekgbMonthRepository).updateMonthCurrentOperation(anyInt(),anyInt(),anyInt());



        ResponseBaseContract result = commissionService.collectCommissionMonthData(anyInt(),anyInt());

        Assertions.assertSame(result.getStatus(), ResponseMessageStatus.SUCCESS);

    }



    @Test
    public void getFilenetDocumentPDF_NotFound() {

        GetDocumentOutput getDocumentOutputNotFound = new GetDocumentOutput();
        getDocumentOutputNotFound.setDoc_Content(null);

        when(filenetServiceImpl.getDocument(any())).thenReturn(getDocumentOutputNotFound);

        byte[] result = commissionService.getFilenetDocumentPDF("");

        Assertions.assertEquals(result.length, new byte[0].length);

    }

    @Test
    public void getFilenetDocumentPDF_Found() {

        GetDocumentOutput getDocumentOutput = new GetDocumentOutput();

        String docContentOriginal = "This Is The Document Content";

        byte[] docContent =Base64.getEncoder().encode(docContentOriginal.getBytes(StandardCharsets.US_ASCII));
        CreateDocumentDocContentInput documentDocContent = new CreateDocumentDocContentInput();
        documentDocContent.setDoc_Base64( new String(docContent, StandardCharsets.US_ASCII));
        getDocumentOutput.setDoc_Content(documentDocContent);


        when(filenetServiceImpl.getDocument(any())).thenReturn(getDocumentOutput);

        byte[] result = commissionService.getFilenetDocumentPDF("");

        String resultString = new String(result, StandardCharsets.US_ASCII);

        Assertions.assertEquals(resultString, docContentOriginal);

    }

    @Test
    public void openMonth_Error() {

        when(ekgbMonthRepository.findEkgbMonthByYearMonth(anyInt(),anyInt())).thenReturn(null);

        ResponseBaseContract result = commissionService.openMonth(2024,1 );

        Assertions.assertEquals(result.getStatus(), ResponseMessageStatus.FAILURE);

    }

    @Test
    public void openMonth_Success() {

        EkgbMonth ekgbMonth = new EkgbMonth();
        when(ekgbMonthRepository.findEkgbMonthByYearMonth(anyInt(),anyInt())).thenReturn(ekgbMonth);
        when(ekgbMonthRepository.save(ekgbMonth)).thenReturn(null);

        ResponseBaseContract result = commissionService.openMonth(2024,1 );

        Assertions.assertEquals(result.getStatus(), ResponseMessageStatus.SUCCESS);

    }

    @Test
    public void closeMonth_Error() {

        when(ekgbMonthRepository.findEkgbMonthByYearMonth(anyInt(),anyInt())).thenReturn(null);

        ResponseBaseContract result = commissionService.closeMonth(2024,1 );

        Assertions.assertEquals(result.getStatus(), ResponseMessageStatus.FAILURE);

    }
    @Test
    public void closeMonth_Success() {

        EkgbMonth ekgbMonth = new EkgbMonth();

        when(ekgbMonthRepository.findEkgbMonthByYearMonth(anyInt(),anyInt())).thenReturn(ekgbMonth);

        ResponseBaseContract result = commissionService.closeMonth(2024,1 );

        Assertions.assertEquals(result.getStatus(), ResponseMessageStatus.SUCCESS);

    }

    @Test
    public void cleanError_Success() {

        EkgbMonth ekgbMonth = new EkgbMonth();
        when(ekgbMonthRepository.findEkgbMonthByYearMonth(anyInt(),anyInt())).thenReturn(ekgbMonth);
        when(ekgbMonthRepository.save(ekgbMonth)).thenReturn(null);

        ResponseBaseContract result = commissionService.cleanError(2024,1 );

        Assertions.assertEquals(ResponseMessageStatus.SUCCESS, result.getStatus());
    }
    @Test
    public void cleanError_failureNotFound() {


        when(ekgbMonthRepository.findEkgbMonthByYearMonth(anyInt(),anyInt())).thenReturn(null);

        ResponseBaseContract result = commissionService.cleanError(2024,1 );

        Assertions.assertEquals(ResponseMessageStatus.FAILURE, result.getStatus());
    }



    private static Commission createTestCommission(){
        Commission commission= new Commission();
        commission.setCompany(AllianzCompany.ALLIANZ_SIGORTA.getValue());
        commission.setKepStatusId(KepStatus.GONDERIM_BEKLENIYOR.getValue());
        commission.setGibStatusId(GibStatus.GONDERIM_BEKLENIYOR.getValue());
        commission.setAgency(100);
        commission.setYear(2024);
        commission.setMonth(1);
        commission.setAgencyTitle("Acente Unvan");
        commission.setAgencyAddress("Acente Adres");
        commission.setAgencyTaxOffice("Vergi dairesi");
        commission.setAgencyTaxNo("12345678901");
        return  commission;
    }

    private static Stream<Arguments> kepSendParameters() {


        Commission commissionALZ = createTestCommission();
        commissionALZ.setGibStatusId(GibStatus.KAYDEDILDI.getValue());
        commissionALZ.setKepAddress("kep address");


        Commission commissionALZ2 = createTestCommission();
        commissionALZ2.setGibStatusId(GibStatus.KAYDEDILDI.getValue());
        commissionALZ2.setKepAddress("kep address");


        Commission commissionAZHE =createTestCommission();
        commissionAZHE.setCompany(AllianzCompany.HAYAT_EMEKLILIK.getValue());
        commissionAZHE.setGibStatusId(GibStatus.KAYDEDILDI.getValue());
        commissionAZHE.setKepAddress("kep address");

        Commission commissionAZYE  =createTestCommission();
        commissionAZYE.setCompany(AllianzCompany.YASAM_EMEKLILIK.getValue());
        commissionAZYE.setGibStatusId(GibStatus.KAYDEDILDI.getValue());
        commissionAZYE.setKepAddress("kep address");

        Commission commissionXX = createTestCommission();
        commissionXX.setCompany("XX");
        commissionXX.setGibStatusId(GibStatus.KAYDEDILDI.getValue());
        commissionXX.setKepAddress("kep address");

        EarsivServiceResult earsivServiceResultSuccess =new EarsivServiceResult();
        Holder<List<BelgeDTO>> output = new Holder<List<BelgeDTO>>();
        EarsivServiceResult.ResultExtra  resultExtra = new EarsivServiceResult.ResultExtra();
        EarsivServiceResult.ResultExtra.Entry entry = new EarsivServiceResult.ResultExtra.Entry();
        entry.setKey("belgeNo");
        entry.setValue("BELGENO0001");
        resultExtra.getEntry().add(entry);
        earsivServiceResultSuccess.setResultCode(EkgbConstants.QNB_RESULT_SUCCESS_CODE);
        earsivServiceResultSuccess.setResultExtra(resultExtra);


        EarsivServiceResult earsivServiceResultFailure  =new EarsivServiceResult();
        earsivServiceResultFailure.setResultCode("QNB_RESULT_FAILURE_CODE");
        earsivServiceResultFailure.setResultText("Some error message");

        int outgoingMailResultErrorCodeSuccess=0;
        int outgoingMailResultErrorCodeFailure=1;

        return Stream.of(

                Arguments.of(commissionALZ,outgoingMailResultErrorCodeSuccess,true),
                Arguments.of(commissionXX,outgoingMailResultErrorCodeSuccess,false),
                Arguments.of(commissionALZ2,outgoingMailResultErrorCodeFailure,false),
                Arguments.of(commissionAZHE,outgoingMailResultErrorCodeSuccess,true),
                Arguments.of(commissionAZYE,outgoingMailResultErrorCodeSuccess,true)


        );

    }

    @SneakyThrows
    @ParameterizedTest
    @MethodSource("kepSendParameters")
    public void kepSend_Test(
            Commission commission,
            int outgoingMailResultErrorCode,
            boolean expectedResult
    ) {

        //Arrange

        CommissionServiceImpl.IsSendKepError = false;


        Optional<Commission> opC = Optional.of(commission);

        when(commissionRepository.findById(any())).thenReturn(opC);


        when(commissionRepository.saveAndFlush(any())).thenReturn(null);


        OutgoingMailResult outgoingMailResult =new OutgoingMailResult();
        outgoingMailResult.setErrorCode(outgoingMailResultErrorCode);
        lenient().when(kEPService.SendMessage(any())).thenReturn(outgoingMailResult);

        GetDocumentOutput getDocumentOutput = new GetDocumentOutput();

        String docContentOriginal = "This Is The Document Content";

        byte[] docContent =Base64.getEncoder().encode(docContentOriginal.getBytes(StandardCharsets.US_ASCII));
        CreateDocumentDocContentInput documentDocContent = new CreateDocumentDocContentInput();
        documentDocContent.setDoc_Base64( new String(docContent, StandardCharsets.US_ASCII));
        getDocumentOutput.setDoc_Content(documentDocContent);
        when(filenetServiceImpl.getDocument(any())).thenReturn(getDocumentOutput);


        if (!expectedResult) {
            doNothing().when(ekgbMonthRepository).updateMonthLastError(anyInt(), anyInt(), anyString());
            doNothing().when(ekgbMonthRepository).flush();
        }




        List<Long> commissionList=new ArrayList<>();
        commissionList.add(1L);

        //Act

        CompletableFuture<Boolean>  createEkgbResult = commissionService.kepSend(commissionList);


        //Assert
        boolean result = false;
//        try {
            result  = createEkgbResult.get();
//        }catch (Exception ex)
//        {
//            //result = !expectedResult;
//            throw ex;
//        }

        Assertions.assertEquals(expectedResult, result);
    }



    private static Stream<Arguments> collectCommissionMonthDataParameters() {


        ResponseBaseContract  getKgbDataOpusSuccess = new ResponseBase();
        getKgbDataOpusSuccess.setStatus(ResponseMessageStatus.SUCCESS);

        ResponseBaseContract  getKgbDataOpusFailure = new ResponseBase();
        getKgbDataOpusFailure.setStatus(ResponseMessageStatus.FAILURE);

        ResponseBaseContract  getKgbDataNonOpusSuccess = new ResponseBase();
        getKgbDataNonOpusSuccess.setStatus(ResponseMessageStatus.SUCCESS);
        ResponseBaseContract  getKgbDataNonOpusFailure = new ResponseBase();
        getKgbDataNonOpusFailure.setStatus(ResponseMessageStatus.FAILURE);

        boolean expectedSuccess = true;
        boolean expectedFailure = false;

        return Stream.of(
                Arguments.of(getKgbDataOpusSuccess,getKgbDataNonOpusSuccess,expectedSuccess),
                Arguments.of(null,getKgbDataNonOpusSuccess,expectedFailure),
                Arguments.of(getKgbDataOpusFailure,getKgbDataNonOpusSuccess,expectedFailure),
                Arguments.of(getKgbDataOpusSuccess,getKgbDataNonOpusFailure,expectedFailure)
        );

    }


    @ParameterizedTest
    @MethodSource("collectCommissionMonthDataParameters")

    public void collectCommissionMonthDataAsync_Tests(
            ResponseBaseContract getKgbDataOpusResult,
            ResponseBaseContract getKgbDataNonOpusResult,
            boolean expectedSuccess
    ) {

//Arrange
        doNothing().when(ekgbMonthRepository).updateMonthLastOperation(anyInt(),anyInt(),anyString());

        doNothing().when(commissionRepository).deleteNonProcessedDataCommissionDetail(anyInt(), anyInt());
        doNothing().when(commissionRepository).deleteNonProcessedDataCommission(anyInt(), anyInt());
        doNothing().when(commissionRepository).deleteAllDataCommissionDetailTemp(anyInt(), anyInt());

        when(collectKGBDataService.getKgbDataOpus(anyInt(), anyInt())).thenReturn(getKgbDataOpusResult);

        if (getKgbDataOpusResult !=null && getKgbDataOpusResult.getStatus()== ResponseMessageStatus.SUCCESS){

            when(collectKGBDataService.getKgbDataNonOPUSAll(anyInt(), anyInt())).thenReturn(getKgbDataNonOpusResult);

            if (getKgbDataNonOpusResult !=null && getKgbDataNonOpusResult.getStatus()== ResponseMessageStatus.SUCCESS) {
                doNothing().when(commissionRepository).transferDataCommissionDetailTemp(anyInt(), anyInt());

                doNothing().when(commissionRepository).createCommissionData(anyInt(), anyInt());

                doNothing().when(commissionRepository).getAddressDataAZS(anyInt(), anyInt());

                doNothing().when(commissionRepository).getAddressDataHE(anyInt(), anyInt());

                doNothing().when(commissionRepository).getAddressDataHeHsbcKoc(anyInt(), anyInt());

                doNothing().when(commissionRepository).getAddressDataYE(anyInt(), anyInt());

                doNothing().when(commissionRepository).updateCustomAddressData_YE_1(anyInt(), anyInt());
                doNothing().when(commissionRepository).updateCustomAddressData_AZS_8569(anyInt(), anyInt());
                doNothing().when(commissionRepository).updateCustomAddressData_YE_852(anyInt(), anyInt());
                doNothing().when(commissionRepository).updateCustomAddressData_YE_7001(anyInt(), anyInt());

                doNothing().when(ekgbMonthRepository).updateMonthStatistics(anyInt(), anyInt());

                doNothing().when(ekgbMonthRepository).cleanMonthError(anyInt(), anyInt());
                doNothing().when(ekgbMonthRepository).flush();
            }
        }else {
            doNothing().when(ekgbMonthRepository).updateMonthLastError(anyInt(), anyInt(), anyString());
        }
        doNothing().when(ekgbMonthRepository).updateMonthCurrentOperation(anyInt(), anyInt(), anyInt());


        //Act

        commissionService.collectCommissionMonthDataAsync(2024,1);

        //Assert

        if(expectedSuccess) {
            verify(ekgbMonthRepository, times(0)).updateMonthLastError(anyInt(), anyInt(), anyString());
        }else{
            verify(ekgbMonthRepository, times(1)).updateMonthLastError(anyInt(), anyInt(), anyString());
        }

    }

    @Test
    public void GetMonth_Success()
    {
        when(ekgbMonthRepository.findEkgbMonthByYearMonth(anyInt(), anyInt())).thenReturn(null);
        commissionService.GetMonth(anyInt(), anyInt());
        verify(ekgbMonthRepository, times(1)).findEkgbMonthByYearMonth(anyInt(),anyInt());
    }

}
