package tr.com.allianz.ekgb.regression;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.restclient.RestTemplateBuilder;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.util.AntPathMatcher;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import tr.com.allianz.ekgb.config.CorsProperties;
import tr.com.allianz.ekgb.config.WebConfig;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class WebConfigRegressionTest {

    private WebConfig webConfig;
    private CorsProperties corsProperties;

    @BeforeEach
    public void setUp() {
        webConfig = new WebConfig(10);
        corsProperties = new CorsProperties();
        corsProperties.setAllowMethod(new String[]{"GET", "POST", "PUT", "DELETE"});
        corsProperties.setDomainList(new String[]{"http://localhost:4200", "*.allianz.com.tr"});
        ReflectionTestUtils.setField(webConfig, "corsProperties", corsProperties);
    }

    @Test
    public void asyncTaskExecutor_ConfiguredWithCorrectCorePoolSizeAndPrefix() {
        ThreadPoolTaskExecutor executor = (ThreadPoolTaskExecutor) ReflectionTestUtils.invokeMethod(webConfig, "asyncTaskExecutor");

        assertNotNull(executor);
        assertEquals(10, executor.getCorePoolSize());
        assertEquals("MvcAsync", executor.getThreadNamePrefix());
    }

    @Test
    public void antPathMatcher_BeanCreated() {
        AntPathMatcher matcher = webConfig.antPathMatcher();

        assertNotNull(matcher);
        assertTrue(matcher.match("/api/v3/**", "/api/v3/version/version"));
    }

    @Test
    public void restTemplate_BuiltFromBuilder() {
        RestTemplateBuilder builder = new RestTemplateBuilder();
        RestTemplate restTemplate = webConfig.restTemplate(builder);

        assertNotNull(restTemplate);
    }

    @Test
    public void corsProperties_GettersAndSetters() {
        assertNotNull(corsProperties.getAllowMethod());
        assertEquals(4, corsProperties.getAllowMethod().length);
        assertNotNull(corsProperties.getDomainList());
        assertEquals(2, corsProperties.getDomainList().length);
    }

    @Test
    public void addCorsMappings_RegistersSuccessfully() {
        CorsRegistry registry = new CorsRegistry();
        webConfig.addCorsMappings(registry);
        // Ensure no exception thrown during mapping configuration
        assertNotNull(registry);
    }
}