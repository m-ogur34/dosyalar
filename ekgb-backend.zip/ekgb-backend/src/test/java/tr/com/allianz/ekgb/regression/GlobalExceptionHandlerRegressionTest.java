package tr.com.allianz.ekgb.regression;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import tr.com.allianz.ekgb.exception.BadRequestException;
import tr.com.allianz.ekgb.exception.FailedDependencyException;
import tr.com.allianz.ekgb.exception.ForbiddenException;
import tr.com.allianz.ekgb.exception.GlobalExceptionHandler;
import tr.com.allianz.ekgb.exception.IDMException;
import tr.com.allianz.ekgb.exception.InvalidDataException;
import tr.com.allianz.ekgb.exception.NotFoundException;
import tr.com.allianz.ekgb.exception.ResourceForbiddenException;
import tr.com.allianz.ekgb.exception.ResourceNotFoundException;
import tr.com.allianz.ekgb.exception.UnprocessableEntityException;
import tr.com.allianz.ekgb.exception.UnsupportedMediaTypeException;
import tr.com.allianz.ekgb.exception.UserNotAuthorizedException;
import tr.com.allianz.ekgb.model.ErrorMessageResponse;

import jakarta.validation.ConstraintViolationException;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class GlobalExceptionHandlerRegressionTest {

    private GlobalExceptionHandler exceptionHandler;

    @BeforeEach
    public void setUp() {
        exceptionHandler = new GlobalExceptionHandler();
    }

    @Test
    public void handleBadRequestException_Returns400() {
        BadRequestException ex = new BadRequestException("Invalid input parameters");
        ResponseEntity<Object> response = exceptionHandler.handleBadRequestException(ex);

        assertNotNull(response);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertTrue(response.getBody() instanceof ErrorMessageResponse);
        ErrorMessageResponse error = (ErrorMessageResponse) response.getBody();
        assertEquals("Invalid input parameters", error.getErrorCode());
        assertNotNull(error.getTimestamp());
    }

    @Test
    public void handleUserNotAuthorizedException_Returns401() {
        UserNotAuthorizedException ex = new UserNotAuthorizedException("User unauthorized");
        ResponseEntity<Object> response = exceptionHandler.handleUserNotAuthorizedException(ex);

        assertNotNull(response);
        assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
        assertTrue(response.getBody() instanceof ErrorMessageResponse);
        ErrorMessageResponse error = (ErrorMessageResponse) response.getBody();
        assertEquals("User unauthorized", error.getErrorCode());
    }

    @Test
    public void handleResourceForbiddenException_Returns403() {
        ResourceForbiddenException ex = new ResourceForbiddenException("Access forbidden");
        ResponseEntity<Object> response = exceptionHandler.handleResourceForbiddenException(ex);

        assertNotNull(response);
        assertEquals(HttpStatus.FORBIDDEN, response.getStatusCode());
        assertTrue(response.getBody() instanceof ErrorMessageResponse);
        ErrorMessageResponse error = (ErrorMessageResponse) response.getBody();
        assertEquals("Access forbidden", error.getErrorCode());
    }

    @Test
    public void handleForbiddenException_Returns403() {
        ForbiddenException ex = new ForbiddenException("Operation not allowed");
        ResponseEntity<Object> response = exceptionHandler.handleForbiddenException(ex);

        assertNotNull(response);
        assertEquals(HttpStatus.FORBIDDEN, response.getStatusCode());
        assertTrue(response.getBody() instanceof ErrorMessageResponse);
    }

    @Test
    public void handleResourceNotFoundException_Returns404() {
        ResourceNotFoundException ex = new ResourceNotFoundException("Resource not found");
        ResponseEntity<Object> response = exceptionHandler.handleResourceNotFoundException(ex);

        assertNotNull(response);
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertTrue(response.getBody() instanceof ErrorMessageResponse);
        ErrorMessageResponse error = (ErrorMessageResponse) response.getBody();
        assertEquals("Resource not found", error.getErrorCode());
    }

    @Test
    public void handleNotFoundException_Returns404() {
        NotFoundException ex = new NotFoundException("Record missing");
        ResponseEntity<ErrorMessageResponse> response = exceptionHandler.handleNotFoundException(ex);

        assertNotNull(response);
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("Record missing", response.getBody().getErrorCode());
    }

    @Test
    public void handleInvalidDataException_Returns422() {
        InvalidDataException ex = new InvalidDataException("Data validation failed");
        ResponseEntity<Object> response = exceptionHandler.handleInvalidDataException(ex);

        assertNotNull(response);
        assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, response.getStatusCode());
        assertEquals("Data validation failed", response.getBody());
    }

    @Test
    public void handleUnprocessableEntityException_Returns422() {
        UnprocessableEntityException ex = new UnprocessableEntityException("Cannot process request");
        ResponseEntity<Object> response = exceptionHandler.handleUnprocessableEntityException(ex);

        assertNotNull(response);
        assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, response.getStatusCode());
        assertTrue(response.getBody() instanceof ErrorMessageResponse);
    }

    @Test
    public void handleIDMException_Returns424() {
        IDMException ex = new IDMException("IDM communication error");
        ResponseEntity<Object> response = exceptionHandler.handleIDMException(ex);

        assertNotNull(response);
        assertEquals(HttpStatus.FAILED_DEPENDENCY, response.getStatusCode());
        assertTrue(response.getBody() instanceof ErrorMessageResponse);
    }

    @Test
    public void handleFailedDependencyException_Returns424() {
        FailedDependencyException ex = new FailedDependencyException("External service failure");
        ResponseEntity<Object> response = exceptionHandler.handleFailedDependencyException(ex);

        assertNotNull(response);
        assertEquals(HttpStatus.FAILED_DEPENDENCY, response.getStatusCode());
        assertTrue(response.getBody() instanceof ErrorMessageResponse);
    }

    @Test
    public void handleUnsupportedMediaTypeException_Returns415() {
        UnsupportedMediaTypeException ex = new UnsupportedMediaTypeException("Unsupported media type");
        ResponseEntity<Object> response = exceptionHandler.handleUnsupportedMediaTypeException(ex);

        assertNotNull(response);
        assertEquals(HttpStatus.UNSUPPORTED_MEDIA_TYPE, response.getStatusCode());
        assertTrue(response.getBody() instanceof ErrorMessageResponse);
    }

    @Test
    public void handleAnyException_Returns500() {
        Exception ex = new RuntimeException("Unexpected internal error");
        ResponseEntity<Object> response = exceptionHandler.handleAnyException(ex);

        assertNotNull(response);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertTrue(response.getBody() instanceof ErrorMessageResponse);
        ErrorMessageResponse error = (ErrorMessageResponse) response.getBody();
        assertEquals("Unexpected internal error", error.getErrorCode());
    }

    @Test
    public void handleConstraintViolationException_Returns400() {
        ConstraintViolationException ex = new ConstraintViolationException("Validation error", Collections.emptySet());
        ResponseEntity<List<String>> response = exceptionHandler.validationErrorHandler(ex);

        assertNotNull(response);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertNotNull(response.getBody());
        assertTrue(response.getBody().isEmpty());
    }
}