package tr.com.allianz.ekgb.service;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.powermock.core.classloader.annotations.PrepareForTest;
import tr.com.allianz.ekgb.entity.Commission;
import tr.com.allianz.ekgb.entity.EkgbMonth;
import tr.com.allianz.ekgb.entity.enums.MonthCurrentOperation;
import tr.com.allianz.ekgb.entity.enums.MonthStatus;
import tr.com.allianz.ekgb.repository.CommissionRepository;
import tr.com.allianz.ekgb.repository.EkgbMonthRepository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;

import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@PrepareForTest(KEPSendPartitionedServiceImpl.class)
public class KEPSendPartitionedServiceTest {

    @InjectMocks
    private KEPSendPartitionedServiceImpl kEPSendPartitionedService;

    @Mock
    private  CommissionService commissionService;

    @Mock
    private  CommissionRepository commissionRepository;

    @Mock
    private EkgbMonthRepository ekgbMonthRepository;



    @Test
    public void kepSendPartitioned_EmptyList() {
        List<Long> commissionList = new ArrayList<>();
        kEPSendPartitionedService.kepSendPartitioned(commissionList);
        verify(commissionRepository,times(0)).findById(any());
    }

    @Test
    public void kepSendPartitioned_ClosedMonth() {
        //Arrange
        List<Long> commissionList = new ArrayList<>();
        commissionList.add(1L);

        EkgbMonth closedMonth = new EkgbMonth();
        closedMonth.setStatus(MonthStatus.CLOSED.getValue());
        closedMonth.setCurrentOperation(MonthCurrentOperation.COLLECTING_DATA.getValue());

        Commission commission = new Commission();
        commission.setYear(2024);
        commission.setMonth(1);

        Optional<Commission>  commissionOptional = Optional.of(commission);


        when(commissionRepository.findById(any())).thenReturn(commissionOptional);
        when(ekgbMonthRepository.getMonth(anyInt(),anyInt())).thenReturn(closedMonth);

        //Act
        kEPSendPartitionedService.kepSendPartitioned(commissionList);

        //Assert
        verify(commissionRepository,times(0)).flush();
    }

    @Test
    public void kepSendPartitioned_NotIdleMonth() {
        List<Long> commissionList = new ArrayList<>();
        commissionList.add(1L);

        EkgbMonth closedMonth = new EkgbMonth();
        closedMonth.setStatus(MonthStatus.OPEN.getValue());
        closedMonth.setCurrentOperation(MonthCurrentOperation.COLLECTING_DATA.getValue());

        Commission commission = new Commission();
        commission.setYear(2024);
        commission.setMonth(1);

        Optional<Commission>  commissionOptional = Optional.of(commission);


        when(commissionRepository.findById(any())).thenReturn(commissionOptional);
        when(ekgbMonthRepository.getMonth(anyInt(),anyInt())).thenReturn(closedMonth);

        kEPSendPartitionedService.kepSendPartitioned(commissionList);
        verify(commissionRepository,times(0)).flush();
    }


    @Test
    public void kepSendPartitioned_Success() {
        List<Long> commissionList = new ArrayList<>();
        commissionList.add(1L);

        EkgbMonth closedMonth = new EkgbMonth();
        closedMonth.setStatus(MonthStatus.OPEN.getValue());
        closedMonth.setCurrentOperation(MonthCurrentOperation.IDLE.getValue());

        Commission commission = new Commission();
        commission.setYear(2024);
        commission.setMonth(1);

        Optional<Commission>  commissionOptional = Optional.of(commission);


        when(commissionRepository.findById(any())).thenReturn(commissionOptional);
        when(ekgbMonthRepository.getMonth(anyInt(),anyInt())).thenReturn(closedMonth);

        doNothing().when(ekgbMonthRepository).updateMonthCurrentOperation(anyInt(),anyInt(),anyInt());
        doNothing().when(ekgbMonthRepository).flush();

        kEPSendPartitionedService.qnbPartition = 3;

        when(commissionService.kepSend(any())).thenReturn(CompletableFuture.completedFuture(true));

        kEPSendPartitionedService.kepSendPartitioned(commissionList);

        verify(ekgbMonthRepository,times(2)).flush();
    }





}
