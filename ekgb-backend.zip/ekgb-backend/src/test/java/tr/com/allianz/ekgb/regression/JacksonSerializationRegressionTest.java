package tr.com.allianz.ekgb.regression;

import tools.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import tr.com.allianz.ekgb.model.ErrorMessageResponse;
import tr.com.allianz.ekgb.model.GetVersionResponse;
import tr.com.allianz.ekgb.model.ResponseMessage;
import tr.com.allianz.ekgb.model.ResponseMessageStatus;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class JacksonSerializationRegressionTest {

    private ObjectMapper objectMapper;

    @BeforeEach
    public void setUp() {
        objectMapper = new ObjectMapper();
    }

    @Test
    public void errorMessageResponse_SerializesWithCorrectDateTimeFormat() throws Exception {
        LocalDateTime timestamp = LocalDateTime.of(2026, 9, 26, 14, 30, 45);
        ErrorMessageResponse errorResponse = new ErrorMessageResponse(timestamp, "INVALID_ARGUMENT");

        String json = objectMapper.writeValueAsString(errorResponse);

        assertNotNull(json);
        assertTrue(json.contains("\"errorCode\":\"INVALID_ARGUMENT\""));
        assertTrue(json.contains("\"timestamp\":\"2026-09-26 14:30:45\""));
    }

    @Test
    public void errorMessageResponse_DeserializesCorrectly() throws Exception {
        String json = "{\"timestamp\":\"2026-09-26 14:30:45\",\"errorCode\":\"RESOURCE_NOT_FOUND\"}";

        ErrorMessageResponse response = objectMapper.readValue(json, ErrorMessageResponse.class);

        assertNotNull(response);
        assertEquals("RESOURCE_NOT_FOUND", response.getErrorCode());
        assertEquals(LocalDateTime.of(2026, 9, 26, 14, 30, 45), response.getTimestamp());
    }

    @Test
    public void responseMessageStatus_EnumSerializationAndDeserialization() throws Exception {
        String successJson = objectMapper.writeValueAsString(ResponseMessageStatus.SUCCESS);
        assertEquals("\"SUCCESS\"", successJson);

        ResponseMessageStatus status = objectMapper.readValue("\"SUCCESS\"", ResponseMessageStatus.class);
        assertEquals(ResponseMessageStatus.SUCCESS, status);
        assertEquals("0", status.getCode());
        assertEquals("0-Success", status.getMessage());
    }

    @Test
    public void getVersionResponse_Serialization() throws Exception {
        GetVersionResponse response = GetVersionResponse.builder()
                .responseMessageStatus(ResponseMessageStatus.SUCCESS)
                .data("Version: 1.05 - Test")
                .build();

        String json = objectMapper.writeValueAsString(response);

        assertNotNull(json);
        assertTrue(json.contains("\"status\":\"SUCCESS\"") || json.contains("\"responseMessageStatus\":\"SUCCESS\""));
        assertTrue(json.contains("\"data\":\"Version: 1.05 - Test\""));
    }

    @Test
    public void responseMessage_SerializationAndDeserialization() throws Exception {
        ResponseMessage msg = new ResponseMessage("CODE_01", "Operation successful");
        String json = objectMapper.writeValueAsString(msg);

        assertNotNull(json);
        assertTrue(json.contains("\"code\":\"CODE_01\""));
        assertTrue(json.contains("\"message\":\"Operation successful\""));

        ResponseMessage deserialized = objectMapper.readValue(json, ResponseMessage.class);
        assertNotNull(deserialized);
        assertEquals("CODE_01", deserialized.getCode());
        assertEquals("Operation successful", deserialized.getMessage());
    }
}