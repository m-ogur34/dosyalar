package tr.com.allianz.ekgb.service.security.user;

import com.msu.userutils.UserProfile;



import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;

import tr.com.allianz.ekgb.security.user.UserProfileInfoServiceImpl;
import  tr.com.allianz.ekgb.security.user.UserProfileInfo;

import java.util.Collection;

@ExtendWith(MockitoExtension.class)
@PrepareForTest(value = UserProfileInfoServiceImpl.class)
public class UserProfileInfoServiceTest {

    @InjectMocks
    private UserProfileInfoServiceImpl userProfileInfoService;

    private UserProfile userProfile;

    @BeforeEach
    public void setUp() {
        Authentication dummyAuthenticationUserProfile = createDummyAuthenticationUserProfile();
        ((UserProfile) dummyAuthenticationUserProfile.getPrincipal()).setJwtToken("test-token");
        SecurityContextHolder.getContext().setAuthentication(dummyAuthenticationUserProfile);
        userProfile = (UserProfile) dummyAuthenticationUserProfile.getPrincipal();
    }

    @Test
    public void getUserInfo() {
        UserProfileInfo userProfileInfo = userProfileInfoService.getUserInfo();

        Assertions.assertEquals("dummy-user",userProfileInfo.getName());
        Assertions.assertEquals("test",userProfileInfo.getUserName());
        Assertions.assertEquals("true",userProfileInfo.getUwUser());
    }

    @Test
    public void getJwtToken() {
        Assertions.assertEquals("test-token", userProfileInfoService.getJwtToken());
    }


    private   Authentication createDummyAuthenticationUserProfile() {
        UserProfile userProfile = new UserProfile();
        userProfile.setUserName("test");
        userProfile.setName("dummy-user");
        userProfile.setEmail("dummy@allianz.com.tr");
        userProfile.setUwUser("true");
        return new Authentication() {
            @Override
            public Collection<? extends GrantedAuthority> getAuthorities() {
                return null;
            }

            @Override
            public Object getCredentials() {
                return null;
            }

            @Override
            public Object getDetails() {
                return null;
            }

            @Override
            public Object getPrincipal() {
                return userProfile;
            }

            @Override
            public boolean isAuthenticated() {
                return false;
            }

            @Override
            public void setAuthenticated(boolean b) throws IllegalArgumentException {

            }

            @Override
            public String getName() {
                return null;
            }
        };
    }

}