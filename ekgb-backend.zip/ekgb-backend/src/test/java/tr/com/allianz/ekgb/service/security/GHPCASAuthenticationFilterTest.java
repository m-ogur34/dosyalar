package tr.com.allianz.ekgb.service.security;



import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.springframework.mock.web.MockFilterChain;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import tr.com.allianz.ekgb.security.GHPCASAuthenticationFilter;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import java.io.IOException;

@ExtendWith(MockitoExtension.class)
@PrepareForTest(value = GHPCASAuthenticationFilter.class)
public class GHPCASAuthenticationFilterTest {

    @InjectMocks
    private GHPCASAuthenticationFilter ghpcasAuthenticationFilter;

    @Test
    public void testDoFilter() throws ServletException, IOException {
        ServletRequest request = new MockHttpServletRequest("OPTIONS", "OPTION");
        ServletResponse response = new MockHttpServletResponse();
        FilterChain chain = new MockFilterChain();
        ghpcasAuthenticationFilter.doFilter(request, response, chain);
    }

}