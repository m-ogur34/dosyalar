package tr.com.allianz.ekgb.service.security;


import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.springframework.mock.web.MockFilterChain;
import org.springframework.mock.web.MockFilterConfig;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

import tr.com.allianz.ekgb.security.JwtPostCasFilter;

import jakarta.servlet.*;
import java.io.IOException;

@ExtendWith(MockitoExtension.class)
@PrepareForTest(value = JwtPostCasFilter.class)
public class JWTPostCasFilterTest {

    @InjectMocks
    private JwtPostCasFilter filter;

    @Test
    public void testInit() {
        FilterConfig filterConfig = new MockFilterConfig();
        filter.init(filterConfig);
    }

    @Test
    public void testDestroy() {
        filter.destroy();
    }

    @Test
    public void testDoFilter() throws ServletException, IOException {
        ServletRequest request = new MockHttpServletRequest();
        ServletResponse response = new MockHttpServletResponse();
        FilterChain chain = new MockFilterChain();

        filter.doFilter(request, response, chain);
    }
}