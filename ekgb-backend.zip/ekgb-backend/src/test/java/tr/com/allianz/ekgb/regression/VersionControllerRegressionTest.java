package tr.com.allianz.ekgb.regression;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import tr.com.allianz.ekgb.controller.VersionController;
import tr.com.allianz.ekgb.model.GetVersionResponse;
import tr.com.allianz.ekgb.model.ResponseBaseContract;
import tr.com.allianz.ekgb.model.ResponseMessageStatus;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

public class VersionControllerRegressionTest {

    private VersionController versionController;
    private MockMvc mockMvc;

    @BeforeEach
    public void setUp() {
        versionController = new VersionController();
        ReflectionTestUtils.setField(versionController, "version", "1.05");
        ReflectionTestUtils.setField(versionController, "versionDescription", "Security aciklari kapatildi.");
        mockMvc = MockMvcBuilders.standaloneSetup(versionController).build();
    }

    @Test
    public void getVersion_EndpointReturns200AndJson() throws Exception {
        mockMvc.perform(get("/api/v3/version/version").accept(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(status().isOk())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.status").value("SUCCESS"))
                .andExpect(jsonPath("$.data").value("Version: 1.05 - Security aciklari kapatildi."));
    }

    @Test
    public void getVersion_DirectInvocationReturnsSuccessContract() {
        ResponseEntity<ResponseBaseContract> response = versionController.getVersion();

        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertTrue(response.getBody() instanceof GetVersionResponse);

        GetVersionResponse getVersionResponse = (GetVersionResponse) response.getBody();
        assertEquals(ResponseMessageStatus.SUCCESS, getVersionResponse.getStatus());
        assertEquals("Version: 1.05 - Security aciklari kapatildi.", getVersionResponse.getData());
    }
}