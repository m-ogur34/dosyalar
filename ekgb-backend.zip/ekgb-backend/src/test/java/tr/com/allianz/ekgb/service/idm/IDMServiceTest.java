package tr.com.allianz.ekgb.service.idm;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;
import tr.com.allianz.ekgb.model.idm.EkgbUserPermissionResponse;
import tr.com.allianz.ekgb.model.idm.IDMUserPermissionResponse;
import tr.com.allianz.ekgb.model.idm.IDMAuthorizationResponse;
import tr.com.allianz.ekgb.model.idm.IDMUserPermissionRequest;
import tr.com.allianz.ekgb.exception.IDMException;
import tr.com.allianz.ekgb.security.user.UserProfileInfo;
import tr.com.allianz.ekgb.security.user.UserProfileInfoService;

import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;
@ExtendWith(MockitoExtension.class)
@PrepareForTest(IDMServiceImpl.class)
public class IDMServiceTest {

    @InjectMocks
    private IDMServiceImpl idmService;

    @Mock
    private UserProfileInfoService userProfileInfoService;

    @Mock
    private RestTemplate restTemplate;

    private final String host = "http://int-uat-pmc.allianz.com.tr/";
    private final String aznetUserName = "allianz-ui-permission/users/aznetUserName?identityNo=";
    private final String unified = "allianz-ui-permission/unified";

    @BeforeEach
    public void setUp() {
        ReflectionTestUtils.setField(idmService, "host", "http://int-uat-pmc.allianz.com.tr/");
        ReflectionTestUtils.setField(idmService, "aznetUserName",
                "allianz-ui-permission/users/aznetUserName?identityNo=");
        ReflectionTestUtils.setField(idmService, "unified", "allianz-ui-permission/unified");
    }


    public void getAznetUserName() {
        when(restTemplate.getForObject(host + aznetUserName + "11111111111", String.class)).thenReturn("WMSOYLU");

        assertEquals("WMSOYLU", idmService.getAznetUserName("11111111111"));
    }

    @Test
    public void getAznetUserName_exception() {
        when(restTemplate.getForObject(host + aznetUserName + "11111111111", String.class))
                .thenThrow(IDMException.class);

        assertThrows(Exception.class, () -> {
            idmService.getAznetUserName("11111111111");
        });
    }


    @Test
    public void getUserAuthorization() {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        HttpEntity<IDMUserPermissionRequest> entity = new HttpEntity<>(IDMUserPermissionRequest.builder()
                .pageName("transaction")
                .userName("WSAYDIN")
                .userType("0")
                .build(), headers);

        when(restTemplate.exchange(host + unified, HttpMethod.POST, entity,
                new ParameterizedTypeReference<IDMAuthorizationResponse<IDMUserPermissionResponse>>() {
                })).thenReturn(createIDMAuthorizationResponse());

        when(userProfileInfoService.getUserInfo()).thenReturn(createUserInfo());

        IDMAuthorizationResponse<EkgbUserPermissionResponse> response = idmService
                .getUserAuthorization("transaction");

        assertEquals(response.getData().getFirst().getFieldName(), "transaction");
        assertTrue(response.getData().getFirst().isReadOnly());
        assertTrue(response.getData().getFirst().isVisible());
    }

    @Test
    public void getUserAuthorization_exception() {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        IDMUserPermissionRequest idmUserPermissionRequest = IDMUserPermissionRequest.builder()
                .pageName("transaction").userName("WSAYDIN").userType("0").build();
        HttpEntity<IDMUserPermissionRequest> entity = new HttpEntity<>(idmUserPermissionRequest, headers);

        when(userProfileInfoService.getUserInfo()).thenReturn(createUserInfo());
        when(restTemplate.exchange(host + unified, HttpMethod.POST, entity,
                new ParameterizedTypeReference<IDMAuthorizationResponse<IDMUserPermissionResponse>>() {
                })).thenThrow(IDMException.class);

        assertThrows(IDMException.class, () -> {
            idmService.getUserAuthorization("transaction");
        });
    }

    private ResponseEntity<IDMAuthorizationResponse<IDMUserPermissionResponse>> createIDMAuthorizationResponse() {
        return ResponseEntity.ok(new IDMAuthorizationResponse<>(createEkgbPermissionList()));
    }

    private List<IDMUserPermissionResponse> createEkgbPermissionList() {
        return Collections.singletonList(IDMUserPermissionResponse.builder()
                .fieldName("transaction")
                .readOnly(1)
                .visible(1)
                .build());
    }

    private UserProfileInfo createUserInfo() {
        UserProfileInfo userProfileInfo = new UserProfileInfo();
        userProfileInfo.setUserName("WSAYDIN");
        userProfileInfo.setUserType("0");
        /*
        userProfileInfo.setName("");
        userProfileInfo.setAgentIntId(0);
        userProfileInfo.setAgencyCode("");
        userProfileInfo.setAgencyTitle("");
        userProfileInfo.setSubAgent("");
        userProfileInfo.setSubAgentCode("");
        userProfileInfo.setSubAgentTitle("");
        userProfileInfo.setSalesPersonEmpId("");
        userProfileInfo.setBgdUser("");
        userProfileInfo.setUwUser("");
        userProfileInfo.setUserType("");
        userProfileInfo.setIsIndustrialUser(0);
*/
        return userProfileInfo;
    }
}

