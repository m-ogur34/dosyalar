package tr.com.allianz.ekgb.controller;


import tools.jackson.core.type.TypeReference;
import tools.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import tr.com.allianz.ekgb.model.idm.EkgbUserPermissionResponse;
import tr.com.allianz.ekgb.model.idm.IDMAuthorizationResponse;
import tr.com.allianz.ekgb.service.idm.IDMService;


import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)
public class AuthorizationControllerTest {

    private static final String AUTHENTICATION_ENDPOINT = "/authorization/";

    private MockMvc mvc;

    private ObjectMapper objectMapper;

    @Mock
    private IDMService idmService;

    @BeforeEach
    public void setUp() {
        objectMapper = new ObjectMapper();
        mvc = MockMvcBuilders
                .standaloneSetup(new AuthorizationController(idmService))
                .build();
    }

    @Test
    public void getUserAuthorization() throws Exception {
        given(idmService.getUserAuthorization(anyString())).willReturn(createAllexPermissionResponse());

        MvcResult mvcResult = mvc.perform(get(AUTHENTICATION_ENDPOINT + "?pageName=transaction-pool")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String contentAsString = mvcResult.getResponse().getContentAsString();
        IDMAuthorizationResponse<EkgbUserPermissionResponse> response = objectMapper.readValue(contentAsString, new TypeReference<IDMAuthorizationResponse<EkgbUserPermissionResponse>>() {
        });

        assertEquals(response.getData().getFirst().getFieldName(), "transaction-pool");
        assertEquals(response.getData().getFirst().isReadOnly(), true);
        assertEquals(response.getData().getFirst().isVisible(), true);

        verify(idmService, times(1)).getUserAuthorization(anyString());
    }

    private IDMAuthorizationResponse<EkgbUserPermissionResponse>  createAllexPermissionResponse() {
        return new IDMAuthorizationResponse<>(createAllexPermissionList());
    }

    private List<EkgbUserPermissionResponse>  createAllexPermissionList() {
        return Arrays.asList(EkgbUserPermissionResponse.builder()
                .fieldName("transaction-pool")
                .readOnly(true)
                .visible(true)
                .build());
    }
}