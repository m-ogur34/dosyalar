package tr.com.allianz.ekgb.service.security;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.springframework.mock.web.MockFilterChain;
import org.springframework.mock.web.MockFilterConfig;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import tr.com.allianz.ekgb.security.JwtPreCasFilter;

import jakarta.servlet.*;
import java.io.IOException;

@ExtendWith(MockitoExtension.class)
@PrepareForTest(value = JwtPreCasFilter.class)
public class JWTPreCasFilterTest {

    @InjectMocks
    private JwtPreCasFilter jwtPreCasFilter;

    @Test
    public void testInit() {
        FilterConfig filterConfig = new MockFilterConfig();
        jwtPreCasFilter.init(filterConfig);
    }

    @Test
    public void testDestroy() {
        jwtPreCasFilter.destroy();
    }

    @Test
    public void testDoFilter() throws ServletException, IOException {
        ServletRequest request = new MockHttpServletRequest();
        ServletResponse response = new MockHttpServletResponse();
        FilterChain chain = new MockFilterChain();

        jwtPreCasFilter.doFilter(request, response, chain);
    }
}