package tr.com.allianz.ekgb.service;

import com.cs.csap.service.SigortaKomisyonWebService;
import org.apache.cxf.jaxws.JaxWsProxyFactoryBean;
import org.junit.Before;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.springframework.core.env.Environment;
import tr.com.allianz.ekgb.entity.Commission;
import tr.com.cs.uut.earsiv.service.Belge;
import tr.com.cs.uut.earsiv.service.BelgeDTO;
import tr.com.cs.uut.earsiv.service.EarsivServiceResult;

import java.util.List;

import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@PrepareForTest(EkgbGibServiceImpl.class)
public class EkgbGibServiceTest {

    @InjectMocks
    private EkgbGibServiceImpl ekgbGibServiceImpl;

    @Mock
    private SigortaKomisyonWebService ekgbGibServiceQNB;

    @Mock
    private  Environment env;


    @Test
    public void sigortaKomisyonOlustur_Success() {
        ekgbGibServiceImpl.ekgbGibService = Mockito.mock(SigortaKomisyonWebService.class);
        when(ekgbGibServiceImpl.ekgbGibService.sigortaKomisyonOlustur(anyString(), any(), any())).thenReturn(null);
        ekgbGibServiceImpl.sigortaKomisyonOlustur(anyString(), any(), any());
        verify(ekgbGibServiceImpl.ekgbGibService,times(1)).sigortaKomisyonOlustur(anyString(), any(), any());
    }

    @Test
    public void sigortaKomisyonSorgula_Success() {
        ekgbGibServiceImpl.ekgbGibService = Mockito.mock(SigortaKomisyonWebService.class);
        when(ekgbGibServiceImpl.ekgbGibService.sigortaKomisyonSorgula(anyString(), any())).thenReturn(null);
        ekgbGibServiceImpl.sigortaKomisyonSorgula(anyString(), any());
        verify(ekgbGibServiceImpl.ekgbGibService,times(1)).sigortaKomisyonSorgula(anyString(), any());
    }


    @Test
    public void sigortaKomisyonIptalEt_Success() {
        ekgbGibServiceImpl.ekgbGibService = Mockito.mock(SigortaKomisyonWebService.class);
        when(ekgbGibServiceImpl.ekgbGibService.sigortaKomisyonIptalEt(anyString())).thenReturn(null);
        ekgbGibServiceImpl.sigortaKomisyonIptalEt(anyString());
        verify(ekgbGibServiceImpl.ekgbGibService,times(1)).sigortaKomisyonIptalEt(anyString());
    }

    @Test
    public void sigortaKomisyonListe_Success() {
        ekgbGibServiceImpl.ekgbGibService = Mockito.mock(SigortaKomisyonWebService.class);
        when(ekgbGibServiceImpl.ekgbGibService.sigortaKomisyonListeSorgula(anyString(),any())).thenReturn(null);
        ekgbGibServiceImpl.sigortaKomisyonListe(anyString(),any());
        verify(ekgbGibServiceImpl.ekgbGibService,times(1)).sigortaKomisyonListeSorgula(anyString(),any());
    }

    @Test
    public void createProxy_Success() {
        Assertions.assertNull(ekgbGibServiceImpl.ekgbGibService);
        ekgbGibServiceImpl.createProxy();
        Assertions.assertNotNull(ekgbGibServiceImpl.ekgbGibService);
    }




}
