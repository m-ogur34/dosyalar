package tr.com.allianz.ekgb.service.xls;

import com.cs.csap.service.SigortaKomisyonWebService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.EnumSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.springframework.core.env.Environment;
import tr.com.allianz.ekgb.entity.enums.AllianzCompany;
import tr.com.allianz.ekgb.entity.enums.GibStatus;
import tr.com.allianz.ekgb.entity.enums.KepStatus;
import tr.com.allianz.ekgb.model.*;
import tr.com.allianz.ekgb.service.CommissionService;
import tr.com.allianz.ekgb.service.EkgbGibServiceImpl;
import tr.com.allianz.ekgb.util.EkgbConstants;

import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@PrepareForTest(CommissionXLSServiceImpl.class)
public class CommissionXLSServiceTest {

    @InjectMocks
    private CommissionXLSServiceImpl commissionXLSService;


    @Mock
    private CommissionService commissionService;


    @Test
    public void createCommissionXLS_Success() {
        List<CommissionXlsDto> commissions = new ArrayList<>();
        CommissionXlsDto CommissionXlsDto = new CommissionXlsDto();
        CommissionXlsDto.setAgency(100);
        CommissionXlsDto.setCompany(AllianzCompany.ALLIANZ_SIGORTA.getValue());
        CommissionXlsDto.setMonth(1);
        CommissionXlsDto.setYear(2024);

        CommissionXlsDto.setAgencyTaxOffice("TaxOffice");
        CommissionXlsDto.setAgencyTaxNo("1234567890");
        CommissionXlsDto.setAgencyAddress("Address");
        CommissionXlsDto.setAgencyTitle("Title");

        CommissionXlsDto.setKepAddress("Kep Address");

        CommissionXlsDto.setProductionAmountABS(new BigDecimal(1111));
        CommissionXlsDto.setProductionAmountMAGIC(new BigDecimal(1111));
        CommissionXlsDto.setProductionAmountOPUS(new BigDecimal(1111));
        CommissionXlsDto.setProductionAmountABS(new BigDecimal(1111));
        CommissionXlsDto.setTotalProductionAmount(new BigDecimal(1111));

        CommissionXlsDto.setCancelAmountABS(new BigDecimal(1111));
        CommissionXlsDto.setCancelAmountMAGIC(new BigDecimal(1111));
        CommissionXlsDto.setCancelAmountOPUS(new BigDecimal(1111));
        CommissionXlsDto.setCancelAmountABS(new BigDecimal(1111));
        CommissionXlsDto.setTotalCancelAmount(new BigDecimal(1111));

        CommissionXlsDto.setGibStatusId(GibStatus.KAYDEDILDI.getValue());
        CommissionXlsDto.setKepStatusId(KepStatus.GONDERILDI.getValue());

        CommissionXlsDto.setRecordCancelDate(LocalDateTime.now());

        commissions.add(CommissionXlsDto);

        when(commissionService.getFilteredCommissions(any())).thenReturn(commissions);


        try {
            byte[] result = commissionXLSService.createCommissionXLS(any());
            Assertions.assertTrue(result.length>0);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }


    }




    @Test
    public void createGibCommissionXLS_Success() {

        EkgbPeriod ekgbPeriod = new EkgbPeriod();
        ekgbPeriod.setYear(2024);
        ekgbPeriod.setMonth(1);

        LocalDate startDate = LocalDate.of(ekgbPeriod.getYear(), ekgbPeriod.getMonth(), 1);
        LocalDate endDate = startDate.plusMonths(1).minusDays(1);


        List<GibEkgbListItem> commissions = new ArrayList<>();
        GibEkgbListItem gibEkgbListItem = new GibEkgbListItem();

        gibEkgbListItem.setCompany(AllianzCompany.YASAM_EMEKLILIK.getValue());
        gibEkgbListItem.setReceiverContact("ReceiverContact");
        gibEkgbListItem.setReceiverName("ReceiverName");
        gibEkgbListItem.setIssueDate("20240101");
        gibEkgbListItem.setBelgeNo("BelgeNo");
        gibEkgbListItem.setIslemId("IslemId");
        gibEkgbListItem.setIstihsalKomisyonu(new BigDecimal(1));
        gibEkgbListItem.setIptalKomisyonu(new BigDecimal(0));
        gibEkgbListItem.setIptalTarihi("20240101");
        gibEkgbListItem.setCreationTime("20240101");

        commissions.add(gibEkgbListItem);


        ResponseBaseContract getCommissionListRemoteByDateResponse = new ResponseBase();
        getCommissionListRemoteByDateResponse.setStatus(ResponseMessageStatus.SUCCESS);
        getCommissionListRemoteByDateResponse.setData(commissions);
        getCommissionListRemoteByDateResponse.setMessage(null);

        when(commissionService.getCommissionListRemoteByDate("AZS", startDate, endDate)).thenReturn(getCommissionListRemoteByDateResponse);
       /*
        when(commissionService.getCommissionListRemoteByDate("HE", startDate, endDate)).thenReturn(getCommissionListRemoteByDateResponse);
        when(commissionService.getCommissionListRemoteByDate("YE", startDate, endDate)).thenReturn(getCommissionListRemoteByDateResponse);
*/

        try {
            byte[] result = commissionXLSService.createGibCommissionXLS(ekgbPeriod);
            Assertions.assertTrue(result.length>0);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }


    }


    @Test
    public void createGibCommissionXLS_FailsAZS() {

        EkgbPeriod ekgbPeriod = new EkgbPeriod();
        ekgbPeriod.setYear(2024);
        ekgbPeriod.setMonth(1);

        LocalDate startDate = LocalDate.of(ekgbPeriod.getYear(), ekgbPeriod.getMonth(), 1);
        LocalDate endDate = startDate.plusMonths(1).minusDays(1);


        List<GibEkgbListItem> commissions = new ArrayList<>();
        GibEkgbListItem gibEkgbListItem = new GibEkgbListItem();

        gibEkgbListItem.setCompany(AllianzCompany.YASAM_EMEKLILIK.getValue());
        gibEkgbListItem.setReceiverContact("ReceiverContact");
        gibEkgbListItem.setReceiverName("ReceiverName");
        gibEkgbListItem.setIssueDate("20240101");
        gibEkgbListItem.setBelgeNo("BelgeNo");
        gibEkgbListItem.setIslemId("IslemId");
        gibEkgbListItem.setIstihsalKomisyonu(new BigDecimal(1));
        gibEkgbListItem.setIptalKomisyonu(new BigDecimal(0));
        gibEkgbListItem.setIptalTarihi("20240101");
        gibEkgbListItem.setCreationTime("20240101");

        commissions.add(gibEkgbListItem);


        ResponseBaseContract getCommissionListRemoteByDateResponse = new ResponseBase();
        getCommissionListRemoteByDateResponse.setStatus(ResponseMessageStatus.FAILURE);
        getCommissionListRemoteByDateResponse.setData(commissions);

        ResponseMessage message = new ResponseMessage();
        message.setMessage("Some error");
        message.setCode("001");
        ResponseMessage[] messages = new ResponseMessage[]{message};
        getCommissionListRemoteByDateResponse.setMessage(messages);

        when(commissionService.getCommissionListRemoteByDate("AZS", startDate, endDate)).thenReturn(getCommissionListRemoteByDateResponse);



        try {
            byte[] result = commissionXLSService.createGibCommissionXLS(ekgbPeriod);
            Assertions.assertTrue(result.length==0);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }


    }
/*
    @Test
    public void createGibCommissionXLS_FailsHE() {

        EkgbPeriod ekgbPeriod = new EkgbPeriod();
        ekgbPeriod.setYear(2024);
        ekgbPeriod.setMonth(1);

        LocalDate startDate = LocalDate.of(ekgbPeriod.getYear(), ekgbPeriod.getMonth(), 1);
        LocalDate endDate = startDate.plusMonths(1).minusDays(1);


        List<GibEkgbListItem> commissions = new ArrayList<>();
        GibEkgbListItem gibEkgbListItem = new GibEkgbListItem();

        gibEkgbListItem.setCompany(AllianzCompany.YASAM_EMEKLILIK.getValue());
        gibEkgbListItem.setReceiverContact("ReceiverContact");
        gibEkgbListItem.setReceiverName("ReceiverName");
        gibEkgbListItem.setIssueDate("20240101");
        gibEkgbListItem.setBelgeNo("BelgeNo");
        gibEkgbListItem.setIslemId("IslemId");
        gibEkgbListItem.setIstihsalKomisyonu(new BigDecimal(1));
        gibEkgbListItem.setIptalKomisyonu(new BigDecimal(0));
        gibEkgbListItem.setIptalTarihi("20240101");
        gibEkgbListItem.setCreationTime("20240101");

        commissions.add(gibEkgbListItem);


        ResponseBaseContract getCommissionListRemoteByDateResponseFailure = new ResponseBase();
        getCommissionListRemoteByDateResponseFailure.setStatus(ResponseMessageStatus.FAILURE);
        getCommissionListRemoteByDateResponseFailure.setData(commissions);

        ResponseMessage message = new ResponseMessage();
        message.setMessage("Some error");
        message.setCode("001");
        ResponseMessage[] messages = new ResponseMessage[]{message};
        getCommissionListRemoteByDateResponseFailure.setMessage(messages);


        ResponseBaseContract getCommissionListRemoteByDateResponseSuccess = new ResponseBase();
        getCommissionListRemoteByDateResponseSuccess.setStatus(ResponseMessageStatus.SUCCESS);
        getCommissionListRemoteByDateResponseSuccess.setData(commissions);

        when(commissionService.getCommissionListRemoteByDate("HE", startDate, endDate)).thenReturn(getCommissionListRemoteByDateResponseFailure);
        when(commissionService.getCommissionListRemoteByDate("AZS", startDate, endDate)).thenReturn(getCommissionListRemoteByDateResponseSuccess);




        try {
            byte[] result = commissionXLSService.createGibCommissionXLS(ekgbPeriod);
            Assertions.assertTrue(result.length==0);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }


    }


    @Test
    public void createGibCommissionXLS_FailsYE() {

        EkgbPeriod ekgbPeriod = new EkgbPeriod();
        ekgbPeriod.setYear(2024);
        ekgbPeriod.setMonth(1);

        LocalDate startDate = LocalDate.of(ekgbPeriod.getYear(), ekgbPeriod.getMonth(), 1);
        LocalDate endDate = startDate.plusMonths(1).minusDays(1);


        List<GibEkgbListItem> commissions = new ArrayList<>();
        GibEkgbListItem gibEkgbListItem = new GibEkgbListItem();

        gibEkgbListItem.setCompany(AllianzCompany.YASAM_EMEKLILIK.getValue());
        gibEkgbListItem.setReceiverContact("ReceiverContact");
        gibEkgbListItem.setReceiverName("ReceiverName");
        gibEkgbListItem.setIssueDate("20240101");
        gibEkgbListItem.setBelgeNo("BelgeNo");
        gibEkgbListItem.setIslemId("IslemId");
        gibEkgbListItem.setIstihsalKomisyonu(new BigDecimal(1));
        gibEkgbListItem.setIptalKomisyonu(new BigDecimal(0));
        gibEkgbListItem.setIptalTarihi("20240101");
        gibEkgbListItem.setCreationTime("20240101");

        commissions.add(gibEkgbListItem);


        ResponseBaseContract getCommissionListRemoteByDateResponseFailure = new ResponseBase();
        getCommissionListRemoteByDateResponseFailure.setStatus(ResponseMessageStatus.FAILURE);
        getCommissionListRemoteByDateResponseFailure.setData(commissions);

        ResponseMessage message = new ResponseMessage();
        message.setMessage("Some error");
        message.setCode("001");
        ResponseMessage[] messages = new ResponseMessage[]{message};
        getCommissionListRemoteByDateResponseFailure.setMessage(messages);


        ResponseBaseContract getCommissionListRemoteByDateResponseSuccess = new ResponseBase();
        getCommissionListRemoteByDateResponseSuccess.setStatus(ResponseMessageStatus.SUCCESS);
        getCommissionListRemoteByDateResponseSuccess.setData(commissions);


        when(commissionService.getCommissionListRemoteByDate("AZS", startDate, endDate)).thenReturn(getCommissionListRemoteByDateResponseSuccess);
        when(commissionService.getCommissionListRemoteByDate("HE", startDate, endDate)).thenReturn(getCommissionListRemoteByDateResponseSuccess);
        when(commissionService.getCommissionListRemoteByDate("YE", startDate, endDate)).thenReturn(getCommissionListRemoteByDateResponseFailure);



        try {
            byte[] result = commissionXLSService.createGibCommissionXLS(ekgbPeriod);
            Assertions.assertTrue(result.length==0);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }


    }

*/



}
