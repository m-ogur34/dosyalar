package tr.com.allianz.ekgb.service.kep;


import com.cs.csap.service.SigortaKomisyonWebService;
import kepUetsRetrieve.IExchangeService;
import kepUetsRetrieve.OutgoingMailInfo;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.springframework.core.env.Environment;
import tr.com.allianz.ekgb.service.xls.CommissionXLSServiceImpl;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@PrepareForTest(KEPServiceImpl.class)
public class KEPServiceTest {

    @InjectMocks
    private KEPServiceImpl kEPServiceImpl;


    @Mock
    private  Environment env;


    @Test
    public  void createProxy_Success()
    {
        Assertions.assertNull(kEPServiceImpl.kepService);
        kEPServiceImpl.createProxy();
        Assertions.assertNotNull(kEPServiceImpl.kepService);
    }

    @Test
    public  void OutgoingMailResult_Success()
    {
        kEPServiceImpl.kepService = Mockito.mock(IExchangeService.class);
        OutgoingMailInfo outgoingMailInfo=null;
        when(kEPServiceImpl.kepService.sendKepMessage(any())).thenReturn(null);
        kEPServiceImpl.SendMessage(outgoingMailInfo);
        verify(kEPServiceImpl.kepService,times(1)).sendKepMessage(any());
    }


}
