package tr.com.allianz.ekgb.controller;

import tools.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import tr.com.allianz.ekgb.entity.Commission;
import tr.com.allianz.ekgb.entity.EkgbMonth;
import tr.com.allianz.ekgb.model.*;
import tr.com.allianz.ekgb.service.CommissionService;
import tr.com.allianz.ekgb.service.EKGBPartitionedCreateService;
import tr.com.allianz.ekgb.service.KEPSendPartitionedService;
import tr.com.allianz.ekgb.service.xls.CommissionXLSService;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)
@PrepareForTest(CommissionController.class)
public class CommissionControllerTest {
    private static final String COMMISSION_ENDPOINT = "/api/v1/commission/";

    private MockMvc mvc;

    private ObjectMapper objectMapper;

    private static LocalDateTime localDateTime;


    @Mock
    private  CommissionService commissionService;
    @Mock
    private  EKGBPartitionedCreateService eKGBPartitionedCreateService;
    @Mock
    private  KEPSendPartitionedService kEPSendPartitionedService;
    @Mock
    private  CommissionXLSService commissionXLSService;


    @BeforeEach
    public void setUp() {
        objectMapper = new ObjectMapper();
        mvc = MockMvcBuilders
                .standaloneSetup(new CommissionController(commissionService, eKGBPartitionedCreateService,
                        kEPSendPartitionedService, commissionXLSService))
                .build();
        localDateTime = LocalDateTime.now();
    }

    @Test
    public void months_Success() throws Exception {
        //Arrange
        when(commissionService.getAllMonths()).thenReturn(null);
        //Act
        MvcResult mvcResult = mvc.perform(get(COMMISSION_ENDPOINT + "months")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String contentAsString = mvcResult.getResponse().getContentAsString();
        ResponseBaseContract result = objectMapper.readValue(contentAsString,  ResponseBase.class);
        //Assert
        verify(commissionService, times(1)).getAllMonths();
    }

    @Test
    public void collectCommissionMonthData_Success() throws Exception {

        EkgbPeriod ekgbPeriod = new EkgbPeriod();
        ekgbPeriod.setYear(2024);
        ekgbPeriod.setMonth(1);


        ResponseBaseContract  responseBaseContractSuccess = new ResponseBase();
        responseBaseContractSuccess.setStatus( ResponseMessageStatus.SUCCESS);

        when(commissionService.collectCommissionMonthData(anyInt(),anyInt())).thenReturn(responseBaseContractSuccess);

        String requestStr = objectMapper.writeValueAsString(ekgbPeriod);

        //Act
        MvcResult mvcResult = mvc.perform(post(COMMISSION_ENDPOINT + "collectCommissionData")
                        .content(requestStr)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String contentAsString = mvcResult.getResponse().getContentAsString();
        ResponseBaseContract result = objectMapper.readValue(contentAsString,  ResponseBase.class);

        //Assert
        assertEquals(ResponseMessageStatus.SUCCESS,result.getStatus());
    }


    @Test
    public void collectCommissionMonthData_Failure() throws Exception {

        EkgbPeriod ekgbPeriod = new EkgbPeriod();
        ekgbPeriod.setYear(2024);
        ekgbPeriod.setMonth(1);


        ResponseBaseContract  responseBaseContractFailure = new ResponseBase();
        responseBaseContractFailure.setStatus( ResponseMessageStatus.FAILURE);
        responseBaseContractFailure.setMessage(new ResponseMessage[]{new ResponseMessage("ErrorCode","ErrorMessage")} );


        when(commissionService.collectCommissionMonthData(anyInt(),anyInt())).thenReturn(responseBaseContractFailure);

        String requestStr = objectMapper.writeValueAsString(ekgbPeriod);

        //Act
        MvcResult mvcResult = mvc.perform(post(COMMISSION_ENDPOINT + "collectCommissionData")
                        .content(requestStr)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String contentAsString = mvcResult.getResponse().getContentAsString();
        ResponseBaseContract result = objectMapper.readValue(contentAsString,  ResponseBase.class);

        //Assert
        assertEquals(ResponseMessageStatus.FAILURE,result.getStatus());
    }





    @Test
    public void createMonth_Success() throws Exception {

        int year = LocalDate.now().minusMonths(1).getYear();
        int month = LocalDate.now().minusMonths(1).getMonthValue();

        EkgbMonth ekgbMonth = new EkgbMonth();
        ekgbMonth.setYear(year);
        ekgbMonth.setMonth(month);

        EkgbPeriod ekgbPeriod = new EkgbPeriod();
        ekgbPeriod.setYear(year);
        ekgbPeriod.setMonth(month);

        when(commissionService.GetMonth(anyInt(),anyInt())).thenReturn(null);
        when(commissionService.createMonth(year,month)).thenReturn(ekgbMonth);
        String requestStr = objectMapper.writeValueAsString(ekgbPeriod);

        //Act
        MvcResult mvcResult = mvc.perform(post(COMMISSION_ENDPOINT + "createMonth")
                        .content(requestStr)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String contentAsString = mvcResult.getResponse().getContentAsString();
        ResponseBaseContract result = objectMapper.readValue(contentAsString,  ResponseBase.class);

        //Assert
        assertEquals(ResponseMessageStatus.SUCCESS,result.getStatus());
    }

    @Test
    public void createMonth_ExistsMonth() throws Exception {

        int year = LocalDate.now().minusMonths(1).getYear();
        int month = LocalDate.now().minusMonths(1).getMonthValue();

        EkgbMonth ekgbMonth = new EkgbMonth();
        ekgbMonth.setYear(year);
        ekgbMonth.setMonth(month);

        EkgbPeriod ekgbPeriod = new EkgbPeriod();
        ekgbPeriod.setYear(year);
        ekgbPeriod.setMonth(month);

        when(commissionService.GetMonth(anyInt(),anyInt())).thenReturn(ekgbMonth);
        String requestStr = objectMapper.writeValueAsString(ekgbPeriod);

        //Act
        MvcResult mvcResult = mvc.perform(post(COMMISSION_ENDPOINT + "createMonth")
                        .content(requestStr)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String contentAsString = mvcResult.getResponse().getContentAsString();
        ResponseBaseContract result = objectMapper.readValue(contentAsString,  ResponseBase.class);

        //Assert
        assertEquals(ResponseMessageStatus.FAILURE,result.getStatus());
    }

    @Test
    public void createMonth_FutureDateFailure() throws Exception {

        int year = LocalDate.now().minusMonths(1).getYear();
        int month = LocalDate.now().getMonthValue();

        EkgbMonth ekgbMonth = new EkgbMonth();
        ekgbMonth.setYear(year);
        ekgbMonth.setMonth(month);

        EkgbPeriod ekgbPeriod = new EkgbPeriod();
        ekgbPeriod.setYear(year);
        ekgbPeriod.setMonth(month);

        when(commissionService.GetMonth(anyInt(),anyInt())).thenReturn(null);

        String requestStr = objectMapper.writeValueAsString(ekgbPeriod);

        //Act
        MvcResult mvcResult = mvc.perform(post(COMMISSION_ENDPOINT + "createMonth")
                        .content(requestStr)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String contentAsString = mvcResult.getResponse().getContentAsString();
        ResponseBaseContract result = objectMapper.readValue(contentAsString,  ResponseBase.class);

        //Assert
        assertEquals(ResponseMessageStatus.FAILURE,result.getStatus());
    }

    @Test
    public void createMonth_PastDateFailure() throws Exception {

        int year = LocalDate.now().minusMonths(1).getYear();
        int month = LocalDate.now().minusMonths(2).getMonthValue();

        EkgbMonth ekgbMonth = new EkgbMonth();
        ekgbMonth.setYear(year);
        ekgbMonth.setMonth(month);

        EkgbPeriod ekgbPeriod = new EkgbPeriod();
        ekgbPeriod.setYear(year);
        ekgbPeriod.setMonth(month);

        when(commissionService.GetMonth(anyInt(),anyInt())).thenReturn(null);

        String requestStr = objectMapper.writeValueAsString(ekgbPeriod);

        //Act
        MvcResult mvcResult = mvc.perform(post(COMMISSION_ENDPOINT + "createMonth")
                        .content(requestStr)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String contentAsString = mvcResult.getResponse().getContentAsString();
        ResponseBaseContract result = objectMapper.readValue(contentAsString,  ResponseBase.class);

        //Assert
        assertEquals(ResponseMessageStatus.FAILURE,result.getStatus());
    }



    @Test
    public void createEkgb_Success() throws Exception {
        //Arrange
        EkgbCreateRequest ekgbCreateRequest = new EkgbCreateRequest();
        doNothing().when(eKGBPartitionedCreateService).createEkgbPartitioned(any());

        //Act
        String requestStr = objectMapper.writeValueAsString(ekgbCreateRequest);
        MvcResult mvcResult = mvc.perform(post(COMMISSION_ENDPOINT + "createEkgb")
                        .content(requestStr)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String contentAsString = mvcResult.getResponse().getContentAsString();
        ResponseBaseContract result = objectMapper.readValue(contentAsString,  ResponseBase.class);

        //Assert
        assertEquals(ResponseMessageStatus.SUCCESS,result.getStatus());
    }

    @Test
    public void sendKEP_Success() throws Exception {
        //Arrange
        KepSendRequest kepSendRequest = new KepSendRequest();
        doNothing().when(kEPSendPartitionedService).kepSendPartitioned(any());

        //Act
        String requestStr = objectMapper.writeValueAsString(kepSendRequest);
        MvcResult mvcResult = mvc.perform(post(COMMISSION_ENDPOINT + "sendKEP")
                        .content(requestStr)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String contentAsString = mvcResult.getResponse().getContentAsString();
        ResponseBaseContract result = objectMapper.readValue(contentAsString,  ResponseBase.class);

        //Assert
        assertEquals(ResponseMessageStatus.SUCCESS,result.getStatus());
    }

    @Test
    public void getFilteredCommissionIds_Success() throws Exception {
        //Arrange
        FilteredCommissionsRequest filteredCommissionsRequest = new FilteredCommissionsRequest();
        filteredCommissionsRequest.setPage(0);
        filteredCommissionsRequest.setPageSize(10);

        List<Integer> commissionIds = new ArrayList<>();
        commissionIds.add(1);

        when(commissionService.getFilteredCommissionIds(any())).thenReturn(commissionIds);

        //Act
        String requestStr = objectMapper.writeValueAsString(filteredCommissionsRequest);
        MvcResult mvcResult = mvc.perform(post(COMMISSION_ENDPOINT + "filterids")
                        .content(requestStr)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String contentAsString = mvcResult.getResponse().getContentAsString();
        CommissionIdsListGetResponse result = objectMapper.readValue(contentAsString,  CommissionIdsListGetResponse.class);

        //Assert
        assertEquals(ResponseMessageStatus.SUCCESS,result.getStatus());
    }



    @Test
    public void getFilteredCommissions_Success() throws Exception {
        //Arrange
        FilteredCommissionsRequest filteredCommissionsRequest = new FilteredCommissionsRequest();
        filteredCommissionsRequest.setPage(0);
        filteredCommissionsRequest.setPageSize(10);

        List<Commission> commissions = new ArrayList<>();
        Pageable pageable = PageRequest.of(filteredCommissionsRequest.getPage(),
                filteredCommissionsRequest.getPageSize());

        Page<Commission> commissionData =new PageImpl<Commission>(commissions, pageable, 1);

        when(commissionService.getFilteredCommissionsPaged(any())).thenReturn(commissionData);

        //Act
        String requestStr = objectMapper.writeValueAsString(filteredCommissionsRequest);
        MvcResult mvcResult = mvc.perform(post(COMMISSION_ENDPOINT + "filter")
                        .content(requestStr)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String contentAsString = mvcResult.getResponse().getContentAsString();
        CommissionListGetResponse result = objectMapper.readValue(contentAsString,  CommissionListGetResponse.class);

        //Assert
        assertEquals(ResponseMessageStatus.SUCCESS,result.getStatus());
    }


    @Test
    public void getEkgb_Success() throws Exception {
        //Arrange
        long commissionID=1L;
        List<Integer> commissionData =new ArrayList<>();

        Commission commission= new Commission();
        commission.setFilenetDocumentID("1");
        Optional<Commission> opCommission = Optional.of(commission);

        when(commissionService.getCommission(1L)).thenReturn(opCommission);
        when(commissionService.getFilenetDocumentPDF(any())).thenReturn("file data".getBytes());


        //Act
        String requestStr = objectMapper.writeValueAsString(commissionID);
        MvcResult mvcResult = mvc.perform(get(COMMISSION_ENDPOINT + "getEkgb")
                        .queryParam("commissionID","1")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String contentAsString = mvcResult.getResponse().getContentAsString();

        //Assert
        assertTrue(contentAsString.getBytes().length>0);
    }

    @Test
    public void getEkgb_NoCommission() throws Exception {
        //Arrange
        long commissionID=1L;
        List<Integer> commissionData =new ArrayList<>();

        Commission commission= new Commission();
        commission.setFilenetDocumentID("1");
        Optional<Commission> opCommission = Optional.empty();

        when(commissionService.getCommission(1L)).thenReturn(opCommission);

        //Act
        String requestStr = objectMapper.writeValueAsString(commissionID);
        MvcResult mvcResult = mvc.perform(get(COMMISSION_ENDPOINT + "getEkgb")
                        .queryParam("commissionID","1")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String contentAsString = mvcResult.getResponse().getContentAsString();

        //Assert
        assertTrue(contentAsString.getBytes().length==0);
    }


    @Test
    public void cancelEkgb_Success() throws Exception {
        //Arrange
        long commissionID=1L;

        ResponseBaseContract  responseBaseContractSuccess = new ResponseBase();
        responseBaseContractSuccess.setStatus( ResponseMessageStatus.SUCCESS);

        when(commissionService.cancelEkgb(1L)).thenReturn(responseBaseContractSuccess);

        //Act
        String requestStr = objectMapper.writeValueAsString(commissionID);
        MvcResult mvcResult = mvc.perform(get(COMMISSION_ENDPOINT + "cancelEkgb")
                        .queryParam("commissionID","1")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String contentAsString = mvcResult.getResponse().getContentAsString();
        ResponseBaseContract result = objectMapper.readValue(contentAsString,  ResponseBase.class);

        //Assert
        assertEquals(ResponseMessageStatus.SUCCESS, result.getStatus());
    }

    @Test
    public void cancelEkgb_NoCommission() throws Exception {
        //Arrange
        long commissionID=1L;

        ResponseBaseContract  responseBaseContractFailure = new ResponseBase();
        responseBaseContractFailure.setStatus( ResponseMessageStatus.FAILURE);
        responseBaseContractFailure.setMessage(new ResponseMessage[]{new ResponseMessage("ErrorCode","ErrorMessage")} );


        when(commissionService.cancelEkgb(1L)).thenReturn(responseBaseContractFailure);

        //Act
        String requestStr = objectMapper.writeValueAsString(commissionID);
        MvcResult mvcResult = mvc.perform(get(COMMISSION_ENDPOINT + "cancelEkgb")
                        .queryParam("commissionID","1")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String contentAsString = mvcResult.getResponse().getContentAsString();
        ResponseBaseContract result = objectMapper.readValue(contentAsString,  ResponseBase.class);
        //Assert
        assertEquals(ResponseMessageStatus.FAILURE, result.getStatus());
    }


    @Test
    public void filteredCommissionsExcel_Success() throws Exception {
        //Arrange
        //Arrange
        FilteredCommissionsRequest filteredCommissionsRequest = new FilteredCommissionsRequest();
        filteredCommissionsRequest.setPage(0);
        filteredCommissionsRequest.setPageSize(10);

        when(commissionXLSService.createCommissionXLS(any())).thenReturn("file data".getBytes());

        //Act
        String requestStr = objectMapper.writeValueAsString(filteredCommissionsRequest);
        MvcResult mvcResult = mvc.perform(post(COMMISSION_ENDPOINT + "filteredExcel")
                        .content(requestStr)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String contentAsString = mvcResult.getResponse().getContentAsString();

        //Assert
        assertTrue(contentAsString.getBytes().length>0);
    }

    @Test
    public void filteredCommissionsExcel_Exception() throws Exception {
        //Arrange
        //Arrange
        FilteredCommissionsRequest filteredCommissionsRequest = new FilteredCommissionsRequest();
        filteredCommissionsRequest.setPage(0);
        filteredCommissionsRequest.setPageSize(10);

        when(commissionXLSService.createCommissionXLS(any())).thenThrow(new IOException());

        //Act
        String requestStr = objectMapper.writeValueAsString(filteredCommissionsRequest);
        MvcResult mvcResult = mvc.perform(post(COMMISSION_ENDPOINT + "filteredExcel")
                        .content(requestStr)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String contentAsString = mvcResult.getResponse().getContentAsString();

        //Assert
        assertTrue(contentAsString.getBytes().length==0);
    }





    @Test
    public void gibKgbExcel_Success() throws Exception {
        //Arrange
        EkgbPeriod ekgbPeriod = new EkgbPeriod();
        ekgbPeriod.setYear(2024);
        ekgbPeriod.setMonth(1);

        when(commissionXLSService.createGibCommissionXLS(any())).thenReturn("file data".getBytes());

        //Act
        String requestStr = objectMapper.writeValueAsString(ekgbPeriod);
        MvcResult mvcResult = mvc.perform(post(COMMISSION_ENDPOINT + "gibKgbExcel")
                        .content(requestStr)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String contentAsString = mvcResult.getResponse().getContentAsString();

        //Assert
        assertTrue(contentAsString.getBytes().length>0);
    }


    @Test
    public void gibKgbExcel_Exception() throws Exception {

        //Arrange
        EkgbPeriod ekgbPeriod = new EkgbPeriod();
        ekgbPeriod.setYear(2024);
        ekgbPeriod.setMonth(1);

        when(commissionXLSService.createGibCommissionXLS(any())).thenThrow(new IOException());

        //Act
        String requestStr = objectMapper.writeValueAsString(ekgbPeriod);
        MvcResult mvcResult = mvc.perform(post(COMMISSION_ENDPOINT + "gibKgbExcel")
                        .content(requestStr)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String contentAsString = mvcResult.getResponse().getContentAsString();
        //Assert
        assertTrue(contentAsString.getBytes().length==0);
    }


    @Test
    public void openMonth_Success() throws Exception {
        //Arrange
        EkgbPeriod ekgbPeriod = new EkgbPeriod();
        ekgbPeriod.setYear(2024);
        ekgbPeriod.setMonth(1);

        ResponseBaseContract  responseBaseContractSuccess = new ResponseBase();
        responseBaseContractSuccess.setStatus( ResponseMessageStatus.SUCCESS);

        when(commissionService.openMonth(anyInt(),anyInt())).thenReturn(responseBaseContractSuccess);

        //Act
        String requestStr = objectMapper.writeValueAsString(ekgbPeriod);
        MvcResult mvcResult = mvc.perform(post(COMMISSION_ENDPOINT + "openMonth")
                        .content(requestStr)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String contentAsString = mvcResult.getResponse().getContentAsString();
        ResponseBaseContract result = objectMapper.readValue(contentAsString,  ResponseBase.class);
        //Assert
        assertEquals(ResponseMessageStatus.SUCCESS, result.getStatus());
    }

    @Test
    public void openMonth_Failure() throws Exception {
        //Arrange
        EkgbPeriod ekgbPeriod = new EkgbPeriod();
        ekgbPeriod.setYear(2024);
        ekgbPeriod.setMonth(1);

        ResponseBaseContract  responseBaseContractFailure = new ResponseBase();
        responseBaseContractFailure.setStatus( ResponseMessageStatus.FAILURE);
        responseBaseContractFailure.setMessage(new ResponseMessage[]{new ResponseMessage("ErrorCode","ErrorMessage")} );


        when(commissionService.openMonth(anyInt(),anyInt())).thenReturn(responseBaseContractFailure);

        //Act
        String requestStr = objectMapper.writeValueAsString(ekgbPeriod);
        MvcResult mvcResult = mvc.perform(post(COMMISSION_ENDPOINT + "openMonth")
                        .content(requestStr)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String contentAsString = mvcResult.getResponse().getContentAsString();
        ResponseBaseContract result = objectMapper.readValue(contentAsString,  ResponseBase.class);
        //Assert
        assertEquals(ResponseMessageStatus.FAILURE, result.getStatus());
    }



    @Test
    public void closeMonth_Success() throws Exception {
        //Arrange
        EkgbPeriod ekgbPeriod = new EkgbPeriod();
        ekgbPeriod.setYear(2024);
        ekgbPeriod.setMonth(1);

        ResponseBaseContract  responseBaseContractSuccess = new ResponseBase();
        responseBaseContractSuccess.setStatus( ResponseMessageStatus.SUCCESS);

        when(commissionService.closeMonth(anyInt(),anyInt())).thenReturn(responseBaseContractSuccess);

        //Act
        String requestStr = objectMapper.writeValueAsString(ekgbPeriod);
        MvcResult mvcResult = mvc.perform(post(COMMISSION_ENDPOINT + "closeMonth")
                        .content(requestStr)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String contentAsString = mvcResult.getResponse().getContentAsString();
        ResponseBaseContract result = objectMapper.readValue(contentAsString,  ResponseBase.class);
        //Assert
        assertEquals(ResponseMessageStatus.SUCCESS, result.getStatus());
    }

    @Test
    public void closeMonth_Failure() throws Exception {
        //Arrange
        EkgbPeriod ekgbPeriod = new EkgbPeriod();
        ekgbPeriod.setYear(2024);
        ekgbPeriod.setMonth(1);

        ResponseBaseContract  responseBaseContractFailure = new ResponseBase();
        responseBaseContractFailure.setStatus( ResponseMessageStatus.FAILURE);
        responseBaseContractFailure.setMessage(new ResponseMessage[]{new ResponseMessage("ErrorCode","ErrorMessage")} );


        when(commissionService.closeMonth(anyInt(),anyInt())).thenReturn(responseBaseContractFailure);

        //Act
        String requestStr = objectMapper.writeValueAsString(ekgbPeriod);
        MvcResult mvcResult = mvc.perform(post(COMMISSION_ENDPOINT + "closeMonth")
                        .content(requestStr)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String contentAsString = mvcResult.getResponse().getContentAsString();
        ResponseBaseContract result = objectMapper.readValue(contentAsString,  ResponseBase.class);
        //Assert
        assertEquals(ResponseMessageStatus.FAILURE, result.getStatus());
    }

    @Test
    public void cleanError_Success() throws Exception {
        //Arrange
        EkgbPeriod ekgbPeriod = new EkgbPeriod();
        ekgbPeriod.setYear(2024);
        ekgbPeriod.setMonth(1);

        ResponseBaseContract  responseBaseContractSuccess = new ResponseBase();
        responseBaseContractSuccess.setStatus( ResponseMessageStatus.SUCCESS);

        when(commissionService.cleanError(anyInt(),anyInt())).thenReturn(responseBaseContractSuccess);

        //Act
        String requestStr = objectMapper.writeValueAsString(ekgbPeriod);
        MvcResult mvcResult = mvc.perform(post(COMMISSION_ENDPOINT + "cleanError")
                        .content(requestStr)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String contentAsString = mvcResult.getResponse().getContentAsString();
        ResponseBaseContract result = objectMapper.readValue(contentAsString,  ResponseBase.class);
        //Assert
        assertEquals(ResponseMessageStatus.SUCCESS, result.getStatus());
    }

    @Test
    public void cleanError_Failure() throws Exception {
        //Arrange
        EkgbPeriod ekgbPeriod = new EkgbPeriod();
        ekgbPeriod.setYear(2024);
        ekgbPeriod.setMonth(1);

        ResponseBaseContract  responseBaseContractFailure = new ResponseBase();
        responseBaseContractFailure.setStatus( ResponseMessageStatus.FAILURE);
        responseBaseContractFailure.setMessage(new ResponseMessage[]{new ResponseMessage("ErrorCode","ErrorMessage")} );


        when(commissionService.cleanError(anyInt(),anyInt())).thenReturn(responseBaseContractFailure);

        //Act
        String requestStr = objectMapper.writeValueAsString(ekgbPeriod);
        MvcResult mvcResult = mvc.perform(post(COMMISSION_ENDPOINT + "cleanError")
                        .content(requestStr)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        String contentAsString = mvcResult.getResponse().getContentAsString();
        ResponseBaseContract result = objectMapper.readValue(contentAsString,  ResponseBase.class);
        //Assert
        assertEquals(ResponseMessageStatus.FAILURE, result.getStatus());
    }


}
