package tr.com.allianz.ekgb.regression;

import org.junit.jupiter.api.Test;
import tr.com.allianz.ekgb.util.UtilDate;

import java.time.LocalDate;
import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class UtilDateRegressionTest {

    @Test
    public void toInteger_ConvertsLocalDateToNumericFormat() {
        LocalDate date = LocalDate.of(2026, 9, 26);
        int result = UtilDate.ToInteger(date);
        assertEquals(20260926, result);

        LocalDate newYear = LocalDate.of(2025, 1, 1);
        assertEquals(20250101, UtilDate.ToInteger(newYear));
    }

    @Test
    public void toEkgbDate_FormatsLocalDateTimeToHyphenatedDate() {
        LocalDateTime dateTime = LocalDateTime.of(2026, 9, 26, 15, 45, 30);
        String formatted = UtilDate.ToEkgbDate(dateTime);
        assertEquals("2026-09-26", formatted);
    }

    @Test
    public void toEkgbTime_FormatsLocalDateTimeToTime() {
        LocalDateTime dateTime = LocalDateTime.of(2026, 9, 26, 15, 45, 30);
        String formatted = UtilDate.ToEkgbTime(dateTime);
        assertEquals("15:45:30", formatted);
    }

    @Test
    public void month_ReturnsCorrectTurkishMonthNames() {
        assertEquals("Ocak", UtilDate.Month(1));
        assertEquals("Şubat", UtilDate.Month(2));
        assertEquals("Mart", UtilDate.Month(3));
        assertEquals("Nisan", UtilDate.Month(4));
        assertEquals("Mayıs", UtilDate.Month(5));
        assertEquals("Haziran", UtilDate.Month(6));
        assertEquals("Temmuz", UtilDate.Month(7));
        assertEquals("Ağustos", UtilDate.Month(8));
        assertEquals("Eylül", UtilDate.Month(9));
        assertEquals("Ekim", UtilDate.Month(10));
        assertEquals("Kasım", UtilDate.Month(11));
        assertEquals("Aralık", UtilDate.Month(12));
    }

    @Test
    public void month_OutOfBoundsThrowsException() {
        assertThrows(ArrayIndexOutOfBoundsException.class, () -> UtilDate.Month(0));
        assertThrows(ArrayIndexOutOfBoundsException.class, () -> UtilDate.Month(13));
    }
}