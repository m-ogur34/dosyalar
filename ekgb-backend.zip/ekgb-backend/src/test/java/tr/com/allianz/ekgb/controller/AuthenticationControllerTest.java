package tr.com.allianz.ekgb.controller;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import tr.com.allianz.ekgb.security.user.UserProfileInfoService;


import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.redirectedUrl;

@ExtendWith(MockitoExtension.class)
public class AuthenticationControllerTest {

    private static final String AUTHENTICATION_ENDPOINT = "/authentication/";

    private MockMvc mvc;

    @Value("${ui.url}")
    private String UI_URL;

    @Value("${ui.local}")
    private String UI_LOCAL;

    @Mock
    private UserProfileInfoService userProfileInfoService;

    @BeforeEach
    public void setUp() {
        mvc = MockMvcBuilders
                .standaloneSetup(new AuthenticationController(UI_URL, UI_LOCAL, userProfileInfoService))
                .build();
    }

    @Test
    public void successHandler() throws Exception {
        given(userProfileInfoService.getJwtToken()).willReturn("tokenInfo");

        mvc.perform(get(AUTHENTICATION_ENDPOINT + "success/**"))
                .andExpect(redirectedUrl(UI_URL + "**" + "#token=tokenInfo"));
    }

    @Test
    public void successHandler_local() throws Exception {
        given(userProfileInfoService.getJwtToken()).willReturn("tokenInfo");

        mvc.perform(get(AUTHENTICATION_ENDPOINT + "success/local"))
                .andExpect(redirectedUrl(UI_LOCAL + "#token=tokenInfo"));
    }
}