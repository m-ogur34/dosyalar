package tr.com.allianz.ekgb.model.idm;


import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EkgbUserPermissionResponse {

    @Schema(description = "Field name")
    private String fieldName;

    @Schema(description = "Is read only?")
    private boolean readOnly;

    @Schema(description = "Is visible?")
    private boolean visible;
}
