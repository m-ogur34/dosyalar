package tr.com.allianz.ekgb.config;



import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.restclient.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.util.AntPathMatcher;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.config.annotation.AsyncSupportConfigurer;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import java.time.Duration;



@EnableAsync
@Configuration
public class WebConfig implements WebMvcConfigurer {

	private final int corePoolSize;

	@Autowired
	private CorsProperties corsProperties;

	private static Logger logger = LoggerFactory.getLogger(WebConfig.class);

	public WebConfig(@Value("${app.mvc-async.core-pool-size}") int corePoolSize) {
		this.corePoolSize = corePoolSize;
	}

	/**
	 * Those are the threads which will be used to free Tomcat's nio-XXXX-exec threads that there are 10 of them by default.
	 * See <a href="https://tomcat.apache.org/tomcat-8.5-doc/config/http.html#Standard_Implementation">minSpareThreads value</a>
	 *
	 * @return ThreadPoolTaskExecutor which will be configured to be used as executor for threads started from async servlets
	 * @see AsyncConfig#getAsyncExecutor()
	 */
	@Bean(name = "asyncExecutor")
	ThreadPoolTaskExecutor asyncTaskExecutor() {
		final ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
		executor.setCorePoolSize(corePoolSize);
		executor.setWaitForTasksToCompleteOnShutdown(true);
		executor.setThreadNamePrefix("MvcAsync");// Default name when not customized
		return executor;
	}

	@Override
	public void configureAsyncSupport(AsyncSupportConfigurer configurer) {
		configurer.setTaskExecutor(asyncTaskExecutor());
	}

	@Override
	public void addCorsMappings(CorsRegistry registry) {
		logger.info("*** addCorsMappings *** Domain list:" + StringUtils.join(corsProperties.getDomainList(), ", ") +"   Methods: " + StringUtils.join(corsProperties.getAllowMethod(), ", "));
		registry.addMapping("/**")
				//.allowedOrigins(corsProperties.getDomainList())
				.allowedOriginPatterns(corsProperties.getDomainList())
				.allowedHeaders("*")
				.allowedMethods(corsProperties.getAllowMethod())
				.allowCredentials(true);
	}




	@Bean
	//@Profile({"prod"})
	public RestTemplate restTemplate(RestTemplateBuilder restTemplateBuilder) {
		return restTemplateBuilder
				.connectTimeout(Duration.ofSeconds(4))
				.readTimeout(Duration.ofSeconds(120))
				.build();
	}







	@Bean
	public AntPathMatcher antPathMatcher() {
		return new AntPathMatcher();
	}
	

}
