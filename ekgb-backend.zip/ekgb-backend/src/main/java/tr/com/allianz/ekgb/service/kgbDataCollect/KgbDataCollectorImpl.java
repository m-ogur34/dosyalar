package tr.com.allianz.ekgb.service.kgbDataCollect;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@RequiredArgsConstructor
public class KgbDataCollectorImpl implements KgbDataCollector {

	private final RestTemplate kgbDataRestTemplate;

	@Value("${kgbData.opusHost}")
	private String kgbDataOpusHost;

	@Value("${kgbData.nonOpusHost}")
	private String kgbDataNonOpusHost;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * tr.com.allianz.ekgb.service.kgbDataCollect.KgbDataCollector#getOpusData(tr.
	 * com.allianz.ekgb.service.kgbDataCollect.GetKgbDataInput, int, int)
	 */
	@Override
	@PostMapping(value = "", consumes = "application/json", produces = "application/json")
	public GetKgbDataOutput getOpusData(@RequestBody GetKgbDataInput getKgbDataInput, @RequestParam int page,
			@RequestParam int size) {
		log.info("getOpusData called.");

		GetKgbDataOutput response;

		try {
			String kgbdataOpusHostWQS = kgbDataOpusHost + "api/v1/agency-commission?page=" + page + "&size=" + size;
			response = kgbDataRestTemplate.postForObject(kgbdataOpusHostWQS, getKgbDataInput, GetKgbDataOutput.class);
		} catch (Exception e) {
			log.error("getOpusData error:" + e.getMessage(), e);
			return null;
		}

		return response;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * tr.com.allianz.ekgb.service.kgbDataCollect.KgbDataCollector#getNonOpusData(tr
	 * .com.allianz.ekgb.service.kgbDataCollect.GetKgbDataInput)
	 */
	@Override
	@PostMapping(value = "", consumes = "application/json", produces = "application/json")
	public GetKgbDataNonOpusOutput getNonOpusData(@RequestBody GetKgbDataInput getKgbDataInput) {

		GetKgbDataNonOpusOutput response = null;
		try {
			response = kgbDataRestTemplate.postForObject(kgbDataNonOpusHost, getKgbDataInput,
					GetKgbDataNonOpusOutput.class);
		} catch (Exception e) {
			log.error("getNonOpusData error:" + e.getMessage(), e);
		}
		return response;
	}

}
