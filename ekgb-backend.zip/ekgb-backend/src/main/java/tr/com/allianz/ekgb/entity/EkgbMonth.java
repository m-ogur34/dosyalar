package tr.com.allianz.ekgb.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;

import lombok.Data;

@Entity
@Data
@Table(name = "EKGB_MONTH", schema = "CUSTOMER")
@IdClass(MonthId.class)
public class EkgbMonth {
	@Id
	@Column(name = "YEAR")
	private int year;
	@Id
	@Column(name = "MONTH")
	private int month;
	@Column(name = "STATUS")
	private int status;
	@Column(name = "CURRENT_OPERATION")
	private int currentOperation;
	@Column(name = "AGENCY_COMMISSION_COUNT")
	private Long agencyCommissionCount;
	@Column(name = "AGENCY_ADDRESS_COUNT")
	private Long agencyAddressCount;
	@Column(name = "AGENCY_KEP_COUNT")
	private Long agencyKEPCount;
	@Column(name = "KGB_COUNT")
	private Long kgbCount;
	@Column(name = "KEP_COUNT")
	private Long kepCount;
	@Column(name = "LAST_ERROR")
	private String lastError;
	@Column(name = "LAST_OPERATION")
	private String lastOperation;
	@Column(name = "USERID")
	private String userID;
}
