package tr.com.allianz.ekgb.model;




public class GetAllPeriodsResponse extends ResponseBase implements ResponseBaseContract{

}
