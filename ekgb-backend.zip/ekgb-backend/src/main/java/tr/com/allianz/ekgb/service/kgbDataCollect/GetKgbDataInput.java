package tr.com.allianz.ekgb.service.kgbDataCollect;

import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@RequiredArgsConstructor
public class GetKgbDataInput {
	private String dataSource;
	private Integer year;
	private Integer month;
}
