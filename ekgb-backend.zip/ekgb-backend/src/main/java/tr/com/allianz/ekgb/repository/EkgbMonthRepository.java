package tr.com.allianz.ekgb.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import tr.com.allianz.ekgb.entity.EkgbMonth;
import tr.com.allianz.ekgb.entity.MonthId;
import tr.com.allianz.ekgb.entity.enums.MonthStatus;

@Transactional
public interface EkgbMonthRepository extends JpaRepository<EkgbMonth, MonthId> {

	@Query(value = "SELECT * FROM CUSTOMER.EKGB_MONTH WHERE YEAR = :year AND MONTH = :month", nativeQuery = true)
	EkgbMonth findEkgbMonthByYearMonth(@Param("year") int year, @Param("month") int month);
	
	

	//------------------- Month
	
	
	@Query(value = "SELECT * FROM CUSTOMER.EKGB_MONTH WHERE YEAR = :year AND MONTH = :month " 
			, nativeQuery = true)
	EkgbMonth getMonth(@Param("year") int year, @Param("month") int month);
	
	
	
	@Query(value = "SELECT * FROM CUSTOMER.EKGB_MONTH ORDER BY YEAR DESC, MONTH DESC " 
			, nativeQuery = true)
	List<EkgbMonth> getAllMonths();
	
	
	
	@Modifying
	@Query(value = "INSERT INTO CUSTOMER.EKGB_MONTH " + 
			"(YEAR, MONTH, STATUS, CURRENT_OPERATION, AGENCY_COMMISSION_COUNT, AGENCY_ADDRESS_COUNT, AGENCY_KEP_COUNT, KGB_COUNT, KEP_COUNT )" + 
			"VALUES (:year, :month, 0, 0, 0, 0, 0, 0, 0 )"
			, nativeQuery = true)
	void createMonth(@Param("year") int year, @Param("month") int month);
	
	@Modifying
	@Query(value = "UPDATE CUSTOMER.EKGB_MONTH " + 
			"SET STATUS = :status " + 
			"WHERE YEAR = :year AND MONTH = :month "
			, nativeQuery = true)
	void updateMonthStatus(@Param("year") int year, @Param("month") int month, @Param("status") MonthStatus status);
	
	@Modifying
	@Query(value = "UPDATE CUSTOMER.EKGB_MONTH " + 
			"SET CURRENT_OPERATION = :operation " + 
			"WHERE YEAR = :year AND MONTH = :month "
			, nativeQuery = true)
	void updateMonthCurrentOperation(@Param("year") int year, @Param("month") int month, @Param("operation") int operation);
	
	
	
	@Modifying
	@Query(value = "UPDATE CUSTOMER.EKGB_MONTH " + 
			"SET LAST_OPERATION = :operation " + 
			"WHERE YEAR = :year AND MONTH = :month "
			, nativeQuery = true)
	void updateMonthLastOperation(@Param("year") int year, @Param("month") int month, @Param("operation") String operation);
	
	@Modifying
	@Query(value = "UPDATE CUSTOMER.EKGB_MONTH " + 
			"SET LAST_ERROR = NVL(LAST_ERROR, '')  ||  '### '  ||  :error " + 
			"WHERE YEAR = :year AND MONTH = :month "
			, nativeQuery = true)
	void updateMonthLastError(@Param("year") int year, @Param("month") int month, @Param("error") String error);


	@Modifying
	@Query(value = "UPDATE CUSTOMER.EKGB_MONTH " +
			"SET LAST_ERROR = '' " +
			"WHERE YEAR = :year AND MONTH = :month "
			, nativeQuery = true)
	void cleanMonthError(@Param("year") int year, @Param("month") int month);









	@Modifying
	@Query(value ="UPDATE CUSTOMER.EKGB_MONTH " + 
			"SET " + 
			"AGENCY_COMMISSION_COUNT = (SELECT COUNT(*) FROM CUSTOMER.EKGB_COMMISSION WHERE YEAR = :year AND MONTH = :month)," + 
			"AGENCY_ADDRESS_COUNT = (SELECT COUNT(*) " + 
			"                        FROM CUSTOMER.EKGB_COMMISSION " + 
			"                        WHERE (" + 
			"                             AGENCY_TAX_NO is null " + 
			"                          OR AGENCY_TAX_OFFICE is null " + 
			"                          OR AGENCY_ADDRESS is null " + 
			"                          OR AGENCY_TITLE is null)" + 
			"                        AND YEAR = :year AND MONTH = :month)" + 
			"                        ," + 
			"AGENCY_KEP_COUNT =      (SELECT COUNT(*) FROM CUSTOMER.EKGB_COMMISSION WHERE KEP_ADDRESS IS NOT NULL AND YEAR = :year AND MONTH = :month),                        " + 
			"KGB_COUNT =             (SELECT COUNT(*) FROM CUSTOMER.EKGB_COMMISSION WHERE FILENET_DOCUMENTID IS NOT NULL AND YEAR = :year AND MONTH = :month)," + 
			"KEP_COUNT =             (SELECT COUNT(*) FROM CUSTOMER.EKGB_COMMISSION WHERE KEP_STATUSID = 2 AND YEAR = :year AND MONTH = :month)" +
			"WHERE YEAR = :year AND MONTH = :month"
			, nativeQuery = true)
	void updateMonthStatistics(@Param("year") int year, @Param("month") int month);
	
	@Modifying
	@Query(value ="UPDATE CUSTOMER.EKGB_MONTH " + 
			"SET " + 
			"KGB_COUNT =  (SELECT COUNT(*) FROM CUSTOMER.EKGB_COMMISSION WHERE FILENET_DOCUMENTID IS NOT NULL AND YEAR = :year AND MONTH = :month)" + 
			"WHERE YEAR = :year AND MONTH = :month"
			, nativeQuery = true)
	void updateMonthStatisticsKGB(@Param("year") int year, @Param("month") int month);

	@Modifying
	@Query(value ="UPDATE CUSTOMER.EKGB_MONTH " +
			"SET " +
			"KEP_COUNT =  (SELECT COUNT(*) FROM CUSTOMER.EKGB_COMMISSION WHERE KEP_STATUSID = 2 AND YEAR = :year AND MONTH = :month)" +
			"WHERE YEAR = :year AND MONTH = :month"
			, nativeQuery = true)
	void updateMonthStatisticsKEP(@Param("year") int year, @Param("month") int month);
	
	
	
	
}
