package tr.com.allianz.ekgb.controller;


import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.util.AntPathMatcher;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.HandlerMapping;
import io.swagger.v3.oas.annotations.Hidden;
import tr.com.allianz.ekgb.security.user.UserProfileInfoService;

import jakarta.servlet.http.HttpServletRequest;

@Controller
@RequestMapping("/authentication")
@Hidden
class AuthenticationController {

    @Value("${ui.url}")
    private final String UI_URL;

    @Value("${ui.local}")
    private final String UI_LOCAL;

    private final UserProfileInfoService userProfileInfoService;

    public AuthenticationController(@Value("${ui.url}") String uiUrl, @Value("${ui.local}") String uiLocal, UserProfileInfoService userProfileInfoService) {
        this.UI_URL = uiUrl;
        this.UI_LOCAL = uiLocal;
        this.userProfileInfoService = userProfileInfoService;
    }

    @GetMapping("/success/**")
    public String successHandler(final HttpServletRequest request) {

        final String finalPath = getFinalPath(request);

        final String jwtToken = userProfileInfoService.getJwtToken();
        if (finalPath.equals("local")) {
            return "redirect:" + UI_LOCAL + "#token=" + jwtToken;
        }
        return "redirect:" + UI_URL + finalPath + "#token=" + jwtToken;

    }

    private String getFinalPath(HttpServletRequest request) {

        final String path = (String) request.getAttribute(HandlerMapping.PATH_WITHIN_HANDLER_MAPPING_ATTRIBUTE);
        final String bestMatchPattern = (String) request.getAttribute(HandlerMapping.BEST_MATCHING_PATTERN_ATTRIBUTE);

        return new AntPathMatcher().extractPathWithinPattern(bestMatchPattern, path);
    }

}