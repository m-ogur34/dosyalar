package tr.com.allianz.ekgb.model.idm;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class IDMUserPermissionResponse {

    private String fieldName;
    private Integer readOnly;
    private Integer visible;
}
