package tr.com.allianz.ekgb.service.idm;

import tools.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import tr.com.allianz.ekgb.entity.enums.LogTarget;
import tr.com.allianz.ekgb.exception.IDMException;
import tr.com.allianz.ekgb.model.AznetUserResponse;
import tr.com.allianz.ekgb.model.idm.EkgbUserPermissionResponse;
import tr.com.allianz.ekgb.model.idm.IDMAuthorizationResponse;
import tr.com.allianz.ekgb.model.idm.IDMUserPermissionRequest;
import tr.com.allianz.ekgb.model.idm.IDMUserPermissionResponse;
import tr.com.allianz.ekgb.security.user.UserProfileInfo;
import tr.com.allianz.ekgb.security.user.UserProfileInfoService;
import tr.com.allianz.ekgb.util.ErrorConstants;
import java.util.ArrayList;
import java.util.List;

@RequiredArgsConstructor
@Service
public class IDMServiceImpl implements IDMService {

    @Value("${idm.host}")
    private String host;

    @Value("${idm.aznetUserName}")
    private String aznetUserName;

    @Value("${idm.unified}")
    private String unified;

    @Value("${idm.actionCode}")
    private String actionCode;

    @Value("${idm.endorsementNo}")
    private String endorsementNo;

    @Value("${idm.productId}")
    private Long productId;

    @Value("${idm.projectId}")
    private String projectId;

    private final UserProfileInfoService userProfileInfoService;
    private final RestTemplate restTemplate;

    @Override
    public List<String> getAznetUserName(String identityNo) {
        String userName;
        AznetUserResponse userNames;
        ObjectMapper mapper = new ObjectMapper();
        try {
            userName = restTemplate.getForObject(host + aznetUserName + identityNo, String.class);
            userNames = mapper.readValue(userName, AznetUserResponse.class);
        } catch (Exception e) {
            throw new IDMException(ErrorConstants.IDM_SERVICE_FAILED);
        }

        return userNames.getData();
    }

    @Override
    public IDMAuthorizationResponse<EkgbUserPermissionResponse> getUserAuthorization(String pageName) {
        IDMAuthorizationResponse<IDMUserPermissionResponse> response;
        List<EkgbUserPermissionResponse> ekgbUserPermissionResponseList = new ArrayList<>();
        UserProfileInfo userProfileInfo = userProfileInfoService.getUserInfo();
        IDMUserPermissionRequest request = IDMUserPermissionRequest.builder()
                .actionCode(actionCode)
                .endorsementNo(endorsementNo)
                .pageName(pageName)
                .productId(productId)
                .projectId(projectId)
                .userName(userProfileInfo.getUserName())
                .userType(userProfileInfo.getUserType())
                .build();

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<IDMUserPermissionRequest> entity = new HttpEntity<>(request, headers);
        try {
            response = restTemplate.exchange(host + unified, HttpMethod.POST, entity,
                    new ParameterizedTypeReference<IDMAuthorizationResponse<IDMUserPermissionResponse>>() {}).getBody();
            if (response != null && !CollectionUtils.isEmpty(response.getData())) {
                response.getData().forEach(permission -> {
                    ekgbUserPermissionResponseList.add(EkgbUserPermissionResponse.builder()
                            .fieldName(permission.getFieldName())
                            .readOnly(permission.getReadOnly() == 1)
                            .visible(permission.getVisible() == 1)
                            .build());
                });
            }
        } catch (Exception e) {
            throw new IDMException(ErrorConstants.IDM_SERVICE_FAILED);
        }

        return new IDMAuthorizationResponse<>(ekgbUserPermissionResponseList);
    }
}
