package tr.com.allianz.ekgb.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import tr.com.allianz.ekgb.entity.Commission;
import tr.com.allianz.ekgb.model.EkgbPdfRequest;
import tr.com.allianz.ekgb.model.GetEkgbByCompanyAgencyYearMonthResponse;
import tr.com.allianz.ekgb.model.ResponseBase;
import tr.com.allianz.ekgb.model.ResponseBaseContract;
import tr.com.allianz.ekgb.model.ResponseMessage;
import tr.com.allianz.ekgb.model.ResponseMessageStatus;
import tr.com.allianz.ekgb.service.CommissionService;
import tr.com.allianz.ekgb.util.EkgbConstants;
import tr.com.allianz.ekgb.util.MessageConstants;

@RestController
@RequestMapping("/api/v3/commission")
@RequiredArgsConstructor
@Tag(name = "E-KGB", description = "E-KGB Service")
public class CommissionControllerV3 {

	private final CommissionService commissionService;
	
	@Value("${app.apiKey}")
	private String apiKey;

	@Operation(summary = "Get E-KGB")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully retrieved E-KGB"),
			@ApiResponse(responseCode = "401", description = "You are not authorized to view E-KGB"),
			@ApiResponse(responseCode = "404", description = "The resource you were trying to reach is not found"),
			@ApiResponse(responseCode = "500", description = "Could not retrieve E-KGB") })
	@RequestMapping(value = "/getEkgByCompanyAgencyYearMonth", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseBaseContract> getEkgByCompanyAgencyYearMonth(
			@RequestBody EkgbPdfRequest ekgbPdfRequest) {
		byte[] filenetDocument = null;

			
			if (ekgbPdfRequest.getKey()==null || !ekgbPdfRequest.getKey().equals(apiKey)) {
				return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(ResponseBase.Unauthorized());	
			}
			
			Commission commission = commissionService.getCommissionByAgencyYearMonth(ekgbPdfRequest.getCompany(),
					ekgbPdfRequest.getAgencyCode(), ekgbPdfRequest.getYear(), ekgbPdfRequest.getMonth());
			
			GetEkgbByCompanyAgencyYearMonthResponse getEkgbByCompanyAgencyYearMonthResponse =null;
			//commission not found
			if(commission==null) {
				getEkgbByCompanyAgencyYearMonthResponse = GetEkgbByCompanyAgencyYearMonthResponse
						.builder().responseMessage(new ResponseMessage[] { new ResponseMessage(EkgbConstants.EKGB_COMMISSION_NOTFOUND_CODE, "Komisyon bilgisi bulunamadı.") }).responseMessageStatus(ResponseMessageStatus.SUCCESS).build();
				
				
			}else
			{
				filenetDocument = commissionService.getFilenetDocumentPDF(commission.getFilenetDocumentID());
				//filenetDocument not found
				if(filenetDocument==null) {
					getEkgbByCompanyAgencyYearMonthResponse = GetEkgbByCompanyAgencyYearMonthResponse
							.builder().responseMessage(new ResponseMessage[] { new ResponseMessage(EkgbConstants.EKGB_PDF_NOTFOUND_CODE, "EKGB PDF bilgisi bulunamadı") }).responseMessageStatus(ResponseMessageStatus.SUCCESS).build();
					
				}else {
					getEkgbByCompanyAgencyYearMonthResponse = GetEkgbByCompanyAgencyYearMonthResponse
							.builder().data(filenetDocument).responseMessageStatus(ResponseMessageStatus.SUCCESS).build();	
				}
			}

			return ResponseEntity.ok(getEkgbByCompanyAgencyYearMonthResponse);
			

	}

}
