package tr.com.allianz.ekgb.model;

public class EkgbCreateResponse  extends ResponseBase implements ResponseBaseContract {

}
