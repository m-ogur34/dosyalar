package tr.com.allianz.ekgb.util;

import tr.com.allianz.ekgb.model.CompanyVatNo;

public class EkgbConstants {
	public static final String QNB_RESULT_SUCCESS_CODE = "AE00000";
	public static final String QNB_EKGB_TOTALCOUNT_FIELD = "toplamAdet";
	
	
	public static Integer  OPUS_DATA_SERVICE_PAGESIZE = 5000;
	
	public static final String EKGB_YKE_PARTAJ = "YKBREG1";
	public static final String EKGB_YKE_PARTAJ_NO = "1";
	public static final String EKGB_EMPTY_TAXNO = "0000000000";
	public static final String EKGB_EMPTY_TAXOFFICE = ".";
	public static final String EKGB_EMPTY_ADDRESS = ".";
	public static final String EKGB_EMPTY_TITLE = " ";
	
	
	public static final String MERSISNO_AZS ="0-8000-0132-7000012";
	public static final String MERSISNO_HE = "0-8000-0124-5400015";
	public static final String MERSISNO_YE = "0-4560-0072-4300012";
	
	
	public static final String KEP_OUTGOINGMAILBOX_AZS = "allianzsigorta-erkancelik";
	public static final String KEP_OUTGOINGMAILBOX_HE = "allianzemeklilik-erkancelik";
	public static final String KEP_OUTGOINGMAILBOX_YE = "allianzyasamemeklilik-erkancelik";
	
	public static final String COMMISSION_DATA_SOURCE_AS400 = "AS400";
	public static final String COMMISSION_DATA_SOURCE_MAGIC = "MAGIC";
	public static final String COMMISSION_DATA_SOURCE_ABS = "ABS";
	
	
	public static final String FILENET_CHANNEL = "EKGB";
	public static final String FILENET_CLASSNAME = "doc_Ekgb";
	public static final String FILENET_MIMETYPE = "PDF";
	
	
	public static final String FILENET_PROPERTY_COMPANYCODE = "prp_CompanyCode";
	public static final String FILENET_PROPERTY_AGENCYCODE = "prp_AgencyCode";
	public static final String FILENET_PROPERTY_YEAR = "prp_Year";
	public static final String FILENET_PROPERTY_MONTH= "prp_Month";
	
	public static final String FILENET_DATATYPE_INTEGER= "I";
	public static final String FILENET_DATATYPE_STRING= "S";
	
	
	public static final String EKGB_COMMISSION_NOTFOUND_CODE= "COMMISSION_NOTFOUND";
	public static final String EKGB_PDF_NOTFOUND_CODE= "PDF_NOTFOUND";
	
	
	public static final String EKGB_DOC_ACCOUNTINGSUPPLIERPARTY_PARTY_PARTYNAME_NAME= "#AccountingSupplierParty.Party.PartyName.Name#";
	public static final String EKGB_DOC_ACCOUNTINGSUPPLIERPARTY_PARTY_PARTYIDENTIFICATION_ID= "#AccountingSupplierParty.Party.PartyIdentification.ID#";
	public static final String EKGB_DOC_ACCOUNTINGSUPPLIERPARTY_PARTY_PARTYTAXSCHEME_TAXSCHEME_TAXTYPECODE= "#AccountingSupplierParty.Party.PartyTaxScheme.TaxScheme.TaxTypeCode#";
	public static final String EKGB_DOC_ACCOUNTINGSUPPLIERPARTY_PARTYIDENTIFICATION_MERSISNO= "#AccountingSupplierParty.PartyIdentification.MERSISNO#";
	public static final String EKGB_DOC_BELGESERI= "#BelgeSeri#";
	
	public static final String KEP_DONEMI= " Dönemi";
	
	
}
