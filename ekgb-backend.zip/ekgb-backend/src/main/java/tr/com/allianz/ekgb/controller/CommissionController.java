package tr.com.allianz.ekgb.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import java.io.IOException;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import tr.com.allianz.ekgb.entity.Commission;
import tr.com.allianz.ekgb.entity.EkgbMonth;
import tr.com.allianz.ekgb.model.CancelEkgbResponse;
import tr.com.allianz.ekgb.model.CleanErrorResponse;
import tr.com.allianz.ekgb.model.CloseMonthResponse;
import tr.com.allianz.ekgb.model.CommissionCollectMonthDataResponse;
import tr.com.allianz.ekgb.model.CommissionIdsListGetResponse;
import tr.com.allianz.ekgb.model.CommissionListGetResponse;
import tr.com.allianz.ekgb.model.CreateMonthResponse;
import tr.com.allianz.ekgb.model.EkgbCreateRequest;
import tr.com.allianz.ekgb.model.EkgbCreateResponse;
import tr.com.allianz.ekgb.model.EkgbPeriod;
import tr.com.allianz.ekgb.model.FilteredCommissionsRequest;
import tr.com.allianz.ekgb.model.GetAllPeriodsResponse;
import tr.com.allianz.ekgb.model.GetEkgbMonthResponse;
import tr.com.allianz.ekgb.model.KepSendRequest;
import tr.com.allianz.ekgb.model.KepSendResponse;
import tr.com.allianz.ekgb.model.OpenMonthResponse;
import tr.com.allianz.ekgb.model.ResponseBase;
import tr.com.allianz.ekgb.model.ResponseBaseContract;
import tr.com.allianz.ekgb.model.ResponseMessageStatus;
import tr.com.allianz.ekgb.service.CommissionService;
import tr.com.allianz.ekgb.service.EKGBPartitionedCreateService;
import tr.com.allianz.ekgb.service.KEPSendPartitionedService;
import tr.com.allianz.ekgb.service.xls.CommissionXLSService;
import tr.com.allianz.ekgb.util.MessageConstants;

@RestController
@RequestMapping("/api/v1/commission")

@RequiredArgsConstructor
@Tag(name = "E-KGB", description = "E-KGB API")

public class CommissionController {

	private final CommissionService commissionService;
	private final EKGBPartitionedCreateService eKGBPartitionedCreateService;
	private final KEPSendPartitionedService kEPSendPartitionedService;
	private final CommissionXLSService commissionXLSService;

	@Operation(summary = "Collect Commission Data")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully collected commission data."),
			@ApiResponse(responseCode = "401", description = "You are not authorized to view the resource"),
			@ApiResponse(responseCode = "403", description = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(responseCode = "404", description = "The resource you were trying to reach is not found") })
	@PostMapping(value = { "/collectCommissionData", "" })
	public ResponseEntity<ResponseBaseContract> collectCommissionData(@RequestBody EkgbPeriod ekgbPeriod) {

				ResponseBaseContract cr = commissionService.collectCommissionMonthData(ekgbPeriod.getYear(),
						ekgbPeriod.getMonth());
				if (cr.getStatus() == ResponseMessageStatus.FAILURE) {
					return ResponseEntity.status(HttpStatus.OK)
							.body(CommissionCollectMonthDataResponse.Failure(ResponseBase.getFirstMessage(cr)));
				}
				commissionService.collectCommissionMonthDataAsync(ekgbPeriod.getYear(), ekgbPeriod.getMonth());
				return ResponseEntity.ok(CommissionCollectMonthDataResponse.Success());

	}

	@Operation(summary = "Get all commission months.")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully retrieved months."),
			@ApiResponse(responseCode = "401", description = "You are not authorized to view the resource"),
			@ApiResponse(responseCode = "403", description = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(responseCode = "404", description = "The resource you were trying to reach is not found") })
	@GetMapping(value = { "/months" })
	public ResponseEntity<ResponseBaseContract> getAllMonths() {
			List<EkgbMonth> months = commissionService.getAllMonths();
			return ResponseEntity.ok(GetEkgbMonthResponse.Success(months));
	}

	@Operation(summary = "Create commission month.")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully created month."),
			@ApiResponse(responseCode = "401", description = "You are not authorized to view the resource"),
			@ApiResponse(responseCode = "403", description = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(responseCode = "404", description = "The resource you were trying to reach is not found") })
	@PostMapping(value = { "/createMonth"})
	public ResponseEntity<ResponseBaseContract> createMonth(@RequestBody EkgbPeriod ekgbPeriod) {

				EkgbMonth existingMonth = commissionService.GetMonth(ekgbPeriod.getYear(), ekgbPeriod.getMonth());
				if (existingMonth != null) {
					return ResponseEntity.status(HttpStatus.OK)
							.body(CreateMonthResponse.Failure("Bu yil-ay zaten mevcut!"));
				}

				LocalDate ekgbAy=LocalDate.now().minusMonths(1);
				ekgbAy=LocalDate.of(ekgbAy.getYear(),ekgbAy.getMonth(), 1);

				if (LocalDate.of(ekgbPeriod.getYear(), ekgbPeriod.getMonth(),1).isAfter(ekgbAy) ) {
					return ResponseEntity.status(HttpStatus.OK)
							.body(CreateMonthResponse.Failure("Gelecek tarihli Yıl-Ay oluşturamazsınız!"));
				}
				if (LocalDate.of(ekgbPeriod.getYear(), ekgbPeriod.getMonth(),1).isBefore(ekgbAy) ) {
					return ResponseEntity.status(HttpStatus.OK)
							.body(CreateMonthResponse.Failure("Geçmiş tarihli Yıl-Ay oluşturamazsınız!"));
				}

				EkgbMonth ekgbMonth = commissionService.createMonth(ekgbPeriod.getYear(), ekgbPeriod.getMonth());
				return ResponseEntity.ok(CreateMonthResponse.Success(ekgbMonth));
	}

	@Operation(summary = "Create EKGB")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully created EKGB"),
			@ApiResponse(responseCode = "401", description = "You are not authorized to view the resource"),
			@ApiResponse(responseCode = "403", description = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(responseCode = "404", description = "The resource you were trying to reach is not found") })
	@PostMapping(value = { "/createEkgb", "" })
	public ResponseEntity<ResponseBaseContract> createEkgb( @RequestBody EkgbCreateRequest ekgbCreateRequest) {
			eKGBPartitionedCreateService.createEkgbPartitioned(ekgbCreateRequest.ids);
			return ResponseEntity.ok(EkgbCreateResponse.Success());
	}

	@Operation(summary = "Send KEP")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully sent KEP"),
			@ApiResponse(responseCode = "401", description = "You are not authorized to view the resource"),
			@ApiResponse(responseCode = "403", description = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(responseCode = "404", description = "The resource you were trying to reach is not found") })
	@PostMapping(value = { "/sendKEP", "" })
	public ResponseEntity<ResponseBaseContract> sendKEP(@RequestBody KepSendRequest kepSendRequest) {
			kEPSendPartitionedService.kepSendPartitioned(kepSendRequest.ids);
			return ResponseEntity.ok(KepSendResponse.Success());
	}

	@Operation(summary = "Get Filtered Commission data")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Commission data retrieved."),
			@ApiResponse(responseCode = "401", description = "You are not authorized to view the resource"),
			@ApiResponse(responseCode = "403", description = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(responseCode = "404", description = "The resource you were trying to reach is not found") })
	@PostMapping(value = { "/filter", "" })
	public ResponseEntity<ResponseBaseContract> getFilteredCommissions(@RequestBody FilteredCommissionsRequest filteredCommissionsRequest) {

				Page<Commission> commissionData = commissionService
						.getFilteredCommissionsPaged(filteredCommissionsRequest);

				CommissionListGetResponse commissionListGetResponse = CommissionListGetResponse.builder()
						.data(commissionData.toList()).responseMessageStatus(ResponseMessageStatus.SUCCESS).build();

				commissionListGetResponse.totalPages = commissionData.getTotalPages();
				commissionListGetResponse.totalElements = commissionData.getTotalElements();

				return ResponseEntity.ok(commissionListGetResponse);
	}

	@Operation(summary = "Get Filtered Commission data-ids")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Commission data-ids retrieved."),
			@ApiResponse(responseCode = "401", description = "You are not authorized to view the resource"),
			@ApiResponse(responseCode = "403", description = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(responseCode = "404", description = "The resource you were trying to reach is not found") })
	@PostMapping(value = { "/filterids", "" })
	public ResponseEntity<ResponseBaseContract> getFilteredCommissionIds(
			@RequestBody FilteredCommissionsRequest filteredCommissionsRequest) {

				List<Integer> commissionIds = commissionService.getFilteredCommissionIds(filteredCommissionsRequest);

				CommissionIdsListGetResponse commissionIdsListGetResponse = CommissionIdsListGetResponse.builder()
						.data(commissionIds).responseMessageStatus(ResponseMessageStatus.SUCCESS).build();

				return ResponseEntity.ok(commissionIdsListGetResponse);

	}

	@Operation(summary = "Get EKGB PDF")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "EKGB PDF retrieved."),
			@ApiResponse(responseCode = "401", description = "You are not authorized to view the resource"),
			@ApiResponse(responseCode = "403", description = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(responseCode = "404", description = "The resource you were trying to reach is not found") })
	@GetMapping(value = "/getEkgb", produces = MediaType.APPLICATION_PDF_VALUE)
	public @ResponseBody byte[] getEkgb(@RequestParam long commissionID) {


			Optional<Commission> opCommission = commissionService.getCommission(commissionID);
			if (opCommission.isPresent()) {
				Commission commission = opCommission.get();
				return commissionService.getFilenetDocumentPDF(commission.getFilenetDocumentID());
			} else {
				return new byte[0];
			}

	}

	@Operation(summary = "Cancel EKGB")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "EKGB cancelled."),
			@ApiResponse(responseCode = "401", description = "You are not authorized to view the resource"),
			@ApiResponse(responseCode = "403", description = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(responseCode = "404", description = "The resource you were trying to reach is not found") })
	@GetMapping(value = "/cancelEkgb")
	public ResponseEntity<ResponseBaseContract> cancelEkgb(@RequestParam long commissionID) {


			ResponseBaseContract result = commissionService.cancelEkgb(commissionID);

			if (result.getStatus() == ResponseMessageStatus.FAILURE) {
				return ResponseEntity.status(HttpStatus.OK)
						.body(CancelEkgbResponse.Failure(ResponseBase.getFirstMessage(result)));
			}
			return ResponseEntity.ok(CancelEkgbResponse.Success());

	}

	@Operation(summary = "Get commission xls")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Commission xls retrieved."),
			@ApiResponse(responseCode = "401", description = "You are not authorized to view the resource"),
			@ApiResponse(responseCode = "403", description = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(responseCode = "404", description = "The resource you were trying to reach is not found") })
	@PostMapping(value = "/filteredExcel", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
	public @ResponseBody byte[] filteredCommissionsExcel(
			@RequestBody FilteredCommissionsRequest filteredCommissionsRequest)
			throws IOException {

			try {
				return commissionXLSService.createCommissionXLS(filteredCommissionsRequest);
			} catch (Exception e) {
				return new byte[0];
			}
	}

	@Operation(summary = "Get commission xls from GIB provider")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Commission xls retrieved."),
			@ApiResponse(responseCode = "401", description = "You are not authorized to view the resource"),
			@ApiResponse(responseCode = "403", description = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(responseCode = "404", description = "The resource you were trying to reach is not found") })
	@PostMapping(value = "/gibKgbExcel", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
	public @ResponseBody byte[] gibKgbExcel(@RequestBody EkgbPeriod ekgbPeriod)
			throws IOException {

			try {
				return commissionXLSService.createGibCommissionXLS(ekgbPeriod);
			} catch (Exception e) {
				return new byte[0];
			}

	}

	@Operation(summary = "Open commission month")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Month opened for changes."),
			@ApiResponse(responseCode = "401", description = "You are not authorized to view the resource"),
			@ApiResponse(responseCode = "403", description = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(responseCode = "404", description = "The resource you were trying to reach is not found") })
	@PostMapping(value = { "/openMonth" })
	public ResponseEntity<ResponseBaseContract> openMonth( @RequestBody EkgbPeriod ekgbPeriod) {

				ResponseBaseContract res = commissionService.openMonth(ekgbPeriod.getYear(), ekgbPeriod.getMonth());

				if (res.getStatus() == ResponseMessageStatus.FAILURE) {
					return ResponseEntity.status(HttpStatus.OK)
							.body(OpenMonthResponse.Failure(ResponseBase.getFirstMessage(res)));
				}
				return ResponseEntity.ok(GetAllPeriodsResponse.Success());

	}

	@Operation(summary = "Close commission month")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Month closed for changes."),
			@ApiResponse(responseCode = "401", description = "You are not authorized to view the resource"),
			@ApiResponse(responseCode = "403", description = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(responseCode = "404", description = "The resource you were trying to reach is not found") })
	@PostMapping(value = { "/closeMonth" })
	public ResponseEntity<ResponseBaseContract> closeMonth(@RequestBody EkgbPeriod ekgbPeriod) {

				ResponseBaseContract res = commissionService.closeMonth(ekgbPeriod.getYear(), ekgbPeriod.getMonth());

				if (res.getStatus() == ResponseMessageStatus.FAILURE) {
					return ResponseEntity.status(HttpStatus.OK)
							.body(CloseMonthResponse.Failure(ResponseBase.getFirstMessage(res)));
				}
				return ResponseEntity.ok(CloseMonthResponse.Success());
	}

	@Operation(summary = "Clean last error")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Error cleaned."),
			@ApiResponse(responseCode = "401", description = "You are not authorized to view the resource"),
			@ApiResponse(responseCode = "403", description = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(responseCode = "404", description = "The resource you were trying to reach is not found") })
	@PostMapping(value = { "/cleanError" })
	public ResponseEntity<ResponseBaseContract> cleanError( @RequestBody EkgbPeriod ekgbPeriod) {

				ResponseBaseContract res = commissionService.cleanError(ekgbPeriod.getYear(), ekgbPeriod.getMonth());

				if (res.getStatus() == ResponseMessageStatus.FAILURE) {
					return ResponseEntity.status(HttpStatus.OK)
							.body(CleanErrorResponse.Failure(ResponseBase.getFirstMessage(res)));
				}
				return ResponseEntity.ok(CloseMonthResponse.Success());

	}
}
