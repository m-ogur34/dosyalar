package tr.com.allianz.ekgb.model;

public class CreateMonthResponse  extends ResponseBase implements ResponseBaseContract {

}
