package tr.com.allianz.ekgb.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import tr.com.allianz.ekgb.entity.CommissionDetail;

@Transactional
public interface CommissionDetailRepository extends JpaRepository<CommissionDetail, Long> {

	@Query(value = "SELECT * FROM CUSTOMER.EKGB_COMMISSION_DETAIL WHERE COMPANY = :company AND AGENCY_CODE = :agency AND YEAR = :year AND MONTH = :month ORDER BY  YEAR, MONTH", nativeQuery = true)
	List<CommissionDetail> findByCompanyAgencyYearMonth(@Param("company") String company, @Param("agency") int agency,
			@Param("year") int year, @Param("month") int month);
}