package tr.com.allianz.ekgb.model;

public class CreateCommissionDetailResponse extends ResponseBase implements ResponseBaseContract{

}
