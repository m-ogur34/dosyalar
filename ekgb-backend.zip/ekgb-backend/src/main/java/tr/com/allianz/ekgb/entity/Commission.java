package tr.com.allianz.ekgb.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;

import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Data
@Table(name = "EKGB_COMMISSION", schema="CUSTOMER")
public class Commission {
	@Id
	@Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;

	@Column(name = "AGENCY_CODE")
	private Integer agency;

	@Column(name = "COMPANY")
	private String company;

	@Column(name = "YEAR")
	private Integer year;

	@Column(name = "MONTH")
	private Integer month;

	@Column(name = "TOTAL_CANCEL_AMOUNT")
	private BigDecimal totalCancelAmount;

	@Column(name = "TOTAL_PRODUCTION_AMOUNT")
	private BigDecimal totalProductionAmount;

	@Column(name = "GIB_STATUSID")
	private  Integer gibStatusId;

	@Column(name = "KEP_STATUSID")
	private Integer kepStatusId;

	@Column(name = "KEP_STATUS")
	private String kepStatus;
	
	
	@Column(name = "KGB_UUID")
	private String kgbUUID;
	
	@Column(name = "KGB_ID")
	private String kgbID;
	
	@Column(name = "RECORD_CANCEL_DATE")
	private LocalDateTime recordCancelDate;

	@Column(name = "RECORD_CANCEL_USERID")
	private String recordCancelUserID;

	@Column(name = "GIB_SEND_REQUEST_DATE")
	private LocalDateTime gibSendRequestDate;

	@Column(name = "GIB_SEND_REQUEST_USERID")
	private String gibSendUserId;

	@Column(name = "GIB_SEND_DATE")
	private LocalDateTime gibSendDate;
	
	@Column(name = "FILENET_SEND_DATE")
	private LocalDateTime filenetSendDate;

	@Column(name = "KEP_SEND_REQUEST_DATE")
	private LocalDateTime kepSendRequestDate;
	
	@Column(name = "KEP_ADDRESS")
	private String kepAddress;

	@Column(name = "KEP_SEND_REQUEST_USERID")
	private String kepSendUserId;

	@Column(name = "KEP_SEND_DATE")
	private LocalDateTime kepSendDate;

	@Column(name = "FILENET_DOCUMENTID")
	private String filenetDocumentID;

	@Column(name = "AGENCY_ADDRESS")
	private String agencyAddress;
	
	@Column(name = "AGENCY_TITLE")
	private String agencyTitle;

	@Column(name = "AGENCY_TAX_OFFICE")
	private String agencyTaxOffice;

	@Column(name = "AGENCY_TAX_NO")
	private String agencyTaxNo;
	
}
