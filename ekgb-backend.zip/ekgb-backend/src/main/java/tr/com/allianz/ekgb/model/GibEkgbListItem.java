package tr.com.allianz.ekgb.model;

import java.math.BigDecimal;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;


@Setter
@Getter
@RequiredArgsConstructor
public class GibEkgbListItem {

	private String company;
	private String belgeNo;
	private String islemId;
	private BigDecimal istihsalKomisyonu;
	private BigDecimal iptalKomisyonu;
	private String iptalTarihi;
	private String receiverContact;
	private String receiverName;
	private String issueDate;
	private String creationTime;

}
