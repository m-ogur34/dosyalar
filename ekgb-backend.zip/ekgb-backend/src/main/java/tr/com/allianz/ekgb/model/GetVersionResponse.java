package tr.com.allianz.ekgb.model;

import lombok.Builder;

public class GetVersionResponse extends ResponseBase implements ResponseBaseContract{
    @Builder
    public GetVersionResponse(ResponseMessageStatus responseMessageStatus,
                                                   ResponseMessage[] responseMessage, Object data) {
        super(responseMessageStatus, responseMessage, data);
    }
}
