package tr.com.allianz.ekgb.service;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import tr.com.allianz.ekgb.model.ResponseBaseContract;

public interface CollectKGBDataService {

	ResponseBaseContract getKgbDataOpus(int year, int month);

	ResponseBaseContract getKgbDataNonOPUSAll(Integer year, Integer month) ;

}