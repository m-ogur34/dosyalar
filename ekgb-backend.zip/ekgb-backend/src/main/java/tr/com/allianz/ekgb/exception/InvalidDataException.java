package tr.com.allianz.ekgb.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.UNPROCESSABLE_ENTITY)
public class InvalidDataException extends RuntimeException {

    public InvalidDataException(String exception) {
        super(exception);
    }
}
