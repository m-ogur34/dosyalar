package tr.com.allianz.ekgb.service.xls;

import java.io.File;
import java.io.IOException;

import tr.com.allianz.ekgb.model.EkgbPeriod;
import tr.com.allianz.ekgb.model.FilteredCommissionsRequest;


public interface CommissionXLSService {

	byte[] createCommissionXLS(FilteredCommissionsRequest filteredCommissionsRequest) throws IOException;
	byte[] createGibCommissionXLS(EkgbPeriod ekgbPeriod) throws IOException;
	
}
