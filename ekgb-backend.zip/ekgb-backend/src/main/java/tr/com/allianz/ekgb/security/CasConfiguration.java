package tr.com.allianz.ekgb.security;


import com.allianz.awp.cas.filter.CASOncePerRequestFilter;
import com.allianz.awp.cas.filter.CASRequestWrapperFilter;
import com.allianz.awp.cas.filter.CASValidationFilter;
import com.allianz.awp.cas.servlet.ErrorHandlerServlet;
import com.allianz.awp.cas.servlet.LogoutServlet;

import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.jasig.cas.client.session.SingleSignOutFilter;
import org.jasig.cas.client.session.SingleSignOutHttpSessionListener;
import org.jasig.cas.client.validation.Cas20ServiceTicketValidator;
import org.jasig.cas.settings.SysType;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.security.autoconfigure.actuate.web.servlet.EndpointRequest;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.boot.web.servlet.ServletListenerRegistrationBean;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.core.convert.converter.Converter;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityCustomizer;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.oauth2.core.DelegatingOAuth2TokenValidator;
import org.springframework.security.oauth2.core.OAuth2TokenValidator;
import org.springframework.security.oauth2.jose.jws.MacAlgorithm;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtClaimValidator;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.jwt.JwtValidators;
import org.springframework.security.oauth2.jwt.NimbusJwtDecoder;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationConverter;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.header.writers.StaticHeadersWriter;
import org.springframework.security.web.header.writers.XXssProtectionHeaderWriter;
import org.springframework.security.web.util.matcher.AnyRequestMatcher;
import org.springframework.util.AntPathMatcher;

import jakarta.servlet.http.HttpServlet;
import javax.crypto.spec.SecretKeySpec;
import javax.sql.DataSource;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity(prePostEnabled = true, securedEnabled = true)
@RequiredArgsConstructor
class CasConfiguration {

    private static final String CAS_SERVER_URL_PREFIX = "casServerUrlPrefix";
    private static final String PROJECT_TYPE = "projectType";
    private static final String ENVIRONMENT = "environment";
    private static final String ANY_PATH = "/*";
    private static final String IGNORE_PATTERN = "ignorePattern";
    private static final String CAS_SERVER_LOGOUT_URL = "casServerLogoutUrl";
    private static final String USE_SERVER_PORT = "useServerPort";
    private static final String CAS_SERVER_LOGIN_URL = "casServerLoginUrl";
    private static final String PROJECT_NAME = "projectName";

    private final AntPathMatcher antPathMatcher;

    @Value("${app.jwt.audience}")
    private String jwtAudience;

    @Value("${app.jwt.issuer}")
    private String jwtIssuer;

    @Value("${app.jwt.secret.key}")
    private String jwtSecret;

    @Bean
    public WebSecurityCustomizer webSecurityCustomizer() {
        return web -> web.ignoring().requestMatchers("/**");
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http.securityMatcher(EndpointRequest.toAnyEndpoint())
                .httpBasic(httpBasic -> httpBasic.disable())
                .csrf(csrf -> csrf.disable())
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers("/api/v3/**",
                                "/actuator/health", "/actuator/loggers/**",
                                "/actuator/health/liveness", "/actuator/health/readiness",
                                "/actuator/prometheus").permitAll()
                        .anyRequest().hasAuthority("ACTUATOR"));

        http.oauth2ResourceServer(oauth2 -> oauth2.jwt(jwt -> jwt
                .decoder(jwtDecoder())
                .jwtAuthenticationConverter(jwtAuthenticationConverter())));

        http.headers(headers -> headers
                .xssProtection(xss -> xss.headerValue(XXssProtectionHeaderWriter.HeaderValue.ENABLED_MODE_BLOCK))
                .frameOptions(frame -> frame.sameOrigin())
                .httpStrictTransportSecurity(hsts -> hsts.includeSubDomains(true).maxAgeInSeconds(31536000).requestMatcher(AnyRequestMatcher.INSTANCE))
        );

        return http.build();
    }

    // replaces the legacy com.auth0:auth0-spring-security-api HS256 configurer (incompatible with Spring Security 7)
    private JwtDecoder jwtDecoder() {
        SecretKeySpec secretKey = new SecretKeySpec(jwtSecret.getBytes(StandardCharsets.UTF_8), "HmacSHA256");
        NimbusJwtDecoder decoder = NimbusJwtDecoder.withSecretKey(secretKey).macAlgorithm(MacAlgorithm.HS256).build();

        OAuth2TokenValidator<Jwt> withIssuer = JwtValidators.createDefaultWithIssuer(jwtIssuer);
        OAuth2TokenValidator<Jwt> withAudience = new JwtClaimValidator<List<String>>("aud",
                aud -> aud != null && aud.contains(jwtAudience));
        decoder.setJwtValidator(new DelegatingOAuth2TokenValidator<>(withIssuer, withAudience));

        return decoder;
    }

    // mirrors the legacy library's "scope"/"permissions" claim authorities (unprefixed) so hasAuthority("ACTUATOR") keeps working
    private Converter<Jwt, AbstractAuthenticationToken> jwtAuthenticationConverter() {
        JwtAuthenticationConverter converter = new JwtAuthenticationConverter();
        converter.setJwtGrantedAuthoritiesConverter(jwt -> {
            Set<String> values = new LinkedHashSet<>();

            Object scope = jwt.getClaim("scope");
            if (scope instanceof String scopeStr) {
                values.addAll(Arrays.asList(scopeStr.split(" ")));
            }

            Object permissions = jwt.getClaim("permissions");
            if (permissions instanceof Collection<?> permissionValues) {
                permissionValues.forEach(p -> values.add(String.valueOf(p)));
            }

            return values.stream()
                    .filter(StringUtils::isNotBlank)
                    .map(SimpleGrantedAuthority::new)
                    .collect(Collectors.<GrantedAuthority>toList());
        });
        return converter;
    }

    @Bean
    @Order(Ordered.HIGHEST_PRECEDENCE)
    FilterRegistrationBean<JwtPreCasFilter> jwtPreCasFilter(@Value("${cas.esb.endPoint}") String casEsbEndpoint) {

        final FilterRegistrationBean<JwtPreCasFilter> registration = new FilterRegistrationBean<>(new JwtPreCasFilter(casEsbEndpoint));
        registration.setName("CAS jwtPreCasFilter");
        registration.addUrlPatterns(ANY_PATH);

        return registration;
    }

    @Bean
    @Order(Ordered.HIGHEST_PRECEDENCE + 1)
    FilterRegistrationBean<SingleSignOutFilter> singleSignOutFilterRegistration(@Value("${cas.url.prefix}") String urlPrefix,
                                                                                @Value("${cas.project.type}") String projectType,
                                                                                @Value("${cas.environment}") String environment) {

        final FilterRegistrationBean<SingleSignOutFilter> registration = new FilterRegistrationBean<>(new SingleSignOutFilter());
        registration.setName("CAS Single Sign Out Filter");
        registration.addUrlPatterns(ANY_PATH);

        final Map<String, String> initParameters = new HashMap<>();
        initParameters.put(CAS_SERVER_URL_PREFIX, urlPrefix);
        initParameters.put(PROJECT_TYPE, projectType);
        initParameters.put(ENVIRONMENT, environment);

        registration.setInitParameters(initParameters);

        return registration;
    }

    @Bean
    @Order(Ordered.HIGHEST_PRECEDENCE + 2)
    public FilterRegistrationBean<CASOncePerRequestFilter> casOncePerRequestFilterRegistration(@Value("${cas.project.type}") String projectType, @Value("${cas.environment}") String environment) {
        FilterRegistrationBean<CASOncePerRequestFilter> registration = new FilterRegistrationBean<>(new CASOncePerRequestFilter());
        registration.setName("CAS OncePerRequest Filter");
        registration.setEnabled(Boolean.TRUE);

        Map<String, String> initParameters = new HashMap<>();
        initParameters.put(ENVIRONMENT, environment);
        initParameters.put(PROJECT_TYPE, projectType);

        registration.setInitParameters(initParameters);

        return registration;
    }

    @Bean
    @Order(Ordered.HIGHEST_PRECEDENCE + 3)
    FilterRegistrationBean<GHPCASAuthenticationFilter> casAuthenticationFilterRegistration(@Value("${cas.url.login}") String loginUrl,
                                                                                           @Value("${cas.url.logout}") String logoutUrl,
                                                                                           @Value("${cas.project.type}") String projectType,
                                                                                           @Value("${cas.environment}") String environment,
                                                                                           @Value("${cas.project.name}") String projectName,
                                                                                           @Value("${cas.useServerPort}") String useServerPort,
                                                                                           @Value("${cas.ignore-pattern}") String ignorePattern) {

        final GHPCASAuthenticationFilter casAuthenticationFilter = new GHPCASAuthenticationFilter(antPathMatcher);

        casAuthenticationFilter.setSsoEnabled(true);

        final FilterRegistrationBean<GHPCASAuthenticationFilter> registration = new FilterRegistrationBean<>(casAuthenticationFilter);
        registration.setName("CAS Authentication Filter");
        registration.addUrlPatterns(ANY_PATH);

        final Map<String, String> initParameters = new HashMap<>();
        initParameters.put(PROJECT_NAME, projectName);
        initParameters.put(CAS_SERVER_LOGIN_URL, loginUrl);
        initParameters.put(CAS_SERVER_LOGOUT_URL, logoutUrl);
        initParameters.put(ENVIRONMENT, environment);
        initParameters.put(PROJECT_TYPE, projectType);
        initParameters.put(USE_SERVER_PORT, useServerPort);

        if (ignorePattern != null) {
            initParameters.put(IGNORE_PATTERN, ignorePattern);
        }

        registration.setInitParameters(initParameters);

        return registration;
    }

    @Bean
    @Order(Ordered.HIGHEST_PRECEDENCE + 4)
    FilterRegistrationBean<CASValidationFilter> casValidationFilterRegistration(@Value("${cas.url.server}") String serverUrl,
                                                                                @Value("${cas.url.prefix}") String urlPrefix,
                                                                                @Value("${cas.project.type}") String projectType, @Value("${cas.environment}")
                                                                                String environment,
                                                                                DataSource dataSource) {

        final Cas20ServiceTicketValidator cas20ServiceTicketValidator = new Cas20ServiceTicketValidator(serverUrl);
        final CASValidationFilter casValidationFilter = new CASValidationFilter(dataSource);
        casValidationFilter.setTicketValidator(cas20ServiceTicketValidator);
        casValidationFilter.setSysType(SysType.UAT);

        final FilterRegistrationBean<CASValidationFilter> registration = new FilterRegistrationBean<>(casValidationFilter);
        registration.setName("CAS Validation Filter");
        registration.addUrlPatterns(ANY_PATH);

        final Map<String, String> initParameters = new HashMap<>();
        initParameters.put(CAS_SERVER_URL_PREFIX, urlPrefix);
        initParameters.put(ENVIRONMENT, environment);
        initParameters.put(PROJECT_TYPE, projectType);

        registration.setInitParameters(initParameters);

        return registration;
    }

    @Bean
    @Order(Ordered.HIGHEST_PRECEDENCE + 5)
    FilterRegistrationBean<CASRequestWrapperFilter> casRequestWrapperFilter(DataSource dataSource) {

        final FilterRegistrationBean<CASRequestWrapperFilter> registration = new FilterRegistrationBean<>(new CASRequestWrapperFilter(dataSource));
        registration.setName("CAS HttpServletRequest Wrapper Filter");
        registration.addUrlPatterns(ANY_PATH);

        return registration;
    }

    @Bean
    @Order(Ordered.HIGHEST_PRECEDENCE + 6)
    FilterRegistrationBean<JwtPostCasFilter> jwtPostCasFilter() {

        final FilterRegistrationBean<JwtPostCasFilter> registration = new FilterRegistrationBean<>(new JwtPostCasFilter());
        registration.setName("CAS JwtPostCasFilter");
        registration.addUrlPatterns(ANY_PATH);

        return registration;
    }

    @Bean
    ServletListenerRegistrationBean<SingleSignOutHttpSessionListener> listenerRegistrationBean() {
        return new ServletListenerRegistrationBean<>(new SingleSignOutHttpSessionListener());
    }

    @Bean
    ServletRegistrationBean<HttpServlet> logoutServletRegistrationBean() {

        final ServletRegistrationBean<HttpServlet> registration = new ServletRegistrationBean<>(new LogoutServlet(), "/LogoutServlet");
        registration.setName("LogoutServlet");
        return registration;
    }

    @Bean
    ServletRegistrationBean<HttpServlet> errorHandlerServletRegistrationBean() {

        final ServletRegistrationBean<HttpServlet> registration = new ServletRegistrationBean<>(new ErrorHandlerServlet(), "/ErrorHandlerServlet");
        registration.setName("ErrorHandlerServlet");
        return registration;
    }
}
