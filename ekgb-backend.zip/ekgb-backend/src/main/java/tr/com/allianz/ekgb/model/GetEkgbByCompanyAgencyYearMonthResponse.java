package tr.com.allianz.ekgb.model;

import lombok.Builder;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public class GetEkgbByCompanyAgencyYearMonthResponse extends ResponseBase implements ResponseBaseContract {

	@Builder
	public GetEkgbByCompanyAgencyYearMonthResponse(ResponseMessageStatus responseMessageStatus,
			ResponseMessage[] responseMessage, Object data) {
		super(responseMessageStatus, responseMessage, data);
	}
}
