package tr.com.allianz.ekgb.entity;

import java.io.Serializable;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public class MonthId implements Serializable {

	private int year;
    private int month;

    // default constructor

    public MonthId(int year, int month) {
        this.year = year;
        this.month = month;
    }

}

