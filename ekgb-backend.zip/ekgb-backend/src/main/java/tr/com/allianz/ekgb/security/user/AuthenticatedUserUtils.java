package tr.com.allianz.ekgb.security.user;

import tools.jackson.databind.ObjectMapper;
import com.msu.userutils.UserProfile;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

public class AuthenticatedUserUtils {

    private static final Integer IS_INDUSTRIAL_USER = 1;

    private final static String IS_BGD_USER_VALUE = "1";

    public static UserProfile getUserProfile() {

        final SecurityContext securityContext = SecurityContextHolder.getContext();
        if (securityContext.getAuthentication() != null) {
            final Authentication casAuthentication = securityContext.getAuthentication();
			// See com.allianz.awp.cas.filter.CASRequestWrapperFilter#doFilter:91
			final Object principal = casAuthentication.getPrincipal();
            return getUserProfile(principal);
        }
        return null;
    }

    public static UserProfile getUserProfile(Object principal) {
        return new ObjectMapper().convertValue(principal, UserProfile.class);
    }



}