package tr.com.allianz.ekgb.model;

public class GetCommissionDetailResponse extends ResponseBase implements ResponseBaseContract{

}
