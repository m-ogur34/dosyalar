package tr.com.allianz.ekgb.service.filenet;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.client.RestTemplate;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@RequiredArgsConstructor

public class FilenetServiceImpl implements FilenetService {

	private final RestTemplate filenetRestTemplate;

	@Value("${filenet.hostCreate}")
	private String filenetHostCreate;
	
	@Value("${filenet.hostRead}")
	private String filenetHostRead;

	
	@Value("${filenet.username}")
	private String filenetUsername;
  
//	@Value("${filenet.password}")
//	private String filenetPassword;

	@Override
	@PostMapping(value = "", consumes = "application/json", produces = "application/json")
	public CreateDocumentOutput createDocument(@RequestBody CreateDocumentInput createDocumentInput) {

		createDocumentInput.setUserName(filenetUsername);
//		createDocumentInput.setPassword(filenetPassword);

		CreateDocumentOutput response;
		try {
			response = filenetRestTemplate.postForObject(filenetHostCreate, createDocumentInput, CreateDocumentOutput.class);
		} catch (Exception e) {
			return null;
		}
		return response;
	}

	@Override
	@PostMapping(value = "", consumes = "application/json", produces = "application/json")
	public GetDocumentOutput getDocument(GetDocumentInput getDocumentInput) {
		getDocumentInput.setUserName(filenetUsername);
//		getDocumentInput.setPassword(filenetPassword);
		GetDocumentOutput response = filenetRestTemplate.postForObject(
				filenetHostRead , getDocumentInput, GetDocumentOutput.class);
		return response;
	}

}
