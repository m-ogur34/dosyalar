package tr.com.allianz.ekgb.model;

import java.io.Serial;
import java.io.Serializable;

public class ResponseMessage implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;
	private String code;
	private String message;

	public ResponseMessage() {
	}

	public ResponseMessage(String code, String message) {
		this.code = code;
		this.message = message;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
}
