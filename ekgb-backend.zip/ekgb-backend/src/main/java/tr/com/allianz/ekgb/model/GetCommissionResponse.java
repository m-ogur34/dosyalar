package tr.com.allianz.ekgb.model;



import lombok.RequiredArgsConstructor;
import tr.com.allianz.ekgb.entity.Commission;




public class GetCommissionResponse extends ResponseBase implements ResponseBaseContract{

	public Commission CommissionData;
	public String FileContentBase64;
}
