package tr.com.allianz.ekgb.model;

public class OpenMonthResponse  extends ResponseBase implements ResponseBaseContract {

}
