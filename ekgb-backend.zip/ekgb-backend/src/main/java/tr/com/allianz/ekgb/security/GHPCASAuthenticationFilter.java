package tr.com.allianz.ekgb.security;

import com.allianz.awp.cas.filter.CASAuthenticationFilter;
import lombok.RequiredArgsConstructor;
import tr.com.allianz.ekgb.security.constant.CASConstant;

import org.springframework.util.AntPathMatcher;


import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import java.io.IOException;

@RequiredArgsConstructor
public class GHPCASAuthenticationFilter extends CASAuthenticationFilter {

    private final AntPathMatcher antPathMatcher;

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        if (shouldNotFilter((HttpServletRequest) request)) {
            chain.doFilter(request, response);
            return;
        }
        super.doFilter(request, response, chain);
    }

    protected boolean shouldNotFilter(HttpServletRequest request) {
        //Ignoring CORS pre-flight request (Which is an OPTIONS req.)
        if ("OPTIONS".equalsIgnoreCase(request.getMethod())) {
            return true;
        }
        return CASConstant.AUTH_WHITELIST.stream().anyMatch(p -> antPathMatcher.match(p, request.getServletPath()));
    }
}