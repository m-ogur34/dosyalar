package tr.com.allianz.ekgb.model;


public class CommissionCollectMonthDataResponse  extends ResponseBase implements ResponseBaseContract{

}
