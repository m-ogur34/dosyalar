package tr.com.allianz.ekgb.model;

import java.util.List;

public class EkgbCreateRequest {

	public List<Long> ids;
	

}
