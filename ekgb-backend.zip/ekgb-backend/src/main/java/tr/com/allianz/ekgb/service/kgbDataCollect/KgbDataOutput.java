package tr.com.allianz.ekgb.service.kgbDataCollect;

import java.util.List;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@RequiredArgsConstructor
public class KgbDataOutput {
	private Integer totalPages;
	private Integer totalElements;
	private Integer pageElements;
	private Integer pageNumber;
	private List<KgbDataItemOutput> commissionDtoList;
}
