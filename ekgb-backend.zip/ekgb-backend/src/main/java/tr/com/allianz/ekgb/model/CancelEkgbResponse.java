package tr.com.allianz.ekgb.model;

public class CancelEkgbResponse  extends ResponseBase implements ResponseBaseContract {

}
