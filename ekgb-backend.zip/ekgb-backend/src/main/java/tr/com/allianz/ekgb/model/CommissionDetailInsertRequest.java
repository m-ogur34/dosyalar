package tr.com.allianz.ekgb.model;

import java.math.BigDecimal;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;

import tr.com.allianz.ekgb.entity.CommissionDetail;

public class CommissionDetailInsertRequest {

	public int agency;

	@NotEmpty
	public String company;

	// @NotEmpty(message = "Komisyon yılı girilmesi zorunludur")
	public int year;

	// @NotEmpty
	// @NotEmpty(message = "Komisyon ayı girilmesi zorunludur")
	public int month;

	@NotEmpty(message = "Komisyon branşı girilmesi zorunludur")
	@Size(max = 100, message = "En fazla 100 karakter girilebilir")
	public String branch;

	// @NotEmpty
	@DecimalMin(value = "0", message = "Zero or positive number required")
	public BigDecimal cancelAmount;

	// @NotEmpty
	@DecimalMin(value = "0", message = "Zero or positive number required")
	public BigDecimal productionAmount;

	@NotEmpty(message = "Hangi sistemden gelen data?")
	@Size(max = 100, message = "En fazla 100 karakter girilebilir")
	public String dataSource;

	public CommissionDetail toCommissionDetail() {

		CommissionDetail cd = new CommissionDetail();
		cd.setAgency(this.agency);
		cd.setCompany(this.company);
		cd.setYear(this.year);
		cd.setMonth(this.month);
		cd.setBranch(this.branch);
		cd.setProductionAmount(this.productionAmount);
		cd.setCancelAmount(this.cancelAmount);
		cd.setDataSource(this.dataSource);
		return cd;
	}
}
