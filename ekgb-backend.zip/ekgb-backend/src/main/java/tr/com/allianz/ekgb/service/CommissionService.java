package tr.com.allianz.ekgb.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;

import org.springframework.data.domain.Page;

import tr.com.allianz.ekgb.entity.Commission;
import tr.com.allianz.ekgb.entity.EkgbMonth;
import tr.com.allianz.ekgb.model.CommissionXlsDto;
import tr.com.allianz.ekgb.model.FilteredCommissionsRequest;
import tr.com.allianz.ekgb.model.ResponseBaseContract;

public interface CommissionService {

	Page<Commission> getFilteredCommissionsPaged(FilteredCommissionsRequest filteredCommissionsRequest);

	List<Integer> getFilteredCommissionIds(FilteredCommissionsRequest filteredCommissionsRequest);

	List<CommissionXlsDto> getFilteredCommissions(FilteredCommissionsRequest filteredCommissionsRequest);

	Optional<Commission> getCommission(long id);

	Commission getCommissionByAgencyYearMonth(String company, int agencyCode, int year, int month);

	// QNB servisten gönderilmiş olan EKGB leri getirir
	ResponseBaseContract getCommissionListRemoteByDate(String company, LocalDate startDate, LocalDate endDate);

	CompletableFuture<Boolean> createEkgb(List<Long> commissionList);

	CompletableFuture<Boolean> kepSend(List<Long> commissionList);

	ResponseBaseContract cancelEkgb(Long commissionId);

	EkgbMonth GetMonth(int year, int month);

	EkgbMonth createMonth(int year, int month);

	List<EkgbMonth> getAllMonths();

	ResponseBaseContract collectCommissionMonthData(int year, int month);

	void collectCommissionMonthDataAsync(int year, int month);

	byte[] getFilenetDocumentPDF(String filenetDocumentID);

	ResponseBaseContract openMonth(int year, int month);

	ResponseBaseContract closeMonth(int year, int month);

	ResponseBaseContract cleanError(int year, int month);

	//ResponseBaseContract createEkgbCheck(List<Long> commissionList);
}