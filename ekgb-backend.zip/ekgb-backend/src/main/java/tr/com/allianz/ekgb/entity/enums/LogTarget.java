package tr.com.allianz.ekgb.entity.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum LogTarget {

    EKGB, IDM
}
