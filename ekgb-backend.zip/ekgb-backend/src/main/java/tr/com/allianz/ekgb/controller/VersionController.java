package tr.com.allianz.ekgb.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import tr.com.allianz.ekgb.model.*;

@RestController
@RequestMapping("/api/v3/version")
@RequiredArgsConstructor
@Tag(name = "E-KGB", description = "E-KGB Version Service")
public class VersionController {


	@Value("${version.number}")
	private String version;

	@Value("${version.description}")
	private String versionDescription;

	@Operation(summary = "Get version")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully retrieved E-KGB"),
			@ApiResponse(responseCode = "401", description = "You are not authorized to view E-KGB"),
			@ApiResponse(responseCode = "404", description = "The resource you were trying to reach is not found"),
			@ApiResponse(responseCode = "500", description = "Could not get version") })
	@RequestMapping(value = "/version", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseBaseContract> getVersion() {
			return ResponseEntity.ok(
					GetVersionResponse.builder()
							.data("Version: "+version + " - " + versionDescription)
							.responseMessageStatus(ResponseMessageStatus.SUCCESS).build());
	}

}
