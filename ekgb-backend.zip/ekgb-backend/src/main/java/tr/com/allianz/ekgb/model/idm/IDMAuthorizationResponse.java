package tr.com.allianz.ekgb.model.idm;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class IDMAuthorizationResponse<T> {

    private List<T> data;
}
