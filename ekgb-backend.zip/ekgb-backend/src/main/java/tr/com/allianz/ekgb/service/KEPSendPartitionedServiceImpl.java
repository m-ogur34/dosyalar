package tr.com.allianz.ekgb.service;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import lombok.RequiredArgsConstructor;
import tr.com.allianz.ekgb.entity.Commission;
import tr.com.allianz.ekgb.entity.EkgbMonth;
import tr.com.allianz.ekgb.entity.enums.MonthCurrentOperation;
import tr.com.allianz.ekgb.entity.enums.MonthStatus;
import tr.com.allianz.ekgb.repository.CommissionRepository;
import tr.com.allianz.ekgb.repository.EkgbMonthRepository;
import tr.com.allianz.ekgb.service.email.NotifierImpl;


@Service
@RequiredArgsConstructor
public class KEPSendPartitionedServiceImpl implements KEPSendPartitionedService {

	private final CommissionService commissionService;
	
	// Repositories
	private final CommissionRepository commissionRepository;
	private final EkgbMonthRepository ekgbMonthRepository;

	@Value("${qnbkgb-service.partition}")
	public int qnbPartition;

	/// Partition the list to send parallel KEPs
	/* (non-Javadoc)
	 * @see tr.com.allianz.ekgb.service.KEPSendPartitionedService#kepSendPartitioned(java.util.List)
	 */
	@Override
	@Async("asyncExecutor")
	public void kepSendPartitioned(List<Long> commissionList) {

		Commission commission = null;
		
		// check if any data
		if (commissionList.size() > 0) {
			commission = commissionRepository.findById(commissionList.getFirst()).get();

			// check if month closed or ready
			EkgbMonth month = ekgbMonthRepository.getMonth(commission.getYear(), commission.getMonth());
			if (month.getStatus() != MonthStatus.OPEN.getValue()
					|| month.getCurrentOperation() != MonthCurrentOperation.IDLE.getValue()) {
				return;
			}

			ekgbMonthRepository.updateMonthCurrentOperation(commission.getYear(), commission.getMonth(),
					MonthCurrentOperation.SENDING_KEP.getValue());
			ekgbMonthRepository.flush();
		} else {
			return;
		}

		//No ekgb error
		CommissionServiceImpl.IsSendKepError = false;

		List<CompletableFuture<Boolean>> futures = new ArrayList<CompletableFuture<Boolean>>();

		int countPerList = commissionList.size() / qnbPartition;
		if (countPerList == 0)
			countPerList = 1;

		int listStartIndex = 0;
		int listEndIndex = 0;
		for (int i = 1; i <= qnbPartition; i++) {
			listEndIndex = listStartIndex + countPerList;
			if (i == qnbPartition)
				listEndIndex = commissionList.size();
			List<Long> commissionListPart = commissionList.subList(listStartIndex, listEndIndex);
			futures.add(commissionService.kepSend(commissionListPart));
			if (listEndIndex >= commissionList.size())
				break;
			listStartIndex = listEndIndex;
		}

		CompletableFuture<?>[] futuresArray = futures.toArray(new CompletableFuture<?>[0]);
		CompletableFuture<List<Boolean>> listFuture = CompletableFuture.allOf(futuresArray)
				.thenApply(v -> futures.stream().map(CompletableFuture::join).collect(Collectors.toList()));
		final List<Boolean> results = listFuture.join();
	
		if (results.stream().allMatch(b->b==true)) {

			//All threads completed. Reset.
			CommissionServiceImpl.IsSendKepError = false;

			ekgbMonthRepository.updateMonthCurrentOperation(commission.getYear(), commission.getMonth(),
					MonthCurrentOperation.IDLE.getValue());
			ekgbMonthRepository.flush();
			NotifierImpl.NotifyByEmail("KEP gönderim işlemi başarıyla tamamlandı.");	
		}
		
	}

}
