package tr.com.allianz.ekgb.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@RequiredArgsConstructor
@AllArgsConstructor
public class EkgbPeriod {

	private int year;
	private int month;
	
	
}
