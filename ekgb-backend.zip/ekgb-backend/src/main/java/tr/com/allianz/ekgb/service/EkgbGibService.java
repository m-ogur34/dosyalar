package tr.com.allianz.ekgb.service;

import java.util.List;

import javax.xml.ws.Holder;

import tr.com.cs.uut.earsiv.service.Belge;
import tr.com.cs.uut.earsiv.service.BelgeDTO;
import tr.com.cs.uut.earsiv.service.EarsivServiceResult;

public interface EkgbGibService {

	EarsivServiceResult sigortaKomisyonListe(String input, Holder<List<BelgeDTO>> output);

	EarsivServiceResult sigortaKomisyonOlustur(String input, Belge belge, Holder<Belge> output);

	EarsivServiceResult sigortaKomisyonSorgula(String input, Holder<Belge> output);

	EarsivServiceResult sigortaKomisyonIptalEt(String input);

}