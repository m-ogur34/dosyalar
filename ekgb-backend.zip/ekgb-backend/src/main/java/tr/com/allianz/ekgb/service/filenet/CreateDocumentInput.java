package tr.com.allianz.ekgb.service.filenet;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreateDocumentInput {

	
	private String userName;
	private String password;
	private String doc_ClassName;
	private String prp_Kanal;
	private CreateDocumentDocContentInput doc_Content;
	private List<CreateDocumentDocPropertyInput> doc_Properties;
	
}
