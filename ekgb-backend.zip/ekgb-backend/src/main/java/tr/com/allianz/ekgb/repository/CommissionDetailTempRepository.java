package tr.com.allianz.ekgb.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

import tr.com.allianz.ekgb.entity.CommissionDetailTemp;

@Transactional
public interface CommissionDetailTempRepository extends JpaRepository<CommissionDetailTemp, Long> {
}