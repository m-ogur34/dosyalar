package tr.com.allianz.ekgb.service.kep;

import jakarta.annotation.PostConstruct;

import org.apache.cxf.jaxws.JaxWsProxyFactoryBean;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import kepUetsRetrieve.IExchangeService;
import kepUetsRetrieve.OutgoingMailInfo;
import kepUetsRetrieve.OutgoingMailResult;
import lombok.RequiredArgsConstructor;


@Service
@RequiredArgsConstructor
public class KEPServiceImpl implements KEPService {

	public IExchangeService kepService;

	private final Environment env;

	@PostConstruct
	public void createProxy() {
		JaxWsProxyFactoryBean factory = new JaxWsProxyFactoryBean();
		factory.setServiceClass(IExchangeService.class);
		factory.setAddress(env.getProperty("kep-service.url"));
		kepService = (IExchangeService) factory.create();
	}
	
	
	/* (non-Javadoc)
	 * @see tr.com.allianz.ekgb.service.kep.KEPService#SendMessage(kepUetsRetrieve.OutgoingMailInfo)
	 */
	@Override
	public OutgoingMailResult SendMessage(OutgoingMailInfo outgoingMailInfo) {
		OutgoingMailResult r = kepService.sendKepMessage(outgoingMailInfo);
		return r;
	}
	
	
	
	
}
