package tr.com.allianz.ekgb.model;


import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AznetUserResponse {

    @Schema(description = "TC No")
    private List<String> data;

    @Schema(description = "Status")
    private String status;

    @Schema(description = "Messagge")
    private List<MessageResponse> messages;
}
