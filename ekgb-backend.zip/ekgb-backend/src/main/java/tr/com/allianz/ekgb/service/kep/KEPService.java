package tr.com.allianz.ekgb.service.kep;

import kepUetsRetrieve.OutgoingMailInfo;
import kepUetsRetrieve.OutgoingMailResult;

public interface KEPService {

	OutgoingMailResult SendMessage(OutgoingMailInfo outgoingMailInfo);

}