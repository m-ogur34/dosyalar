package tr.com.allianz.ekgb.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;
import com.allianz.common.acws.core.client.model.PmcClientRestResponse;
import com.allianz.common.acws.core.model.AgentCommissionDto;
import com.allianz.common.acws.core.model.AgentCommissionRequest;
import com.allianz.common.acws.core.model.AgentCommissionResponse;
import com.allianz.common.acws.core.model.GenericResponseAgentCommissionResponse;
import lombok.RequiredArgsConstructor;
import tr.com.allianz.ekgb.entity.CommissionDetailTemp;
import tr.com.allianz.ekgb.model.InternalCallResponse;
import tr.com.allianz.ekgb.model.ResponseBaseContract;
import tr.com.allianz.ekgb.model.ResponseMessage;
import tr.com.allianz.ekgb.model.ResponseMessageStatus;
import tr.com.allianz.ekgb.repository.CommissionDetailTempRepository;
import tr.com.allianz.ekgb.repository.EkgbMonthRepository;
import tr.com.allianz.ekgb.service.kgbDataCollect.*;
import tr.com.allianz.ekgb.util.EkgbConstants;
import tr.com.allianz.ekgb.util.MessageConstants;

@Service
@RequiredArgsConstructor
@Transactional
public class CollectKGBDataServiceImpl implements CollectKGBDataService {

	private static Logger logger = LoggerFactory.getLogger(CollectKGBDataServiceImpl.class);
	
	private final EkgbMonthRepository ekgbMonthRepository;

	private final KgbDataCollector kgbDataCollector;

	private final CommissionDetailTempRepository commissionDetailTempRepository;

	/* (non-Javadoc)
	 * @see tr.com.allianz.ekgb.service.CollectKGBDataService#getKgbDataOpus(int, int)
	 */
	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public ResponseBaseContract getKgbDataOpus(int year, int month) {
		AgentCommissionRequest agentCommissionRequest = new AgentCommissionRequest();
		agentCommissionRequest.setDataSource("OPUS");
		agentCommissionRequest.setYear(year);
		agentCommissionRequest.setMonth(month);

		Integer pageSize = EkgbConstants.OPUS_DATA_SERVICE_PAGESIZE;
		Integer currentPage = 0;
		Integer totalPages = 0;
		List<CommissionDetailTemp> commissions = new ArrayList<CommissionDetailTemp>();

		currentPage = 0;
		commissions.clear();
		do {

			GetKgbDataInput getKgbDataInput = new GetKgbDataInput();
			getKgbDataInput.setDataSource(agentCommissionRequest.getDataSource());
			getKgbDataInput.setYear(agentCommissionRequest.getYear());
			getKgbDataInput.setMonth(agentCommissionRequest.getMonth());

			GetKgbDataOutput getKgbDataOutput = kgbDataCollector.getOpusData(getKgbDataInput, currentPage, pageSize);

			if (getKgbDataOutput == null)
				return InternalCallResponse.Failure("getOpusData serviste hata");

			if (getKgbDataOutput.getSucceeded()) {
				KgbDataOutput kgbDataOutput = getKgbDataOutput.getData();

				totalPages = kgbDataOutput.getTotalPages();

				for (KgbDataItemOutput item : kgbDataOutput.getCommissionDtoList()) {
					CommissionDetailTemp newCommissionDetail = new CommissionDetailTemp();
					newCommissionDetail.setDataSource("OPUS");
					newCommissionDetail.setCompany(item.getCompany());
					newCommissionDetail.setAgency(item.getAgencyNo());
					newCommissionDetail.setBranch(item.getBranch());
					newCommissionDetail.setYear(year);
					newCommissionDetail.setMonth(month);
					newCommissionDetail.setProductionAmount(new BigDecimal(item.getProductionAmount().toString()).setScale(2, RoundingMode.HALF_UP));
					newCommissionDetail.setCancelAmount(new BigDecimal(item.getCancellationAmount().toString()).setScale(2, RoundingMode.HALF_UP));
					commissions.add(newCommissionDetail);
				}

				commissionDetailTempRepository.saveAll(commissions);
				commissions.clear();
				currentPage++;
			} else {
				TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
				return InternalCallResponse
						.Failure("getKgbDataOPUS: hata alindi");
			}

//			PmcClientRestResponse<GenericResponseAgentCommissionResponse> genericResponseAgentCommissionResponse = pmcRestClientService
//					.getPmcRestClient().restAgentCommissionControllerApi.getAgentCommissionsUsingPOST(
//							agentCommissionRequest, currentPage.toString(), pageSize.toString());
//
//
//
//			if (genericResponseAgentCommissionResponse == null)
//				return InternalCallResponse.Failure("getOpusData serviste hata");
//
//			if (genericResponseAgentCommissionResponse.isSuccess()) {
//				AgentCommissionResponse agentCommissionResponse = ((GenericResponseAgentCommissionResponse) genericResponseAgentCommissionResponse
//						.getPayload()).getData();
//
//				totalPages = agentCommissionResponse.getTotalPages();
//
//				for (AgentCommissionDto item : agentCommissionResponse.getCommissionDtoList()) {
//					CommissionDetailTemp newCommissionDetail = new CommissionDetailTemp();
//					newCommissionDetail.setDataSource("OPUS");
//					newCommissionDetail.setCompany(item.getCompany());
//					newCommissionDetail.setAgency(Integer.parseInt(item.getAgencyNo()));
//					newCommissionDetail.setBranch(item.getBranch());
//					newCommissionDetail.setYear(year);
//					newCommissionDetail.setMonth(month);
//					newCommissionDetail.setProductionAmount(new BigDecimal(item.getProductionAmount().toString()).setScale(2, RoundingMode.HALF_UP));
//					newCommissionDetail.setCancelAmount(new BigDecimal(item.getCancellationAmount().toString()).setScale(2, RoundingMode.HALF_UP));
//					commissions.add(newCommissionDetail);
//				}
//
//				commissionDetailTempRepository.saveAll(commissions);
//				commissions.clear();
//				currentPage++;
//			} else {
//				TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
//				return InternalCallResponse
//						.Failure("getKgbDataOPUS:" + genericResponseAgentCommissionResponse.getError());
//			}

		} while (currentPage < totalPages);

		return InternalCallResponse.Success();
	}
	
	/* (non-Javadoc)
	 * @see tr.com.allianz.ekgb.service.CollectKGBDataService#getKgbDataNonOPUSAll(java.lang.Integer, java.lang.Integer)
	 */
	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public ResponseBaseContract getKgbDataNonOPUSAll(Integer year, Integer month) {
		
		logger.info("execute: getKgbDataNonOPUSResponseAS400");
		ekgbMonthRepository.updateMonthLastOperation(year, month, MessageConstants.COLLECT_COMMISSION_AS400);
		ResponseBaseContract getKgbDataNonOPUSResponseAS400 = getKgbDataNonOPUS(EkgbConstants.COMMISSION_DATA_SOURCE_AS400, year, month);
		

		logger.info("execute: getKgbDataNonOPUSResponseMAGIC");
		ekgbMonthRepository.updateMonthLastOperation(year, month, MessageConstants.COLLECT_COMMISSION_MAGIC);
		ResponseBaseContract getKgbDataNonOPUSResponseMAGIC = getKgbDataNonOPUS(EkgbConstants.COMMISSION_DATA_SOURCE_MAGIC, year, month);
		

		logger.info("execute: getKgbDataNonOPUSResponseABS");
		ekgbMonthRepository.updateMonthLastOperation(year, month, MessageConstants.COLLECT_COMMISSION_ABS);
		ResponseBaseContract getKgbDataNonOPUSResponseABS = getKgbDataNonOPUS(EkgbConstants.COMMISSION_DATA_SOURCE_ABS, year, month);
		
		
		String errorMessage="";
		
		if (getKgbDataNonOPUSResponseAS400.getStatus() == ResponseMessageStatus.FAILURE) {
			errorMessage = errorMessage + " getKgbDataNonOPUSResponseAS400" + allMessages(getKgbDataNonOPUSResponseAS400);	
		}
		if (getKgbDataNonOPUSResponseMAGIC.getStatus() == ResponseMessageStatus.FAILURE) {
			errorMessage = errorMessage + 
					" getKgbDataNonOPUSResponseMAGIC" + allMessages(getKgbDataNonOPUSResponseMAGIC);
		}
		
		if (getKgbDataNonOPUSResponseABS.getStatus() == ResponseMessageStatus.FAILURE) {
			errorMessage = errorMessage + 
					" getKgbDataNonOPUSResponseABS" + allMessages(getKgbDataNonOPUSResponseABS);
     	}
		
		if (errorMessage.isEmpty()) {
			return InternalCallResponse.Success();	
		}
		else{
			try {
				TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
			}
			catch (Exception ex){
				logger.info("no transaction");
			}
			return InternalCallResponse.Failure("getKgbDataNonOPUS: " + errorMessage);
		}
	}
	
	
	
	private ResponseBaseContract getKgbDataNonOPUS(String source, Integer year, Integer month) {
		
		logger.info(" getKgbDataNonOPUS: " + source);
		
		GetKgbDataInput getKgbDataInput = new GetKgbDataInput();

		getKgbDataInput.setYear(year);
		getKgbDataInput.setMonth(month);

		List<CommissionDetailTemp> commissions = new ArrayList<CommissionDetailTemp>();

		getKgbDataInput.setDataSource(source);

		GetKgbDataNonOpusOutput kgbDataOutput = kgbDataCollector.getNonOpusData(getKgbDataInput);

		if (kgbDataOutput == null) {
			return InternalCallResponse.Failure("getKgbDataNonOPUS: kgbDataOutput NULL");
		}

		if (kgbDataOutput.getSuccess()) {

			for (KgbDataItemOutput item : kgbDataOutput.getData()) {
				CommissionDetailTemp newCommissionDetail = new CommissionDetailTemp();
				newCommissionDetail.setDataSource(source);
				newCommissionDetail.setCompany(item.getCompany());
				newCommissionDetail.setAgency(item.getAgencyNo());
				newCommissionDetail.setBranch(item.getBranch());
				newCommissionDetail.setYear(year);
				newCommissionDetail.setMonth(month);
				newCommissionDetail.setProductionAmount(
						(item.getProductionAmount() == null ?
								new BigDecimal(0) :
								new BigDecimal(item.getProductionAmount().toString()).setScale(2, RoundingMode.HALF_UP)));
				newCommissionDetail.setCancelAmount(
						(item.getCancellationAmount() == null ?
								new BigDecimal(0) :
								new BigDecimal(item.getCancellationAmount().toString()).setScale(2, RoundingMode.HALF_UP)));
				commissions.add(newCommissionDetail);
			}

			commissionDetailTempRepository.saveAll(commissions);
			commissions.clear();
		} else {
			return InternalCallResponse.Failure("getKgbDataNonOPUS: " + kgbDataOutput.getMessage());
		}

		return InternalCallResponse.Success();
	}
	
	private String allMessages(ResponseBaseContract response) {
		String message = "";
		for (ResponseMessage msg : response.getMessage()) {
			message = message + msg.getCode() + "-" + msg.getMessage() + "<br>";
		}
		return message;
	}
	
	
	
	
	
}
