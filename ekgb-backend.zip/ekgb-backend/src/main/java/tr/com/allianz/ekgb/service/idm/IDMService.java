package tr.com.allianz.ekgb.service.idm;




import java.util.List;

import tr.com.allianz.ekgb.model.idm.EkgbUserPermissionResponse;
import tr.com.allianz.ekgb.model.idm.IDMAuthorizationResponse;

public interface IDMService {

    List<String> getAznetUserName(String identityNo);

    IDMAuthorizationResponse<EkgbUserPermissionResponse> getUserAuthorization(String pageName);
}
