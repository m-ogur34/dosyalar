package tr.com.allianz.ekgb.security;

import org.apache.commons.lang3.StringUtils;

import tr.com.allianz.ekgb.security.constant.CASConstant;
import tr.com.allianz.ekgb.util.UtilString;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

public class JwtPreCasFilter implements Filter {

    public JwtPreCasFilter(String casEsbEndpoint) {
        this.casEsbEndpoint = casEsbEndpoint;
    }

    @Override
    public void init(FilterConfig filterConfig) {
    	// check why empty
    }

    private final String casEsbEndpoint;

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain chain) throws IOException, ServletException {

        final HttpServletRequest request = (HttpServletRequest) servletRequest;
        final HttpServletResponse response = (HttpServletResponse) servletResponse;

        final String jwtToken = request.getHeader(CASConstant.AUTHORIZATION_TOKEN_KEY);
        if (!UtilString.isNullOrEmpty(jwtToken)) {
            request.setAttribute(CASConstant.TOKEN, jwtToken);
            request.setAttribute(CASConstant.CAS_ESB_ENDPOINT, casEsbEndpoint);
        }
        chain.doFilter(request, response);
    }

    @Override
    public void destroy() {
    	// check why empty
    }
}