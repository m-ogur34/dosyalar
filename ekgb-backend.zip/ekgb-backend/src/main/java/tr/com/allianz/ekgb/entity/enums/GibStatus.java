package tr.com.allianz.ekgb.entity.enums;

import java.util.Arrays;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum GibStatus {
	GONDERIM_BEKLENIYOR(0),GONDERILIYOR(1), GONDERILDI(2), KAYDEDILDI(3), IPTAL(9);

	@Getter
	private int value;

	@Getter
	private String name;

	GibStatus(int value) {
		name = name();
		this.value = value;
	}

	public static  String getNameByValue(int value) {
		List<GibStatus> gibStatusList = Arrays.asList(GibStatus.values());
		GibStatus status = gibStatusList.stream().filter(s -> s.value == value).findAny().orElse(null);
		return status == null ? "" : status.name;
	}

}
