package tr.com.allianz.ekgb.exception;

import lombok.extern.slf4j.Slf4j;
import tr.com.allianz.ekgb.model.ErrorMessageResponse;
import tr.com.allianz.ekgb.util.ErrorConstants;

import org.springframework.context.support.DefaultMessageSourceResolvable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.lang.NonNull;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import jakarta.validation.ConstraintViolationException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@ControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

    @ExceptionHandler(value = Exception.class)
    public ResponseEntity<Object> handleAnyException(Exception ex) {
        log.info("exception type is any Exception");
        return new ResponseEntity<>(createErrorMessageRes(ex), new HttpHeaders(), HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @ExceptionHandler(UserNotAuthorizedException.class)
    public ResponseEntity<Object> handleUserNotAuthorizedException(UserNotAuthorizedException ex) {
        log.info("exception type is UserNotAuthorizedException");
        return new ResponseEntity<>(createErrorMessageRes(ex), new HttpHeaders(), HttpStatus.UNAUTHORIZED);
    }

    @ExceptionHandler(ResourceForbiddenException.class)
    public ResponseEntity<Object> handleResourceForbiddenException(ResourceForbiddenException ex) {
        log.info("exception type is ResourceForbiddenException");
        return new ResponseEntity<>(createErrorMessageRes(ex), new HttpHeaders(), HttpStatus.FORBIDDEN);
    }

    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<Object> handleResourceNotFoundException(ResourceNotFoundException ex) {
        log.info("exception type is ResourceNotFoundException");
        return new ResponseEntity<>(createErrorMessageRes(ex), new HttpHeaders(), HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(InvalidDataException.class)
    public ResponseEntity<Object> handleInvalidDataException(InvalidDataException ex) {
        log.info("exception type is InvalidDataException");
        ErrorMessageResponse response = createErrorMessageRes(ex);
        return new ResponseEntity<>(response.getErrorCode(), new HttpHeaders(), HttpStatus.UNPROCESSABLE_ENTITY);
    }

    @ExceptionHandler(NotFoundException.class)
    public ResponseEntity<ErrorMessageResponse> handleNotFoundException(NotFoundException ex) {
        log.info("exception type is NotFoundException");
        return new ResponseEntity<>(createErrorMessageRes(ex), new HttpHeaders(), HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(ConstraintViolationException.class)
    public ResponseEntity<List<String>> validationErrorHandler(ConstraintViolationException e) {

        log.info("validationErrorHandler : {}", e.getMessage(), e);
        List<String> errors = new ArrayList<>(e.getConstraintViolations().size());

        e.getConstraintViolations().forEach(ex -> errors.add(ex.getPropertyPath() + " : " + ex.getMessage()));

        return new ResponseEntity<>(errors, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(UnprocessableEntityException.class)
    public ResponseEntity<Object> handleUnprocessableEntityException(UnprocessableEntityException ex) {
        log.info("exception type is CouldNotCreateXLSException");
        return new ResponseEntity<>(createErrorMessageRes(ex), new HttpHeaders(), HttpStatus.UNPROCESSABLE_ENTITY);
    }

    @ExceptionHandler(BadRequestException.class)
    public ResponseEntity<Object> handleBadRequestException(BadRequestException ex) {
        log.info("exception type is BadRequestException");
        return new ResponseEntity<>(createErrorMessageRes(ex), new HttpHeaders(), HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(ForbiddenException.class)
    public ResponseEntity<Object> handleForbiddenException(ForbiddenException ex) {
        log.info("exception type is ForbiddenException");
        return new ResponseEntity<>(createErrorMessageRes(ex), new HttpHeaders(), HttpStatus.FORBIDDEN);
    }

    @ExceptionHandler(IDMException.class)
    public ResponseEntity<Object> handleIDMException(IDMException ex) {
        return new ResponseEntity<>(createErrorMessageRes(ex), new HttpHeaders(), HttpStatus.FAILED_DEPENDENCY);
    }

    @ExceptionHandler(UnsupportedMediaTypeException.class)
    public ResponseEntity<Object> handleUnsupportedMediaTypeException(UnsupportedMediaTypeException ex) {
        return new ResponseEntity<>(createErrorMessageRes(ex), new HttpHeaders(), HttpStatus.UNSUPPORTED_MEDIA_TYPE);
    }

    @ExceptionHandler(FailedDependencyException.class)
    public ResponseEntity<Object> handleFailedDependencyException(FailedDependencyException ex) {
        return new ResponseEntity<>(createErrorMessageRes(ex), new HttpHeaders(), HttpStatus.FAILED_DEPENDENCY);
    }

    @Override
    @NonNull
    protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex, @NonNull HttpHeaders headers,
                                                                  @NonNull HttpStatusCode status, @NonNull WebRequest request) {
        log.info("exception type is MethodArgumentNotValidException");
        String error = ex.getBindingResult().getFieldErrors().stream()
                .map(DefaultMessageSourceResolvable::getDefaultMessage)
                .collect(Collectors.collectingAndThen(Collectors.toList(), strings -> strings.getFirst()));
        return new ResponseEntity<>(createErrorMessageRes(ex, error), new HttpHeaders(), HttpStatus.BAD_REQUEST);
    }

    private ErrorMessageResponse createErrorMessageRes(Exception ex, String... error) {
        log.error("error : {}", ex.getMessage(), ex);
        String errorCode;
        if (error.length == 0) {
            errorCode = ex.getLocalizedMessage();
            if (errorCode == null) errorCode = ex.toString();
        } else {
            errorCode = ErrorConstants.MAY_NOT_BE_NULL.equals(error[0])
                    ? ErrorConstants.EXPECTED_PARAMETER_DOES_NOT_EXIST : error[0];
        }
        return new ErrorMessageResponse(LocalDateTime.now(), errorCode);
    }
}