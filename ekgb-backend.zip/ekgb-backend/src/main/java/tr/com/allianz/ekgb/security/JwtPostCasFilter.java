package tr.com.allianz.ekgb.security;

import com.msu.userutils.UserProfile;

import tr.com.allianz.ekgb.security.constant.CASConstant;

import org.apache.commons.lang3.StringUtils;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;


import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Map;

public class JwtPostCasFilter implements Filter {

    @Override
    public void init(FilterConfig filterConfig) {
    	// check why empty
    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain)
            throws IOException, ServletException {

        final HttpServletRequest request = (HttpServletRequest) servletRequest;
        final HttpServletResponse response = (HttpServletResponse) servletResponse;

        final String jwtToken = request.getHeader(CASConstant.AUTHORIZATION_TOKEN_KEY);
        final Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (authentication != null) {

            if (authentication.getPrincipal() instanceof UserProfile) {

                final UserProfile profile = (UserProfile) authentication.getPrincipal();
                response.setHeader(CASConstant.AUTHORIZATION_TOKEN_KEY, profile.getJwtToken());
            }

            if (authentication.getPrincipal() instanceof Map && StringUtils.isNotBlank(jwtToken)) {

                final Map<String, Object> principalMap = (Map<String, Object>) authentication.getPrincipal();
                principalMap.put("jwtToken", jwtToken);
            }
        }

        filterChain.doFilter(request, response);
    }

    @Override
    public void destroy() {
    	// check why empty
    }

}
