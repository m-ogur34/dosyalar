package tr.com.allianz.ekgb.model;

public class KepSendResponse  extends ResponseBase implements ResponseBaseContract {

}
