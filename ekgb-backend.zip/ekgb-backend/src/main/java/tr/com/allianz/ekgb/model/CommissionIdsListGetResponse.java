package tr.com.allianz.ekgb.model;

import lombok.Builder;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public class CommissionIdsListGetResponse  extends ResponseBase implements ResponseBaseContract {

	@Builder
	public CommissionIdsListGetResponse (	
	 ResponseMessageStatus responseMessageStatus,
	 ResponseMessage[] responseMessage,
	 Object data) {
		super(responseMessageStatus, responseMessage, data);
	}
}
