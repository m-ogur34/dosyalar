package tr.com.allianz.ekgb.util;

public class ErrorConstants {
	public static final String AZNET_USER_NOT_FOUND = "AZNET_USER_NOT_FOUND";
    public static final String EKGB = "EKGB";
    public static final String IDM_SERVICE_FAILED = "IDM_SERVICE_FAILED";
    public static final String MAY_NOT_BE_NULL = "may not be null";
    public static final String EXPECTED_PARAMETER_DOES_NOT_EXIST = "EXPECTED_PARAMETER_DOES_NOT_EXIST";
    public static final String FILENET_SERVICE_ERROR = "Filenet servis hatası.";
}
