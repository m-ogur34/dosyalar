package tr.com.allianz.ekgb.entity.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum MonthStatus {
	OPEN(0), CLOSED(1);

	@Getter
	private int value;

	@Getter
	private String name;

	MonthStatus(int value) {
		name = name();
		this.value = value;
	}

}
