package tr.com.allianz.ekgb.exception;


public class FilenetException extends RuntimeException {

    public FilenetException(String exception) {
        super(exception);
    }

    public FilenetException() {
        super();
    }
}
