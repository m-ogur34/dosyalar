package tr.com.allianz.ekgb.service;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.time.LocalDateTime;
import java.time.LocalDate;
import jakarta.annotation.PostConstruct;
import jakarta.persistence.Query;
import javax.xml.ws.Holder;

import org.apache.commons.lang3.StringEscapeUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.repository.query.Param;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import kepUetsRetrieve.ArrayOfFileInfo;
import kepUetsRetrieve.FileInfo;
import kepUetsRetrieve.OutgoingMailInfo;
import kepUetsRetrieve.OutgoingMailResult;
import lombok.RequiredArgsConstructor;
import tr.com.allianz.ekgb.entity.Commission;
import tr.com.allianz.ekgb.entity.CommissionDetail;
import tr.com.allianz.ekgb.entity.EkgbMonth;
import tr.com.allianz.ekgb.entity.enums.AllianzCompany;
import tr.com.allianz.ekgb.entity.enums.GibStatus;
import tr.com.allianz.ekgb.entity.enums.KepStatus;
import tr.com.allianz.ekgb.entity.enums.MonthCurrentOperation;
import tr.com.allianz.ekgb.entity.enums.MonthStatus;
import tr.com.allianz.ekgb.exception.FilenetException;
import tr.com.allianz.ekgb.exception.KepException;
import tr.com.allianz.ekgb.exception.QnbException;
import tr.com.allianz.ekgb.model.CommissionXlsDto;
import tr.com.allianz.ekgb.model.CompanyVatNo;
import tr.com.allianz.ekgb.model.FilteredCommissionsRequest;
import tr.com.allianz.ekgb.model.GibEkgbListItem;
import tr.com.allianz.ekgb.model.InternalCallResponse;
import tr.com.allianz.ekgb.model.ResponseBaseContract;
import tr.com.allianz.ekgb.model.ResponseMessage;
import tr.com.allianz.ekgb.model.ResponseMessageStatus;
import tr.com.allianz.ekgb.repository.CommissionDetailRepository;
import tr.com.allianz.ekgb.repository.CommissionRepository;
import tr.com.allianz.ekgb.repository.EkgbMonthRepository;
import tr.com.allianz.ekgb.service.email.NotifierImpl;
import tr.com.allianz.ekgb.service.filenet.CreateDocumentDocContentInput;
import tr.com.allianz.ekgb.service.filenet.CreateDocumentDocPropertyInput;
import tr.com.allianz.ekgb.service.filenet.CreateDocumentInput;
import tr.com.allianz.ekgb.service.filenet.CreateDocumentOutput;
import tr.com.allianz.ekgb.service.filenet.FilenetServiceImpl;
import tr.com.allianz.ekgb.service.filenet.GetDocumentInput;
import tr.com.allianz.ekgb.service.filenet.GetDocumentOutput;
import tr.com.allianz.ekgb.service.kep.KEPService;
import tr.com.allianz.ekgb.util.EkgbConstants;
import tr.com.allianz.ekgb.util.MessageConstants;
import tr.com.allianz.ekgb.util.UtilDate;
import tr.com.allianz.ekgb.util.UtilFile;
import tr.com.cs.uut.earsiv.service.Belge;
import tr.com.cs.uut.earsiv.service.BelgeDTO;
import tr.com.cs.uut.earsiv.service.BelgeFormatiEnum;
import tr.com.cs.uut.earsiv.service.EarsivServiceResult;
import tr.com.cs.uut.earsiv.service.EarsivServiceResult.ResultExtra.Entry;

@Service
@RequiredArgsConstructor
public class CommissionServiceImpl implements CommissionService {

	private static Logger logger = LoggerFactory.getLogger(CommissionServiceImpl.class);

	// filenet Service
	private final FilenetServiceImpl filenetServiceImpl;

	// QNB GIB service
	private final EkgbGibService ekgbGibService;

	// KEP TNB service
	private final KEPService kEPService;

	// DATA Collection services
	private final CollectKGBDataService collectKGBDataService;

	// Repositories
	private final CommissionRepository commissionRepository;
	private final CommissionDetailRepository commissionDetailRepository;
	private final EkgbMonthRepository ekgbMonthRepository;

	//
	public  static boolean IsCreateCommissionError = false;
	public  static boolean IsSendKepError = false;

	// Template to send to GIB via QNB service. Red from file
	private String ekgbGIBTemplate;

	@PostConstruct
	public void getEkgbGIBTemplate() {

		try {
			ekgbGIBTemplate = UtilFile.readFromResource("ekgbGibTemplate");
		} catch (IOException e) {
			logger.error(e.getMessage());
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * tr.com.allianz.ekgb.service.CommissionService#getFilteredCommissionsPaged(tr.
	 * com.allianz.ekgb.model.FilteredCommissionsRequest)
	 */
	@Override
	public Page<Commission> getFilteredCommissionsPaged(FilteredCommissionsRequest filteredCommissionsRequest) {

		Sort sort;
		if (filteredCommissionsRequest.getSortOrder().equals("desc")){
			sort = Sort.by(filteredCommissionsRequest.getSortBy()).descending();
		}else{
			sort = Sort.by(filteredCommissionsRequest.getSortBy());
		}

		Pageable pageable = PageRequest.of(
				filteredCommissionsRequest.getPage(),
				filteredCommissionsRequest.getPageSize(),
				sort);

		boolean filterCompany = filteredCommissionsRequest.getCompany() != null && !filteredCommissionsRequest.getCompany().isEmpty();
		boolean filterKep = filteredCommissionsRequest.getKepStatus() != null && !filteredCommissionsRequest.getKepStatus().isEmpty();
		boolean filterGib = filteredCommissionsRequest.getGibStatus() != null && !filteredCommissionsRequest.getGibStatus().isEmpty();


        return commissionRepository.findFilteredPaged(
                filterCompany,
                filteredCommissionsRequest.getCompany(),
                filterKep,
                filteredCommissionsRequest.getKepStatus(),
                filterGib,
                filteredCommissionsRequest.getGibStatus(),
                filteredCommissionsRequest.getAgency(),
                filteredCommissionsRequest.getAgencyTaxNo(),
                filteredCommissionsRequest.getYear(),
                filteredCommissionsRequest.getMonth(),
                pageable);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * tr.com.allianz.ekgb.service.CommissionService#getFilteredCommissionIds(tr.com
	 * .allianz.ekgb.model.FilteredCommissionsRequest)
	 */
	@Override
	public List<Integer> getFilteredCommissionIds(FilteredCommissionsRequest filteredCommissionsRequest) {

		boolean filterCompany = filteredCommissionsRequest.getCompany() != null && !filteredCommissionsRequest.getCompany().isEmpty();
		boolean filterKep = filteredCommissionsRequest.getKepStatus() != null && !filteredCommissionsRequest.getKepStatus().isEmpty();
		boolean filterGib = filteredCommissionsRequest.getGibStatus() != null && !filteredCommissionsRequest.getGibStatus().isEmpty();


		return commissionRepository.findFilteredIds(
				filterCompany,
				filteredCommissionsRequest.getCompany(),
				filterKep,
				filteredCommissionsRequest.getKepStatus(),
				filterGib,
				filteredCommissionsRequest.getGibStatus(),
				filteredCommissionsRequest.getAgency(),
				filteredCommissionsRequest.getAgencyTaxNo(),
				filteredCommissionsRequest.getYear(),
				filteredCommissionsRequest.getMonth());


	}

	@Override
	public List<CommissionXlsDto> getFilteredCommissions(FilteredCommissionsRequest filteredCommissionsRequest) {

		boolean filterCompany = filteredCommissionsRequest.getCompany() != null && !filteredCommissionsRequest.getCompany().isEmpty();
		boolean filterKep = filteredCommissionsRequest.getKepStatus() != null && !filteredCommissionsRequest.getKepStatus().isEmpty();
		boolean filterGib = filteredCommissionsRequest.getGibStatus() != null && !filteredCommissionsRequest.getGibStatus().isEmpty();

		return commissionRepository.findFiltered(
				filterCompany,
				filteredCommissionsRequest.getCompany(),
				filterKep,
				filteredCommissionsRequest.getKepStatus(),
				filterGib,
				filteredCommissionsRequest.getGibStatus(),
				filteredCommissionsRequest.getAgency(),
				filteredCommissionsRequest.getAgencyTaxNo(),
				filteredCommissionsRequest.getYear(),
				filteredCommissionsRequest.getMonth());

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see tr.com.allianz.ekgb.service.CommissionService#getCommission(long)
	 */
	@Override
	public Optional<Commission> getCommission(long id) {
		return commissionRepository.findById(id);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * tr.com.allianz.ekgb.service.CommissionService#getCommissionByAgencyYearMonth(
	 * java.lang.String, int, int, int)
	 */
	@Override
	public Commission getCommissionByAgencyYearMonth(String company, int agencyCode, int year, int month) {
		List<Commission> commissionList = commissionRepository.findByAgencyYearMonth(company, agencyCode, year, month);
		if (commissionList.size() == 0)
			return null;
		return commissionList.getFirst();
	}

	// QNB servisten gönderilmiş olan EKGB leri getirir
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * tr.com.allianz.ekgb.service.CommissionService#getCommissionListRemoteByDate(
	 * java.lang.String, java.time.LocalDate, java.time.LocalDate)
	 */
	@Override
	public ResponseBaseContract getCommissionListRemoteByDate(String company, LocalDate startDate, LocalDate endDate) {

		String vatNo = "";

		if (company.equals(AllianzCompany.ALLIANZ_SIGORTA.getValue())) {
			vatNo = CompanyVatNo.AZS;
		}
		if (company.equals(AllianzCompany.HAYAT_EMEKLILIK.getValue())) {
			vatNo = CompanyVatNo.HE;
		}
		if (company.equals(AllianzCompany.YASAM_EMEKLILIK.getValue())) {
			vatNo = CompanyVatNo.YE;
		}

		if (vatNo.equals("")) {
			return InternalCallResponse.Failure(MessageConstants.EKGB_SOURCEDATA_COMPANYNAME_ERROR);
		}

		final String companyVatoNo=  vatNo;

		List<GibEkgbListItem> gibEkgbList = new ArrayList<GibEkgbListItem>();

		// Zero based pagingStart
		int pagingLimit = 100; //max 100 olabiliyor. Documentation.
		int pagingStart = 0;

		// First call is done synchronously to learn the total record count (toplamAdet)
		Holder<List<BelgeDTO>> firstOutput = new Holder<List<BelgeDTO>>();
		firstOutput.value = new ArrayList<>();

		String firstInput = "{\"mukellefVkn\":\"" + companyVatoNo + "\",\"belgeTarihiBaslangic\":\""
				+ UtilDate.ToInteger(startDate) + "\",\"pagingLimit\":\"" + pagingLimit + "\",\"pagingStart\":\""
				+ pagingStart + "\",\"belgeTarihiBitis\":\"" + UtilDate.ToInteger(endDate) + "\"}";

		EarsivServiceResult firstResult = ekgbGibService.sigortaKomisyonListe(firstInput, firstOutput);

		int toplamAdet;
		if (firstResult.getResultCode().equals(EkgbConstants.QNB_RESULT_SUCCESS_CODE)) {

			Optional<Entry> toplamAdetEntry = firstResult.getResultExtra().getEntry().stream()
					.filter(item -> item.getKey().equals(EkgbConstants.QNB_EKGB_TOTALCOUNT_FIELD)).findFirst();

			toplamAdet = (int) (toplamAdetEntry.get().getValue());
		} else {
			return InternalCallResponse
					.Failure("getCommissionListRemoteByDate:" + firstResult.getResultText());
		}

		gibEkgbList.addAll(toGibEkgbListItems(firstOutput.value, company));

		// Remaining pages can be fetched in parallel since we already know toplamAdet
		List<Integer> remainingPagingStarts = new ArrayList<>();
		for (int start = pagingStart + pagingLimit; start <= toplamAdet; start += pagingLimit) {
			remainingPagingStarts.add(start);
		}

		List<CompletableFuture<Object>> futures = new ArrayList<CompletableFuture<Object>>();
		for (Integer start : remainingPagingStarts) {
			futures.add(CompletableFuture.supplyAsync(() -> {
				String input = "{\"mukellefVkn\":\"" + companyVatoNo + "\",\"belgeTarihiBaslangic\":\""
						+ UtilDate.ToInteger(startDate) + "\",\"pagingLimit\":\"" + pagingLimit + "\",\"pagingStart\":\""
						+ start + "\",\"belgeTarihiBitis\":\"" + UtilDate.ToInteger(endDate) + "\"}";

				Holder<List<BelgeDTO>> output = new Holder<List<BelgeDTO>>();
				output.value = new ArrayList<>();

				EarsivServiceResult earsivServiceResult = ekgbGibService.sigortaKomisyonListe(input, output);
				if (!earsivServiceResult.getResultCode().equals(EkgbConstants.QNB_RESULT_SUCCESS_CODE)) {
					throw new RuntimeException(
							"getCommissionListRemoteByDate:" + earsivServiceResult.getResultText());
				}
				return toGibEkgbListItems(output.value, company);
			}));
		}

		try {
			for (CompletableFuture<Object> future : futures) {
				@SuppressWarnings("unchecked")
				List<GibEkgbListItem> pageItems = (List<GibEkgbListItem>) future.get();
				gibEkgbList.addAll(pageItems);
			}
		} catch (Exception ex) {
			return InternalCallResponse.Failure("getCommissionListRemoteByDate:" + ex.getMessage());
		}

		return InternalCallResponse.Success(gibEkgbList);

	}

	private List<GibEkgbListItem> toGibEkgbListItems(List<BelgeDTO> belgeDTOList, String company) {
		List<GibEkgbListItem> result = new ArrayList<GibEkgbListItem>();
		for (BelgeDTO item : belgeDTOList) {
			GibEkgbListItem newGibEkgbListItem = new GibEkgbListItem();
			newGibEkgbListItem.setCompany(company);
			newGibEkgbListItem.setBelgeNo(item.getBelgeNo());
			newGibEkgbListItem.setIslemId(item.getIslemId());
			newGibEkgbListItem.setIstihsalKomisyonu(item.getIstihsalKomisyonu());
			newGibEkgbListItem.setIptalKomisyonu(item.getIptalKomisyonu());
			newGibEkgbListItem.setIptalTarihi(item.getIptalTarihi());
			newGibEkgbListItem.setReceiverContact(item.getReceiverContact());
			newGibEkgbListItem.setReceiverName(item.getReceiverName());
			newGibEkgbListItem.setIssueDate(item.getIssueDate());
			newGibEkgbListItem.setCreationTime(item.getCreationTime());
			result.add(newGibEkgbListItem);
		}
		return result;
	}

	private EarsivServiceResult SendCommissionToGIB(Commission commission, Holder<Belge> output) {

		List<CommissionDetail> commissionDetails = commissionDetailRepository.findByCompanyAgencyYearMonth(
				commission.getCompany(), commission.getAgency(), commission.getYear(), commission.getMonth());

		LocalDateTime now = LocalDateTime.now();

		LocalDateTime IssueDate = LocalDateTime
				.of(commission.getYear(), commission.getMonth(), 1, now.getHour(), now.getMinute(), now.getSecond())
				.plusMonths(1).minusDays(1);

		String partaj = commission.getAgency().toString();
		if (commission.getCompany().equals(AllianzCompany.YASAM_EMEKLILIK.getValue())
				&& commission.getAgency().toString().equals(EkgbConstants.EKGB_YKE_PARTAJ_NO)) {
			partaj = EkgbConstants.EKGB_YKE_PARTAJ;
		}

		String TaxNo = commission.getAgencyTaxNo() == null ? "" : commission.getAgencyTaxNo();
		String TaxOffice = commission.getAgencyTaxOffice() == null ? "" : commission.getAgencyTaxOffice();
		String Address = commission.getAgencyAddress() == null ? "" : StringEscapeUtils.escapeXml(commission.getAgencyAddress());
		String Title = commission.getAgencyTitle() == null ? "" : StringEscapeUtils.escapeXml(commission.getAgencyTitle());

		if (TaxNo.equals("") || TaxOffice.equals("") || Address.equals("") || Title.equals("")) {
			EarsivServiceResult errorRes = new EarsivServiceResult();
			errorRes.setResultCode("ALZ_HATA");
			errorRes.setResultText(MessageConstants.EKGB_AGENCY_MISSING_DATA);
			return errorRes;
		}

		String donem = UtilDate.Month(commission.getMonth()) + " - " + commission.getYear();

		BigDecimal TotalNetAmount = new BigDecimal(0);

		String creditNoteLine = "<cac:CreditNoteLine><cbc:ID>#ID#</cbc:ID>"
				+ "<cac:AllowanceCharge><cbc:ChargeIndicator>false</cbc:ChargeIndicator><cbc:AllowanceChargeReason>IPTAL</cbc:AllowanceChargeReason><cbc:Amount currencyID=\"TRY\">#IPTAL#</cbc:Amount></cac:AllowanceCharge>"
				+ "<cac:AllowanceCharge><cbc:ChargeIndicator>true</cbc:ChargeIndicator><cbc:AllowanceChargeReason>Istihsal</cbc:AllowanceChargeReason><cbc:Amount currencyID=\"TRY\">#ISTIHSAL#</cbc:Amount></cac:AllowanceCharge>"
				+ "<cac:Item><cbc:Name>#NAME#</cbc:Name></cac:Item>" + "</cac:CreditNoteLine>";

		String creditNoteLines = "";

		int lineIndex = 1;
		for (CommissionDetail commissionDetail : commissionDetails) {
			String newLine = creditNoteLine;

			String branchName = commissionDetail.getBranch() + (commissionDetail.getCompany().equals("AZS") ? ""
					: " (" + commissionDetail.getDataSource() + ")");
			creditNoteLines = creditNoteLines
					+ newLine.replace("#ID#", String.valueOf(lineIndex)).replace("#NAME#", branchName)
							.replace("#IPTAL#", String.valueOf(commissionDetail.getCancelAmount()))
							.replace("#ISTIHSAL#", String.valueOf(commissionDetail.getProductionAmount()));
			lineIndex++;
		}


		String FirstName = "";
		String kimlikTipi = "";

		if (TaxNo.length()==10){
			kimlikTipi = "VKN";
			FirstName = "" ;
		}else{
			kimlikTipi = "TCKN";
			FirstName = Title;
			Title = "";

		}

		String uuid = commission.getKgbUUID();

		String ekgbGIBInput = ekgbGIBTemplate.replace("#ID#", "").replace("#UUID#", uuid) // ID yrine 3
																							// karakter
				// girince ID yi kendi
				// oluşturuyor.
				.replace("#IssueDate#", UtilDate.ToEkgbDate(IssueDate)) // Ayın son gününe yapılacak
				.replace("#IssueTime#", UtilDate.ToEkgbTime(IssueDate))

				.replace("#SignatureschemeID#", kimlikTipi)
				.replace("#AccountingCustomerParty.Party.PartyIdentification.ID.schemeID#", kimlikTipi)

				.replace("#NOTE#", "PARTAJ: " + partaj
						+ ". Üretilen poliçelere ait komisyon tutarı cari hesabınıza alacak, iptal edilen poliçelere ait komisyon tutarı borç kaydedilmiştir. e-Sigorta Komisyon Gider Belgesi GİB izni kapsamında elektronik ortamda iletilmiştir.")
				// --
				.replace("#LineCountNumeric#", String.valueOf(commissionDetails.size()))// Detay Satır sayısı
				// -- Acente Bilgileri
				.replace("#Signature.ID#", TaxNo) // VKN
				.replace("#Signature.SignatoryParty.PartyIdentification.ID#", TaxNo) // VKN

				.replace("#Signature.SignatoryParty.PostalAddress.CitySubdivisionName#", "") // İlçe
				.replace("#Signature.SignatoryParty.PostalAddress.CityName#", "") //
				// Şehir
				.replace("#Signature.SignatoryParty.PostalAddress.Country.Name#", "TÜRKİYE") // Ülke
				// -- Allianz Şirket Bilgileri

				.replace("#AccountingSupplierParty.Party.PostalAddress.PostalZone#", "34750") //

				.replace("#InvoicePeriod.Description#", donem) //
				// .replace("#AccountingSupplierParty.WebsiteURI#", "www.allianzsigorta.com.tr")
				// //

				// //
				.replace("#AccountingSupplierParty.Party.PostalAddress.StreetName#",
						" Allianz Tower Küçükbakkalköy Mah. Kayışdağı Cad. No:1") //
				.replace("#AccountingSupplierParty.Party.PostalAddress.AdditionalStreetName#", "")
				.replace("#AccountingSupplierParty.Party.PostalAddress.CitySubdivisionName#", "Ataşehir") // İlçe
				.replace("#AccountingSupplierParty.Party.PostalAddress.CityName#", "İstanbul") // Şehir
				.replace("#AccountingSupplierParty.Party.PostalAddress.Country.Name#", "Türkiye") // Ülke

				.replace("#AccountingSupplierParty.Party.PartyTaxScheme.TaxScheme.Name#", "Büyük Mükellefler V.D.")

				// -- Acente Bilgileri
				.replace("#AccountingCustomerParty.Party.PartyIdentification.ID#", TaxNo) // VKN
				.replace("#AccountingCustomerParty.Party.PartyName.Name#", Title) // Ünvan
				.replace("#AccountingCustomerParty.Party.Person.FirstName#", FirstName)

				// //TODO
				.replace("#AccountingCustomerParty.Party.PostalAddress.StreetName#", Address) //
				// "Acente Adres 2. Satır") //

				.replace("#AccountingCustomerParty.Party.cac:PostalAddress.CitySubdivisionName#", "") // İlçe
				.replace("#AccountingCustomerParty.Party.cac:PostalAddress.CityName#", "") // Şehir
				.replace("#AccountingCustomerParty.Party.cac:PostalAddress.Country#", "") // Ülke

				.replace("#AccountingCustomerParty.Party.PartyTaxScheme.TaxScheme.Name#", TaxOffice) // Vergi Dairesi
				.replace("#AccountingCustomerParty.Party.PartyTaxScheme.TaxScheme.TaxTypeCode#", TaxNo) // VKN
				// -- Toplam Komisyon Miktarı
				// Buraya komisyon detayları gelmeli
				.replace("#LegalMonetaryTotal.LineExtensionAmount#", String.valueOf(TotalNetAmount))
				.replace("#LegalMonetaryTotal.TaxExclusiveAmount#", String.valueOf(TotalNetAmount))
				.replace("#LegalMonetaryTotal.TaxInclusiveAmount#", String.valueOf(TotalNetAmount))
				.replace("#LegalMonetaryTotal.AllowanceTotalAmount#",
						String.valueOf(commission.getTotalProductionAmount()))
				.replace("#LegalMonetaryTotal.ChargeTotalAmount#", String.valueOf(commission.getTotalCancelAmount()))
				.replace("#LegalMonetaryTotal.PayableAmount#", String.valueOf(TotalNetAmount))
				// -- Komisyon Detayları
				.replace("#creditNoteLine#", creditNoteLines);

		String inputTemplate = "{\"islemId\":\"#UUID#\",\"numaraVerilsinMi\":\"1\",\"belgeSeri\":\"#BelgeSeri#\",\"sube\":\"DFLT\",\"kasa\":\"DFLT\",\"donenBelgeFormati\":\"3\",\"vkn\":\"#AccountingSupplierParty.Party.PartyTaxScheme.TaxScheme.TaxTypeCode#\"}";
		String input = inputTemplate.replace("#UUID#", uuid);

		switch (commission.getCompany()) {
		case "AZS":
			ekgbGIBInput = ekgbGIBInput
					.replace(EkgbConstants.EKGB_DOC_ACCOUNTINGSUPPLIERPARTY_PARTY_PARTYNAME_NAME,
							"Allianz Sigorta A.Ş.") // Ünvan
					.replace(EkgbConstants.EKGB_DOC_ACCOUNTINGSUPPLIERPARTY_PARTY_PARTYIDENTIFICATION_ID,
							CompanyVatNo.AZS) // VKN olabilir
					.replace(EkgbConstants.EKGB_DOC_ACCOUNTINGSUPPLIERPARTY_PARTY_PARTYTAXSCHEME_TAXSCHEME_TAXTYPECODE,
							CompanyVatNo.AZS) // VKN
					.replace(EkgbConstants.EKGB_DOC_ACCOUNTINGSUPPLIERPARTY_PARTYIDENTIFICATION_MERSISNO,
							EkgbConstants.MERSISNO_AZS); // Mersis
			input = input
					.replace(EkgbConstants.EKGB_DOC_ACCOUNTINGSUPPLIERPARTY_PARTY_PARTYTAXSCHEME_TAXSCHEME_TAXTYPECODE,
							CompanyVatNo.AZS)
					.replace(EkgbConstants.EKGB_DOC_BELGESERI, "ALZ");
			break;
		case "HE":
			ekgbGIBInput = ekgbGIBInput
					.replace(EkgbConstants.EKGB_DOC_ACCOUNTINGSUPPLIERPARTY_PARTY_PARTYNAME_NAME,
							"Allianz Hayat ve Emeklilik A.Ş.") // Ünvan
					.replace(EkgbConstants.EKGB_DOC_ACCOUNTINGSUPPLIERPARTY_PARTY_PARTYIDENTIFICATION_ID,
							CompanyVatNo.HE) // VKN olabilir
					.replace(EkgbConstants.EKGB_DOC_ACCOUNTINGSUPPLIERPARTY_PARTY_PARTYTAXSCHEME_TAXSCHEME_TAXTYPECODE,
							CompanyVatNo.HE) // VKN
					.replace(EkgbConstants.EKGB_DOC_ACCOUNTINGSUPPLIERPARTY_PARTYIDENTIFICATION_MERSISNO,
							EkgbConstants.MERSISNO_HE); // Mersis
			input = input
					.replace(EkgbConstants.EKGB_DOC_ACCOUNTINGSUPPLIERPARTY_PARTY_PARTYTAXSCHEME_TAXSCHEME_TAXTYPECODE,
							CompanyVatNo.HE)
					.replace(EkgbConstants.EKGB_DOC_BELGESERI, "AHE");
			break;
		case "YE":
			ekgbGIBInput = ekgbGIBInput
					.replace(EkgbConstants.EKGB_DOC_ACCOUNTINGSUPPLIERPARTY_PARTY_PARTYNAME_NAME,
							"Allianz Yaşam ve Emeklilik A.Ş.") // Ünvan
					.replace(EkgbConstants.EKGB_DOC_ACCOUNTINGSUPPLIERPARTY_PARTY_PARTYIDENTIFICATION_ID,
							CompanyVatNo.YE) // VKN olabilir
					.replace(EkgbConstants.EKGB_DOC_ACCOUNTINGSUPPLIERPARTY_PARTY_PARTYTAXSCHEME_TAXSCHEME_TAXTYPECODE,
							CompanyVatNo.YE) // VKN
					.replace(EkgbConstants.EKGB_DOC_ACCOUNTINGSUPPLIERPARTY_PARTYIDENTIFICATION_MERSISNO,
							EkgbConstants.MERSISNO_YE); // Mersis
			input = input
					.replace(EkgbConstants.EKGB_DOC_ACCOUNTINGSUPPLIERPARTY_PARTY_PARTYTAXSCHEME_TAXSCHEME_TAXTYPECODE,
							CompanyVatNo.YE)
					.replace(EkgbConstants.EKGB_DOC_BELGESERI, "AYE");
			break;
		default:
			break;
		}

		Belge belge = new Belge();
		belge.setBelgeFormati(BelgeFormatiEnum.UBL);
		logger.info(input); // TODO log kapatalım
		logger.info(ekgbGIBInput); // TODO log kapatalım
		belge.setBelgeIcerigi(ekgbGIBInput.getBytes());
		EarsivServiceResult earsivServiceResult = ekgbGibService.sigortaKomisyonOlustur(input, belge, output);
		return earsivServiceResult;
	}

	private OutgoingMailResult CommissionSendKep(Commission commission) {

		String kepAddress = commission.getKepAddress();

		OutgoingMailInfo outgoingMailInfo = new OutgoingMailInfo();

		kepUetsRetrieve.ObjectFactory objectFactory = new kepUetsRetrieve.ObjectFactory();

		//Partaj
		String partaj = commission.getAgency().toString();

		// Mail Address
		outgoingMailInfo.setKepAddress(objectFactory.createOutgoingMailInfoKepAddress(kepAddress));

		// body
		String donem = UtilDate.Month(commission.getMonth()) + " " + commission.getYear();

		// Attachment
		ArrayOfFileInfo arrayOfFileInfo = new ArrayOfFileInfo();
		FileInfo fileInfo = new FileInfo();
		fileInfo.setFileName(objectFactory.createFileInfoFileName("EKGB.PDF"));
		fileInfo.setContent(
				objectFactory.createFileInfoContent(getFilenetDocumentPDF(commission.getFilenetDocumentID())));
		arrayOfFileInfo.getFileInfo().add(fileInfo);
		outgoingMailInfo.setAttachments(objectFactory.createOutgoingMailInfoAttachments(arrayOfFileInfo));

		outgoingMailInfo.setBody(objectFactory.createOutgoingMailInfoBody("Sayın Acentemiz, " + donem
				+ " dönemine ait E-Sigorta Komisyon Gider Belgeniz GİB izni kapsamında elektronik ortamda ekte iletilmiştir."));


		// Subject and mailbox
		switch (commission.getCompany()) {
		case "AZS":
			outgoingMailInfo.setMailBoxName(
					objectFactory.createOutgoingMailInfoMailBoxName(EkgbConstants.KEP_OUTGOINGMAILBOX_AZS));
			outgoingMailInfo.setSubject(objectFactory
					.createOutgoingMailInfoSubject(
							"Allianz Sigorta A.Ş.  Partaj no:" + partaj + " E-Sigorta Komisyon Gider Belgesi " + donem + EkgbConstants.KEP_DONEMI+ " Dönemi"));
			break;
		case "HE":
			outgoingMailInfo.setMailBoxName(
					objectFactory.createOutgoingMailInfoMailBoxName(EkgbConstants.KEP_OUTGOINGMAILBOX_HE));
			outgoingMailInfo.setSubject(objectFactory
					.createOutgoingMailInfoSubject(
							"Allianz Hayat Emeklilik A.Ş.  Partaj no:" + partaj + " E-Sigorta Komisyon Gider Belgesi " + donem + EkgbConstants.KEP_DONEMI+ " Dönemi"));
			break;
		case "YE":
			outgoingMailInfo.setMailBoxName(
					objectFactory.createOutgoingMailInfoMailBoxName(EkgbConstants.KEP_OUTGOINGMAILBOX_YE));
			outgoingMailInfo.setSubject(objectFactory
					.createOutgoingMailInfoSubject(
							"Allianz Yaşam Emeklilik A.Ş.  Partaj no:" + partaj + " E-Sigorta Komisyon Gider Belgesi " + donem + EkgbConstants.KEP_DONEMI+ " Dönemi"));
			break;
		default:
			OutgoingMailResult outgoingMailResult = new OutgoingMailResult();
			outgoingMailResult.setErrorCode(1);
			outgoingMailResult.getErrorMessage().setValue("Company not found");
			return outgoingMailResult;
		}

		OutgoingMailResult outgoingMailResult = kEPService.SendMessage(outgoingMailInfo);

		return outgoingMailResult;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see tr.com.allianz.ekgb.service.CommissionService#createEkgb(java.util.List)
	 */
	@Override
	@Async("asyncExecutor")
	public CompletableFuture<Boolean> createEkgb(List<Long> commissionList) {

		Commission commission = null;

		for (Long commissionId : commissionList) {


			//Some error happened in another thread. Stop.
			if (IsCreateCommissionError){
				return CompletableFuture.completedFuture(true);
			}

			logger.info("createEkgb for:" + commissionId.toString());
			commission = commissionRepository.findById(commissionId).get();

			try {

				if (commission.getGibStatusId() == GibStatus.GONDERIM_BEKLENIYOR.getValue()) {

					Belge belge = sendToQnb(commission);
					if (belge != null){
						saveToFilenet(commission, belge);
					}
				} else {
					// Kaydedilememis. Kaydedelim. Belki filenet bozuklu
					if (commission.getGibStatusId() == GibStatus.GONDERILDI.getValue()) {

						Belge belge = new Belge();
						belge.setBelgeIcerigi(new byte[]{});
						Holder<Belge> output = new Holder<Belge>(belge);


						EarsivServiceResult earsivServiceResult = retievePdfFromQnb(commission, output);

						if (earsivServiceResult.getResultCode().equals(EkgbConstants.QNB_RESULT_SUCCESS_CODE)) {

							belge = output.value;

							saveToFilenet(commission, belge);

						} else {
							logger.error("sigortaKomisyonSorgula for commission:" + commissionId.toString()
									+ earsivServiceResult.getResultCode() + MessageConstants.MESSAAGE_SEPARATOR
									+ earsivServiceResult.getResultText());
							throw new QnbException("sigortaKomisyonSorgula for commission:" + commissionId.toString()
									+ earsivServiceResult.getResultCode() + MessageConstants.MESSAAGE_SEPARATOR
									+ earsivServiceResult.getResultText());
						}

					}
				}

			} catch (Exception ex) {

				// Signal error. this should stop other threads.
				IsCreateCommissionError = true;

				logger.error("HATA1: createEkgb for commission:" + commissionId.toString() + ex.getMessage());

				if (commission.getGibStatusId() == GibStatus.GONDERILIYOR.getValue()) {
					commission.setGibStatusId(GibStatus.GONDERIM_BEKLENIYOR.getValue());
					commissionRepository.saveAndFlush(commission);
				}

				ekgbMonthRepository.updateMonthCurrentOperation(commission.getYear(), commission.getMonth(),
						MonthCurrentOperation.ERROR.getValue());
				ekgbMonthRepository.updateMonthLastError(commission.getYear(), commission.getMonth(),
						"HATA2: createEkgb for commission:" + commissionId.toString() + " - Partaj:"+ commission.getAgency()+ " - " + ex.getMessage());
				ekgbMonthRepository.flush();

				NotifierImpl.NotifyByEmail("createEkgb for commission:" + commissionId.toString() + ex.getMessage());
				return CompletableFuture.completedFuture(false);
			}
		}

		return CompletableFuture.completedFuture(true);

	}

	private EarsivServiceResult retievePdfFromQnb(Commission commission, Holder<Belge> output) {
		String vatNo = "";

		if (commission.getCompany().equals(AllianzCompany.ALLIANZ_SIGORTA.getValue())) {
			vatNo = CompanyVatNo.AZS;
		}
		if (commission.getCompany().equals(AllianzCompany.HAYAT_EMEKLILIK.getValue())) {
			vatNo = CompanyVatNo.HE;
		}
		if (commission.getCompany().equals(AllianzCompany.YASAM_EMEKLILIK.getValue())) {
			vatNo = CompanyVatNo.YE;
		}

		String input = "{ \"vkn\":\"" + vatNo + "\", \"donenBelgeFormati\":\"3\", \"uuid\":\"" + commission.getKgbUUID()
				+ "\"}";

		EarsivServiceResult earsivServiceResult = ekgbGibService.sigortaKomisyonSorgula(input, output);
		return earsivServiceResult;
	}

	private Belge sendToQnb(Commission commission) throws Exception {

		commission.setGibStatusId(GibStatus.GONDERILIYOR.getValue());
		commission.setKgbUUID(UUID.randomUUID().toString());
		commissionRepository.saveAndFlush(commission);

		// Send to GIB
		Belge belge = new Belge();
		belge.setBelgeIcerigi(new byte[]{});
		String kgbID = "";

		Holder<Belge> output = new Holder<Belge>(belge);


		logger.info("SendCommissionToGIB - start - " + LocalDateTime.now().toString());
		EarsivServiceResult earsivServiceResult = SendCommissionToGIB(commission, output);
		logger.info("SendCommissionToGIB - end - " + LocalDateTime.now().toString());
		if (earsivServiceResult.getResultCode().equals(EkgbConstants.QNB_RESULT_SUCCESS_CODE)) {

			belge = output.value;

			Optional<Entry> kgbIdEntry = earsivServiceResult.getResultExtra().getEntry().stream()
					.filter(item -> item.getKey().equals("belgeNo")).findFirst();

			kgbID = (String) (kgbIdEntry.get().getValue());

		} else {
			commission.setGibStatusId(GibStatus.GONDERIM_BEKLENIYOR.getValue());
			commissionRepository.saveAndFlush(commission);
			logger.error(
					"SendCommissionToGIB for commission:" + commission.getId() + earsivServiceResult.getResultCode()
							+ MessageConstants.MESSAAGE_SEPARATOR + earsivServiceResult.getResultText());
			if (earsivServiceResult.getResultText().equals(MessageConstants.EKGB_AGENCY_MISSING_DATA)) {
				// do nothing
				return  null;
			}
			else {
				throw new QnbException(
						"SendCommissionToGIB for commission:" + commission.getId() + earsivServiceResult.getResultCode()
								+ MessageConstants.MESSAAGE_SEPARATOR + earsivServiceResult.getResultText());
			}


		}

		commission.setGibSendDate(LocalDateTime.now());
		commission.setGibStatusId(GibStatus.GONDERILDI.getValue());
		commission.setKgbID(kgbID);
		commission.setFilenetSendDate(LocalDateTime.now());
		commissionRepository.saveAndFlush(commission);
		return belge;

	}

	private void saveToFilenet(Commission commission, Belge belge) throws Exception {

		if (commission.getGibStatusId() == GibStatus.GONDERILDI.getValue()) {
			logger.info("filenet write commission:" + commission.getId());
			String belgeIcerigi = Base64.getEncoder().encodeToString(belge.getBelgeIcerigi());

			logger.info("setFilenetDocument - start - " + LocalDateTime.now().toString());
			CreateDocumentOutput createDocumentOutput = setFilenetDocument(commission, belgeIcerigi);
			if (createDocumentOutput == null) {
				throw new FilenetException(MessageConstants.FILENET_SERVICE_ERROR);
			}
			if (createDocumentOutput.getDoc_ID() == null) {
				throw new FilenetException(MessageConstants.FILENET_SERVICE_ERROR);
			}
			logger.info("setFilenetDocument - end - " + LocalDateTime.now().toString());

			commission.setFilenetDocumentID(createDocumentOutput.getDoc_ID());
			commission.setGibStatusId(GibStatus.KAYDEDILDI.getValue());
			commissionRepository.saveAndFlush(commission);

			logger.info("updateMonthStatisticsKGB");
			ekgbMonthRepository.updateMonthStatisticsKGB(commission.getYear(), commission.getMonth());
			ekgbMonthRepository.flush();
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see tr.com.allianz.ekgb.service.CommissionService#kepSend(java.util.List)
	 */
	@Override
	@Async("asyncExecutor")
	public CompletableFuture<Boolean> kepSend(List<Long> commissionList) {

		Commission commission = null;

		for (Long commissionId : commissionList) {

			//Some error happened in another thread. Stop.
			if (IsSendKepError){
				return CompletableFuture.completedFuture(true);
			}

			logger.info("send KEP for commission:" + commissionId.toString());
			commission = commissionRepository.findById(commissionId).get();

			try {
				// lets check if commission has KEP email and EKGB
				if (commission.getKepAddress() != null
						&& commission.getKepStatusId() == KepStatus.GONDERIM_BEKLENIYOR.getValue()
						&& commission.getGibStatusId() == GibStatus.KAYDEDILDI.getValue()
						&& commission.getRecordCancelDate() == null
				) {

					commission.setKepStatusId(KepStatus.GONDERILIYOR.getValue());
					commissionRepository.saveAndFlush(commission);

					// KEP gönder

					logger.info("SendKEP - start - " + LocalDateTime.now().toString());
					OutgoingMailResult outgoingMailResult = CommissionSendKep(commission);
					logger.info("SendKEP - end - " + LocalDateTime.now().toString());
					if (outgoingMailResult.getErrorCode() != 0) {
						commission.setKepStatusId(KepStatus.GONDERIM_BEKLENIYOR.getValue());
						commissionRepository.saveAndFlush(commission);
						logger.error("kepSend for commission:" + commissionId.toString()
								+ outgoingMailResult.getErrorCode() + MessageConstants.MESSAAGE_SEPARATOR
								+ outgoingMailResult.getErrorMessage().getValue());
						throw new KepException("kepSend for commission:" + commissionId.toString()
								+ outgoingMailResult.getErrorCode() + MessageConstants.MESSAAGE_SEPARATOR
								+ outgoingMailResult.getErrorMessage().getValue());
					}

					commission.setKepSendDate(LocalDateTime.now());
					commission.setKepStatusId(KepStatus.GONDERILDI.getValue());
					commissionRepository.saveAndFlush(commission);
					ekgbMonthRepository.updateMonthStatisticsKEP(commission.getYear(), commission.getMonth());
				}

			} catch (Exception ex) {

				// Signal error. this should stop other threads.
				IsSendKepError = true;

				logger.error("HATA: kepSend for commission:" + commissionId.toString() + ex.getMessage());

				if (commission.getKepStatusId() == KepStatus.GONDERILIYOR.getValue()) {
					commission.setKepStatusId(KepStatus.GONDERIM_BEKLENIYOR.getValue());
					commissionRepository.saveAndFlush(commission);
				}

				ekgbMonthRepository.updateMonthCurrentOperation(commission.getYear(), commission.getMonth(),
						MonthCurrentOperation.ERROR.getValue());
				ekgbMonthRepository.updateMonthLastError(commission.getYear(), commission.getMonth(),
						"HATA: kepSend for commission:" + commissionId.toString() + ex.getMessage());
				ekgbMonthRepository.flush();

				return CompletableFuture.completedFuture(false);
			}
		}

		return CompletableFuture.completedFuture(true);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see tr.com.allianz.ekgb.service.CommissionService#cancelEkgb(java.lang.Long)
	 */
	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public ResponseBaseContract cancelEkgb(Long commissionId) {

		Commission commission = commissionRepository.findById(commissionId).get();

		// check if month closed or ready
		EkgbMonth month = ekgbMonthRepository.getMonth(commission.getYear(), commission.getMonth());
		if (month.getStatus() != MonthStatus.OPEN.getValue()
				|| month.getCurrentOperation() != MonthCurrentOperation.IDLE.getValue()) {
			return InternalCallResponse.Failure(MessageConstants.EKGB_MONTH_CLOSED);
		}

		logger.info("cancelEkgb for commission:" + commissionId.toString());

		if (commission.getGibStatusId() == GibStatus.KAYDEDILDI.getValue()) {

			String vatNo = "";

			if (commission.getCompany().equals(AllianzCompany.ALLIANZ_SIGORTA.getValue())) {
				vatNo = CompanyVatNo.AZS;
			}
			if (commission.getCompany().equals(AllianzCompany.HAYAT_EMEKLILIK.getValue())) {
				vatNo = CompanyVatNo.HE;
			}
			if (commission.getCompany().equals(AllianzCompany.YASAM_EMEKLILIK.getValue())) {
				vatNo = CompanyVatNo.YE;
			}

			String input = "{ \"vkn\":\"" + vatNo + "\", \"uuid\":\"" + commission.getKgbUUID() + "\"}";

			EarsivServiceResult earsivServiceResult = ekgbGibService.sigortaKomisyonIptalEt(input);

			if (earsivServiceResult.getResultCode().equals(EkgbConstants.QNB_RESULT_SUCCESS_CODE)) {
				commission.setRecordCancelDate(LocalDateTime.now());
				commission.setGibStatusId(GibStatus.IPTAL.getValue());
				commissionRepository.save(commission);
				return InternalCallResponse.Success();

			} else {
				logger.error(
						"cancelEkgb for commission:" + commissionId.toString() + earsivServiceResult.getResultCode()
								+ MessageConstants.MESSAAGE_SEPARATOR + earsivServiceResult.getResultText());
				return InternalCallResponse.Failure(MessageConstants.EKGB_CANCEL_PROVIDER_ERROR);
			}

		}
		return InternalCallResponse.Success();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see tr.com.allianz.ekgb.service.CommissionService#GetMonth(int, int)
	 */
	@Override
	public EkgbMonth GetMonth(int year, int month) {
		return ekgbMonthRepository.findEkgbMonthByYearMonth(year, month);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see tr.com.allianz.ekgb.service.CommissionService#createMonth(int, int)
	 */
	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public EkgbMonth createMonth(int year, int month) {

		EkgbMonth newMonth = new EkgbMonth();
		newMonth.setAgencyAddressCount(0L);
		newMonth.setAgencyCommissionCount(0L);
		newMonth.setAgencyKEPCount(0L);
		newMonth.setKepCount(0L);
		newMonth.setKgbCount(0L);
		newMonth.setUserID(" ");

		newMonth.setYear(year);
		newMonth.setMonth(month);
		newMonth.setStatus(MonthStatus.OPEN.getValue());
		newMonth.setCurrentOperation(MonthCurrentOperation.IDLE.getValue());
		ekgbMonthRepository.save(newMonth);
		return newMonth;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see tr.com.allianz.ekgb.service.CommissionService#getAllMonths()
	 */
	@Override
	public List<EkgbMonth> getAllMonths() {
		List<EkgbMonth> months = ekgbMonthRepository.getAllMonths();
		return months;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * tr.com.allianz.ekgb.service.CommissionService#collectCommissionMonthData(int,
	 * int)
	 */
	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public ResponseBaseContract collectCommissionMonthData(int year, int month) {

		String operationStatus = "";
		String methodName = "Komisyon bilgisi oluşturma (collectCommissionMonthData) - ";

		EkgbMonth ekgbMonth = ekgbMonthRepository.findEkgbMonthByYearMonth(year, month);

		if (ekgbMonth != null) {
			if (ekgbMonth.getStatus() == MonthStatus.CLOSED.getValue()) {
				operationStatus = methodName + MessageConstants.EKGB_MONTH_CLOSED;
				return InternalCallResponse.Failure(operationStatus);
			}
			if (ekgbMonth.getCurrentOperation() != MonthCurrentOperation.IDLE.getValue()) { // MonthCurrentOperation.IDLE
				operationStatus = methodName + MessageConstants.EKGB_MONTH_OPERATION_IN_PROGGRESS;
				return InternalCallResponse.Failure(operationStatus);
			}
		} else {
			operationStatus = methodName + MessageConstants.EKGB_MONTH_NOTFOUND;
			return InternalCallResponse.Failure(operationStatus);
		}

		ekgbMonthRepository.updateMonthCurrentOperation(year, month, MonthCurrentOperation.COLLECTING_DATA.getValue());

		logger.info(" ******** collectCommissionMonthData completed");

		return InternalCallResponse.Success();
	}

	private void deleteNonProcessedDataCommissionDetail(int year, int month) {
		logger.info(" deleteNonProcessedDataCommissionDetail");
		ekgbMonthRepository.updateMonthLastOperation(year, month,
				MessageConstants.COLLECT_COMMISSION_DELETE_COMMISSION_DETAILS);
		commissionRepository.deleteNonProcessedDataCommissionDetail(year, month);
	}

	private void deleteNonProcessedDataCommission(int year, int month) {
		logger.info("deleteNonProcessedDataCommission");
		ekgbMonthRepository.updateMonthLastOperation(year, month,
				MessageConstants.COLLECT_COMMISSION_DELETE_COMMISSIONS);
		commissionRepository.deleteNonProcessedDataCommission(year, month);
	}

	private void deleteZeroCommissionDetail(int year, int month) {
		logger.info("deleteZeroCommissionDetail");
		ekgbMonthRepository.updateMonthLastOperation(year, month,
				MessageConstants.COLLECT_COMMISSION_DELETE_COMMISSIONS);
		commissionRepository.deleteZeroCommissionDetail(year, month);
	}


	private void deleteAllDataCommissionDetailTemp(int year, int month) {
		logger.info("deleteAllDataCommissionDetailTemp");
		ekgbMonthRepository.updateMonthLastOperation(year, month,
				MessageConstants.COLLECT_COMMISSION_DELETE_TEMP_COMMISSION_DETAILS);
		commissionRepository.deleteAllDataCommissionDetailTemp(year, month);
	}

	private void transferDataCommissionDetailTemp(int year, int month)  {
		logger.info("transferDataCommissionDetailTemp");
		ekgbMonthRepository.updateMonthLastOperation(year, month,
				MessageConstants.COLLECT_COMMISSION_TRANSFER_COMMISSION);
		commissionRepository.transferDataCommissionDetailTemp(year, month);
	}

	private boolean createCommissionData(int year, int month) {
			logger.info("createCommissionData");
			ekgbMonthRepository.updateMonthLastOperation(year, month,
					MessageConstants.COLLECT_COMMISSION_CREATE_COMMISSION);
			commissionRepository.createCommissionData(year, month);
			return true;
	}

	private boolean getAddressDataAZS(int year, int month) {

			logger.info("getAddressDataAZS");
			ekgbMonthRepository.updateMonthLastOperation(year, month,
					MessageConstants.COLLECT_COMMISSION_UPDATE_ADDRESS_AZS);
			commissionRepository.getAddressDataAZS(year, month);
			return true;

	}

	private boolean getAddressDataHE(int year, int month) {

			logger.info("getAddressDataHE");
			ekgbMonthRepository.updateMonthLastOperation(year, month,
					MessageConstants.COLLECT_COMMISSION_UPDATE_ADDRESS_HE);
			commissionRepository.getAddressDataHE(year, month);
			return true;

	}

	private boolean getAddressDataHeHsbcKoc(int year, int month) {

			logger.info("getAddressDataHeHsbcKoc");
			ekgbMonthRepository.updateMonthLastOperation(year, month,
					MessageConstants.COLLECT_COMMISSION_UPDATE_ADDRESS_CUSTOM);
			commissionRepository.getAddressDataHeHsbcKoc(year, month);
			return true;

	}

	private boolean getAddressDataYE(int year, int month) {

			logger.info("getAddressDataYE");
			ekgbMonthRepository.updateMonthLastOperation(year, month,
					MessageConstants.COLLECT_COMMISSION_UPDATE_ADDRESS_HE);
			commissionRepository.getAddressDataYE(year, month);
			return true;

	}
	
	
	private boolean updateCustomAddressData(int year, int month) {

			logger.info("updateCustomAddressData");
			ekgbMonthRepository.updateMonthLastOperation(year, month,
					MessageConstants.COLLECT_COMMISSION_UPDATE_ADDRESS_CUSTOM2);
			commissionRepository.updateCustomAddressData_YE_1(year, month);
			commissionRepository.updateCustomAddressData_AZS_8569(year, month);
			commissionRepository.updateCustomAddressData_YE_852(year, month);
			commissionRepository.updateCustomAddressData_YE_7001(year, month);
			return true;

	}

	private boolean updateMonthStatistics(int year, int month) {

			logger.info("updateMonthStatistics");
			ekgbMonthRepository.updateMonthLastOperation(year, month,
					MessageConstants.COLLECT_COMMISSION_UPDATE_MONTH_STATISTICS);
			ekgbMonthRepository.updateMonthStatistics(year, month);
			return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * tr.com.allianz.ekgb.service.CommissionService#collectCommissionMonthDataAsync
	 * (int, int)
	 */
	@Override
	@Async("asyncExecutor")
	public void collectCommissionMonthDataAsync(int year, int month) {

		logger.info("collectCommissionMonthDataAsync(" + year + ", " + month + ")");

		String operationStatus = "";
		String methodName = "Komisyon bilgisi oluşturma (collectCommissionMonthDataAsync): ";

		try {

			deleteNonProcessedDataCommissionDetail(year, month);
			deleteNonProcessedDataCommission(year, month);
			deleteZeroCommissionDetail(year, month);
			deleteAllDataCommissionDetailTemp(year, month);

			// Get Data for OPUS
			logger.info(methodName + " getKgbDataOpusResponse");
			ekgbMonthRepository.updateMonthLastOperation(year, month, MessageConstants.COLLECT_COMMISSION_OPUS);
			ResponseBaseContract getKgbDataOpusResponse = collectKGBDataService.getKgbDataOpus(year, month);
			if (getKgbDataOpusResponse.getStatus() == ResponseMessageStatus.FAILURE) {
				saveError(year, month, methodName + allMessages(getKgbDataOpusResponse));
			}

			// Get Data for MAGIC AS400 ABS
			logger.info(methodName + " getKgbDataNonOPUSAll");
			ekgbMonthRepository.updateMonthLastOperation(year, month, MessageConstants.COLLECT_COMMISSION_AS400);
			ResponseBaseContract getKgbDataNonOPUSAllResponse = collectKGBDataService.getKgbDataNonOPUSAll(year, month);
			if (getKgbDataNonOPUSAllResponse.getStatus() == ResponseMessageStatus.FAILURE) {
				saveError(year, month, methodName + allMessages(getKgbDataNonOPUSAllResponse));
			}

			transferDataCommissionDetailTemp(year, month);

			createCommissionData(year, month);

			getAddressDataAZS(year, month);

			getAddressDataHE(year, month);

			getAddressDataHeHsbcKoc(year, month);

			getAddressDataYE(year, month);

			updateCustomAddressData(year, month);

			updateMonthStatistics(year, month);


			// Clean
			ekgbMonthRepository.updateMonthLastOperation(year, month, "");
			ekgbMonthRepository.cleanMonthError(year, month);

			ekgbMonthRepository.updateMonthCurrentOperation(year, month, MonthCurrentOperation.IDLE.getValue());
			ekgbMonthRepository.flush();

			// Send notification Mail with statistics

			operationStatus = "Komisyon bilgisi toplama: Tamamlandı. Başarılı.";
			NotifierImpl.NotifyByEmail(operationStatus);

		} catch (Exception ex) {
			ekgbMonthRepository.updateMonthCurrentOperation(year, month, MonthCurrentOperation.ERROR.getValue());
			saveError(year, month, methodName + " getKgbDataNonOPUSAll" + ex.getMessage());
			operationStatus = ex.getMessage();
			logger.error("**** HATA ****" + operationStatus);
			NotifierImpl.NotifyByEmail(operationStatus);
		}

	}

	@Transactional(propagation = Propagation.REQUIRES_NEW)
	private void saveError(int year, int month, String message) {
		ekgbMonthRepository.updateMonthCurrentOperation(year, month, MonthCurrentOperation.ERROR.getValue());
		ekgbMonthRepository.updateMonthLastError(year, month, message);
		NotifierImpl.NotifyByEmail(message);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * tr.com.allianz.ekgb.service.CommissionService#getFilenetDocumentPDF(java.lang
	 * .String)
	 */
	@Override
	public byte[] getFilenetDocumentPDF(String filenetDocumentID) {

		GetDocumentInput getDocumentInput = new GetDocumentInput();
		getDocumentInput.setDoc_ID(filenetDocumentID);
		GetDocumentOutput response = filenetServiceImpl.getDocument(getDocumentInput);
		if (response.getDoc_Content() == null)
			return new byte[0];
		return Base64.getDecoder().decode(response.getDoc_Content().getDoc_Base64());
	}

	private CreateDocumentOutput setFilenetDocument(Commission commission, String docBase64) {

		CreateDocumentInput createDocumentInput = new CreateDocumentInput();

		createDocumentInput.setPrp_Kanal(EkgbConstants.FILENET_CHANNEL);
		createDocumentInput.setDoc_ClassName(EkgbConstants.FILENET_CLASSNAME);
		CreateDocumentDocContentInput doc_Content = new CreateDocumentDocContentInput();
		doc_Content.setDoc_MimeType(EkgbConstants.FILENET_MIMETYPE);

		doc_Content.setDoc_Base64(docBase64);
		doc_Content.setDoc_Title(
				commission.getYear() + " - " + commission.getMonth() + " - " + commission.getAgency().toString());
		createDocumentInput.setDoc_Content(doc_Content);

		createDocumentInput.setDoc_Properties(new ArrayList<CreateDocumentDocPropertyInput>());

		CreateDocumentDocPropertyInput prp_CompanyCode = new CreateDocumentDocPropertyInput();
		prp_CompanyCode.setPrp_SymbolicName(EkgbConstants.FILENET_PROPERTY_COMPANYCODE);
		prp_CompanyCode.setPrp_Type(EkgbConstants.FILENET_DATATYPE_STRING);
		prp_CompanyCode.setPrp_Value(commission.getCompany());

		CreateDocumentDocPropertyInput prp_AgencyCode = new CreateDocumentDocPropertyInput();
		prp_AgencyCode.setPrp_SymbolicName(EkgbConstants.FILENET_PROPERTY_AGENCYCODE);
		prp_AgencyCode.setPrp_Type(EkgbConstants.FILENET_DATATYPE_STRING);
		prp_AgencyCode.setPrp_Value(commission.getAgency().toString());

		CreateDocumentDocPropertyInput prp_Year = new CreateDocumentDocPropertyInput();
		prp_Year.setPrp_SymbolicName(EkgbConstants.FILENET_PROPERTY_YEAR);
		prp_Year.setPrp_Type(EkgbConstants.FILENET_DATATYPE_INTEGER);
		prp_Year.setPrp_Value(commission.getYear().toString());

		CreateDocumentDocPropertyInput prp_Month = new CreateDocumentDocPropertyInput();
		prp_Month.setPrp_SymbolicName(EkgbConstants.FILENET_PROPERTY_MONTH);
		prp_Month.setPrp_Type(EkgbConstants.FILENET_DATATYPE_INTEGER);
		prp_Month.setPrp_Value(commission.getMonth().toString());

		createDocumentInput.getDoc_Properties().add(prp_CompanyCode);
		createDocumentInput.getDoc_Properties().add(prp_AgencyCode);
		createDocumentInput.getDoc_Properties().add(prp_Year);
		createDocumentInput.getDoc_Properties().add(prp_Month);

		CreateDocumentOutput createDocumentOutput = filenetServiceImpl.createDocument(createDocumentInput);

		return createDocumentOutput;
	}

	private String allMessages(ResponseBaseContract response) {
		String message = "";
		for (ResponseMessage msg : response.getMessage()) {
			message = message + msg.getCode() + "-" + msg.getMessage() + "<br>";
		}
		return message;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see tr.com.allianz.ekgb.service.CommissionService#openMonth(int, int)
	 */
	@Override
	public ResponseBaseContract openMonth(int year, int month) {
		try {
			EkgbMonth ekgbMonth = ekgbMonthRepository.findEkgbMonthByYearMonth(year, month);
			ekgbMonth.setStatus(MonthStatus.OPEN.getValue());
			ekgbMonthRepository.save(ekgbMonth);
		} catch (Exception ex) {
			return InternalCallResponse.Failure(ex.getMessage());
		}
		return InternalCallResponse.Success();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see tr.com.allianz.ekgb.service.CommissionService#closeMonth(int, int)
	 */
	@Override
	public ResponseBaseContract closeMonth(int year, int month) {
		try {
			EkgbMonth ekgbMonth = ekgbMonthRepository.findEkgbMonthByYearMonth(year, month);
			ekgbMonth.setStatus(MonthStatus.CLOSED.getValue());
			ekgbMonthRepository.save(ekgbMonth);
		} catch (Exception ex) {
			return InternalCallResponse.Failure(ex.getMessage());
		}
		return InternalCallResponse.Success();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see tr.com.allianz.ekgb.service.CommissionService#cleanError(int, int)
	 */
	@Override
	public ResponseBaseContract cleanError(int year, int month) {
		try {
			EkgbMonth ekgbMonth = ekgbMonthRepository.findEkgbMonthByYearMonth(year, month);
			ekgbMonth.setCurrentOperation(MonthCurrentOperation.IDLE.getValue());
			ekgbMonth.setLastError("");
			ekgbMonthRepository.save(ekgbMonth);
		} catch (Exception ex) {
			return InternalCallResponse.Failure(ex.getMessage());
		}
		return InternalCallResponse.Success();
	}



}
