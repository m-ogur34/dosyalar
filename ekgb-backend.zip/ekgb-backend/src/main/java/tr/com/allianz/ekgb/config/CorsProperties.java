package tr.com.allianz.ekgb.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "cors-config")
public class CorsProperties {

    private String[] allowMethod;
    //private String[] allowHeader;
    private String[] domainList;

    public String[] getAllowMethod() {
        return allowMethod;
    }

    public void setAllowMethod(String[] allowMethod) {
        this.allowMethod = allowMethod;
    }

    /*
    public String[] getAllowHeader() {
        return allowHeader;
    }

    public void setAllowHeader(String[] allowHeader) {
        this.allowHeader = allowHeader;
    }

     */

    public String[] getDomainList() {
        return domainList;
    }

    public void setDomainList(String[] domainList) {
        this.domainList = domainList;
    }
}
