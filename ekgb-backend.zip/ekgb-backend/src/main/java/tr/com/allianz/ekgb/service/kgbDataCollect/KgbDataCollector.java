package tr.com.allianz.ekgb.service.kgbDataCollect;

public interface KgbDataCollector {

	GetKgbDataOutput getOpusData(GetKgbDataInput getKgbDataInput, int page, int size);

	GetKgbDataNonOpusOutput getNonOpusData(GetKgbDataInput getKgbDataInput);

}