package tr.com.allianz.ekgb.service.filenet;

import org.springframework.beans.factory.annotation.Value;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class GetDocumentInput {
	private String userName;
	private String password;
	private String doc_ID;
	final String doc_Base64 = "True";

}
