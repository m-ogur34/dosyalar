package tr.com.allianz.ekgb.model;

public enum ResponseMessageStatus {

	SUCCESS("0", "0-Success"), FAILURE("1", "1-Failure"), UNAUTHORIZED("2", "2-Unauthorized");

	private String code;
	private String message;

	ResponseMessageStatus(String code, String message) {
		this.code = code;
		this.message = message;
	}

	public String getCode() {
		return code;
	}

	public String getMessage() {
		return message;
	}

	public String getMessageWithDetail(String messageDetail) {
		return message + " " + "(" + messageDetail + ")";
	}
}
