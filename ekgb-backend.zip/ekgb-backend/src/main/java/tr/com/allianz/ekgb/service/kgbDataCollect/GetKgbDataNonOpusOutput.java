package tr.com.allianz.ekgb.service.kgbDataCollect;
import java.util.List;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@RequiredArgsConstructor
public class GetKgbDataNonOpusOutput {
	private Boolean success;
	private String message;
	private List<KgbDataItemOutput> data;
}

