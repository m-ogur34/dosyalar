package tr.com.allianz.ekgb.service.kgbDataCollect;

import java.math.BigDecimal;

import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@RequiredArgsConstructor
public class KgbDataItemOutput {
	private Integer agencyNo;
	private String company;
	private String branch;
	private BigDecimal productionAmount;
	private BigDecimal cancellationAmount;
}
