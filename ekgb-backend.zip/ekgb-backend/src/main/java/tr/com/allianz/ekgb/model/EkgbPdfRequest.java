package tr.com.allianz.ekgb.model;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@RequiredArgsConstructor
public class EkgbPdfRequest {
	private String company;
	private int agencyCode;
	private int year;
	private int month;
	private String key;
}
