package tr.com.allianz.ekgb.service;

import java.util.List;

import org.springframework.scheduling.annotation.Async;

public interface KEPSendPartitionedService {

	/// Partition the list to send parallel KEPs
	void kepSendPartitioned(List<Long> commissionList);

}