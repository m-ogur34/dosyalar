package tr.com.allianz.ekgb.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

@Entity
@Data
@Table(name = "EKGB_COMMISSION_DETAIL")
public class CommissionDetail {

	
	@Id
	@Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "USERS_SEQ")
    @SequenceGenerator(name = "USERS_SEQ", sequenceName = "CUSTOMER.EKGB_COMMISSION_DETAIL_ID_SEQ")
    private Long id;
	
	
	@Column(name = "AGENCY_CODE")
	private int agency;

	@Column(name = "COMPANY")
	private String company;

	@Column(name = "YEAR")
	private int year;

	@Column(name = "MONTH")
	private int month;

	@Column(name = "BRANCH")
	private String branch;

	@Column(name = "CANCEL_AMOUNT")
	private BigDecimal cancelAmount;

	@Column(name = "PRODUCTION_AMOUNT")
	private BigDecimal productionAmount;
	
	@Column(name = "DATA_SOURCE")
	private String dataSource;

	@Column(name = "RECORD_CREATE", insertable = false)
	private Date recordDate;

}
