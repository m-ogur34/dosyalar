package tr.com.allianz.ekgb.model;

public interface ResponseBaseContract {
	
	void setStatus(ResponseMessageStatus responseMessageStatus);

	void setMessage(ResponseMessage[] responseMessage);

	void setData(Object data);

	Object getData();

	ResponseMessage[] getMessage();
	
	ResponseMessageStatus getStatus();
}
