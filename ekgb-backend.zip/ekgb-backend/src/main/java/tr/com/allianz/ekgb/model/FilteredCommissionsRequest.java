package tr.com.allianz.ekgb.model;

import java.util.List;

import org.springframework.data.domain.Pageable;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;


@Getter
@Setter
@RequiredArgsConstructor
public class FilteredCommissionsRequest {

	private List<String> company;
	private Integer agency;
	private int year;
	private int month;
	private String agencyTaxNo;
	private List<Integer> kepStatus;
	private List<Integer> gibStatus;
	private int page;
	private int pageSize;
	private String sortBy;
	private String sortOrder;

}
