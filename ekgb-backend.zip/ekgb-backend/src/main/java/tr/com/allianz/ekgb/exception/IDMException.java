package tr.com.allianz.ekgb.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.FAILED_DEPENDENCY)
public class IDMException extends RuntimeException {

    public IDMException(String exception) {
        super(exception);
    }
}
