package tr.com.allianz.ekgb.service.kgbDataCollect;

import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@RequiredArgsConstructor
public class GetKgbDataOutput {
	private Boolean succeeded;
	private Integer status;
	private String errorCode;
	private KgbDataOutput data;
}

