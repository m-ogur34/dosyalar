package tr.com.allianz.ekgb.model;

public class CreateCommissionResponse extends ResponseBase implements ResponseBaseContract{

}
