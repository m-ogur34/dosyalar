package tr.com.allianz.ekgb.repository;



import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import tr.com.allianz.ekgb.entity.Commission;
import tr.com.allianz.ekgb.model.CommissionXlsDto;
import tr.com.allianz.ekgb.model.FilteredCommissionsRequest;


@Transactional
public interface CommissionRepository extends JpaRepository<Commission, Long> {


	//-------   KEP operations ---------

	@Modifying
	@Query(value = "UPDATE CUSTOMER.EKGB_COMMISSION SET "
			+ "KEP_STATUSID = :statusId  "
			+ "WHERE ID = :id ", nativeQuery = true)
	List<Commission> updateKEPStatusId(@Param("id") long id, @Param("statusId") int statusId );


	@Modifying
	@Query(value = "UPDATE CUSTOMER.EKGB_COMMISSION SET "
			+ "KEP_SEND_DATE = :kepSendDate  "
			+ "WHERE ID = :id ", nativeQuery = true)
	List<Commission> updateKEPSendDate(@Param("id") long id, @Param("kepSendDate") LocalDateTime kepSendDate );

	//-------   KEP operations ---------END




	//-------   Commission Transfer operations ---------


	//gib status gonderildi ve kaydedildi olan disindakileri veya iptal edilmisleri sil
	@Modifying
	@Query(value = "DELETE FROM CUSTOMER.EKGB_COMMISSION_DETAIL " +
			"WHERE ID IN" +
			"(" +
			"  SELECT D.ID " +
			"  FROM CUSTOMER.EKGB_COMMISSION_DETAIL D INNER JOIN CUSTOMER.EKGB_COMMISSION C ON " +
			"  D.AGENCY_CODE = C.AGENCY_CODE AND " +
			"  D.COMPANY = C.COMPANY AND " +
			"  D.YEAR = C.YEAR AND " +
			"  D.MONTH = C.MONTH  " +
			"  WHERE C.YEAR = :year AND C.MONTH = :month AND  GIB_STATUSID <> 2 AND GIB_STATUSID <> 3 AND GIB_STATUSID <> 9 " +
			")"
			, nativeQuery = true)
	void deleteNonProcessedDataCommissionDetail(@Param("year") int year, @Param("month") int month);


	//Üretim ve iptal bilgisi 0 olan kayıtları silelim
	@Modifying
	@Query(value = "DELETE " +
					"FROM " +
					"	CUSTOMER.EKGB_COMMISSION_DETAIL D " +
					"WHERE " +
					"	D.PRODUCTION_AMOUNT=0 " +
					"	AND D.Cancel_Amount=0 " +
					"	AND D.YEAR = :year " +
					"	AND D.MONTH = :month "
			, nativeQuery = true)
	void deleteZeroCommissionDetail(@Param("year") int year, @Param("month") int month);






	// EKGB_COMMISSION_DETAIL tablosunda olmayanlari EKGB_COMMISSION_DETAIL_TEMP tablosundan aktar
	@Modifying
	@Query(value = "INSERT INTO CUSTOMER.EKGB_COMMISSION_DETAIL (AGENCY_CODE, COMPANY, YEAR, MONTH, BRANCH, CANCEL_AMOUNT, PRODUCTION_AMOUNT, DATA_SOURCE, USERID, RECORD_CREATE)" +
			"SELECT T.AGENCY_CODE, T.COMPANY, T.YEAR, T.MONTH, T.BRANCH, T.CANCEL_AMOUNT, T.PRODUCTION_AMOUNT, T.DATA_SOURCE, T.USERID, T.RECORD_CREATE  "
			+ " FROM CUSTOMER.EKGB_COMMISSION_DETAIL_TEMP T LEFT JOIN CUSTOMER.EKGB_COMMISSION_DETAIL D ON " +
			"         T.COMPANY = D.COMPANY " +
			"    AND  T.AGENCY_CODE = D.AGENCY_CODE " +
			"    AND  T.YEAR = D.YEAR " +
			"    AND  T.MONTH = D.MONTH " +
			"	 AND  T.BRANCH = D.BRANCH " +
			"WHERE T.YEAR = :year AND T.MONTH = :month AND D.COMPANY IS NULL"
			, nativeQuery = true)
	void transferDataCommissionDetailTemp(@Param("year") int year, @Param("month") int month);


	@Modifying
	@Query(value = "DELETE FROM CUSTOMER.EKGB_COMMISSION_DETAIL_TEMP  WHERE YEAR = :year AND MONTH = :month "
			, nativeQuery = true)
	void deleteAllDataCommissionDetailTemp(@Param("year") int year, @Param("month") int month);




	@Modifying
	@Query(value = "DELETE FROM CUSTOMER.EKGB_COMMISSION C WHERE C.YEAR = :year AND C.MONTH = :month AND FILENET_DOCUMENTID IS NULL"
			, nativeQuery = true)
	void deleteNonProcessedDataCommission(@Param("year") int year, @Param("month") int month);


	//gib status gonderildi veya kaydedildi olanlar disindakiler icin komisyon olustur
	@Modifying
	@Query(value =
			" INSERT INTO CUSTOMER.EKGB_COMMISSION (AGENCY_CODE,COMPANY, YEAR, MONTH, TOTAL_CANCEL_AMOUNT, TOTAL_PRODUCTION_AMOUNT, GIB_STATUSID, KEP_STATUSID, KEP_STATUS) "
					+ "SELECT " +
					"       AGENCY_CODE," +
					"       COMPANY, " +
					"       YEAR, " +
					"       MONTH, " +
					"       SUM(CANCEL_AMOUNT) AS TOTAL_CANCEL_AMOUNT , " +
					"       SUM(PRODUCTION_AMOUNT) AS TOTAL_PRODUCTION_AMOUNT, " +
					"       0 AS GIB_STATUSID , " +
					"       0 AS KEP_STATUSID , " +
					"       ' ' AS KEP_STATUS" +
					"      FROM CUSTOMER.EKGB_COMMISSION_DETAIL" +
					"      WHERE YEAR = :year AND MONTH = :month "	+
					"      AND NOT((COMPANY = 'AZS' AND AGENCY_CODE IN (1, 999, 1923, 3180, 3181, 3185))OR (COMPANY = 'YE' AND AGENCY_CODE IN (2481)))" + //Serkan Istar exclude edilmesini istedi
					"      AND ID NOT IN" +
					"      (" +
					"        SELECT D.ID" +
					"        FROM CUSTOMER.EKGB_COMMISSION_DETAIL D INNER JOIN CUSTOMER.EKGB_COMMISSION C ON" +
					"          D.AGENCY_CODE = C.AGENCY_CODE AND" +
					"          D.COMPANY = C.COMPANY AND" +
					"          D.YEAR = C.YEAR AND" +
					"          D.MONTH = C.MONTH " +
					"        WHERE 	C.YEAR = :year AND C.MONTH = :month" +
					"				AND (GIB_STATUSID = 2 OR GIB_STATUSID = 3) " +
					"      )" +
					"	   HAVING SUM(CANCEL_AMOUNT)>0 OR SUM(PRODUCTION_AMOUNT)>0 " +
					"      GROUP BY AGENCY_CODE,COMPANY, YEAR, MONTH"
			, nativeQuery = true)
	void createCommissionData(@Param("year") int year, @Param("month") int month);

	@Modifying
	@Query(value = "UPDATE" +
			"        CUSTOMER.EKGB_COMMISSION C " +
			"    SET" +

			"        (C.AGENCY_TAX_OFFICE, C.AGENCY_TAX_NO, C.AGENCY_TITLE, C.KEP_ADDRESS, C.AGENCY_ADDRESS) = (  " +
			"        SELECT" +
			"            P.Tax_Office,COALESCE(P.Tax_Number,P.Identity_No), T.title AS TITLE, D.Explanation, customer.koc_address_utils.address(" +

//			"        (C.AGENCY_TAX_OFFICE, C.AGENCY_TAX_NO, C.AGENCY_TITLE, C.AGENCY_ADDRESS) = (  " +
//			"        SELECT" +
//			"            P.Tax_Office,COALESCE(P.Tax_Number,P.Identity_No), T.title AS TITLE, customer.koc_address_utils.address(" +

			"              COALESCE(" +
			"              (SELECT add_id  FROM koc_cp_address_links   " +
			"                 WHERE  PART_ID = TO_NUMBER(substr(A.CUST_PART_UNIQUE_CODE,10)) " +
			"                        AND PURPOSE='AW' " +
			"                        AND TO_DATE is NULL " +
			"                        AND ROWNUM = 1" +
			"              ), " +
			"              (SELECT add_id  FROM koc_cp_address_links   " +
			"               WHERE    PART_ID = TO_NUMBER(substr(A.CUST_PART_UNIQUE_CODE,10)) " +
			"                        AND PURPOSE='WK' " +
			"                        AND TO_DATE is NULL " +
			"                        AND ROWNUM = 1)," +
			"              (SELECT add_id  FROM koc_cp_address_links   " +
			"               WHERE    PART_ID = TO_NUMBER(substr(A.CUST_PART_UNIQUE_CODE,10)) " +
			"                        AND PURPOSE='HM' " +
			"                        AND TO_DATE is NULL " +
			"                        AND ROWNUM = 1)" +
			"              ))" +
			"        FROM" +
			"            koc_dmt_agents_title_ext T " +
			"        INNER JOIN" +
			"            dmt_agents A " +
			"                ON T.INT_ID=A.INT_ID " +
			"                AND SYSDATE > T.VALIDITY_START_DATE " +
			"                AND SYSDATE < T.VALIDITY_END_DATE    " +
			"        LEFT JOIN" +
			"            koc_cp_comm_devices D ON D.PART_ID =  TO_NUMBER(substr(A.CUST_PART_UNIQUE_CODE, 10)) " +
			"            AND D.COMM_DEV_TYPE = '0091' " +
			"            AND D.VALIDITY_END_DATE is null    " +
			"        INNER JOIN" +
			"            koc_cp_partners_ext P ON P.PART_ID = substr(A.CUST_PART_UNIQUE_CODE, 10)  " +
			"        WHERE" +
			"            A.Reference_Code = TO_CHAR(C.AGENCY_CODE))" +
			"    WHERE" +
			"        C.YEAR = :year " +
			"        AND C.MONTH = :month" +
			"        AND COMPANY = 'AZS'"

			, nativeQuery = true)
	void getAddressDataAZS(@Param("year") int year, @Param("month") int month);


	@Modifying
	@Query(value =

			"UPDATE CUSTOMER.EKGB_COMMISSION C" +
			"   SET (C.AGENCY_TAX_OFFICE," +
			"        C.AGENCY_TAX_NO," +
			"        C.AGENCY_TITLE," +
			"        C.AGENCY_ADDRESS) =" +
			"        " +
			"       (SELECT AGENCY_TAX_OFFICE," +
			"               AGENCY_TAX_NO," +
			"               AGENCY_TITLE," +
			"               AGENCY_ADDRESS" +
			"          FROM (" +
			"                " +
			"                SELECT  AllDates.*," +
			"                        ROW_NUMBER() OVER(PARTITION BY AllDates.Agency_Code ORDER BY AllDates.Start_Date DESC, AllDates.Validity_Start_Date DESC) AS rn" +
			"                  FROM (SELECT A.START_DATE," +
			"                                T.VALIDITY_START_DATE," +
			"                                AGENCY_CODE," +
			"                                P.Tax_Office AS AGENCY_TAX_OFFICE," +
			"                                COALESCE(P.Tax_Number, P.Identity_No) AS AGENCY_TAX_NO," +
			"                                T.title AS AGENCY_TITLE," +
			"                                customer.koc_address_utils.address(" +
			"                                                                   COALESCE((SELECT add_id" +
			"                                                                              FROM koc_cp_address_links" +
			"                                                                             WHERE PART_ID =" +
			"                                                                                   TO_NUMBER(substr(A.CUST_PART_UNIQUE_CODE, 10))" +
			"                                                                               AND PURPOSE = 'AW'" +
			"                                                                               AND TO_DATE is NULL" +
			"                                                                               AND ROWNUM = 1)," +
			"                                                                            (SELECT add_id" +
			"                                                                               FROM koc_cp_address_links" +
			"                                                                              WHERE PART_ID =" +
			"                                                                                    TO_NUMBER(substr(A.CUST_PART_UNIQUE_CODE, 10))" +
			"                                                                                AND PURPOSE = 'WK'" +
			"                                                                                AND TO_DATE is NULL" +
			"                                                                                AND ROWNUM = 1)," +
			"                                                                            (SELECT add_id" +
			"                                                                               FROM koc_cp_address_links" +
			"                                                                              WHERE PART_ID =" +
			"                                                                                    TO_NUMBER(substr(A.CUST_PART_UNIQUE_CODE, 10))" +
			"                                                                                AND PURPOSE = 'HM'" +
			"                                                                                AND TO_DATE is NULL" +
			"                                                                                AND ROWNUM = 1))) AS AGENCY_ADDRESS" +
			"                           FROM koc_dmt_agents_title_ext T" +
			"                          INNER JOIN dmt_agents A" +
			"                             ON T.INT_ID = A.INT_ID" +
			"                           LEFT JOIN koc_cp_comm_devices D" +
			"                             ON D.PART_ID =" +
			"                                TO_NUMBER(substr(A.CUST_PART_UNIQUE_CODE, 10))" +
			"                            AND D.COMM_DEV_TYPE = '0091'" +
			"                            AND D.VALIDITY_END_DATE is null" +
			"                          INNER JOIN koc_cp_partners_ext P" +
			"                             ON P.PART_ID = substr(A.CUST_PART_UNIQUE_CODE, 10)" +
			"                          INNER JOIN koc_dmt_agents_ext A2" +
			"                             ON A2.INT_ID = A.INT_ID" +
			"                          WHERE A2.KOC_ALLIANZ_LIFE_AGENT_CODE =" +
			"                                TO_CHAR(C.AGENCY_CODE)" +
			"                         " +
			"                         ) AllDates" +
			"                " +
			"                ) Partitioned" +
			"         WHERE rn = 1)" +
			"WHERE C.YEAR = :year" +
			"   AND C.MONTH = :month" +
			"   AND COMPANY = 'HE'" +
			"   AND AGENCY_CODE NOT IN (2985, 2854)"

			, nativeQuery = true)
	void getAddressDataHE(@Param("year") int year, @Param("month") int month);


	@Modifying
	@Query(value = "UPDATE" +
			"        CUSTOMER.EKGB_COMMISSION C " +
			"    SET" +

			"        (C.AGENCY_TAX_OFFICE, C.AGENCY_TAX_NO, C.AGENCY_TITLE, C.KEP_ADDRESS, C.AGENCY_ADDRESS) = (  " +
			"        SELECT" +
			"            P.Tax_Office,COALESCE(P.Tax_Number,P.Identity_No), T.title AS TITLE, D.Explanation, customer.koc_address_utils.address(" +

//			"        (C.AGENCY_TAX_OFFICE, C.AGENCY_TAX_NO, C.AGENCY_TITLE, C.AGENCY_ADDRESS) = (  " +
//			"        SELECT" +
//			"            P.Tax_Office,COALESCE(P.Tax_Number,P.Identity_No), T.title AS TITLE, customer.koc_address_utils.address(" +

			"              COALESCE(" +
			"              (SELECT add_id  FROM koc_cp_address_links   " +
			"                 WHERE  PART_ID = TO_NUMBER(substr(A.CUST_PART_UNIQUE_CODE,10)) " +
			"                        AND PURPOSE='AW' " +
			"                        AND TO_DATE is NULL " +
			"                        AND ROWNUM = 1" +
			"              ), " +
			"              (SELECT add_id  FROM koc_cp_address_links   " +
			"               WHERE    PART_ID = TO_NUMBER(substr(A.CUST_PART_UNIQUE_CODE,10)) " +
			"                        AND PURPOSE='WK' " +
			"                        AND TO_DATE is NULL " +
			"                        AND ROWNUM = 1)," +
			"              (SELECT add_id  FROM koc_cp_address_links   " +
			"               WHERE    PART_ID = TO_NUMBER(substr(A.CUST_PART_UNIQUE_CODE,10)) " +
			"                        AND PURPOSE='HM' " +
			"                        AND TO_DATE is NULL " +
			"                        AND ROWNUM = 1)" +
			"              ))" +
			"        FROM" +
			"            koc_dmt_agents_title_ext T " +
			"        INNER JOIN" +
			"            dmt_agents A " +
			"                ON T.INT_ID=A.INT_ID " +
			"                AND SYSDATE > T.VALIDITY_START_DATE " +
			"                AND SYSDATE < T.VALIDITY_END_DATE    " +
			"        LEFT JOIN" +
			"            koc_cp_comm_devices D ON D.PART_ID =  TO_NUMBER(substr(A.CUST_PART_UNIQUE_CODE, 10)) " +
			"            AND D.COMM_DEV_TYPE = '0091' " +
			"            AND D.VALIDITY_END_DATE is null    " +
			"        INNER JOIN" +
			"            koc_cp_partners_ext P ON P.PART_ID = substr(A.CUST_PART_UNIQUE_CODE, 10)  " +
			"        WHERE" +
			"            A.Reference_Code = " +
			"			CASE " +
			"		          WHEN C.AGENCY_CODE = 2985 THEN '8711-706'  " +  //--AZS partajı HSBC
			"		          WHEN C.AGENCY_CODE = 2854 THEN '8329'      " +  //--AZS partajı KOÇ Finansman
			"		          ELSE TO_CHAR(C.AGENCY_CODE) " +
			"			END )" +
			"    WHERE" +
			"        C.YEAR = :year " +
			"        AND C.MONTH = :month" +
			"        AND COMPANY = 'HE'"
			+ "		 AND AGENCY_CODE IN (2985, 2854)"

			, nativeQuery = true)
	void getAddressDataHeHsbcKoc(@Param("year") int year, @Param("month") int month);





	@Modifying
	@Query(value =
			"UPDATE CUSTOMER.EKGB_COMMISSION C" +
					"   SET (C.AGENCY_TAX_OFFICE," +
					"        C.AGENCY_TAX_NO," +
					"        C.AGENCY_TITLE," +
					"        C.AGENCY_ADDRESS) =" +
					"        " +
					"       (SELECT AGENCY_TAX_OFFICE," +
					"               AGENCY_TAX_NO," +
					"               AGENCY_TITLE," +
					"               AGENCY_ADDRESS" +
					"          FROM (" +
					"                " +
					"                SELECT  AllDates.*," +
					"                        ROW_NUMBER() OVER(PARTITION BY AllDates.Agency_Code ORDER BY AllDates.Start_Date DESC, AllDates.Validity_Start_Date DESC) AS rn" +
					"                  FROM (SELECT A.START_DATE," +
					"                                T.VALIDITY_START_DATE," +
					"                                AGENCY_CODE," +
					"                                P.Tax_Office AS AGENCY_TAX_OFFICE," +
					"                                COALESCE(P.Tax_Number, P.Identity_No) AS AGENCY_TAX_NO," +
					"                                T.title AS AGENCY_TITLE," +
					"                                customer.koc_address_utils.address(" +
					"                                                                   COALESCE((SELECT add_id" +
					"                                                                              FROM koc_cp_address_links" +
					"                                                                             WHERE PART_ID =" +
					"                                                                                   TO_NUMBER(substr(A.CUST_PART_UNIQUE_CODE, 10))" +
					"                                                                               AND PURPOSE = 'AW'" +
					"                                                                               AND TO_DATE is NULL" +
					"                                                                               AND ROWNUM = 1)," +
					"                                                                            (SELECT add_id" +
					"                                                                               FROM koc_cp_address_links" +
					"                                                                              WHERE PART_ID =" +
					"                                                                                    TO_NUMBER(substr(A.CUST_PART_UNIQUE_CODE, 10))" +
					"                                                                                AND PURPOSE = 'WK'" +
					"                                                                                AND TO_DATE is NULL" +
					"                                                                                AND ROWNUM = 1)," +
					"                                                                            (SELECT add_id" +
					"                                                                               FROM koc_cp_address_links" +
					"                                                                              WHERE PART_ID =" +
					"                                                                                    TO_NUMBER(substr(A.CUST_PART_UNIQUE_CODE, 10))" +
					"                                                                                AND PURPOSE = 'HM'" +
					"                                                                                AND TO_DATE is NULL" +
					"                                                                                AND ROWNUM = 1))) AS AGENCY_ADDRESS" +
					"                           FROM koc_dmt_agents_title_ext T" +
					"                          INNER JOIN dmt_agents A" +
					"                             ON T.INT_ID = A.INT_ID" +
					"                           LEFT JOIN koc_cp_comm_devices D" +
					"                             ON D.PART_ID =" +
					"                                TO_NUMBER(substr(A.CUST_PART_UNIQUE_CODE, 10))" +
					"                            AND D.COMM_DEV_TYPE = '0091'" +
					"                            AND D.VALIDITY_END_DATE is null" +
					"                          INNER JOIN koc_cp_partners_ext P" +
					"                             ON P.PART_ID = substr(A.CUST_PART_UNIQUE_CODE, 10)" +
					"                          INNER JOIN koc_dmt_agents_ext A2" +
					"                             ON A2.INT_ID = A.INT_ID" +
					"                          WHERE A2.AZYE_AGENT_CODE =" +
					"                                TO_CHAR(C.AGENCY_CODE)" +
					"                         " +
					"                         ) AllDates" +
					"                " +
					"                ) Partitioned" +
					"         WHERE rn = 1)" +
					"WHERE C.YEAR = :year" +
					"   AND C.MONTH = :month" +
					"   AND COMPANY = 'YE'"

			, nativeQuery = true)
	void getAddressDataYE(@Param("year") int year, @Param("month") int month);

	@Modifying
	@Query(value =
			" UPDATE CUSTOMER.EKGB_COMMISSION C SET C.AGENCY_TITLE = N'YAPI VE KREDİ BANKASI A.Ş.', " +
					"        C.AGENCY_TAX_OFFICE = N'BÜYÜK MÜKELLEFLER VERGİ DAİRESİ BAŞKANLIĞI', " +
					"        C.AGENCY_TAX_NO = '9370020892', /*C.KEP_ADDRESS =  '',*/ " +
					"        C.AGENCY_ADDRESS = N'BÜYÜKDERE CAD. D BLOK/ 34330 İSTANBUL' " +
					" WHERE C.Agency_Code=1 AND C.YEAR = :year AND C.MONTH = :month AND C.COMPANY = 'YE' "
			, nativeQuery = true)
	void


	updateCustomAddressData_YE_1(@Param("year") int year, @Param("month") int month);


	@Modifying
	@Query(value =
			" UPDATE CUSTOMER.EKGB_COMMISSION C SET C.AGENCY_TITLE = N'TİMURLAR SİGORTA ARACILIK HİZMETLERİ LTD.ŞTİ.', " +
					"        C.AGENCY_TAX_OFFICE = N'OSTİM', " +
					"        C.AGENCY_TAX_NO = '8440449300', /*C.KEP_ADDRESS =  '',*/ " +
					"        C.AGENCY_ADDRESS = N'TÜRKİYE, Ankara 6680, Çankay, Kavaklıdere MAH, OSB Olgunlar Caddesi NO:36/A 13 D:2/14' " +
					" WHERE C.Agency_Code=8569 AND C.YEAR = :year AND C.MONTH = :month AND C.COMPANY = 'AZS' "
			, nativeQuery = true)
	void updateCustomAddressData_AZS_8569(@Param("year") int year, @Param("month") int month);


	@Modifying
	@Query(value =
			" UPDATE CUSTOMER.EKGB_COMMISSION C SET C.AGENCY_TITLE = N'YAPI VE KREDİ BANKASI A.Ş. GENEL MÜDÜRLÜK', " +
					"        C.AGENCY_TAX_OFFICE = N'BÜYÜK MÜKELLEFLER VERGİ DAİRESİ BAŞKANLIĞI', " +
					"        C.AGENCY_TAX_NO = '9370020892', /*C.KEP_ADDRESS =  '',*/ " +
					"        C.AGENCY_ADDRESS = N'TÜRKİYE, BEŞİKTAŞ, BÜYÜKDERE CAD. YAPI KREDİ PLAZA D BLOK, 34330 İSTANBUL' " +
					" WHERE C.Agency_Code=7001 AND C.YEAR = :year AND C.MONTH = :month AND C.COMPANY = 'YE' "
			, nativeQuery = true)
	void updateCustomAddressData_YE_7001(@Param("year") int year, @Param("month") int month);


	@Modifying
	@Query(value =
			" UPDATE CUSTOMER.EKGB_COMMISSION C SET C.AGENCY_TITLE = N'AKIN SİGORTA ARA. HİZ. LTD.ŞTİ.', " +
					"        C.AGENCY_TAX_OFFICE = N'MİTHATPAŞA', " +
					"        C.AGENCY_TAX_NO = '0280135934', /*C.KEP_ADDRESS =  '',*/ " +
					"        C.AGENCY_ADDRESS = N'TÜRKİYE, ANKARA, ÇANKAYA, KIZILAY MH. ATATÜRK BUL NO: 103 D:19-20' " +
					" WHERE C.Agency_Code=852 AND C.YEAR = :year AND C.MONTH = :month AND C.COMPANY = 'YE' "
			, nativeQuery = true)
	void updateCustomAddressData_YE_852(@Param("year") int year, @Param("month") int month);



	//-------   Commission Transfer operations ---------END





	//Sadece Filenet e kadedilmis olanlar
	@Query(value = "SELECT * FROM CUSTOMER.EKGB_COMMISSION WHERE COMPANY = :company AND AGENCY_CODE = :agency AND YEAR = :year AND MONTH = :month AND GIB_STATUSID = 3 ", nativeQuery = true)
	List<Commission> findByAgencyYearMonth(@Param("company") String company, @Param("agency") int agencyCode,
										   @Param("year") int year, @Param("month") int month);


	@Query("""
    SELECT c
    FROM Commission c
    WHERE (:filterCompany = false OR c.company IN :company)
      AND (:filterKepStatus = false OR c.kepStatusId IN :kepStatusIds)
      AND (:filterGibStatus = false OR c.gibStatusId IN :gibStatusIds)
      AND (:agencyCode IS NULL OR c.agency = :agencyCode)
      AND (:agencyTaxNo IS NULL OR c.agencyTaxNo = :agencyTaxNo)
      AND (:year IS NULL OR c.year = :year)
      AND (:month IS NULL OR c.month = :month)
    """)
	Page<Commission> findFilteredPaged(
			@Param("filterCompany") boolean filterCompany,
			@Param("company") List<String> company,
			@Param("filterKepStatus") boolean filterKepStatus,
			@Param("kepStatusIds") List<Integer> kepStatusIds,
			@Param("filterGibStatus") boolean filterGibStatus,
			@Param("gibStatusIds") List<Integer> gibStatusIds,
			@Param("agencyCode") Integer agencyCode,
			@Param("agencyTaxNo") String agencyTaxNo,
			@Param("year") Integer year,
			@Param("month") Integer month,
			Pageable pageable);



		@Query("""
		SELECT c.Id
		FROM Commission c
		WHERE (:filterCompany = false OR c.company IN :company)
		  AND (:filterKepStatus = false OR c.kepStatusId IN :kepStatusIds)
		  AND (:filterGibStatus = false OR c.gibStatusId IN :gibStatusIds)
		  AND (:agencyCode IS NULL OR c.agency = :agencyCode)
		  AND (:agencyTaxNo IS NULL OR c.agencyTaxNo = :agencyTaxNo)
		  AND (:year IS NULL OR c.year = :year)
		  AND (:month IS NULL OR c.month = :month)
		""")
		List<Integer> findFilteredIds(
			@Param("filterCompany") boolean filterCompany,
			@Param("company") List<String> company,
			@Param("filterKepStatus") boolean filterKepStatus,
			@Param("kepStatusIds") List<Integer> kepStatusIds,
			@Param("filterGibStatus") boolean filterGibStatus,
			@Param("gibStatusIds") List<Integer> gibStatusIds,
			@Param("agencyCode") Integer agencyCode,
			@Param("agencyTaxNo") String agencyTaxNo,
			@Param("year") Integer year,
			@Param("month") Integer month);


	@Query(value = "SELECT new tr.com.allianz.ekgb.model.CommissionXlsDto(" +
			"C.agency, C.company, C.year, C.month, " +
			"C.totalCancelAmount, C.totalProductionAmount, C.gibStatusId, " +
			"C.kepStatusId, C.kepAddress, C.agencyTitle, C.agencyAddress, " +
			"C.agencyTaxOffice, C.agencyTaxNo, C.recordCancelDate, " +
			"SUM(CASE WHEN D.dataSource = 'OPUS' THEN D.productionAmount ELSE 0.00BD END), " +
			"SUM(CASE WHEN D.dataSource = 'AS400' THEN D.productionAmount ELSE 0.00BD END), " +
			"SUM(CASE WHEN D.dataSource = 'ABS' THEN D.productionAmount ELSE 0.00BD END), " +
			"SUM(CASE WHEN D.dataSource = 'MAGIC' THEN D.productionAmount ELSE 0.00BD END), " +
			"SUM(CASE WHEN D.dataSource = 'OPUS' THEN D.cancelAmount ELSE 0.00BD END), " +
			"SUM(CASE WHEN D.dataSource = 'AS400' THEN D.cancelAmount ELSE 0.00BD END), " +
			"SUM(CASE WHEN D.dataSource = 'ABS' THEN D.cancelAmount ELSE 0.00BD END), " +
			"SUM(CASE WHEN D.dataSource = 'MAGIC' THEN D.cancelAmount ELSE 0.00BD END)) " +
			"FROM Commission C " +
			"LEFT JOIN CommissionDetail D ON D.company = C.company " +
			"AND D.agency = C.agency AND D.year = C.year AND D.month = C.month " +
			"WHERE (:filterCompany = false OR C.company IN (:company)) " +
			"AND (:filterKepStatus = false OR C.kepStatusId IN (:kepStatusIds)) " +
			"AND (:filterGibStatus = false OR C.gibStatusId IN (:gibStatusIds)) " +
			"AND (:agencyCode IS NULL OR C.agency = :agencyCode) " +
			"AND (:agencyTaxNo IS NULL OR C.agencyTaxNo = :agencyTaxNo) " +
			"AND (:year IS NULL OR C.year = :year) " +
			"AND (:month IS NULL OR C.month = :month) " +
			"GROUP BY C.agency, C.company, C.year, C.month, " +
			"C.totalCancelAmount, C.totalProductionAmount, C.gibStatusId, " +
			"C.kepStatusId, C.kepAddress, C.agencyTitle, C.agencyAddress, " +
			"C.agencyTaxOffice, C.agencyTaxNo, C.recordCancelDate")
	List<CommissionXlsDto> findFiltered(
			@Param("filterCompany") boolean filterCompany,
			@Param("company") List<String> company,
			@Param("filterKepStatus") boolean filterKepStatus,
			@Param("kepStatusIds") List<Integer> kepStatusIds,
			@Param("filterGibStatus") boolean filterGibStatus,
			@Param("gibStatusIds") List<Integer> gibStatusIds,
			@Param("agencyCode") Integer agencyCode,
			@Param("agencyTaxNo") String agencyTaxNo,
			@Param("year") Integer year,
			@Param("month") Integer month);


}
