package tr.com.allianz.ekgb.service;

import java.util.List;

import jakarta.annotation.PostConstruct;
import javax.xml.ws.Holder;
import org.apache.cxf.endpoint.Client;
import org.apache.cxf.frontend.ClientProxy;
import org.apache.cxf.jaxws.JaxWsProxyFactoryBean;
import org.apache.cxf.transport.http.HTTPConduit;
import org.apache.cxf.transports.http.configuration.HTTPClientPolicy;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import com.cs.csap.service.SigortaKomisyonWebService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import tr.com.cs.uut.earsiv.service.Belge;
import tr.com.cs.uut.earsiv.service.BelgeDTO;
import tr.com.cs.uut.earsiv.service.EarsivServiceResult;


@Slf4j
@RequiredArgsConstructor
@Service
public class EkgbGibServiceImpl implements EkgbGibService {

	public SigortaKomisyonWebService ekgbGibService;

	
	private final Environment env;

	@PostConstruct
	public void createProxy() {
		try {
			JaxWsProxyFactoryBean factory = new JaxWsProxyFactoryBean();
			factory.setServiceClass(SigortaKomisyonWebService.class);
			factory.setAddress(env.getProperty("qnbkgb-service.url"));
			ekgbGibService = (SigortaKomisyonWebService) factory.create();

			Client client = ClientProxy.getClient(ekgbGibService);
			HTTPConduit httpConduit = (HTTPConduit) client.getConduit();
			HTTPClientPolicy httpClientPolicy = new HTTPClientPolicy();
			httpClientPolicy.setReceiveTimeout(180000);//3 dakika
			httpConduit.setClient(httpClientPolicy);
		} catch (RuntimeException | LinkageError failure) {
			log.error("GIB SOAP proxy initialization failed", failure);
			throw failure;
		}
	}
	

	/* (non-Javadoc)
	 * @see tr.com.allianz.ekgb.service.EkgbGibService#sigortaKomisyonOlustur(java.lang.String, tr.com.cs.uut.earsiv.service.Belge, javax.xml.ws.Holder)
	 */
	@Override
	public EarsivServiceResult sigortaKomisyonOlustur(String input, Belge belge, Holder<Belge> output) {
		EarsivServiceResult belgeOutputWrapper = ekgbGibService.sigortaKomisyonOlustur(input, belge, output);
		return belgeOutputWrapper;
	}
	
	
	/* (non-Javadoc)
	 * @see tr.com.allianz.ekgb.service.EkgbGibService#sigortaKomisyonSorgula(java.lang.String, javax.xml.ws.Holder)
	 */
	@Override
	public EarsivServiceResult sigortaKomisyonSorgula(String input, Holder<Belge> output) {
		EarsivServiceResult belgeOutputWrapper = ekgbGibService.sigortaKomisyonSorgula(input, output);
		return belgeOutputWrapper;
	}
	

	/* (non-Javadoc)
	 * @see tr.com.allianz.ekgb.service.EkgbGibService#sigortaKomisyonIptalEt(java.lang.String)
	 */
	@Override
	public EarsivServiceResult sigortaKomisyonIptalEt(String input) {
		EarsivServiceResult belgeOutputWrapper = ekgbGibService.sigortaKomisyonIptalEt(input);
		return belgeOutputWrapper;
	}


	@Override
	public EarsivServiceResult sigortaKomisyonListe(String input, Holder<List<BelgeDTO>> output) {
		EarsivServiceResult r = ekgbGibService.sigortaKomisyonListeSorgula(input, output);
		return r;
	}
	
	
	
}