package tr.com.allianz.ekgb.service.filenet;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class GetDocumentOutput {

	
	private String doc_ID;
	private String resultCode;
	private String resultMessage;
	private CreateDocumentDocContentInput doc_Content;
	private List<CreateDocumentDocPropertyInput> doc_Properties;
	
	
}
