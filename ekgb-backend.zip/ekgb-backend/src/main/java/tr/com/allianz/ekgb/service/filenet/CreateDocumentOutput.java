package tr.com.allianz.ekgb.service.filenet;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreateDocumentOutput {

	
	private String doc_ID;
	private String resultCode;
	private String resultMessage;
	
}
