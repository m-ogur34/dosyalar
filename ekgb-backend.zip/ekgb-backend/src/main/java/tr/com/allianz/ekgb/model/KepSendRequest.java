package tr.com.allianz.ekgb.model;

import java.util.List;

public class KepSendRequest {

	public List<Long> ids;
	

}
