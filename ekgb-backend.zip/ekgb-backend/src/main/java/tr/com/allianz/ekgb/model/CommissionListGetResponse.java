package tr.com.allianz.ekgb.model;

import lombok.Builder;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public class CommissionListGetResponse  extends ResponseBase implements ResponseBaseContract {
	public long totalElements;
	public int totalPages;
	
	@Builder
	public CommissionListGetResponse (	
	 ResponseMessageStatus responseMessageStatus,
	 ResponseMessage[] responseMessage,
	 Object data) {
		super(responseMessageStatus, responseMessage, data);
	}
	
}
