package tr.com.allianz.ekgb.entity.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum MonthCurrentOperation {
	IDLE(0), COLLECTING_DATA(1), GENERATING_KGB(2), SENDING_KEP(3),ERROR(9);

	@Getter
	private int value;

	@Getter
	private String name;

	MonthCurrentOperation(int value) {
		name = name();
		this.value = value;
	}

}
