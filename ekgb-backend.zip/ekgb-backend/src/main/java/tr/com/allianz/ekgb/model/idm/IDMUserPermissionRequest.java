package tr.com.allianz.ekgb.model.idm;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class IDMUserPermissionRequest {

    private String actionCode;
    private String endorseReasonCode;
    private String endorsementNo;
    private String pageName;
    private String partitionType;
    private Long productId;
    private String projectId;
    private String userName;
    private String userType;
}
