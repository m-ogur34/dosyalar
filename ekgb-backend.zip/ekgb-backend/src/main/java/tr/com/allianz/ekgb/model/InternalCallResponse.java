package tr.com.allianz.ekgb.model;

public class InternalCallResponse extends ResponseBase implements ResponseBaseContract {

}