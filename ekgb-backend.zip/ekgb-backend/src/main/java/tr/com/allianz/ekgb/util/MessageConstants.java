package tr.com.allianz.ekgb.util;

import tr.com.allianz.ekgb.model.ResponseBase;

public class MessageConstants {

	public static final String VALIDATION_BINDING_ERROR = "Request parameter binding error. Check input.";

	public static final String INTERNAL_ERROR = "Beklenmeyen bir hata oluştu.<br>${errorMessage}";
	
	
	public static final String EKGB_NO_COMMISSION_SELECTED = "Seçilmiş komisyon bulunmamaktadır.";
	public static final String EKGB_MONTH_CLOSED = "İşlem yapmak istediğiniz ay kapalı.";
	public static final String EKGB_MONTH_OPERATION_IN_PROGGRESS = "Seçili ay üzerinde zaten işlem yapılıyor! Daha sonra deneyiniz.";
	public static final String EKGB_MONTH_NOTFOUND = "Yil-Ay mevcut değil.";
	
	public static final String EKGB_CANCEL_PROVIDER_ERROR = "Servis hatası. log kontrol ediniz";
	
	
	public static final String EKGB_SOURCEDATA_COMPANYNAME_ERROR = "Şirket adı: AZS, HE veya YE olmalı!";
	public static final String EKGB_AGENCY_MISSING_DATA = "Ünvan, Adres, VKN-TCKN veya Vergi Dairesi eksik!";
	
	
	public static final String FILENET_SERVICE_ERROR = "Filenet servis hatası.";
	
	
	public static final String COLLECT_COMMISSION_DELETE_TEMP_COMMISSION_DETAILS = "Geçici komisyon detayları siliniyor geçici";
	public static final String COLLECT_COMMISSION_DELETE_COMMISSION_DETAILS = "Komisyon detayları siliniyor";
	public static final String COLLECT_COMMISSION_DELETE_COMMISSIONS = "Komisyonlar siliniyor";
	
	public static final String COLLECT_COMMISSION_TRANSFER_COMMISSION ="Komisyon detay bilgileri aktarılıyor";
	public static final String COLLECT_COMMISSION_CREATE_COMMISSION ="Komisyon detay bilgileri aktarılıyor";
	public static final String COLLECT_COMMISSION_UPDATE_ADDRESS_AZS ="AZS adres bilgisi alınıyor";
	public static final String COLLECT_COMMISSION_UPDATE_ADDRESS_HE ="HE adres bilgisi alınıyor";
	public static final String COLLECT_COMMISSION_UPDATE_ADDRESS_YE ="YE adres bilgisi alınıyor";
	public static final String COLLECT_COMMISSION_UPDATE_ADDRESS_CUSTOM = "HSBC ve KOC adres bilgisi alınıyor";
	public static final String COLLECT_COMMISSION_UPDATE_ADDRESS_CUSTOM2 = "Manuel adres bilgisi güncelleniyor";
	
	public static final String COLLECT_COMMISSION_UPDATE_MONTH_STATISTICS = "Ay bilgilerini güncelle";
	
	
	
	public static final String COLLECT_COMMISSION_OPUS = "OPUS komisyonlar bilgileri alınıyor";
	public static final String COLLECT_COMMISSION_AS400 = "AS400 komisyonlar bilgileri alınıyor";
	public static final String COLLECT_COMMISSION_MAGIC = "MAGIC komisyonlar bilgileri alınıyor";
	public static final String COLLECT_COMMISSION_ABS = "ABS komisyonlar bilgileri alınıyor";
	
	public static final String MESSAAGE_SEPARATOR = " --- ";

	public static final String VALIDATION_COMMISSION_GET_REQUEST_PRODUCTIONCANCELZERO = "İptal ve istihsal aynı kayıtta 0 olamaz. En az biri sıfırdan büyük olmalı.";

	public static String internalErrorMessage(Exception e) {
		String errorMessage=e.getMessage()==null ? "" :e.getMessage(); 
		return INTERNAL_ERROR.replace("${errorMessage}", errorMessage);
	}
	
	
}
