package tr.com.allianz.ekgb.security.user;

public interface UserProfileInfoService {

    UserProfileInfo getUserInfo();

    String getJwtToken();

}
