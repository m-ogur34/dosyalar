package tr.com.allianz.ekgb.model;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;


@AllArgsConstructor
@NoArgsConstructor
@Data
public class CommissionXlsDto {

	private Integer agency;
	private String company;
	private Integer year;
	private Integer month;
	private BigDecimal totalCancelAmount;
	private BigDecimal totalProductionAmount;
	private Integer gibStatusId;
	private Integer kepStatusId;
	private String kepAddress;
	private String agencyTitle;
	private String agencyAddress;
	private String agencyTaxOffice;
	private String agencyTaxNo;
	private LocalDateTime recordCancelDate;
	
	private BigDecimal productionAmountOPUS;
	private BigDecimal productionAmountAS400;
	private BigDecimal productionAmountABS;
	private BigDecimal productionAmountMAGIC;

	private BigDecimal cancelAmountOPUS;
	private BigDecimal cancelAmountAS400;
	private BigDecimal cancelAmountABS;
	private BigDecimal cancelAmountMAGIC;


	
}
