package tr.com.allianz.ekgb.entity.enums;

import java.util.Arrays;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum KepStatus {
	GONDERIM_BEKLENIYOR(0),GONDERILIYOR(1), GONDERILDI(2);
	
	@Getter
	private int value;

	@Getter
	private String name;

	KepStatus(int value) {
		name = name();
		this.value = value;
	}
	public static  String getNameByValue(int value) {
		List<KepStatus> kepStatusList = Arrays.asList(KepStatus.values());
		KepStatus status = kepStatusList.stream().filter(s -> s.value == value).findAny().orElse(null);
		return status == null ? "" : status.name;
	}
}
