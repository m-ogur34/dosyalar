package tr.com.allianz.ekgb.model;

public class CloseMonthResponse  extends ResponseBase implements ResponseBaseContract {

}
