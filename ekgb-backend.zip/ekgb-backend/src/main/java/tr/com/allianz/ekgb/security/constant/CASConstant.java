package tr.com.allianz.ekgb.security.constant;

import java.util.Arrays;
import java.util.List;

public class CASConstant {

    public static final String AUTHORIZATION_TOKEN_KEY = "Authorization";
    public static final String TOKEN = "token";
    public static final String CAS_ESB_ENDPOINT = "casEsbEndpoint";

   public static final List<String> AUTH_WHITELIST = Arrays.asList("/swagger-resources/**", "/swagger-ui.html", "/v2/api-docs", "/webjars/**","/api/v3/**");
}
