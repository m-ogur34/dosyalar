package tr.com.allianz.ekgb.service.xls;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

import lombok.RequiredArgsConstructor;
import tr.com.allianz.ekgb.entity.enums.AllianzCompany;
import tr.com.allianz.ekgb.entity.enums.GibStatus;
import tr.com.allianz.ekgb.entity.enums.KepStatus;
import tr.com.allianz.ekgb.model.CommissionXlsDto;
import tr.com.allianz.ekgb.model.EkgbPeriod;
import tr.com.allianz.ekgb.model.FilteredCommissionsRequest;
import tr.com.allianz.ekgb.model.GibEkgbListItem;
import tr.com.allianz.ekgb.model.ResponseBaseContract;
import tr.com.allianz.ekgb.model.ResponseMessageStatus;
import tr.com.allianz.ekgb.service.CommissionService;
import tr.com.allianz.ekgb.service.email.NotifierImpl;
import tr.com.allianz.ekgb.util.EkgbConstants;

@RequiredArgsConstructor
@Service
public class CommissionXLSServiceImpl extends AbstractXLSCreatorService implements CommissionXLSService {

	private final CommissionService commissionService;

	private static final List<String> COMMISSION_HEADER_LIST = Arrays.asList("Şirket", "Partaj", "Ünvan", "Yıl", "Ay",
			"Toplam İstihsal", "Toplam İptal", "OPUS Üretim", "OPUS İptal", "AS400 Üretim", "AS400 İptal", "ABS Üretim",
			"ABS İptal", "MAGIC Üretim", "MAGIC İptal", "Vergi Dairesi", "VKN-TCKN", "Adres", "KEP", "GİB Durumu",
			"KEP Durumu", "İptal Tarihi");

	private static final List<String> GIB_COMMISSION_HEADER_LIST = Arrays.asList("Şirket", "VKN-TCKN", "Ünvan",
			"Belge Tarihi", "Belge No", "Işlem ID", "Toplam İstihsal", "Toplam İptal", "İptal Tarihi",
			"Oluşturma Tarihi");

	public byte[] createCommissionXLS(FilteredCommissionsRequest filteredCommissionsRequest) throws IOException {

		List<CommissionXlsDto> commissions = commissionService.getFilteredCommissions(filteredCommissionsRequest);

		try {
			Workbook workbook = new XSSFWorkbook();
			initializeStyles(workbook);
			Sheet sheet = workbook.createSheet("KGB Liste");

			int row = 0;
			createHeader(row++, sheet);
			createRows(commissions, row, sheet);
			autoWidthAllColumns(sheet);

			ByteArrayOutputStream out = new ByteArrayOutputStream();

			workbook.write(out);
			out.close();
			workbook.close();
			return out.toByteArray();
		} catch (Exception e) {
			throw new IOException(e.getMessage());
		}
	}

	private void createHeader(int row, Sheet sheet) {
		Row headerRow = sheet.createRow(row);
		int column = 0;
		for (String visibleColumn : COMMISSION_HEADER_LIST) {
			Cell cell = headerRow.createCell(column++);
			cell.setCellStyle(cellStyleHeader);
			cell.setCellValue(visibleColumn);
		}
	}

	private int createRows(List<CommissionXlsDto> commissions, int row, Sheet sheet) {
		for (CommissionXlsDto commission : commissions) {
			row = createNewRow(sheet, row, commission);
		}
		sheet.createRow(row++);
		return row;
	}

	private int createNewRow(Sheet orderSheet, int row, CommissionXlsDto commission) {
		int column = 0;
		Row dataRow = orderSheet.createRow(row);
		String agency = commission.getAgency().toString();
		
		if (commission.getCompany().equals(AllianzCompany.YASAM_EMEKLILIK.getValue()) && agency.equals(EkgbConstants.EKGB_YKE_PARTAJ_NO)) {
			agency = EkgbConstants.EKGB_YKE_PARTAJ;
		}
		addToRow(dataRow, column++, commission.getCompany());
		addToRow(dataRow, column++, agency);
		addToRow(dataRow, column++, commission.getAgencyTitle());
		addToRowInt(dataRow, column++, commission.getYear());
		addToRowInt(dataRow, column++, commission.getMonth());
		addToRowRightAligned(dataRow, column++, commission.getTotalProductionAmount());
		addToRowRightAligned(dataRow, column++, commission.getTotalCancelAmount());
		
		addToRowRightAligned(dataRow, column++, commission.getProductionAmountOPUS());
		addToRowRightAligned(dataRow, column++, commission.getCancelAmountOPUS());
		
		addToRowRightAligned(dataRow, column++, commission.getProductionAmountAS400());
		addToRowRightAligned(dataRow, column++, commission.getCancelAmountAS400());
		
		addToRowRightAligned(dataRow, column++, commission.getProductionAmountABS());
		addToRowRightAligned(dataRow, column++, commission.getCancelAmountABS());
		
		addToRowRightAligned(dataRow, column++, commission.getProductionAmountMAGIC());
		addToRowRightAligned(dataRow, column++, commission.getCancelAmountMAGIC());

		addToRow(dataRow, column++, commission.getAgencyTaxOffice());
		addToRow(dataRow, column++, commission.getAgencyTaxNo());

		addToRow(dataRow, column++, commission.getAgencyAddress());
		addToRow(dataRow, column++, commission.getKepAddress());
		addToRow(dataRow, column++, GibStatus.getNameByValue(commission.getGibStatusId()));
		addToRow(dataRow, column++, KepStatus.getNameByValue(commission.getKepStatusId()));
		addToRowLocalDateTime(dataRow, column, commission.getRecordCancelDate());

		row++;
		return row;
	}

	@Override
	public byte[] createGibCommissionXLS(EkgbPeriod ekgbPeriod) throws IOException {
		// get data

		List<GibEkgbListItem> kgbList = new ArrayList<GibEkgbListItem>();

		LocalDate startDate = LocalDate.of(ekgbPeriod.getYear(), ekgbPeriod.getMonth(), 1);
		LocalDate endDate = startDate.plusMonths(1).minusDays(1);

		ResponseBaseContract responseAzs = commissionService.getCommissionListRemoteByDate("AZS", startDate, endDate);
		if (responseAzs.getStatus() == ResponseMessageStatus.FAILURE) {
			NotifierImpl.NotifyByEmail("createGibCommissionXLS: AZS: " + responseAzs.getMessage()[0].getMessage());
			return new byte[0];
		} 
	
		kgbList = (List<GibEkgbListItem>) (responseAzs.getData());
	
//		ResponseBaseContract responseHE = commissionService.getCommissionListRemoteByDate("HE", startDate, endDate);
//		if (responseHE.getStatus() == ResponseMessageStatus.FAILURE) {
//			NotifierImpl.NotifyByEmail("createGibCommissionXLS: HE: " + responseHE.getMessage()[0].getMessage());
//			return new byte[0];
//		} else {
//			kgbList.addAll((List<GibEkgbListItem>) (responseHE.getData()));
//		}
//
//		ResponseBaseContract responseYE = commissionService.getCommissionListRemoteByDate("YE", startDate, endDate);
//		if (responseYE.getStatus() == ResponseMessageStatus.FAILURE) {
//			NotifierImpl.NotifyByEmail("createGibCommissionXLS: YE: " + responseYE.getMessage()[0].getMessage());
//			return new byte[0];
//		} else {
//			kgbList.addAll((List<GibEkgbListItem>) (responseYE.getData()));
//		}

		try {
			Workbook workbook = new XSSFWorkbook();
			initializeStyles(workbook);
			Sheet sheet = workbook.createSheet("GIB KGB Liste");

			int row = 0;
			createHeaderGIB(row++, sheet);
			createRowsGIB(kgbList, row, sheet);
			autoWidthAllColumns(sheet);

			ByteArrayOutputStream out = new ByteArrayOutputStream();

			workbook.write(out);
			out.close();
			workbook.close();
			return out.toByteArray();

		} catch (Exception e) {
			throw new IOException(e.getMessage());
		}
	}

	private void createHeaderGIB(int row, Sheet sheet) {
		Row headerRow = sheet.createRow(row);
		int column = 0;
		for (String visibleColumn : GIB_COMMISSION_HEADER_LIST) {
			Cell cell = headerRow.createCell(column++);
			cell.setCellStyle(cellStyleHeader);
			cell.setCellValue(visibleColumn);
		}
	}

	private int createRowsGIB(List<GibEkgbListItem> commissions, int row, Sheet sheet) {
		for (GibEkgbListItem commission : commissions) {
			row = createNewRowGIB(sheet, row, commission);
		}
		sheet.createRow(row++);
		return row;
	}

	private int createNewRowGIB(Sheet orderSheet, int row, GibEkgbListItem commission) {
		int column = 0;
		Row dataRow = orderSheet.createRow(row);

		addToRow(dataRow, column++, commission.getCompany());
		addToRow(dataRow, column++, commission.getReceiverContact());
		addToRow(dataRow, column++, commission.getReceiverName());
		addToRow(dataRow, column++, commission.getIssueDate());
		addToRow(dataRow, column++, commission.getBelgeNo());
		addToRow(dataRow, column++, commission.getIslemId());
		addToRowRightAligned(dataRow, column++, commission.getIstihsalKomisyonu());
		addToRowRightAligned(dataRow, column++, commission.getIptalKomisyonu());
		addToRow(dataRow, column++, commission.getIptalTarihi());
		addToRow(dataRow, column++, commission.getCreationTime());

		row++;
		return row;
	}

}
