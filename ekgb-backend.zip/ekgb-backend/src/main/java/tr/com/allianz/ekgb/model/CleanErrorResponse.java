package tr.com.allianz.ekgb.model;

public class CleanErrorResponse  extends ResponseBase implements ResponseBaseContract {

}
