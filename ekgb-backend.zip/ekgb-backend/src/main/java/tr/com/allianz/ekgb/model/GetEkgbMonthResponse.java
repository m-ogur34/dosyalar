package tr.com.allianz.ekgb.model;

public class GetEkgbMonthResponse extends ResponseBase implements ResponseBaseContract{

}
