package tr.com.allianz.ekgb.security.user;

import com.msu.userutils.ProfileInformation;
import com.msu.userutils.UserProfile;

import tr.com.allianz.ekgb.exception.BadRequestException;
import tr.com.allianz.ekgb.security.user.mapper.UserProfileInfoMapper;
import tr.com.allianz.ekgb.util.ErrorConstants;

import org.springframework.stereotype.Service;


@Service
public class UserProfileInfoServiceImpl implements UserProfileInfoService {

	public UserProfileInfo getUserInfo() {
		final UserProfile userProfile = AuthenticatedUserUtils.getUserProfile();
		final UserProfileInfo userProfileInfo = UserProfileInfoMapper.INSTANCE.convertToUserProfileResponse(userProfile);

		return userProfileInfo;
	}

	public String getJwtToken() {
		final UserProfile userProfile = AuthenticatedUserUtils.getUserProfile();

		return userProfile.getJwtToken();
	}

}
