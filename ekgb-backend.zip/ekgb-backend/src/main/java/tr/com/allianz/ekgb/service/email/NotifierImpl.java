package tr.com.allianz.ekgb.service.email;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import tr.com.allianz.ekgb.service.CommissionServiceImpl;

import java.time.LocalDateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class NotifierImpl {

	private static Logger logger = LoggerFactory.getLogger(CommissionServiceImpl.class);


	public static void NotifyByEmail( String messageText) {
		messageText = messageText + " <br><br>" + LocalDateTime.now();
		//Şimdilik email göndermeyelim
		logger.info(messageText);
	}

}
