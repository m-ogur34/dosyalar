package tr.com.allianz.ekgb.entity.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum AllianzCompany {
	ALLIANZ_SIGORTA("Allianz Sigorta", "AZS"), 
	HAYAT_EMEKLILIK("Allianz Hayat ve Emeklilik A.Ş","HE"), 
	YASAM_EMEKLILIK("Allianz Yaşam ve Emeklilik A.Ş","YE");

	
	@Getter
	private String companyName;
	
	@Getter
	private String value;

	@Getter
	private String name;

	AllianzCompany(String companyName, String value) {
		name = name();
		this.value = value;
		this.companyName = companyName;
	}

}

