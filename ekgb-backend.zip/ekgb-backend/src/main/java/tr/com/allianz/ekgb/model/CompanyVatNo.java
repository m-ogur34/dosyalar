package tr.com.allianz.ekgb.model;


public class CompanyVatNo {
	public static final String AZS = "8000013270";
	public static final String HE = "8000012454";
	public static final String YE= "4560007243";
	
	

}
