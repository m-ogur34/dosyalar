package tr.com.allianz.ekgb.security.user.mapper;

import com.msu.userutils.UserProfile;
import fr.xebia.extras.selma.IgnoreMissing;
import fr.xebia.extras.selma.Mapper;
import fr.xebia.extras.selma.Maps;
import fr.xebia.extras.selma.Selma;
import tr.com.allianz.ekgb.security.user.UserProfileInfo;


@Mapper
public interface UserProfileInfoMapper {

    UserProfileInfoMapper INSTANCE = Selma.builder(UserProfileInfoMapper.class).build();

    @Maps(withIgnoreMissing = IgnoreMissing.ALL)
    UserProfileInfo convertToUserProfileResponse(UserProfile userProfile);
}
