package tr.com.allianz.ekgb.security.user;

import com.msu.userutils.ProfileInformation;
import lombok.Data;

import java.util.List;

@Data
public class UserProfileInfo {

	private String userName;

	private String name;

//	private Integer agentIntId;
//
//	private String agencyCode;
//
//	private String agencyTitle;
//
//	private String subAgent;
//
//	private String subAgentCode;
//
//	private String subAgentTitle;
//
//	private String salesPersonEmpId;
//
//	private String bgdUser;

	private String uwUser;

	private String userType;

//	private Integer isIndustrialUser;
//
//	private List<ProfileInformation> profileInformations;
}