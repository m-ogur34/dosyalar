package tr.com.allianz.ekgb.service.filenet;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreateDocumentDocPropertyInput {

	private String prp_SymbolicName;
	private String prp_Type;
	private String prp_Value; 
    
	
}
