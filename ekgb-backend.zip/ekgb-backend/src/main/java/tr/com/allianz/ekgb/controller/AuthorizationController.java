package tr.com.allianz.ekgb.controller;


import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import tr.com.allianz.ekgb.model.idm.IDMAuthorizationResponse;
import tr.com.allianz.ekgb.service.idm.IDMService;


@RestController
@RequiredArgsConstructor
@RequestMapping("/authorization")
@Tag(name = "Authorization")
public class AuthorizationController {

    private final IDMService idmService;

    @Operation(summary = "List all fields that user has authorization")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved user authorization"),
            @ApiResponse(responseCode = "401", description = "You are not authorized to view the resource"),
            @ApiResponse(responseCode = "424", description = "The request to idm service failed"),
            @ApiResponse(responseCode = "404", description = "The resource you were trying to reach is not found")
    })
    @GetMapping(value = {"", "/"}, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<IDMAuthorizationResponse> getUserAuthorization(@RequestParam(name = "pageName") String pageName) {
        IDMAuthorizationResponse response = idmService.getUserAuthorization(pageName);
        return ResponseEntity.ok(response);
    }
}