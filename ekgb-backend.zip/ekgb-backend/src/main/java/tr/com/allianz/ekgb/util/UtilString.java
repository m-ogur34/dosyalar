package tr.com.allianz.ekgb.util;

import org.apache.commons.lang3.StringUtils;

public final class UtilString {

	private UtilString() {
	}

	public static boolean isNullOrEmpty(String str) {
		return (str == null || str.trim().isEmpty());
	}


}