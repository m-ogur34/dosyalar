package tr.com.allianz.ekgb.service;

import java.util.List;

import org.springframework.scheduling.annotation.Async;

public interface EKGBPartitionedCreateService {

	/// Partition the list to create parallel EKGBs
	void createEkgbPartitioned(List<Long> commissionList);

}