package tr.com.allianz.ekgb.model;

public class ResponseBase implements ResponseBaseContract {

	private ResponseMessageStatus responseMessageStatus;
	private ResponseMessage[] responseMessage;
	private Object data;

	public static ResponseBaseContract Success(Object data) {
		return new ResponseBase(ResponseMessageStatus.SUCCESS, new ResponseMessage[] {}, data);
	}

	public static ResponseBaseContract Success() {
		return new ResponseBase(ResponseMessageStatus.SUCCESS, new ResponseMessage[] {}, null);
	}

	public static ResponseBaseContract Success(Object data, String message) {
		return new ResponseBase(ResponseMessageStatus.SUCCESS,
				new ResponseMessage[] { new ResponseMessage("", message) }, data);
	}

	public static ResponseBaseContract Failure(String message) {
		return new ResponseBase(ResponseMessageStatus.FAILURE,
				new ResponseMessage[] { new ResponseMessage("", message) }, "");
	}

	public static ResponseBaseContract Failure(ResponseMessage[] responseMessage) {
		return new ResponseBase(ResponseMessageStatus.FAILURE, responseMessage, "");
	}

	public static ResponseBaseContract Unauthorized() {
		return new ResponseBase(ResponseMessageStatus.UNAUTHORIZED, new ResponseMessage[] {}, null);
	}
	
	public ResponseBase() {

	}

	public ResponseBase(ResponseMessageStatus responseMessageStatus, ResponseMessage[] responseMessage) {
		this.responseMessageStatus = responseMessageStatus;
		this.responseMessage = responseMessage;
	}

	public ResponseBase(ResponseMessageStatus responseMessageStatus, ResponseMessage[] responseMessage, Object data) {
		this.responseMessageStatus = responseMessageStatus;
		this.responseMessage = responseMessage;
		this.data = data;
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}

	public ResponseMessage[] getMessage() {
		return responseMessage;
	}

	public static String getFirstMessage(ResponseBaseContract cr) {

		if (cr.getMessage() != null && cr.getMessage().length > 0) {
			return cr.getMessage()[0].getMessage();
		}

		return "";
	}

	public void setMessage(ResponseMessage[] responseMessage) {
		this.responseMessage = responseMessage;
	}

	public ResponseMessageStatus getStatus() {
		return responseMessageStatus;
	}

	public void setStatus(ResponseMessageStatus responseMessageStatus) {
		this.responseMessageStatus = responseMessageStatus;
	}

}
