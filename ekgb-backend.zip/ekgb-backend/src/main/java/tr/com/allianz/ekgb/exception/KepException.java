package tr.com.allianz.ekgb.exception;


public class KepException extends RuntimeException {

    public KepException(String exception) {
        super(exception);
    }

    public KepException() {
        super();
    }
}
