package tr.com.allianz.ekgb.service.filenet;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreateDocumentDocContentInput {
	private String doc_MimeType;
	private String doc_Title;
	private String doc_Base64;
}
