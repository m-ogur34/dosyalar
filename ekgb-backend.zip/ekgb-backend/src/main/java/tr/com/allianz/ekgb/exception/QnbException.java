package tr.com.allianz.ekgb.exception;


public class QnbException extends RuntimeException {

    public QnbException(String exception) {
        super(exception);
    }

    public QnbException() {
        super();
    }
}
