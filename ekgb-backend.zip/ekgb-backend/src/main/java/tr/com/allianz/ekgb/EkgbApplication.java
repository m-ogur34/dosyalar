package tr.com.allianz.ekgb;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.web.WebApplicationInitializer;

@SpringBootApplication
public class EkgbApplication extends SpringBootServletInitializer implements WebApplicationInitializer {
	
	private static Logger logger = LoggerFactory.getLogger(EkgbApplication.class);
	
	public static void main(String[] args) {
		SpringApplication.run(EkgbApplication.class, args);
		logger.info("********* EKGB HAZIR V1.05  2026-11-03 *********");
	}

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(EkgbApplication.class);
	}

}



