package tr.com.allianz.ekgb.service.filenet;

public interface FilenetService {
	CreateDocumentOutput createDocument (CreateDocumentInput createDocumentInput);
	GetDocumentOutput getDocument (GetDocumentInput getDocumentInput);
}
