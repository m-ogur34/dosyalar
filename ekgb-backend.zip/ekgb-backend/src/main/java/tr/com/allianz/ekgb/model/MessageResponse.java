package tr.com.allianz.ekgb.model;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MessageResponse {

    @Schema(description = "Code")
    private String code;

    @Schema(description = "Message")
    private String message;

    @Schema(description = "Severity")
    private String severity;

}
