package tr.com.allianz.ekgb.service.xls;

import org.apache.poi.hssf.usermodel.DVConstraint;
import org.apache.poi.hssf.usermodel.HSSFDataFormat;
import org.apache.poi.hssf.usermodel.HSSFDataValidation;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.DataValidation;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddressList;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;

public abstract class AbstractXLSCreatorService {

	protected CellStyle rateStyle = null;
	protected CellStyle amountStyle = null;
	protected CellStyle dateDDMMYYYYStyle = null;
	protected CellStyle timeHHMMStyle = null;
	protected CellStyle dateDDMMYYYYHHMMSSStyle = null;
	protected CellStyle dateYYYYMMDDHHMMSSStyle = null;
	protected CellStyle cellStyleTemplate = null;
	protected CellStyle cellStyle = null;
	protected CellStyle cellStyleHeader = null;

	protected void initializeStyles(Workbook wb) {
		CreationHelper createHelper = wb.getCreationHelper();

		rateStyle = wb.createCellStyle();
		rateStyle.setDataFormat(HSSFDataFormat.getBuiltinFormat("0.00"));
		rateStyle.setWrapText(true);

		dateDDMMYYYYStyle = wb.createCellStyle();
		dateDDMMYYYYStyle.setDataFormat(createHelper.createDataFormat().getFormat("dd.MM.yyyy"));
		dateDDMMYYYYStyle.setWrapText(true);

		timeHHMMStyle = wb.createCellStyle();
		timeHHMMStyle.setDataFormat(createHelper.createDataFormat().getFormat("HH:mm"));
		timeHHMMStyle.setWrapText(true);

		dateDDMMYYYYHHMMSSStyle = wb.createCellStyle();
		dateDDMMYYYYHHMMSSStyle.setDataFormat(createHelper.createDataFormat().getFormat("dd.MM.yyyy HH:mm:ss"));
		dateDDMMYYYYHHMMSSStyle.setWrapText(true);

		amountStyle = wb.createCellStyle();
		amountStyle.setDataFormat(HSSFDataFormat.getBuiltinFormat("#,##0.00"));
		amountStyle.setWrapText(true);

		dateYYYYMMDDHHMMSSStyle = wb.createCellStyle();
		dateYYYYMMDDHHMMSSStyle.setDataFormat(createHelper.createDataFormat().getFormat("yyyy.MM.dd HH:mm:ss"));
		dateYYYYMMDDHHMMSSStyle.setWrapText(true);

		cellStyle = wb.createCellStyle();
		cellStyle.setWrapText(true);

		cellStyleTemplate = wb.createCellStyle();
		cellStyleTemplate.setFillBackgroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
		cellStyleTemplate.setWrapText(true);

		cellStyleHeader = wb.createCellStyle();
		cellStyleHeader.setWrapText(true);
		Font font = wb.createFont();
		font.setFontHeightInPoints((short) 13);
		font.setBold(true);
		cellStyleHeader.setFont(font);
	}

	protected void autoWidthAllColumns(Sheet sheet) {
		int countOfColumns = sheet.getRow(0).getPhysicalNumberOfCells();
		for (int columnsCounter = 0; columnsCounter < countOfColumns; columnsCounter++) {
			sheet.autoSizeColumn(columnsCounter);
		}
	}


	protected void addToRow(Row dataRow, int columnNo, String value) {
		if (value != null) {
			Cell cell = dataRow.createCell(columnNo);
			cell.setCellValue(value);
			cell.setCellStyle(cellStyle);
		}
	}

	
	protected void addToRowInt(Row dataRow, int columnNo, int value) {

		Cell cell = dataRow.createCell(columnNo);
		cell.setCellValue(value);
		cell.setCellStyle(cellStyle);

	}


	protected void addToRowRightAligned(Row dataRow, int columnNo, BigDecimal value) {
		if (value != null) {
			Cell cell = dataRow.createCell(columnNo);
			cell.setCellValue(value.doubleValue());
			cell.setCellStyle(amountStyle);
		}
	}


	protected void addToRowLocalDateTime(Row dataRow, int columnNo, LocalDateTime value) {
		if (value != null) {
			Cell cell = dataRow.createCell(columnNo);
			cell.setCellValue(value.format(DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm:ss")));
			cell.setCellStyle(dateDDMMYYYYHHMMSSStyle);
		}
	}


}