package tr.com.allianz.accounting_services.actuary.interfaces.web;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import tr.com.allianz.accounting_services.actuary.application.service.ActuaryLogService;
import tr.com.allianz.accounting_services.actuary.application.usecases.SaveActuaryProcessAmountUseCase;
import tr.com.allianz.accounting_services.actuary.application.usecases.UploadActuaryProcessAmountExcelUseCase;
import tr.com.allianz.accounting_services.actuary.interfaces.web.dto.SaveActuaryProcessAmountRequestDto;
import tr.com.allianz.accounting_services.shared.api.ApiResponse;
import tr.com.allianz.accounting_services.shared.web.SharedExceptionHandler;

import java.math.BigDecimal;
import java.security.Principal;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)
class ActuaryProcessAmountControllerTest {

    @Mock
    private SaveActuaryProcessAmountUseCase saveActuaryProcessAmountUseCase;

    @Mock
    private UploadActuaryProcessAmountExcelUseCase uploadActuaryProcessAmountExcelUseCase;

    @Mock
    private ActuaryLogService actuaryLogService;


    @InjectMocks
    private ActuaryProcessAmountController controller;

    @Test
    void save_ShouldReturnSuccessResponse() {
        SaveActuaryProcessAmountRequestDto request = new SaveActuaryProcessAmountRequestDto(
                2024, 6, "P1001", 100,
                new BigDecimal("1000"), new BigDecimal("100"), new BigDecimal("900"),
                new BigDecimal("950"), new BigDecimal("95"), new BigDecimal("855"),
                new BigDecimal("1100"), new BigDecimal("110"), new BigDecimal("990"),
                new BigDecimal("1050"), new BigDecimal("105"), new BigDecimal("945"),
                new BigDecimal("1.0"), new BigDecimal("0.1"), new BigDecimal("0.9"),
                new BigDecimal("0.95"), new BigDecimal("0.095"), new BigDecimal("0.855"),
                new BigDecimal("1.1"), new BigDecimal("0.11"), new BigDecimal("0.99"),
                new BigDecimal("1.05"), new BigDecimal("0.105"), new BigDecimal("0.945")
        );

        ResponseEntity<ApiResponse<Void>> response = controller.save(request, null);

        assertThat(response.getStatusCode().value()).isEqualTo(200);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().success()).isTrue();
        assertThat(response.getBody().code()).isEqualTo("SUCCESS");

        verify(saveActuaryProcessAmountUseCase).handle(any(), eq("SYSTEM"));
    }

    @Test
    void save_ShouldUsePrincipalNameWhenPresent() {
        SaveActuaryProcessAmountRequestDto request = new SaveActuaryProcessAmountRequestDto(
                2024, 6, "P1001", 100,
                new BigDecimal("1000"), new BigDecimal("100"), new BigDecimal("900"),
                new BigDecimal("950"), new BigDecimal("95"), new BigDecimal("855"),
                new BigDecimal("1100"), new BigDecimal("110"), new BigDecimal("990"),
                new BigDecimal("1050"), new BigDecimal("105"), new BigDecimal("945"),
                new BigDecimal("1.0"), new BigDecimal("0.1"), new BigDecimal("0.9"),
                new BigDecimal("0.95"), new BigDecimal("0.095"), new BigDecimal("0.855"),
                new BigDecimal("1.1"), new BigDecimal("0.11"), new BigDecimal("0.99"),
                new BigDecimal("1.05"), new BigDecimal("0.105"), new BigDecimal("0.945")
        );
        Principal principal = () -> "tester";

        ResponseEntity<ApiResponse<Void>> response = controller.save(request, principal);

        assertThat(response.getStatusCode().value()).isEqualTo(200);
        verify(saveActuaryProcessAmountUseCase).handle(any(), eq("tester"));
    }

    @Test
    void save_ShouldReturn400WhenRequiredFieldsMissing() throws Exception {
        MockMvc mockMvc = MockMvcBuilders
                .standaloneSetup(controller)
                .setControllerAdvice(new SharedExceptionHandler())
                .build();

        // year, month, processId, ruleId hepsi null
        Map<String, Object> invalidRequest = Map.of(
                "grossAmount", 1000
        );

        mockMvc.perform(post("/api/v1/actuary-process-amounts")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(new ObjectMapper().writeValueAsString(invalidRequest)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.code").value("VALIDATION_ERROR"));
    }

    @Test
    void uploadExcel_ShouldReturnSuccessResponse() {
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "amounts.xlsx",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                new byte[]{1, 2, 3}
        );

        ResponseEntity<ApiResponse<Void>> response = controller.uploadExcel(file, 2024, 6, null);

        assertThat(response.getStatusCode().value()).isEqualTo(200);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().success()).isTrue();
        assertThat(response.getBody().code()).isEqualTo("SUCCESS");

        verify(uploadActuaryProcessAmountExcelUseCase).handle(file, 2024, 6, "SYSTEM");
    }

    @Test
    void uploadExcel_ShouldUsePrincipalNameWhenPresent() {
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "amounts.xlsx",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                new byte[]{1, 2, 3}
        );
        Principal principal = () -> "tester";

        ResponseEntity<ApiResponse<Void>> response = controller.uploadExcel(file, 2024, 6, principal);

        assertThat(response.getStatusCode().value()).isEqualTo(200);
        verify(uploadActuaryProcessAmountExcelUseCase).handle(file, 2024, 6, "tester");
    }

    @Test
    void save_ShouldLogAndRethrowWhenUseCaseFails() {
        SaveActuaryProcessAmountRequestDto request = new SaveActuaryProcessAmountRequestDto(
                2024, 6, "P1001", 100,
                null, null, null,
                null, null, null,
                null, null, null,
                null, null, null,
                null, null, null,
                null, null, null,
                null, null, null,
                null, null, null
        );

        doThrow(new RuntimeException("boom"))
                .when(saveActuaryProcessAmountUseCase)
                .handle(any(), eq("SYSTEM"));

        assertThatThrownBy(() -> controller.save(request, null))
                .isInstanceOf(RuntimeException.class)
                .hasMessage("boom");

        verify(actuaryLogService).logError(
                "P1001",
                2024,
                6,
                "Amount save failed: boom",
                "SYSTEM"
        );
    }

    @Test
    void save_ShouldLogAndRethrowWithPrincipalNameWhenUseCaseFails() {
        SaveActuaryProcessAmountRequestDto request = new SaveActuaryProcessAmountRequestDto(
                2024, 6, "P1001", 100,
                null, null, null,
                null, null, null,
                null, null, null,
                null, null, null,
                null, null, null,
                null, null, null,
                null, null, null,
                null, null, null
        );
        Principal principal = () -> "tester";

        doThrow(new RuntimeException("boom"))
                .when(saveActuaryProcessAmountUseCase)
                .handle(any(), eq("tester"));

        assertThatThrownBy(() -> controller.save(request, principal))
                .isInstanceOf(RuntimeException.class)
                .hasMessage("boom");

        verify(actuaryLogService).logError(
                "P1001",
                2024,
                6,
                "Amount save failed: boom",
                "tester"
        );
    }

    @Test
    void uploadExcel_ShouldThrowWhenFileIsEmpty() {
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "amounts.xlsx",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                new byte[]{}
        );

        assertThatThrownBy(() -> controller.uploadExcel(file, 2024, 6, null))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("Excel dosyasi secilmesi zorunludur");

        verify(uploadActuaryProcessAmountExcelUseCase, never()).handle(any(), eq(2024), eq(6), eq("SYSTEM"));
        verify(actuaryLogService, never()).logError(any(), any(), any(), any(), any());
    }

    @Test
    void uploadExcel_ShouldLogAndRethrowWhenUseCaseFails() {
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "amounts.xlsx",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                new byte[]{1, 2, 3}
        );

        doThrow(new RuntimeException("upload boom"))
                .when(uploadActuaryProcessAmountExcelUseCase)
                .handle(file, 2024, 6, "SYSTEM");

        assertThatThrownBy(() -> controller.uploadExcel(file, 2024, 6, null))
                .isInstanceOf(RuntimeException.class)
                .hasMessage("upload boom");

        verify(actuaryLogService).logError(
                null,
                2024,
                6,
                "Excel upload failed: upload boom",
                "SYSTEM"
        );
    }

    @Test
    void uploadExcel_ShouldLogAndRethrowWithPrincipalNameWhenUseCaseFails() {
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "amounts.xlsx",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                new byte[]{1, 2, 3}
        );
        Principal principal = () -> "tester";

        doThrow(new RuntimeException("upload boom"))
                .when(uploadActuaryProcessAmountExcelUseCase)
                .handle(file, 2024, 6, "tester");

        assertThatThrownBy(() -> controller.uploadExcel(file, 2024, 6, principal))
                .isInstanceOf(RuntimeException.class)
                .hasMessage("upload boom");

        verify(actuaryLogService).logError(
                null,
                2024,
                6,
                "Excel upload failed: upload boom",
                "tester"
        );
    }
}
