package tr.com.allianz.accounting_services.actuary.domain.valueobject;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class ActuaryPeriodStatusTest {

    @Test
    void getValue_ShouldReturnCorrectStringForInProgress() {
        assertThat(ActuaryPeriodStatus.IN_PROGRESS.getValue()).isEqualTo("In Progress");
    }

    @Test
    void getValue_ShouldReturnCorrectStringForApproved() {
        assertThat(ActuaryPeriodStatus.APPROVED.getValue()).isEqualTo("Approved");
    }

    @Test
    void fromValue_ShouldReturnInProgressWhenGivenInProgressInput() {
        ActuaryPeriodStatus result = ActuaryPeriodStatus.fromValue("In Progress");
        assertThat(result).isEqualTo(ActuaryPeriodStatus.IN_PROGRESS);
    }

    @Test
    void fromValue_ShouldReturnApprovedWhenGivenApprovedInput() {
        ActuaryPeriodStatus result = ActuaryPeriodStatus.fromValue("Approved");
        assertThat(result).isEqualTo(ActuaryPeriodStatus.APPROVED);
    }

    @Test
    void fromValue_ShouldBeCaseInsensitive() {
        assertThat(ActuaryPeriodStatus.fromValue("in progress")).isEqualTo(ActuaryPeriodStatus.IN_PROGRESS);
        assertThat(ActuaryPeriodStatus.fromValue("IN PROGRESS")).isEqualTo(ActuaryPeriodStatus.IN_PROGRESS);
        assertThat(ActuaryPeriodStatus.fromValue("approved")).isEqualTo(ActuaryPeriodStatus.APPROVED);
        assertThat(ActuaryPeriodStatus.fromValue("APPROVED")).isEqualTo(ActuaryPeriodStatus.APPROVED);
    }

    @Test
    void fromValue_ShouldReturnNullWhenGivenNull() {
        ActuaryPeriodStatus result = ActuaryPeriodStatus.fromValue(null);
        assertThat(result).isNull();
    }

    @Test
    void fromValue_ShouldThrowExceptionWhenGivenInvalidValue() {
        assertThatThrownBy(() -> ActuaryPeriodStatus.fromValue("Invalid"))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("Unknown ActuaryPeriodStatus value: Invalid");
    }

    @Test
    void fromValue_ShouldThrowExceptionWhenGivenEmptyString() {
        assertThatThrownBy(() -> ActuaryPeriodStatus.fromValue(""))
                .isInstanceOf(IllegalArgumentException.class);
    }

    @ParameterizedTest
    @ValueSource(strings = {"In Progress", "Approved"})
    void fromValue_ShouldRecognizeAllValidStatuses(String value) {
        ActuaryPeriodStatus status = ActuaryPeriodStatus.fromValue(value);
        assertThat(status).isNotNull();
        assertThat(status.getValue()).isEqualTo(value);
    }

    @Test
    void values_ShouldContainBothStatuses() {
        ActuaryPeriodStatus[] statuses = ActuaryPeriodStatus.values();
        assertThat(statuses).containsExactlyInAnyOrder(
                ActuaryPeriodStatus.IN_PROGRESS,
                ActuaryPeriodStatus.APPROVED
        );
    }

    @Test
    void valueOf_ShouldReturnCorrectStatus() {
        assertThat(ActuaryPeriodStatus.valueOf("IN_PROGRESS")).isEqualTo(ActuaryPeriodStatus.IN_PROGRESS);
        assertThat(ActuaryPeriodStatus.valueOf("APPROVED")).isEqualTo(ActuaryPeriodStatus.APPROVED);
    }
}

