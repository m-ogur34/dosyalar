package tr.com.allianz.accounting_services.actuary.application.usecases;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import tr.com.allianz.accounting_services.actuary.application.port.out.LoadActuaryQueryPort;
import tr.com.allianz.accounting_services.actuary.application.port.out.LoadIfrsDistributionTotalsPort;
import tr.com.allianz.accounting_services.actuary.application.port.out.LoadTrfsDistributionTotalsPort;
import tr.com.allianz.accounting_services.actuary.application.port.out.SaveActuaryProcessAmountPort;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.ActuaryProcessRuleAmount;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.ActuaryQueryCriteria;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.TrfsDistributionTotals;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ExecuteDistributionUseCaseTest {

    @Mock
    private LoadActuaryQueryPort loadActuaryQueryPort;

    @Mock
    private SaveActuaryProcessAmountPort saveActuaryProcessAmountPort;

    @Mock
    private LoadTrfsDistributionTotalsPort loadTrfsDistributionTotalsPort;

    @Mock
    private LoadIfrsDistributionTotalsPort loadIfrsDistributionTotalsPort;

    @Test
    void handle_ShouldCalculateRatesAndSaveAll() {
        ExecuteDistributionUseCase useCase = new ExecuteDistributionUseCase(
                loadActuaryQueryPort,
                loadTrfsDistributionTotalsPort,
                loadIfrsDistributionTotalsPort,
                saveActuaryProcessAmountPort
        );

        when(loadActuaryQueryPort.loadActuaryQueryResults(new ActuaryQueryCriteria("P1001", 2026, 6)))
                .thenReturn(List.of(
                        row(1, bd("60"), bd("20"), bd("50"), null, null, null, bd("30"), null, null, bd("15"), null, bd("10")),
                        row(2, bd("40"), bd("30"), bd("25"), null, null, null, bd("70"), null, null, bd("25"), null, bd("20"))
                ));
        when(loadTrfsDistributionTotalsPort.loadTotalsByRuleIds("P1001", Set.of(1, 2), 2026, 6))
                .thenReturn(Map.of(
                        1, new TrfsDistributionTotals(bd("100"), bd("200")),
                        2, new TrfsDistributionTotals(bd("80"), bd("50"))
                ));
        when(loadIfrsDistributionTotalsPort.loadPyTotalsByRuleIds("P1001", Set.of(1, 2), 2026, 6))
                .thenReturn(Map.of(
                        1, new TrfsDistributionTotals(bd("50"), bd("40")),
                        2, new TrfsDistributionTotals(bd("80"), bd("60"))
                ));

        useCase.handle("P1001", 2026, 6, "tester");

        verify(saveActuaryProcessAmountPort).saveAll(argThat(saved -> {
            assertThat(saved).hasSize(2);

            assertThat(saved.get(0).processId()).isEqualTo("P1001");
            assertThat(saved.get(0).year()).isEqualTo(2026);
            assertThat(saved.get(0).month()).isEqualTo(6);
            assertThat(saved.get(0).ruleId()).isEqualTo(1);

            // TRFS CY rates — denominator from external query (100, 200)
            assertThat(saved.get(0).grossCyAmountRate()).isEqualByComparingTo("0.6000000000000000"); // 60/100
            assertThat(saved.get(0).reCyAmountRate()).isEqualByComparingTo("0.4000000000000000");    // 20/50 (aggregate: 20+30=50)
            assertThat(saved.get(0).netCyAmountRate()).isEqualByComparingTo("0.2500000000000000");   // 50/200

            // IFRS CY rates — aggregate denominator (30+70=100)
            assertThat(saved.get(0).ifrsCyGrossRate()).isEqualByComparingTo("0.3000000000000000");   // 30/100

            // IFRS PY rates — denominator from external PRV query (50, 40)
            assertThat(saved.get(0).ifrsPyGrossRate()).isEqualByComparingTo("0.3000000000000000");   // 15/50
            assertThat(saved.get(0).ifrsPyNetRate()).isEqualByComparingTo("0.2500000000000000");     // 10/40

            assertThat(saved.get(1).ruleId()).isEqualTo(2);

            // TRFS CY rates — denominator from external query (80, 50)
            assertThat(saved.get(1).grossCyAmountRate()).isEqualByComparingTo("0.5000000000000000"); // 40/80
            assertThat(saved.get(1).reCyAmountRate()).isEqualByComparingTo("0.6000000000000000");    // 30/50
            assertThat(saved.get(1).netCyAmountRate()).isEqualByComparingTo("0.5000000000000000");   // 25/50

            // IFRS CY rates — aggregate denominator (30+70=100)
            assertThat(saved.get(1).ifrsCyGrossRate()).isEqualByComparingTo("0.7000000000000000");   // 70/100

            // IFRS PY rates — denominator from external PRV query (80, 60)
            assertThat(saved.get(1).ifrsPyGrossRate()).isEqualByComparingTo("0.3125000000000000");   // 25/80
            assertThat(saved.get(1).ifrsPyNetRate()).isEqualByComparingTo("0.3333333333333333");     // 20/60

            return true;
        }));
    }

    @Test
    void handle_ShouldSkipSaveWhenNoDistributableRows() {
        ExecuteDistributionUseCase useCase = new ExecuteDistributionUseCase(
                loadActuaryQueryPort,
                loadTrfsDistributionTotalsPort,
                loadIfrsDistributionTotalsPort,
                saveActuaryProcessAmountPort
        );

        when(loadActuaryQueryPort.loadActuaryQueryResults(new ActuaryQueryCriteria("P1001", 2026, 6)))
                .thenReturn(List.of(
                        row(1, null, null, null, null, null, null, null, null, null, null, null, null)
                ));

        useCase.handle("P1001", 2026, 6, "tester");

        verify(saveActuaryProcessAmountPort, never()).saveAll(anyList());
    }

    @Test
    void handle_ShouldSetNullRateWhenTotalIsZero() {
        ExecuteDistributionUseCase useCase = new ExecuteDistributionUseCase(
                loadActuaryQueryPort,
                loadTrfsDistributionTotalsPort,
                loadIfrsDistributionTotalsPort,
                saveActuaryProcessAmountPort
        );

        when(loadActuaryQueryPort.loadActuaryQueryResults(new ActuaryQueryCriteria("P1001", 2026, 6)))
                .thenReturn(List.of(
                        row(1, bd("0"), null, null, null, null, null, null, null, null, null, null, null)
                ));
        when(loadTrfsDistributionTotalsPort.loadTotalsByRuleIds("P1001", Set.of(1), 2026, 6))
                .thenReturn(Map.of(1, new TrfsDistributionTotals(BigDecimal.ZERO, BigDecimal.ZERO)));
        when(loadIfrsDistributionTotalsPort.loadPyTotalsByRuleIds("P1001", Set.of(1), 2026, 6))
                .thenReturn(Map.of(1, new TrfsDistributionTotals(BigDecimal.ZERO, BigDecimal.ZERO)));

        useCase.handle("P1001", 2026, 6, "tester");

        verify(saveActuaryProcessAmountPort).saveAll(argThat(saved -> {
            assertThat(saved).hasSize(1);
            assertThat(saved.getFirst().grossCyAmountRate()).isNull();
            return true;
        }));
    }

    @Test
    void handle_ShouldClampRateToOneWhenCalculatedValueIsGreaterThanOne() {
        ExecuteDistributionUseCase useCase = new ExecuteDistributionUseCase(
                loadActuaryQueryPort,
                loadTrfsDistributionTotalsPort,
                loadIfrsDistributionTotalsPort,
                saveActuaryProcessAmountPort
        );

        when(loadActuaryQueryPort.loadActuaryQueryResults(new ActuaryQueryCriteria("P1001", 2026, 6)))
                .thenReturn(List.of(
                        row(1, bd("60"), null, null, null, null, null, null, null, null, null, null, null)
                ));
        when(loadTrfsDistributionTotalsPort.loadTotalsByRuleIds("P1001", Set.of(1), 2026, 6))
                .thenReturn(Map.of(1, new TrfsDistributionTotals(bd("10"), bd("10"))));
        when(loadIfrsDistributionTotalsPort.loadPyTotalsByRuleIds("P1001", Set.of(1), 2026, 6))
                .thenReturn(Map.of(1, new TrfsDistributionTotals(BigDecimal.ZERO, BigDecimal.ZERO)));

        useCase.handle("P1001", 2026, 6, "tester");

        verify(saveActuaryProcessAmountPort).saveAll(argThat(saved -> {
            assertThat(saved).hasSize(1);
            assertThat(saved.getFirst().grossCyAmountRate()).isEqualByComparingTo("0.9999999999999999");
            return true;
        }));
    }

    @Test
    void handle_ShouldLoadTotalsOncePerDistinctRuleId() {
        ExecuteDistributionUseCase useCase = new ExecuteDistributionUseCase(
                loadActuaryQueryPort,
                loadTrfsDistributionTotalsPort,
                loadIfrsDistributionTotalsPort,
                saveActuaryProcessAmountPort
        );

        when(loadActuaryQueryPort.loadActuaryQueryResults(new ActuaryQueryCriteria("P1001", 2026, 6)))
                .thenReturn(List.of(
                        row(1, bd("10"), null, null, null, null, null, null, null, null, null, null, null),
                        row(1, bd("20"), null, null, null, null, null, null, null, null, null, null, null),
                        row(2, bd("30"), null, null, null, null, null, null, null, null, null, null, null)
                ));

        when(loadTrfsDistributionTotalsPort.loadTotalsByRuleIds("P1001", Set.of(1, 2), 2026, 6))
                .thenReturn(Map.of(
                        1, new TrfsDistributionTotals(bd("100"), bd("100")),
                        2, new TrfsDistributionTotals(bd("100"), bd("100"))
                ));
        when(loadIfrsDistributionTotalsPort.loadPyTotalsByRuleIds("P1001", Set.of(1, 2), 2026, 6))
                .thenReturn(Map.of(
                        1, new TrfsDistributionTotals(bd("100"), bd("100")),
                        2, new TrfsDistributionTotals(bd("100"), bd("100"))
                ));

        useCase.handle("P1001", 2026, 6, "tester");

        verify(loadTrfsDistributionTotalsPort, times(1)).loadTotalsByRuleIds("P1001", Set.of(1, 2), 2026, 6);
        verify(loadIfrsDistributionTotalsPort, times(1)).loadPyTotalsByRuleIds("P1001", Set.of(1, 2), 2026, 6);
    }

    private static ActuaryProcessRuleAmount row(
            Integer ruleId,
            BigDecimal grossCyAmount,
            BigDecimal reCyAmount,
            BigDecimal netCyAmount,
            BigDecimal grossPyAmount,
            BigDecimal rePyAmount,
            BigDecimal netPyAmount,
            BigDecimal ifrsCyGross,
            BigDecimal ifrsCyRe,
            BigDecimal ifrsCyNet,
            BigDecimal ifrsPyGross,
            BigDecimal ifrsPyRe,
            BigDecimal ifrsPyNet
    ) {
        return new ActuaryProcessRuleAmount(
                "Rule " + ruleId,
                2026,
                6,
                "P1001",
                ruleId,
                grossCyAmount,
                reCyAmount,
                netCyAmount,
                grossPyAmount,
                rePyAmount,
                netPyAmount,
                ifrsCyGross,
                ifrsCyRe,
                ifrsCyNet,
                ifrsPyGross,
                ifrsPyRe,
                ifrsPyNet,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null
        );
    }

    private static BigDecimal bd(String value) {
        return new BigDecimal(value);
    }
}
