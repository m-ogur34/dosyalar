package tr.com.allianz.accounting_services.actuary.application.usecases;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mock.web.MockMultipartFile;
import tr.com.allianz.accounting_services.actuary.application.port.out.ParseActuaryProcessAmountExcelPort;
import tr.com.allianz.accounting_services.actuary.application.port.out.SaveActuaryProcessAmountPort;
import tr.com.allianz.accounting_services.actuary.application.service.ActuaryLogService;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.ActuaryProcessAmount;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.ActuaryProcessAmountExcelRow;

import java.math.BigDecimal;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class UploadActuaryProcessAmountExcelUseCaseTest {

    @Mock
    private ParseActuaryProcessAmountExcelPort parsePort;

    @Mock
    private SaveActuaryProcessAmountPort savePort;

    @Mock
    private ActuaryLogService actuaryLogService;

    @Test
    void handle_ShouldUseRequestMetadataForAllRows() {
        String processId = "P777";
        MockMultipartFile file = new MockMultipartFile("file", "amount.xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", new byte[]{1});

        ActuaryProcessAmountExcelRow amountRow = new ActuaryProcessAmountExcelRow(
                processId,
                200,
                "TestRule",
                new BigDecimal("1000"),
                new BigDecimal("100"),
                new BigDecimal("900"),
                new BigDecimal("800"),
                new BigDecimal("80"),
                new BigDecimal("720"),
                null, null, null, null, null, null,
                null, null, null, null, null, null,
                null, null, null, null, null, null
        );

        when(parsePort.parse(file)).thenReturn(List.of(amountRow));

        UploadActuaryProcessAmountExcelUseCase useCase = new UploadActuaryProcessAmountExcelUseCase(
                parsePort,
                savePort,
                actuaryLogService
        );
        int uploadedCount = useCase.handle(file, 2026, 7, "tester");

        verify(savePort).saveAll(argThat(savedAmounts -> {
            assertThat(savedAmounts).hasSize(1);

            ActuaryProcessAmount saved = savedAmounts.getFirst();
            assertThat(saved.year()).isEqualTo(2026);
            assertThat(saved.month()).isEqualTo(7);
            assertThat(saved.processId()).isEqualTo(processId);
            assertThat(saved.ruleId()).isEqualTo(200);
            assertThat(saved.grossCyAmount()).isEqualTo(new BigDecimal("1000"));
            assertThat(saved.grossPyAmount()).isEqualTo(new BigDecimal("800"));
            assertThat(saved.ifrsCyGross()).isNull();
            assertThat(saved.grossCyAmountRate()).isNull();
            return true;
        }));

        assertThat(uploadedCount).isEqualTo(1);

        verify(actuaryLogService).logExcelUpload(
                null,
                2026,
                7,
                1,
                "tester"
        );
    }

    @Test
    void handle_WithoutUser_ShouldUseSystemUser() {
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "amount.xlsx",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                new byte[]{1}
        );
        ActuaryProcessAmountExcelRow row = new ActuaryProcessAmountExcelRow(
                "P777",
                200,
                "TestRule",
                new BigDecimal("1000"),
                new BigDecimal("100"),
                new BigDecimal("900"),
                new BigDecimal("800"),
                new BigDecimal("80"),
                new BigDecimal("720"),
                null, null, null, null, null, null,
                null, null, null, null, null, null,
                null, null, null, null, null, null
        );
        when(parsePort.parse(file)).thenReturn(List.of(row));

        UploadActuaryProcessAmountExcelUseCase useCase = new UploadActuaryProcessAmountExcelUseCase(
                parsePort,
                savePort,
                actuaryLogService
        );

        int uploadedCount = useCase.handle(file, 2026, 7);

        assertThat(uploadedCount).isEqualTo(1);
        verify(savePort).saveAll(argThat(savedAmounts -> savedAmounts.size() == 1));
        verify(actuaryLogService).logExcelUpload(null, 2026, 7, 1, "SYSTEM");
    }
}

