package tr.com.allianz.accounting_services.actuary.infrastructure.persistence.adapter;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jdbc.core.PreparedStatementCallback;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.TrfsDistributionTotals;
import tr.com.allianz.accounting_services.actuary.infrastructure.persistence.entity.AlzActProcessRules;
import tr.com.allianz.accounting_services.actuary.infrastructure.persistence.repository.AlzActProcessRulesRepository;

import java.math.BigDecimal;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class TrfsDistributionTotalsAdapterTest {

    @Mock
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @Mock
    private AlzActProcessRulesRepository rulesRepository;

    @Test
    void loadTotals_ShouldReturnAggregateFromBothQueries() {
        AlzActProcessRules rule = new AlzActProcessRules();
        rule.setProcessId("P1001");
        rule.setRuleId(10);
        rule.setRuleText("branch_code = '01'");

        when(rulesRepository.findByProcessIdAndRuleIdIn("P1001", List.of(10))).thenReturn(List.of(rule));

        // Cari ay: 125.50 / 80.25 ; Ocak: 0 / 0
        doAnswer(invocation -> {
            String sql = invocation.getArgument(0);
            PreparedStatementCallback<?> callback = invocation.getArgument(2);

            java.sql.PreparedStatement ps = mock(java.sql.PreparedStatement.class);
            java.sql.ResultSet rs = mock(java.sql.ResultSet.class);
            when(ps.executeQuery()).thenReturn(rs);
            when(rs.next()).thenReturn(true);

            if (sql.contains(":month")) { // current month query
                when(rs.getBigDecimal(1)).thenReturn(new BigDecimal("125.50"));
                when(rs.getBigDecimal(2)).thenReturn(new BigDecimal("80.25"));
            } else {                       // january query
                when(rs.getBigDecimal(1)).thenReturn(BigDecimal.ZERO);
                when(rs.getBigDecimal(2)).thenReturn(BigDecimal.ZERO);
            }
            return callback.doInPreparedStatement(ps);
        }).when(namedParameterJdbcTemplate).execute(anyString(), any(MapSqlParameterSource.class), any());

        TrfsDistributionTotalsAdapter adapter =
                new TrfsDistributionTotalsAdapter(namedParameterJdbcTemplate, rulesRepository);
        TrfsDistributionTotals totals = adapter.loadTotals("P1001", 10, 2026, 6);

        assertThat(totals.grossAmountTotal()).isEqualByComparingTo("125.50");
        assertThat(totals.netAmountTotal()).isEqualByComparingTo("80.25");
    }

    @Test
    void loadTotals_ShouldAccumulateBothCurrentAndJanuaryAggregates() {
        AlzActProcessRules rule = new AlzActProcessRules();
        rule.setProcessId("P1001");
        rule.setRuleId(10);
        rule.setRuleText("branch_code = '01'");

        when(rulesRepository.findByProcessIdAndRuleIdIn("P1001", List.of(10))).thenReturn(List.of(rule));

        doAnswer(invocation -> {
            String sql = invocation.getArgument(0);
            PreparedStatementCallback<?> callback = invocation.getArgument(2);
            java.sql.PreparedStatement ps = mock(java.sql.PreparedStatement.class);
            java.sql.ResultSet rs = mock(java.sql.ResultSet.class);
            when(ps.executeQuery()).thenReturn(rs);
            when(rs.next()).thenReturn(true);
            if (sql.contains(":month")) {
                when(rs.getBigDecimal(1)).thenReturn(new BigDecimal("100.00"));
                when(rs.getBigDecimal(2)).thenReturn(new BigDecimal("70.00"));
            } else {
                when(rs.getBigDecimal(1)).thenReturn(new BigDecimal("50.00"));
                when(rs.getBigDecimal(2)).thenReturn(new BigDecimal("30.00"));
            }
            return callback.doInPreparedStatement(ps);
        }).when(namedParameterJdbcTemplate).execute(anyString(), any(MapSqlParameterSource.class), any());

        TrfsDistributionTotalsAdapter adapter =
                new TrfsDistributionTotalsAdapter(namedParameterJdbcTemplate, rulesRepository);
        TrfsDistributionTotals totals = adapter.loadTotals("P1001", 10, 2026, 3);

        assertThat(totals.grossAmountTotal()).isEqualByComparingTo("150.00");
        assertThat(totals.netAmountTotal()).isEqualByComparingTo("100.00");
    }

    @Test
    void loadTotals_ShouldRejectUnsafeRuleText() {
        AlzActProcessRules rule = new AlzActProcessRules();
        rule.setProcessId("P1001");
        rule.setRuleId(10);
        rule.setRuleText("1=1; delete from x");

        when(rulesRepository.findByProcessIdAndRuleIdIn("P1001", List.of(10))).thenReturn(List.of(rule));

        TrfsDistributionTotalsAdapter adapter =
                new TrfsDistributionTotalsAdapter(namedParameterJdbcTemplate, rulesRepository);

        assertThatThrownBy(() -> adapter.loadTotals("P1001", 10, 2026, 6))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("Rule text güvenli değil");
    }

    @Test
    void loadTotals_ShouldRejectTautologyRuleText() {
        AlzActProcessRules rule = new AlzActProcessRules();
        rule.setProcessId("P1001");
        rule.setRuleId(11);
        rule.setRuleText("branch_code = '01' OR 1=1");

        when(rulesRepository.findByProcessIdAndRuleIdIn("P1001", List.of(11))).thenReturn(List.of(rule));

        TrfsDistributionTotalsAdapter adapter =
                new TrfsDistributionTotalsAdapter(namedParameterJdbcTemplate, rulesRepository);

        assertThatThrownBy(() -> adapter.loadTotals("P1001", 11, 2026, 6))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("Rule text güvenli değil");
    }
}
