package tr.com.allianz.accounting_services.actuary.infrastructure.persistence.adapter;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jdbc.core.PreparedStatementCallback;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.TrfsDistributionTotals;
import tr.com.allianz.accounting_services.actuary.infrastructure.persistence.entity.AlzActProcessRules;
import tr.com.allianz.accounting_services.actuary.infrastructure.persistence.repository.AlzActProcessRulesRepository;

import java.math.BigDecimal;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class IfrsDistributionTotalsAdapterTest {

    @Mock
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @Mock
    private AlzActProcessRulesRepository rulesRepository;

    @Test
    void loadPyTotals_ShouldAccumulateAllThreeAggregates() {
        AlzActProcessRules rule = new AlzActProcessRules();
        rule.setProcessId("P1001");
        rule.setRuleId(10);
        rule.setRuleText("branch_code = '01'");

        when(rulesRepository.findByProcessIdAndRuleIdIn("P1001", List.of(10))).thenReturn(List.of(rule));

        doAnswer(invocation -> {
            String sql = invocation.getArgument(0);
            PreparedStatementCallback<?> callback = invocation.getArgument(2);
            java.sql.PreparedStatement ps = mock(java.sql.PreparedStatement.class);
            java.sql.ResultSet rs = mock(java.sql.ResultSet.class);
            when(ps.executeQuery()).thenReturn(rs);
            when(rs.next()).thenReturn(true);

            if (sql.contains(":yearMinus1")) {
                when(rs.getBigDecimal(1)).thenReturn(new BigDecimal("300.00"));
                when(rs.getBigDecimal(2)).thenReturn(new BigDecimal("250.00"));
            } else if (sql.contains("BETWEEN :yearMinus3 AND :yearMinus2")) {
                when(rs.getBigDecimal(1)).thenReturn(BigDecimal.ZERO);
                when(rs.getBigDecimal(2)).thenReturn(BigDecimal.ZERO);
            } else {
                when(rs.getBigDecimal(1)).thenReturn(BigDecimal.ZERO);
                when(rs.getBigDecimal(2)).thenReturn(BigDecimal.ZERO);
            }
            return callback.doInPreparedStatement(ps);
        }).when(namedParameterJdbcTemplate).execute(anyString(), any(MapSqlParameterSource.class), any());

        IfrsDistributionTotalsAdapter adapter =
                new IfrsDistributionTotalsAdapter(namedParameterJdbcTemplate, rulesRepository);
        TrfsDistributionTotals totals = adapter.loadPyTotals("P1001", 10, 2026, 6);

        assertThat(totals.grossAmountTotal()).isEqualByComparingTo("300.00");
        assertThat(totals.netAmountTotal()).isEqualByComparingTo("250.00");
    }

    @Test
    void loadPyTotals_ShouldSumAcrossAllThreePartitions() {
        AlzActProcessRules rule = new AlzActProcessRules();
        rule.setProcessId("P1001");
        rule.setRuleId(5);
        rule.setRuleText("product_code = 'AUTO'");

        when(rulesRepository.findByProcessIdAndRuleIdIn("P1001", List.of(5))).thenReturn(List.of(rule));

        doAnswer(invocation -> {
            String sql = invocation.getArgument(0);
            PreparedStatementCallback<?> callback = invocation.getArgument(2);
            java.sql.PreparedStatement ps = mock(java.sql.PreparedStatement.class);
            java.sql.ResultSet rs = mock(java.sql.ResultSet.class);
            when(ps.executeQuery()).thenReturn(rs);
            when(rs.next()).thenReturn(true);

            if (sql.contains(":yearMinus1")) {
                when(rs.getBigDecimal(1)).thenReturn(BigDecimal.TEN);        // 10
                when(rs.getBigDecimal(2)).thenReturn(BigDecimal.ONE);        // 1
            } else if (sql.contains("BETWEEN :yearMinus3 AND :yearMinus2")) {
                when(rs.getBigDecimal(1)).thenReturn(new BigDecimal("5.00")); // 5
                when(rs.getBigDecimal(2)).thenReturn(new BigDecimal("3.00")); // 3
            } else {
                when(rs.getBigDecimal(1)).thenReturn(new BigDecimal("2.00")); // 2
                when(rs.getBigDecimal(2)).thenReturn(new BigDecimal("1.00")); // 1
            }
            return callback.doInPreparedStatement(ps);
        }).when(namedParameterJdbcTemplate).execute(anyString(), any(MapSqlParameterSource.class), any());

        IfrsDistributionTotalsAdapter adapter =
                new IfrsDistributionTotalsAdapter(namedParameterJdbcTemplate, rulesRepository);
        TrfsDistributionTotals totals = adapter.loadPyTotals("P1001", 5, 2025, 12);

        assertThat(totals.grossAmountTotal()).isEqualByComparingTo("17.00"); // 10+5+2
        assertThat(totals.netAmountTotal()).isEqualByComparingTo("5.00");    // 1+3+1
    }

    @Test
    void loadPyTotals_ShouldRejectUnsafeRuleText() {
        AlzActProcessRules rule = new AlzActProcessRules();
        rule.setProcessId("P1001");
        rule.setRuleId(10);
        rule.setRuleText("1=1; drop table x");

        when(rulesRepository.findByProcessIdAndRuleIdIn("P1001", List.of(10))).thenReturn(List.of(rule));

        IfrsDistributionTotalsAdapter adapter =
                new IfrsDistributionTotalsAdapter(namedParameterJdbcTemplate, rulesRepository);

        assertThatThrownBy(() -> adapter.loadPyTotals("P1001", 10, 2026, 6))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("IFRS rule text güvenli değil");
    }

    @Test
    void loadPyTotals_ShouldRejectTautologyRuleText() {
        AlzActProcessRules rule = new AlzActProcessRules();
        rule.setProcessId("P1001");
        rule.setRuleId(12);
        rule.setRuleText("product_code = 'AUTO' OR 1=1");

        when(rulesRepository.findByProcessIdAndRuleIdIn("P1001", List.of(12))).thenReturn(List.of(rule));

        IfrsDistributionTotalsAdapter adapter =
                new IfrsDistributionTotalsAdapter(namedParameterJdbcTemplate, rulesRepository);

        assertThatThrownBy(() -> adapter.loadPyTotals("P1001", 12, 2026, 6))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("IFRS rule text güvenli değil");
    }

    @Test
    void loadPyTotals_ShouldThrowWhenRuleNotFound() {
        when(rulesRepository.findByProcessIdAndRuleIdIn("P1001", List.of(99))).thenReturn(List.of());

        IfrsDistributionTotalsAdapter adapter =
                new IfrsDistributionTotalsAdapter(namedParameterJdbcTemplate, rulesRepository);

        assertThatThrownBy(() -> adapter.loadPyTotals("P1001", 99, 2026, 6))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("IFRS rule tanımı bulunamadı");
    }
}
