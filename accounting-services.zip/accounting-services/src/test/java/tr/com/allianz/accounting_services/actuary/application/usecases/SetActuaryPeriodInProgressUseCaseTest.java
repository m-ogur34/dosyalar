package tr.com.allianz.accounting_services.actuary.application.usecases;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import tr.com.allianz.accounting_services.actuary.application.service.ActuaryLogService;
import tr.com.allianz.accounting_services.actuary.application.port.out.SaveActuaryPeriodStatusPort;
import tr.com.allianz.accounting_services.actuary.application.port.out.LoadActuaryPeriodStatusPort;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.ActuaryPeriodStatus;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
@ExtendWith(MockitoExtension.class)
class SetActuaryPeriodInProgressUseCaseTest {
    @Mock
    private SaveActuaryPeriodStatusPort saveActuaryPeriodStatusPort;
    @Mock
    private LoadActuaryPeriodStatusPort loadActuaryPeriodStatusPort;
    @Mock
    private ActuaryLogService actuaryLogService;
    @InjectMocks
    private SetActuaryPeriodInProgressUseCase useCase;
    @Test
    void handle_ShouldSetStatusInProgress() {
        when(loadActuaryPeriodStatusPort.getStatus("P1001", 2026, 6))
                .thenReturn(ActuaryPeriodStatus.APPROVED);

        useCase.handle("P1001", 2026, 6, "tester");
        verify(saveActuaryPeriodStatusPort)
                .upsertStatus("P1001", 2026, 6, ActuaryPeriodStatus.IN_PROGRESS);
        verify(actuaryLogService).logInProgress("P1001", 2026, 6, "tester");
    }

    @Test
    void handle_ShouldRejectPeriodOlderThanOneMonthAgo() {
        assertThatThrownBy(() -> useCase.handle("P1001", 2026, 4, "tester"))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("işlem yapılamaz");
    }

    @Test
    void handle_ShouldRejectIfNotApproved() {
        when(loadActuaryPeriodStatusPort.getStatus("P1001", 2026, 6))
                .thenReturn(ActuaryPeriodStatus.IN_PROGRESS);

        assertThatThrownBy(() -> useCase.handle("P1001", 2026, 6, "tester"))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("'Approved' olmalıdır");
    }

    @Test
    void handle_ShouldRejectIfStatusIsNull() {
        when(loadActuaryPeriodStatusPort.getStatus("P1001", 2026, 6))
                .thenReturn(null);

        assertThatThrownBy(() -> useCase.handle("P1001", 2026, 6, "tester"))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("Mevcut statü: yok");
    }

    @Test
    void handle_WithDefaultSystemUser_ShouldUseSystemUser() {
        when(loadActuaryPeriodStatusPort.getStatus("P1001", 2026, 6))
                .thenReturn(ActuaryPeriodStatus.APPROVED);

        useCase.handle("P1001", 2026, 6);

        verify(saveActuaryPeriodStatusPort)
                .upsertStatus("P1001", 2026, 6, ActuaryPeriodStatus.IN_PROGRESS);
        verify(actuaryLogService).logInProgress("P1001", 2026, 6, "SYSTEM");
    }
}