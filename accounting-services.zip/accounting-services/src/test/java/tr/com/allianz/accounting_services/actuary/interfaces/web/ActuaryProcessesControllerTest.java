package tr.com.allianz.accounting_services.actuary.interfaces.web;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;
import tr.com.allianz.accounting_services.actuary.application.service.ActuaryLogService;
import tr.com.allianz.accounting_services.actuary.application.usecases.ApproveActuaryPeriodUseCase;
import tr.com.allianz.accounting_services.actuary.application.usecases.ListActuaryProcessesUseCase;
import tr.com.allianz.accounting_services.actuary.application.usecases.SetActuaryPeriodInProgressUseCase;
import tr.com.allianz.accounting_services.actuary.application.usecases.ExecuteDistributionUseCase;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.ActuaryProcess;
import tr.com.allianz.accounting_services.actuary.interfaces.web.dto.ActuaryProcessResponseDto;
import tr.com.allianz.accounting_services.actuary.interfaces.web.dto.ActuaryQueryRequestDto;
import tr.com.allianz.accounting_services.shared.api.ApiResponse;
import java.time.LocalDate;
import java.util.List;
import java.security.Principal;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
@ExtendWith(MockitoExtension.class)
class ActuaryProcessesControllerTest {
    @Mock
    private ListActuaryProcessesUseCase listActuaryProcessesUseCase;

    @Mock
    private ApproveActuaryPeriodUseCase approveActuaryPeriodUseCase;

    @Mock
    private SetActuaryPeriodInProgressUseCase setActuaryPeriodInProgressUseCase;

    @Mock
    private ExecuteDistributionUseCase executeDistributionUseCase;

    @Mock
    private ActuaryLogService actuaryLogService;

    @InjectMocks
    private ActuaryProcessesController controller;
    @Test
    void listActiveProcesses_ShouldReturnApiResponse() {
        ActuaryProcess process = new ActuaryProcess("P1001", "Process 1", "Desc", LocalDate.now().minusDays(1), LocalDate.now().plusDays(1));
        when(listActuaryProcessesUseCase.handle()).thenReturn(List.of(process));
        ResponseEntity<ApiResponse<List<ActuaryProcessResponseDto>>> response = controller.listActiveProcesses();
        assertThat(response.getStatusCode().value()).isEqualTo(200);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().data()).hasSize(1);
        verify(listActuaryProcessesUseCase).handle();
    }

    @Test
    void approveActuaryPeriod_ShouldReturnSuccessResponse() {
        ActuaryQueryRequestDto request = new ActuaryQueryRequestDto("P1001", 2024, 6);

        ResponseEntity<ApiResponse<Void>> response = controller.approveActuaryPeriod(request, null);

        assertThat(response.getStatusCode().value()).isEqualTo(200);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().success()).isTrue();
        assertThat(response.getBody().code()).isEqualTo("SUCCESS");

        verify(approveActuaryPeriodUseCase).handle("P1001", 2024, 6, "SYSTEM");
    }

    @Test
    void approveActuaryPeriod_ShouldReturnBadRequestWhenNotInProgress() {
        ActuaryQueryRequestDto request = new ActuaryQueryRequestDto("P1001", 2026, 4);
        String errorMessage = "Onaylanabilmesi için statü 'In Progress' olmalıdır. Mevcut statü: Approved";
        
        doThrow(new IllegalArgumentException(errorMessage))
                .when(approveActuaryPeriodUseCase)
                .handle("P1001", 2026, 4, "SYSTEM");

        ResponseEntity<ApiResponse<Void>> response = controller.approveActuaryPeriod(request, null);

        assertThat(response.getStatusCode().value()).isEqualTo(400);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().success()).isFalse();
        assertThat(response.getBody().code()).isEqualTo("VALIDATION_ERROR");
        assertThat(response.getBody().message()).isEqualTo(errorMessage);

        verify(actuaryLogService).logError(
                "P1001",
                2026,
                4,
                "Approval failed: " + errorMessage,
                "SYSTEM"
        );
    }

    @Test
    void setActuaryPeriodInProgress_ShouldReturnSuccessResponse() {
        ActuaryQueryRequestDto request = new ActuaryQueryRequestDto("P1001", 2024, 6);

        ResponseEntity<ApiResponse<Void>> response = controller.setActuaryPeriodInProgress(request, null);

        assertThat(response.getStatusCode().value()).isEqualTo(200);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().success()).isTrue();
        assertThat(response.getBody().code()).isEqualTo("SUCCESS");

        verify(setActuaryPeriodInProgressUseCase).handle("P1001", 2024, 6, "SYSTEM");
    }

    @Test
    void setActuaryPeriodInProgress_ShouldReturnBadRequestWhenPeriodTooOld() {
        ActuaryQueryRequestDto request = new ActuaryQueryRequestDto("P1001", 2026, 4);
        String errorMessage = "Seçilen ay ve yıl için işlem yapılamaz. En fazla 1 ay öncesi için işlem yapılabilir.";
        
        doThrow(new IllegalArgumentException(errorMessage))
                .when(setActuaryPeriodInProgressUseCase)
                .handle("P1001", 2026, 4, "SYSTEM");

        ResponseEntity<ApiResponse<Void>> response = controller.setActuaryPeriodInProgress(request, null);

        assertThat(response.getStatusCode().value()).isEqualTo(400);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().success()).isFalse();
        assertThat(response.getBody().code()).isEqualTo("VALIDATION_ERROR");
        assertThat(response.getBody().message()).isEqualTo(errorMessage);

        verify(actuaryLogService).logError(
                "P1001",
                2026,
                4,
                "Setting In Progress failed: " + errorMessage,
                "SYSTEM"
        );
    }

    @Test
    void revokeActuaryApproval_ShouldReturnSuccessResponse() {
        ActuaryQueryRequestDto request = new ActuaryQueryRequestDto("P1001", 2024, 6);

        ResponseEntity<ApiResponse<Void>> response = controller.revokeActuaryApproval(request, null);

        assertThat(response.getStatusCode().value()).isEqualTo(200);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().success()).isTrue();
        assertThat(response.getBody().code()).isEqualTo("SUCCESS");

        verify(setActuaryPeriodInProgressUseCase).handle("P1001", 2024, 6, "SYSTEM");
    }

    @Test
    void revokeActuaryApproval_ShouldUsePrincipalNameWhenPresent() {
        ActuaryQueryRequestDto request = new ActuaryQueryRequestDto("P1001", 2024, 6);
        Principal principal = () -> "tester";

        ResponseEntity<ApiResponse<Void>> response = controller.revokeActuaryApproval(request, principal);

        assertThat(response.getStatusCode().value()).isEqualTo(200);
        verify(setActuaryPeriodInProgressUseCase).handle("P1001", 2024, 6, "tester");
    }

    @Test
    void revokeActuaryApproval_ShouldReturnBadRequestWhenValidationFails() {
        ActuaryQueryRequestDto request = new ActuaryQueryRequestDto("P1001", 2026, 4);
        String errorMessage = "Sadece Approved statüsündeki dönemler revoke edilebilir.";

        doThrow(new IllegalArgumentException(errorMessage))
                .when(setActuaryPeriodInProgressUseCase)
                .handle("P1001", 2026, 4, "SYSTEM");

        ResponseEntity<ApiResponse<Void>> response = controller.revokeActuaryApproval(request, null);

        assertThat(response.getStatusCode().value()).isEqualTo(400);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().success()).isFalse();
        assertThat(response.getBody().code()).isEqualTo("VALIDATION_ERROR");
        assertThat(response.getBody().message()).isEqualTo(errorMessage);

        verify(actuaryLogService).logError(
                "P1001",
                2026,
                4,
                "Revoke approval failed: " + errorMessage,
                "SYSTEM"
        );
    }

    @Test
    void executeDistribution_ShouldReturnSuccessAndAutoApprove() {
        ActuaryQueryRequestDto request = new ActuaryQueryRequestDto("P1001", 2024, 6);

        ResponseEntity<ApiResponse<Void>> response = controller.executeDistribution(request, null);

        assertThat(response.getStatusCode().value()).isEqualTo(200);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().success()).isTrue();
        assertThat(response.getBody().code()).isEqualTo("SUCCESS");

        verify(executeDistributionUseCase).handle("P1001", 2024, 6, "SYSTEM");
        verify(approveActuaryPeriodUseCase).handle("P1001", 2024, 6, "SYSTEM");
    }

    @Test
    void executeDistribution_ShouldReturnBadRequestWhenDistributionValidationFails() {
        ActuaryQueryRequestDto request = new ActuaryQueryRequestDto("P1001", 2026, 4);
        String errorMessage = "Distribution precondition failed";

        doThrow(new IllegalArgumentException(errorMessage))
                .when(executeDistributionUseCase)
                .handle("P1001", 2026, 4, "SYSTEM");

        ResponseEntity<ApiResponse<Void>> response = controller.executeDistribution(request, null);

        assertThat(response.getStatusCode().value()).isEqualTo(400);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().success()).isFalse();
        assertThat(response.getBody().code()).isEqualTo("VALIDATION_ERROR");
        assertThat(response.getBody().message()).isEqualTo(errorMessage);

        verify(actuaryLogService).logError(
                "P1001",
                2026,
                4,
                "Execute distribution failed: " + errorMessage,
                "SYSTEM"
        );
    }

    @Test
    void executeDistribution_ShouldReturnBadRequestWhenApproveValidationFails() {
        ActuaryQueryRequestDto request = new ActuaryQueryRequestDto("P1001", 2026, 4);
        String errorMessage = "Onaylanabilmesi için statü 'In Progress' olmalıdır. Mevcut statü: Approved";

        doThrow(new IllegalArgumentException(errorMessage))
                .when(approveActuaryPeriodUseCase)
                .handle("P1001", 2026, 4, "SYSTEM");

        ResponseEntity<ApiResponse<Void>> response = controller.executeDistribution(request, null);

        assertThat(response.getStatusCode().value()).isEqualTo(400);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().success()).isFalse();
        assertThat(response.getBody().code()).isEqualTo("VALIDATION_ERROR");
        assertThat(response.getBody().message()).isEqualTo(errorMessage);

        verify(executeDistributionUseCase).handle("P1001", 2026, 4, "SYSTEM");
        verify(actuaryLogService).logError(
                "P1001",
                2026,
                4,
                "Execute distribution failed: " + errorMessage,
                "SYSTEM"
        );
    }

    @Test
    void approveActuaryPeriod_ShouldLogAndRethrow_WhenUnexpectedErrorOccurs() {
        ActuaryQueryRequestDto request = new ActuaryQueryRequestDto("P1001", 2026, 4);
        doThrow(new RuntimeException("db down"))
                .when(approveActuaryPeriodUseCase)
                .handle("P1001", 2026, 4, "SYSTEM");

        assertThatThrownBy(() -> controller.approveActuaryPeriod(request, null))
                .isInstanceOf(RuntimeException.class)
                .hasMessage("db down");

        verify(actuaryLogService).logError("P1001", 2026, 4, "Approval failed: db down", "SYSTEM");
    }

    @Test
    void setActuaryPeriodInProgress_ShouldLogAndRethrow_WhenUnexpectedErrorOccurs() {
        ActuaryQueryRequestDto request = new ActuaryQueryRequestDto("P1001", 2026, 4);
        doThrow(new RuntimeException("db down"))
                .when(setActuaryPeriodInProgressUseCase)
                .handle("P1001", 2026, 4, "SYSTEM");

        assertThatThrownBy(() -> controller.setActuaryPeriodInProgress(request, null))
                .isInstanceOf(RuntimeException.class)
                .hasMessage("db down");

        verify(actuaryLogService).logError("P1001", 2026, 4, "Setting In Progress failed: db down", "SYSTEM");
    }

    @Test
    void revokeActuaryApproval_ShouldLogAndRethrow_WhenUnexpectedErrorOccurs() {
        ActuaryQueryRequestDto request = new ActuaryQueryRequestDto("P1001", 2026, 4);
        doThrow(new RuntimeException("db down"))
                .when(setActuaryPeriodInProgressUseCase)
                .handle("P1001", 2026, 4, "SYSTEM");

        assertThatThrownBy(() -> controller.revokeActuaryApproval(request, null))
                .isInstanceOf(RuntimeException.class)
                .hasMessage("db down");

        verify(actuaryLogService).logError("P1001", 2026, 4, "Revoke approval failed: db down", "SYSTEM");
    }

    @Test
    void executeDistribution_ShouldLogAndRethrow_WhenUnexpectedErrorOccurs() {
        ActuaryQueryRequestDto request = new ActuaryQueryRequestDto("P1001", 2026, 4);
        doThrow(new RuntimeException("db down"))
                .when(executeDistributionUseCase)
                .handle("P1001", 2026, 4, "SYSTEM");

        assertThatThrownBy(() -> controller.executeDistribution(request, null))
                .isInstanceOf(RuntimeException.class)
                .hasMessage("db down");

        verify(actuaryLogService).logError("P1001", 2026, 4, "Execute distribution failed: db down", "SYSTEM");
    }
}
