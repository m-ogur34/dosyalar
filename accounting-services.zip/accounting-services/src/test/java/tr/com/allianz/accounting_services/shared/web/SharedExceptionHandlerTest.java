package tr.com.allianz.accounting_services.shared.web;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.MethodParameter;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import tr.com.allianz.accounting_services.shared.api.ApiResponse;
import tr.com.allianz.accounting_services.shared.api.ErrorDetail;
import tr.com.allianz.accounting_services.shared.exception.BaseApplicationException;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class SharedExceptionHandlerTest {

    @InjectMocks
    private SharedExceptionHandler exceptionHandler;

    // Concrete implementation for testing BaseApplicationException
    private static class TestAppException extends BaseApplicationException {
        protected TestAppException(String errorCode, String message, String detail, HttpStatus httpStatus) {
            super(errorCode, message, detail, httpStatus);
        }
    }

    @Test
    void handleBaseApplicationException_ShouldReturnCorrectResponse() {
        // Arrange
        String errorCode = "ERR_001";
        String message = "Custom error";
        String detailMsg = "Detail info";
        HttpStatus status = HttpStatus.BAD_REQUEST;

        TestAppException ex = new TestAppException(errorCode, message, detailMsg, status);

        // Act
        ResponseEntity<ApiResponse<List<ErrorDetail>>> response = exceptionHandler.handleBaseApplicationException(ex);

        // Assert
        assertThat(response.getStatusCode()).isEqualTo(status);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().code()).isEqualTo(errorCode);
        assertThat(response.getBody().message()).isEqualTo(message);
        assertThat(response.getBody().data()).hasSize(1);
        assertThat(response.getBody().data().getFirst().field()).isEqualTo("error");
        assertThat(response.getBody().data().getFirst().message()).isEqualTo(detailMsg);
    }

    @Test
    void handleValidation_ShouldReturnBadRequestWithDetails() {
        // Arrange
        BindingResult bindingResult = mock(BindingResult.class);
        MethodArgumentNotValidException ex = new MethodArgumentNotValidException(mock(MethodParameter.class), bindingResult);

        FieldError fieldError = new FieldError("objectName", "fieldName", "must not be null");
        ObjectError objectError = new ObjectError("objectName", "Global error message");

        when(bindingResult.getAllErrors()).thenReturn(List.of(fieldError, objectError));

        // Act
        ResponseEntity<ApiResponse<List<ErrorDetail>>> response = exceptionHandler.handleValidation(ex);

        // Assert
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().code()).isEqualTo("VALIDATION_ERROR");
        assertThat(response.getBody().data()).hasSize(2);

        // Check field error
        ErrorDetail detail1 = response.getBody().data().getFirst();
        assertThat(detail1.field()).isEqualTo("fieldName");
        assertThat(detail1.message()).isEqualTo("must not be null");

        // Check global error
        ErrorDetail detail2 = response.getBody().data().get(1);
        assertThat(detail2.field()).isEqualTo("objectName");
        assertThat(detail2.message()).isEqualTo("Global error message");
    }

    @Test
    void handleGeneric_ShouldReturnInternalServerError() {
        // Arrange
        Exception ex = new NullPointerException("Something null");

        // Act
        ResponseEntity<ApiResponse<List<ErrorDetail>>> response = exceptionHandler.handleGeneric(ex);

        // Assert
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().code()).isEqualTo("UNEXPECTED_ERROR");
        assertThat(response.getBody().message()).contains("NullPointerException");
    }
}

