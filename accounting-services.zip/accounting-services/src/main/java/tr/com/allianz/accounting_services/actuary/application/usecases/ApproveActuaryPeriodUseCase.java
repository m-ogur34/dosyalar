package tr.com.allianz.accounting_services.actuary.application.usecases;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import tr.com.allianz.accounting_services.actuary.application.service.ActuaryLogService;
import tr.com.allianz.accounting_services.actuary.application.port.out.SaveActuaryPeriodStatusPort;
import tr.com.allianz.accounting_services.actuary.application.port.out.LoadActuaryPeriodStatusPort;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.ActuaryPeriodStatus;

@Service
@RequiredArgsConstructor
@Transactional
public class ApproveActuaryPeriodUseCase {

    private final SaveActuaryPeriodStatusPort saveActuaryPeriodStatusPort;
    private final LoadActuaryPeriodStatusPort loadActuaryPeriodStatusPort;
    private final ActuaryLogService actuaryLogService;

    public void handle(String processId, Integer year, Integer month, String byUser) {
        validateCurrentStatus(processId, year, month);
        saveActuaryPeriodStatusPort.upsertStatus(processId, year, month, ActuaryPeriodStatus.APPROVED);
        actuaryLogService.logApprove(processId, year, month, byUser);
    }

    private void validateCurrentStatus(String processId, Integer year, Integer month) {
        ActuaryPeriodStatus currentStatus = loadActuaryPeriodStatusPort.getStatus(processId, year, month);
        if (currentStatus != ActuaryPeriodStatus.IN_PROGRESS) {
            throw new IllegalArgumentException("Onaylanabilmesi için statü 'In Progress' olmalıdır. Mevcut statü: " + 
                (currentStatus != null ? currentStatus.getValue() : "yok"));
        }
    }

    public void handle(String processId, Integer year, Integer month) {
        handle(processId, year, month, "SYSTEM");
    }
}

