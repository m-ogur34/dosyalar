package tr.com.allianz.accounting_services.actuary.application.usecases;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;
import tr.com.allianz.accounting_services.actuary.application.port.out.ParseActuaryProcessAmountExcelPort;
import tr.com.allianz.accounting_services.actuary.application.port.out.SaveActuaryProcessAmountPort;
import tr.com.allianz.accounting_services.actuary.application.service.ActuaryLogService;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.ActuaryProcessAmount;

import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional
public class UploadActuaryProcessAmountExcelUseCase {

    private final ParseActuaryProcessAmountExcelPort parseActuaryProcessAmountExcelPort;
    private final SaveActuaryProcessAmountPort saveActuaryProcessAmountPort;
    private final ActuaryLogService actuaryLogService;

    public int handle(MultipartFile file, Integer year, Integer month, String byUser) {
        List<ActuaryProcessAmount> amounts = parseActuaryProcessAmountExcelPort.parse(file)
                .stream()
                .map(row -> new ActuaryProcessAmount(
                        year,
                        month,
                        row.processId(),
                        row.ruleId(),
                        row.grossCyAmount(),
                        row.reCyAmount(),
                        row.netCyAmount(),
                        row.grossPyAmount(),
                        row.rePyAmount(),
                        row.netPyAmount(),
                        row.ifrsCyGross(),
                        row.ifrsCyRe(),
                        row.ifrsCyNet(),
                        row.ifrsPyGross(),
                        row.ifrsPyRe(),
                        row.ifrsPyNet(),
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null
                ))
                .toList();

        saveActuaryProcessAmountPort.saveAll(amounts);

        actuaryLogService.logExcelUpload(
                null,
                year,
                month,
                amounts.size(),
                byUser
        );

        return amounts.size();
    }

    public int handle(MultipartFile file, Integer year, Integer month) {
        return handle(file, year, month, "SYSTEM");
    }
}

