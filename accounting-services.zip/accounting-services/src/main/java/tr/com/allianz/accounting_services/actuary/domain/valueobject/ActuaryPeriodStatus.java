package tr.com.allianz.accounting_services.actuary.domain.valueobject;

public enum ActuaryPeriodStatus {
    IN_PROGRESS("In Progress"),
    APPROVED("Approved");

    private final String value;

    ActuaryPeriodStatus(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public static ActuaryPeriodStatus fromValue(String value) {
        if (value == null) {
            return null;
        }
        for (ActuaryPeriodStatus status : values()) {
            if (status.value.equalsIgnoreCase(value)) {
                return status;
            }
        }
        throw new IllegalArgumentException("Unknown ActuaryPeriodStatus value: " + value);
    }
}

