package tr.com.allianz.accounting_services.actuary.infrastructure.persistence.adapter;

import lombok.RequiredArgsConstructor;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;
import tr.com.allianz.accounting_services.actuary.application.port.out.ParseActuaryProcessAmountExcelPort;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.ActuaryProcessAmountExcelRow;
import tr.com.allianz.accounting_services.actuary.infrastructure.persistence.entity.AlzActProcessRules;
import tr.com.allianz.accounting_services.actuary.infrastructure.persistence.repository.AlzActProcessRulesRepository;

import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Component
@RequiredArgsConstructor
public class ActuaryProcessAmountExcelAdapter implements ParseActuaryProcessAmountExcelPort {

    private final AlzActProcessRulesRepository alzActProcessRulesRepository;

    // Constants for Excel validation
    private static final long MAX_FILE_SIZE = 5 * 1024 * 1024; // 5 MB
    private static final String[] ALLOWED_EXTENSIONS = {".xlsx", ".xls"};
    private static final String[] ALLOWED_CONTENT_TYPES = {
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            "application/vnd.ms-excel"
    };

    private static final int PROCESS_ID_COL = 0;
    private static final int RULE_ID_COL = 1;
    private static final int RULE_NAME_COL = 2;

    private static final int COL_1 = 3;
    private static final int COL_2 = 4;
    private static final int COL_3 = 5;
    private static final int COL_4 = 6;
    private static final int COL_5 = 7;
    private static final int COL_6 = 8;


    @Override
    public List<ActuaryProcessAmountExcelRow> parse(MultipartFile file) {
        if (file == null || file.isEmpty()) {
            throw new IllegalArgumentException("Excel dosyasi bos olamaz");
        }

        // Validate file
        validateExcelFile(file);

        DataFormatter formatter = new DataFormatter();
        List<ActuaryProcessAmountExcelRow> rows = new ArrayList<>();

        try (InputStream is = file.getInputStream(); Workbook workbook = WorkbookFactory.create(is)) {
            Sheet sheet = workbook.getSheetAt(0);
            ExcelType excelType = detectExcelType(sheet, formatter);

            for (int i = 1; i <= sheet.getLastRowNum(); i++) {
                Row row = sheet.getRow(i);
                if (row == null || isRowEmpty(row, formatter)) {
                    continue;
                }

                String processId = getCellValue(row, PROCESS_ID_COL, formatter);
                Integer ruleId = toInteger(getCellValue(row, RULE_ID_COL, formatter));
                String ruleName = getCellValue(row, RULE_NAME_COL, formatter);

                if (processId == null || processId.isBlank()) {
                    throw new IllegalArgumentException("Process ID bos olamaz. Satir: " + (i + 1));
                }

                // If ruleId is empty, try to find it using ruleName and processId
                if (ruleId == null) {
                    if (ruleName == null || ruleName.isBlank()) {
                        throw new IllegalArgumentException("Rule ID veya Rule Name bos olamaz. Satir: " + (i + 1));
                    }
                    ruleId = findRuleIdByNameAndProcessId(ruleName, processId, i + 1);
                }

                rows.add(new ActuaryProcessAmountExcelRow(
                        processId,
                        ruleId,
                        ruleName,
                        excelType == ExcelType.AMOUNT ? toBigDecimal(getCellValue(row, COL_1, formatter)) : null,
                        excelType == ExcelType.AMOUNT ? toBigDecimal(getCellValue(row, COL_2, formatter)) : null,
                        excelType == ExcelType.AMOUNT ? toBigDecimal(getCellValue(row, COL_3, formatter)) : null,
                        excelType == ExcelType.AMOUNT ? toBigDecimal(getCellValue(row, COL_4, formatter)) : null,
                        excelType == ExcelType.AMOUNT ? toBigDecimal(getCellValue(row, COL_5, formatter)) : null,
                        excelType == ExcelType.AMOUNT ? toBigDecimal(getCellValue(row, COL_6, formatter)) : null,
                        excelType == ExcelType.IFRS ? toBigDecimal(getCellValue(row, COL_1, formatter)) : null,
                        excelType == ExcelType.IFRS ? toBigDecimal(getCellValue(row, COL_2, formatter)) : null,
                        excelType == ExcelType.IFRS ? toBigDecimal(getCellValue(row, COL_3, formatter)) : null,
                        excelType == ExcelType.IFRS ? toBigDecimal(getCellValue(row, COL_4, formatter)) : null,
                        excelType == ExcelType.IFRS ? toBigDecimal(getCellValue(row, COL_5, formatter)) : null,
                        excelType == ExcelType.IFRS ? toBigDecimal(getCellValue(row, COL_6, formatter)) : null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null
                ));
            }

            return rows;
        } catch (IOException e) {
            throw new IllegalArgumentException("Excel dosyasi okunamadi", e);
        }
    }

    private Integer findRuleIdByNameAndProcessId(String ruleName, String processId, int rowNumber) {
        return alzActProcessRulesRepository.findByRuleNameAndProcessId(ruleName, processId)
                .map(AlzActProcessRules::getRuleId)
                .orElseThrow(() -> new IllegalArgumentException(
                        "Rule ID bulunamadi. Rule Name: " + ruleName + ", Process ID: " + processId + ", Satir: " + rowNumber
                ));
    }

    private String getCellValue(Row row, int index, DataFormatter formatter) {
        if (row.getCell(index) == null) {
            return null;
        }
        String value = formatter.formatCellValue(row.getCell(index));
        return value == null ? null : value.trim();
    }

    private Integer toInteger(String value) {
        if (value == null || value.isBlank()) {
            return null;
        }
        return new BigDecimal(value).intValue();
    }

    private BigDecimal toBigDecimal(String value) {
        if (value == null || value.isBlank()) {
            return null;
        }
        return new BigDecimal(value.replace(",", "."));
    }

    private boolean isRowEmpty(Row row, DataFormatter formatter) {
        for (int i = 0; i <= COL_6; i++) {
            String cellValue = getCellValue(row, i, formatter);
            if (cellValue != null && !cellValue.isBlank()) {
                return false;
            }
        }
        return true;
    }

    private ExcelType detectExcelType(Sheet sheet, DataFormatter formatter) {
        Row headerRow = sheet.getRow(0);
        if (headerRow == null) {
            throw new IllegalArgumentException("Excel header satiri bos olamaz");
        }

        String h1 = normalizeHeader(getCellValue(headerRow, COL_1, formatter));
        String h2 = normalizeHeader(getCellValue(headerRow, COL_2, formatter));
        String h3 = normalizeHeader(getCellValue(headerRow, COL_3, formatter));

        if (h1.startsWith("IFRS_") || h2.startsWith("IFRS_") || h3.startsWith("IFRS_")) {
            return ExcelType.IFRS;
        }
        return ExcelType.AMOUNT;
    }

    private String normalizeHeader(String value) {
        return value == null ? "" : value.trim().toUpperCase();
    }

    private enum ExcelType {
        AMOUNT,
        IFRS
    }

    private void validateExcelFile(MultipartFile file) {
        // Check file size
        if (file.getSize() > MAX_FILE_SIZE) {
            throw new IllegalArgumentException(
                    String.format("Dosya boyutu %d MB'ı geçemez. Yüklenen dosya: %.2f MB",
                            MAX_FILE_SIZE / (1024 * 1024),
                            (double) file.getSize() / (1024 * 1024))
            );
        }

        // Check file extension
        String filename = file.getOriginalFilename();
        if (filename == null || !hasAllowedExtension(filename)) {
            throw new IllegalArgumentException(
                    "Geçersiz dosya formatı. Lütfen Excel formatında dosya yükleyiniz (.xlsx, .xls)"
            );
        }

        // Check content type
        String contentType = file.getContentType();
        if (contentType == null || !isAllowedContentType(contentType)) {
            throw new IllegalArgumentException(
                    "Geçersiz dosya türü. Lütfen Excel formatında dosya yükleyiniz."
            );
        }
    }

    private boolean hasAllowedExtension(String filename) {
        String lowerFilename = filename.toLowerCase();
        for (String ext : ALLOWED_EXTENSIONS) {
            if (lowerFilename.endsWith(ext)) {
                return true;
            }
        }
        return false;
    }

    private boolean isAllowedContentType(String contentType) {
        for (String type : ALLOWED_CONTENT_TYPES) {
            if (contentType.equals(type) || contentType.contains(type)) {
                return true;
            }
        }
        return false;
    }
}

