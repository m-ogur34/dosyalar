package tr.com.allianz.accounting_services.actuary.infrastructure.persistence.adapter;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.regex.Pattern;

final class SqlRulePredicateSupport {

    private static final int MAX_RULE_TEXT_LENGTH = 500;

    private static final Pattern FORBIDDEN_SQL_PATTERN = Pattern.compile(
            "(;|--|/\\*|\\*/|\\b(select|update|delete|insert|merge|drop|alter|truncate|union|commit|rollback|execute|call|grant|revoke|declare|begin|end)\\b|\\|\\||\\b(dbms_|utl_|chr\\s*\\())",
            Pattern.CASE_INSENSITIVE
    );

    private static final Pattern ALLOWED_RULE_TEXT_PATTERN = Pattern.compile("^[A-Za-z0-9_\\s.,()'=<>!%]+$");
    private static final Pattern NUMERIC_TAUTOLOGY_PATTERN = Pattern.compile("\\b(\\d+)\\s*=\\s*\\1\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern STRING_TAUTOLOGY_PATTERN = Pattern.compile("'([^']*)'\\s*=\\s*'\\1'", Pattern.CASE_INSENSITIVE);

    private SqlRulePredicateSupport() {
    }

    static String sanitizeRuleText(String ruleText, String processId, Integer ruleId, String ruleLabel) {
        if (ruleText == null || ruleText.isBlank()) {
            throw new IllegalArgumentException(
                    String.format(Locale.ROOT, "%s boş olamaz. processId=%s, ruleId=%s", ruleLabel, processId, ruleId)
            );
        }

        String trimmed = ruleText.trim();
        if (trimmed.length() > MAX_RULE_TEXT_LENGTH ||
                FORBIDDEN_SQL_PATTERN.matcher(trimmed).find() ||
                !ALLOWED_RULE_TEXT_PATTERN.matcher(trimmed).matches() ||
                NUMERIC_TAUTOLOGY_PATTERN.matcher(trimmed).find() ||
                STRING_TAUTOLOGY_PATTERN.matcher(trimmed).find() ||
                !hasBalancedParentheses(trimmed) ||
                !hasEvenSingleQuotes(trimmed)) {
            throw new IllegalArgumentException(
                    String.format(Locale.ROOT, "%s güvenli değil. processId=%s, ruleId=%s", ruleLabel, processId, ruleId)
            );
        }
        return trimmed;
    }

    static RulePredicate compile(String ruleText, Integer ruleId) {
        String sanitized = sanitizeRuleText(ruleText, "P1001", ruleId, "Rule text");
        Parser parser = new Parser(tokenize(sanitized), "P1001", ruleId, "Rule text");
        return parser.parse();
    }

    static RulePredicate compile(String ruleText, String processId, Integer ruleId, String ruleLabel) {
        String sanitized = sanitizeRuleText(ruleText, processId, ruleId, ruleLabel);
        Parser parser = new Parser(tokenize(sanitized), processId, ruleId, ruleLabel);
        return parser.parse();
    }


    private static boolean hasBalancedParentheses(String text) {
        int depth = 0;
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (c == '(') {
                depth++;
            } else if (c == ')') {
                depth--;
                if (depth < 0) {
                    return false;
                }
            }
        }
        return depth == 0;
    }

    private static boolean hasEvenSingleQuotes(String text) {
        long count = text.chars().filter(ch -> ch == '\'').count();
        return count % 2 == 0;
    }

    private static List<Token> tokenize(String text) {
        List<Token> tokens = new ArrayList<>();
        int index = 0;
        while (index < text.length()) {
            char current = text.charAt(index);
            if (Character.isWhitespace(current)) {
                index++;
                continue;
            }
            if (current == '(') {
                tokens.add(new Token(TokenType.LPAREN, "("));
                index++;
                continue;
            }
            if (current == ')') {
                tokens.add(new Token(TokenType.RPAREN, ")"));
                index++;
                continue;
            }
            if (current == ',') {
                tokens.add(new Token(TokenType.COMMA, ","));
                index++;
                continue;
            }
            if (current == '\'') {
                int end = text.indexOf('\'', index + 1);
                if (end < 0) {
                    throw invalidRule("Eksik tek tırnak", null, null, null);
                }
                tokens.add(new Token(TokenType.STRING, text.substring(index + 1, end)));
                index = end + 1;
                continue;
            }
            if (index + 1 < text.length()) {
                String twoChars = text.substring(index, index + 2);
                if (twoChars.equals("<=") || twoChars.equals(">=") || twoChars.equals("<>") || twoChars.equals("!=")) {
                    tokens.add(new Token(TokenType.OPERATOR, twoChars));
                    index += 2;
                    continue;
                }
            }
            if (current == '=' || current == '<' || current == '>') {
                tokens.add(new Token(TokenType.OPERATOR, String.valueOf(current)));
                index++;
                continue;
            }
            if (Character.isDigit(current)) {
                int start = index;
                index++;
                while (index < text.length() && (Character.isDigit(text.charAt(index)) || text.charAt(index) == '.')) {
                    index++;
                }
                tokens.add(new Token(TokenType.NUMBER, text.substring(start, index)));
                continue;
            }
            if (Character.isLetter(current) || current == '_') {
                int start = index;
                index++;
                while (index < text.length() && (Character.isLetterOrDigit(text.charAt(index)) || text.charAt(index) == '_')) {
                    index++;
                }
                String word = text.substring(start, index);
                String upperWord = word.toUpperCase(Locale.ROOT);
                if (upperWord.equals("AND") || upperWord.equals("OR") || upperWord.equals("NOT")
                        || upperWord.equals("IN") || upperWord.equals("IS") || upperWord.equals("NULL")
                        || upperWord.equals("LIKE")) {
                    tokens.add(new Token(TokenType.KEYWORD, upperWord));
                } else {
                    tokens.add(new Token(TokenType.IDENTIFIER, word));
                }
                continue;
            }
            throw invalidRule("Desteklenmeyen karakter: " + current, null, null, null);
        }
        tokens.add(new Token(TokenType.EOF, ""));
        return tokens;
    }

    private static IllegalArgumentException invalidRule(String detail, String processId, Integer ruleId, String ruleLabel) {
        String label = ruleLabel == null ? "Rule text" : ruleLabel;
        return new IllegalArgumentException(
                String.format(Locale.ROOT, "%s güvenli değil. %s processId=%s, ruleId=%s",
                        label,
                        detail == null ? "" : detail,
                        processId,
                        ruleId).trim()
        );
    }

    record RulePredicate(Expression expression) {
        boolean matches(Map<String, Object> row) {
            return expression.evaluate(row);
        }
    }

    private interface Expression {
        boolean evaluate(Map<String, Object> row);
    }

    private interface ValueExpression {
        Object resolve(Map<String, Object> row);
    }

    private record Token(TokenType type, String text) {
    }

    private enum TokenType {
        IDENTIFIER, STRING, NUMBER, OPERATOR, KEYWORD, LPAREN, RPAREN, COMMA, EOF
    }

    private static final class Parser {
        private final List<Token> tokens;
        private final String processId;
        private final Integer ruleId;
        private final String ruleLabel;
        private int currentIndex;

        private Parser(List<Token> tokens, String processId, Integer ruleId, String ruleLabel) {
            this.tokens = tokens;
            this.processId = processId;
            this.ruleId = ruleId;
            this.ruleLabel = ruleLabel;
        }

        RulePredicate parse() {
            Expression expression = parseOr();
            expect(TokenType.EOF);
            return new RulePredicate(expression);
        }

        private Expression parseOr() {
            Expression expression = parseAnd();
            while (matchKeyword("OR")) {
                Expression right = parseAnd();
                Expression left = expression;
                expression = row -> left.evaluate(row) || right.evaluate(row);
            }
            return expression;
        }

        private Expression parseAnd() {
            Expression expression = parseNot();
            while (matchKeyword("AND")) {
                Expression right = parseNot();
                Expression left = expression;
                expression = row -> left.evaluate(row) && right.evaluate(row);
            }
            return expression;
        }

        private Expression parseNot() {
            if (matchKeyword("NOT")) {
                Expression nested = parseNot();
                return row -> !nested.evaluate(row);
            }
            return parsePrimary();
        }

        private Expression parsePrimary() {
            if (match(TokenType.LPAREN)) {
                Expression expression = parseOr();
                expect(TokenType.RPAREN);
                return expression;
            }
            return parsePredicate();
        }

        private Expression parsePredicate() {
            ValueExpression left = parseValue();
            if (matchKeyword("IS")) {
                boolean negate = matchKeyword("NOT");
                expectKeyword();
                return row -> negate == (left.resolve(row) != null);
            }
            boolean negate = matchKeyword("NOT");
            if (negate && peekKeyword("IN")) {
                advance();
                List<ValueExpression> values = parseList();
                return row -> !contains(values, left.resolve(row), row);
            }
            if (negate && peekKeyword("LIKE")) {
                advance();
                ValueExpression pattern = parseValue();
                return row -> !like(left.resolve(row), pattern.resolve(row));
            }
            if (matchKeyword("IN")) {
                List<ValueExpression> values = parseList();
                return row -> contains(values, left.resolve(row), row);
            }
            if (matchKeyword("LIKE")) {
                ValueExpression pattern = parseValue();
                return row -> like(left.resolve(row), pattern.resolve(row));
            }
            Token operator = expect(TokenType.OPERATOR);
            ValueExpression right = parseValue();
            return row -> compare(left.resolve(row), operator.text(), right.resolve(row));
        }

        private List<ValueExpression> parseList() {
            expect(TokenType.LPAREN);
            List<ValueExpression> values = new ArrayList<>();
            values.add(parseValue());
            while (match(TokenType.COMMA)) {
                values.add(parseValue());
            }
            expect(TokenType.RPAREN);
            return values;
        }

        private ValueExpression parseValue() {
            Token token = advance();
            return switch (token.type()) {
                case IDENTIFIER -> {
                    if (match(TokenType.LPAREN)) {
                        yield parseFunctionCall(token.text());
                    }
                    yield row -> lookup(row, token.text());
                }
                case STRING -> row -> token.text();
                case NUMBER -> row -> new BigDecimal(token.text());
                default -> throw invalidRule("Desteklenmeyen ifade", processId, ruleId, ruleLabel);
            };
        }

        private ValueExpression parseFunctionCall(String functionName) {
            List<ValueExpression> args = new ArrayList<>();
            if (!peek(TokenType.RPAREN, null)) {
                args.add(parseValue());
                while (match(TokenType.COMMA)) {
                    args.add(parseValue());
                }
            }
            expect(TokenType.RPAREN);

            if ("NVL".equalsIgnoreCase(functionName)) {
                if (args.size() != 2) {
                    throw invalidRule("NVL için 2 argüman bekleniyor", processId, ruleId, ruleLabel);
                }
                ValueExpression first = args.get(0);
                ValueExpression second = args.get(1);
                return row -> {
                    Object value = first.resolve(row);
                    return value != null ? value : second.resolve(row);
                };
            }

            throw invalidRule("Desteklenmeyen fonksiyon: " + functionName, processId, ruleId, ruleLabel);
        }

        private boolean matchKeyword(String keyword) {
            if (peek(TokenType.KEYWORD, keyword)) {
                currentIndex++;
                return true;
            }
            return false;
        }

        private boolean peekKeyword(String keyword) {
            return peek(TokenType.KEYWORD, keyword);
        }

        private boolean match(TokenType type) {
            if (peek(type, null)) {
                currentIndex++;
                return true;
            }
            return false;
        }

        private Token expect(TokenType type) {
            Token token = advance();
            if (token.type() != type) {
                throw invalidRule("Beklenmeyen token: " + token.text(), processId, ruleId, ruleLabel);
            }
            return token;
        }

        private void expectKeyword() {
            if (!matchKeyword("NULL")) {
                throw invalidRule("Beklenen anahtar kelime: " + "NULL", processId, ruleId, ruleLabel);
            }
        }

        private boolean peek(TokenType type, String text) {
            Token token = tokens.get(currentIndex);
            return token.type() == type && (text == null || token.text().equalsIgnoreCase(text));
        }

        private Token advance() {
            return tokens.get(currentIndex++);
        }
    }

    private static Object lookup(Map<String, Object> row, String column) {
        if (row.containsKey(column)) {
            return row.get(column);
        }
        String lower = column.toLowerCase(Locale.ROOT);
        if (row.containsKey(lower)) {
            return row.get(lower);
        }
        String upper = column.toUpperCase(Locale.ROOT);
        if (row.containsKey(upper)) {
            return row.get(upper);
        }
        return null;
    }

    static Object lookupValue(Map<String, Object> row, String column) {
        return lookup(row, column);
    }

    private static boolean contains(List<ValueExpression> values, Object actual, Map<String, Object> row) {
        for (ValueExpression value : values) {
            if (Objects.equals(normalize(actual), normalize(value.resolve(row)))) {
                return true;
            }
        }
        return false;
    }

    private static boolean like(Object actual, Object pattern) {
        if (actual == null || pattern == null) {
            return false;
        }
        String candidate = actual.toString();
        String sqlPattern = pattern.toString();
        String regex = sqlPattern.replace(".", "\\.")
                .replace("%", ".*")
                .replace("_", ".");
        return candidate.matches(regex);
    }

    private static boolean compare(Object left, String operator, Object right) {
        Object normalizedLeft = normalize(left);
        Object normalizedRight = normalize(right);
        if (normalizedLeft == null || normalizedRight == null) {
            return false;
        }
        int result;
        if (normalizedLeft instanceof BigDecimal leftNumber && normalizedRight instanceof BigDecimal rightNumber) {
            result = leftNumber.compareTo(rightNumber);
        } else {
            result = normalizedLeft.toString().compareTo(normalizedRight.toString());
        }
        return switch (operator) {
            case "=" -> result == 0;
            case "<>", "!=" -> result != 0;
            case ">" -> result > 0;
            case ">=" -> result >= 0;
            case "<" -> result < 0;
            case "<=" -> result <= 0;
            default -> throw new IllegalArgumentException("Desteklenmeyen operator: " + operator);
        };
    }

    private static Object normalize(Object value) {
        return switch (value) {
            case null -> null;
            case BigDecimal bigDecimal -> bigDecimal.stripTrailingZeros();
            case Number number -> new BigDecimal(number.toString()).stripTrailingZeros();
            default -> value.toString();
        };
    }
}

