package tr.com.allianz.accounting_services.shared.web;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import tr.com.allianz.accounting_services.shared.api.ApiResponse;
import tr.com.allianz.accounting_services.shared.api.ErrorDetail;
import tr.com.allianz.accounting_services.shared.exception.BaseApplicationException;

import java.util.List;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestControllerAdvice
public class SharedExceptionHandler {

    @ExceptionHandler(BaseApplicationException.class)
    public ResponseEntity<ApiResponse<List<ErrorDetail>>> handleBaseApplicationException(
            BaseApplicationException ex
    ) {
        ErrorDetail detail = new ErrorDetail(
                "error",
                ex.getDetail()
        );

        ApiResponse<List<ErrorDetail>> body = ApiResponse.error(
                ex.getErrorCode(),
                ex.getMessage(),
                List.of(detail)
        );

        return ResponseEntity.status(ex.getHttpStatus()).body(body);
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ApiResponse<List<ErrorDetail>>> handleValidation(
            MethodArgumentNotValidException ex
    ) {
        List<ErrorDetail> details = ex.getBindingResult()
                .getAllErrors()
                .stream()
                .map(error -> {
                    if (error instanceof FieldError fe) {
                        return new ErrorDetail(fe.getField(), fe.getDefaultMessage());
                    }
                    return new ErrorDetail(error.getObjectName(), error.getDefaultMessage());
                })
                .toList();

        ApiResponse<List<ErrorDetail>> body = ApiResponse.error(
                "VALIDATION_ERROR",
                "Bir ya da daha fazla alan geçersiz.",
                details
        );

        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(body);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ApiResponse<List<ErrorDetail>>> handleGeneric(
            Exception ex
    ) {
        Throwable root = rootCause(ex);
        log.error("Unhandled exception. type={}, rootType={}, message={}",
                ex.getClass().getSimpleName(),
                root.getClass().getSimpleName(),
                root.getMessage(),
                ex);

        ErrorDetail detail = new ErrorDetail(
                "error",
                "Beklenmeyen hata : " + ex.getClass().getSimpleName() + " (root: " + root.getClass().getSimpleName() + ")"
        );

        ApiResponse<List<ErrorDetail>> body = ApiResponse.error(
                "UNEXPECTED_ERROR",
                "Beklenmeyen hata oluştu. " + ex.getClass().getSimpleName(),
                List.of(detail)
        );

        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(body);
    }

    private Throwable rootCause(Throwable t) {
        Throwable result = t;
        while (result.getCause() != null && result.getCause() != result) {
            result = result.getCause();
        }
        return result;
    }
}
