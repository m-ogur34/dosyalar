package tr.com.allianz.accounting_services.actuary.infrastructure.persistence.adapter;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.PreparedStatementCallback;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;
import tr.com.allianz.accounting_services.actuary.application.port.out.LoadIfrsDistributionTotalsPort;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.TrfsDistributionTotals;
import tr.com.allianz.accounting_services.actuary.infrastructure.persistence.entity.AlzActProcessRules;
import tr.com.allianz.accounting_services.actuary.infrastructure.persistence.repository.AlzActProcessRulesRepository;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * IFRS PY dağıtım toplamlarını hesaplayan adapter.
 * <p>
 * Satırlar Java heap'e çekilmez; SUM işlemi DB'de 3 ayrı aggregate SQL şablonuyla yapılır.
 * Her query yalnızca 1 satır (gross_amount, net_amount) döndürür.
 */
@Component
@Slf4j
@RequiredArgsConstructor
public class IfrsDistributionTotalsAdapter implements LoadIfrsDistributionTotalsPort {

    private static final int QUERY_TIMEOUT_SECONDS = 120;

    private static final String YEAR_MINUS_1_AGG_TEMPLATE = """
            SELECT NVL(SUM(DECODE(t.code,'WCRI',-1,1)*NVL(t.amount,0)+DECODE(t.code,'W',1,0)*NVL(t.prv_amount,0)),0) gross_amount,
                   NVL(SUM(CASE WHEN t.is_pool=1 THEN 0 ELSE
                            DECODE(t.code,'WCRI',-1,1)*(NVL(t.amount,0)-NVL(t.reas_amount,0))
                           +DECODE(t.code,'W',1,0)*(NVL(t.prv_amount,0)-NVL(t.prv_reas_amount,0)) END),0) net_amount
              FROM customer.alz_hp_data t
             WHERE t.year = :yearMinus1
               AND t.month = :month
               AND t.code IN ('W','WCRI')
               AND t.product_id NOT IN (12,60)
               AND NVL(Koc_acc_utils.GET_LOB(t.acc_cover_code,t.product_id,t.partition_type,sysdate),'X') NOT IN ('600','601','604')
               AND ({RULE_CONDITION})
            """;

    private static final String YEAR_RANGE_AGG_TEMPLATE = """
            SELECT NVL(SUM(NVL(t.amount,0)+NVL(t.prv_amount,0)),0) gross_amount,
                   NVL(SUM(CASE WHEN t.is_pool=1 THEN 0 ELSE
                            NVL(t.amount,0)-NVL(t.reas_amount,0)+(NVL(t.prv_amount,0)-NVL(t.prv_reas_amount,0)) END),0) net_amount
              FROM customer.alz_hp_data t
             WHERE t.year BETWEEN :yearMinus3 AND :yearMinus2
               AND t.month = 12
               AND t.code = 'W'
               AND t.product_id NOT IN (12,60)
               AND NVL(Koc_acc_utils.GET_LOB(t.acc_cover_code,t.product_id,t.partition_type,sysdate),'X') NOT IN ('600','601','604')
               AND ({RULE_CONDITION})
            """;

    private static final String YEAR_MINUS_3_AGG_TEMPLATE = """
            SELECT NVL(SUM(NVL(t.prv_amount,0)),0) gross_amount,
                   NVL(SUM(CASE WHEN t.is_pool=1 THEN 0 ELSE NVL(t.prv_amount,0)-NVL(t.prv_reas_amount,0) END),0) net_amount
              FROM customer.alz_hp_data t
             WHERE t.year = :yearMinus3
               AND t.month = 1
               AND t.code = 'WCRI'
               AND t.product_id NOT IN (12,60)
               AND NVL(Koc_acc_utils.GET_LOB(t.acc_cover_code,t.product_id,t.partition_type,sysdate),'X') NOT IN ('600','601','604')
               AND ({RULE_CONDITION})
            """;

    private final NamedParameterJdbcTemplate namedParameterJdbcTemplate;
    private final AlzActProcessRulesRepository alzActProcessRulesRepository;

    @Override
    public TrfsDistributionTotals loadPyTotals(String processId, Integer ruleId, Integer year, Integer month) {
        return loadPyTotalsByRuleIds(processId, Set.of(ruleId), year, month).get(ruleId);
    }

    @Override
    public Map<Integer, TrfsDistributionTotals> loadPyTotalsByRuleIds(String processId,
                                                                      Set<Integer> ruleIds,
                                                                      Integer year,
                                                                      Integer month) {
        if (ruleIds == null || ruleIds.isEmpty()) {
            return Map.of();
        }

        Map<Integer, AlzActProcessRules> rulesById = alzActProcessRulesRepository
                .findByProcessIdAndRuleIdIn(processId, List.copyOf(ruleIds))
                .stream()
                .collect(Collectors.toMap(r -> r.getId().getRuleId(), Function.identity()));

        for (Integer ruleId : ruleIds) {
            if (!rulesById.containsKey(ruleId)) {
                throw new IllegalArgumentException(
                        String.format(Locale.ROOT, "IFRS rule tanımı bulunamadı. processId=%s, ruleId=%s", processId, ruleId));
            }
        }

        MapSqlParameterSource allParams = new MapSqlParameterSource()
                .addValue("yearMinus1", year - 1)
                .addValue("yearMinus2", year - 2)
                .addValue("yearMinus3", year - 3)
                .addValue("month", month);

        Map<Integer, TrfsDistributionTotals> totalsByRuleId = new HashMap<>();
        for (Map.Entry<Integer, AlzActProcessRules> entry : rulesById.entrySet()) {
            Integer ruleId = entry.getKey();
            String ruleText = SqlRulePredicateSupport.sanitizeRuleText(
                    entry.getValue().getRuleText(), processId, ruleId, "IFRS rule text");

            BigDecimal[] ym1 = queryAggregates(
                    YEAR_MINUS_1_AGG_TEMPLATE.replace("{RULE_CONDITION}", ruleText), allParams);
            BigDecimal[] range = queryAggregates(
                    YEAR_RANGE_AGG_TEMPLATE.replace("{RULE_CONDITION}", ruleText), allParams);
            BigDecimal[] ym3 = queryAggregates(
                    YEAR_MINUS_3_AGG_TEMPLATE.replace("{RULE_CONDITION}", ruleText), allParams);

            totalsByRuleId.put(ruleId, new TrfsDistributionTotals(
                    ym1[0].add(range[0]).add(ym3[0]),
                    ym1[1].add(range[1]).add(ym3[1])
            ));
        }
        return totalsByRuleId;
    }

    private BigDecimal[] queryAggregates(String sql, MapSqlParameterSource params) {
        return namedParameterJdbcTemplate.execute(sql, params,
                (PreparedStatementCallback<BigDecimal[]>) ps -> {
                    ps.setQueryTimeout(QUERY_TIMEOUT_SECONDS);
                    try (java.sql.ResultSet rs = ps.executeQuery()) {
                        if (rs.next()) {
                            BigDecimal gross = rs.getBigDecimal(1);
                            BigDecimal net = rs.getBigDecimal(2);
                            return new BigDecimal[]{
                                    gross != null ? gross : BigDecimal.ZERO,
                                    net != null ? net : BigDecimal.ZERO
                            };
                        }
                        return new BigDecimal[]{BigDecimal.ZERO, BigDecimal.ZERO};
                    }
                });
    }
}
