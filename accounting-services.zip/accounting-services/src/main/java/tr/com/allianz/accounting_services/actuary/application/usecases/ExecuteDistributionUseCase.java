package tr.com.allianz.accounting_services.actuary.application.usecases;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import tr.com.allianz.accounting_services.actuary.application.port.out.LoadActuaryQueryPort;
import tr.com.allianz.accounting_services.actuary.application.port.out.LoadIfrsDistributionTotalsPort;
import tr.com.allianz.accounting_services.actuary.application.port.out.LoadTrfsDistributionTotalsPort;
import tr.com.allianz.accounting_services.actuary.application.port.out.SaveActuaryProcessAmountPort;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.ActuaryProcessAmount;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.ActuaryProcessRuleAmount;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.ActuaryQueryCriteria;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.TrfsDistributionTotals;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
@Slf4j
@RequiredArgsConstructor
@Transactional
public class ExecuteDistributionUseCase {

    private static final int RATE_SCALE = 16;
    // NUMBER(16,16) cannot store 1.0000..., max storable value is 0.9999... (16 decimals)
    private static final BigDecimal MAX_RATE = BigDecimal.ONE
            .subtract(BigDecimal.ONE.movePointLeft(RATE_SCALE))
            .setScale(RATE_SCALE, RoundingMode.HALF_UP);
    private static final BigDecimal MIN_RATE = MAX_RATE.negate();

    private final LoadActuaryQueryPort loadActuaryQueryPort;
    private final LoadTrfsDistributionTotalsPort loadTrfsDistributionTotalsPort;
    private final LoadIfrsDistributionTotalsPort loadIfrsDistributionTotalsPort;
    private final SaveActuaryProcessAmountPort saveActuaryProcessAmountPort;

    public void handle(String processId, Integer year, Integer month, String byUser) {
        ActuaryQueryCriteria criteria = new ActuaryQueryCriteria(processId, year, month);
        List<ActuaryProcessRuleAmount> results = loadActuaryQueryPort.loadActuaryQueryResults(criteria);

        List<ActuaryProcessRuleAmount> distributableRows = results.stream()
                .filter(this::isDistributable)
                .toList();

        if (distributableRows.isEmpty()) {
            return;
        }

        AmountTotals totals = AmountTotals.from(distributableRows);
        Set<Integer> distinctRuleIds = distributableRows.stream()
                .map(ActuaryProcessRuleAmount::ruleId)
                .collect(Collectors.toSet());

        Map<Integer, TrfsDistributionTotals> trfsTotalsByRuleId =
                loadTrfsDistributionTotalsPort.loadTotalsByRuleIds(processId, distinctRuleIds, year, month);
       Map<Integer, TrfsDistributionTotals> ifrsPyTotalsByRuleId =
                loadIfrsDistributionTotalsPort.loadPyTotalsByRuleIds(processId, distinctRuleIds, year, month);

        List<ActuaryProcessAmount> updates = distributableRows.stream()
                .map(row -> toProcessAmount(processId, year, month, row, totals,
                        trfsTotalsByRuleId.get(row.ruleId()),
                        ifrsPyTotalsByRuleId.get(row.ruleId())))
                .toList();

        saveActuaryProcessAmountPort.saveAll(updates);
    }

    private boolean isDistributable(ActuaryProcessRuleAmount row) {
        return row.ruleId() != null && (
                row.grossCyAmount() != null || row.reCyAmount() != null || row.netCyAmount() != null ||
                row.grossPyAmount() != null || row.rePyAmount() != null || row.netPyAmount() != null ||
                row.ifrsCyGross() != null || row.ifrsCyRe() != null || row.ifrsCyNet() != null ||
                row.ifrsPyGross() != null || row.ifrsPyRe() != null || row.ifrsPyNet() != null
        );
    }

    private ActuaryProcessAmount toProcessAmount(
            String processId,
            Integer year,
            Integer month,
            ActuaryProcessRuleAmount row,
            AmountTotals totals,
            TrfsDistributionTotals trfsTotals,
            TrfsDistributionTotals ifrsPyTotals
    ) {
        return new ActuaryProcessAmount(
                year,
                month,
                processId,
                row.ruleId(),
                row.grossCyAmount(),
                row.reCyAmount(),
                row.netCyAmount(),
                row.grossPyAmount(),
                row.rePyAmount(),
                row.netPyAmount(),
                row.ifrsCyGross(),
                row.ifrsCyRe(),
                row.ifrsCyNet(),
                row.ifrsPyGross(),
                row.ifrsPyRe(),
                row.ifrsPyNet(),
                // TRFS CY rates — denominator from rule-based alz_hp_data query
                calculateRate(row.grossCyAmount(), totalOrDefault(trfsTotals, TrfsDistributionTotals::grossAmountTotal, totals.grossCyAmount)),
                calculateRate(row.reCyAmount(), totals.reCyAmount),
                calculateRate(row.netCyAmount(), totalOrDefault(trfsTotals, TrfsDistributionTotals::netAmountTotal, totals.netCyAmount)),
                calculateRate(row.grossPyAmount(), totals.grossPyAmount),
                calculateRate(row.rePyAmount(), totals.rePyAmount),
                calculateRate(row.netPyAmount(), totals.netPyAmount),
                // IFRS CY rates — aggregate denominator (CY query TBD)
                calculateRate(row.ifrsCyGross(), totals.ifrsCyGross),
                calculateRate(row.ifrsCyRe(), totals.ifrsCyRe),
                calculateRate(row.ifrsCyNet(), totals.ifrsCyNet),
                // IFRS PY rates — denominator from rule-based PRV IFRS query
                calculateRate(row.ifrsPyGross(), totalOrDefault(ifrsPyTotals, TrfsDistributionTotals::grossAmountTotal, totals.ifrsPyGross)),
                calculateRate(row.ifrsPyRe(), totals.ifrsPyRe),
                calculateRate(row.ifrsPyNet(), totalOrDefault(ifrsPyTotals, TrfsDistributionTotals::netAmountTotal, totals.ifrsPyNet))
        );
    }

    private BigDecimal calculateRate(BigDecimal value, BigDecimal total) {
        if (value == null || total == null || total.compareTo(BigDecimal.ZERO) == 0) {
            return null;
        }
        BigDecimal calculated = value.divide(total, RATE_SCALE, RoundingMode.HALF_UP);
        return normalizeRateForPersistence(calculated);
    }

    private BigDecimal normalizeRateForPersistence(BigDecimal rate) {
        BigDecimal clamped = rate;
        if (rate.compareTo(MAX_RATE) > 0) {
            clamped = MAX_RATE;
        } else if (rate.compareTo(MIN_RATE) < 0) {
            clamped = MIN_RATE;
        }
        return clamped.setScale(RATE_SCALE, RoundingMode.HALF_UP);
    }

    private BigDecimal totalOrDefault(
            TrfsDistributionTotals trfsTotals,
            Function<TrfsDistributionTotals, BigDecimal> extractor,
            BigDecimal fallback
    ) {
        if (trfsTotals == null) {
            return fallback;
        }

        BigDecimal total = extractor.apply(trfsTotals);
        return total != null ? total : fallback;
    }

    private static BigDecimal sum(List<ActuaryProcessRuleAmount> rows, java.util.function.Function<ActuaryProcessRuleAmount, BigDecimal> extractor) {
        return rows.stream()
                .map(extractor)
                .filter(Objects::nonNull)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    private static final class AmountTotals {
        private final BigDecimal grossCyAmount;
        private final BigDecimal reCyAmount;
        private final BigDecimal netCyAmount;
        private final BigDecimal grossPyAmount;
        private final BigDecimal rePyAmount;
        private final BigDecimal netPyAmount;
        private final BigDecimal ifrsCyGross;
        private final BigDecimal ifrsCyRe;
        private final BigDecimal ifrsCyNet;
        private final BigDecimal ifrsPyGross;
        private final BigDecimal ifrsPyRe;
        private final BigDecimal ifrsPyNet;

        private AmountTotals(
                BigDecimal grossCyAmount,
                BigDecimal reCyAmount,
                BigDecimal netCyAmount,
                BigDecimal grossPyAmount,
                BigDecimal rePyAmount,
                BigDecimal netPyAmount,
                BigDecimal ifrsCyGross,
                BigDecimal ifrsCyRe,
                BigDecimal ifrsCyNet,
                BigDecimal ifrsPyGross,
                BigDecimal ifrsPyRe,
                BigDecimal ifrsPyNet
        ) {
            this.grossCyAmount = grossCyAmount;
            this.reCyAmount = reCyAmount;
            this.netCyAmount = netCyAmount;
            this.grossPyAmount = grossPyAmount;
            this.rePyAmount = rePyAmount;
            this.netPyAmount = netPyAmount;
            this.ifrsCyGross = ifrsCyGross;
            this.ifrsCyRe = ifrsCyRe;
            this.ifrsCyNet = ifrsCyNet;
            this.ifrsPyGross = ifrsPyGross;
            this.ifrsPyRe = ifrsPyRe;
            this.ifrsPyNet = ifrsPyNet;
        }

        private static AmountTotals from(List<ActuaryProcessRuleAmount> rows) {
            return new AmountTotals(
                    sum(rows, ActuaryProcessRuleAmount::grossCyAmount),
                    sum(rows, ActuaryProcessRuleAmount::reCyAmount),
                    sum(rows, ActuaryProcessRuleAmount::netCyAmount),
                    sum(rows, ActuaryProcessRuleAmount::grossPyAmount),
                    sum(rows, ActuaryProcessRuleAmount::rePyAmount),
                    sum(rows, ActuaryProcessRuleAmount::netPyAmount),
                    sum(rows, ActuaryProcessRuleAmount::ifrsCyGross),
                    sum(rows, ActuaryProcessRuleAmount::ifrsCyRe),
                    sum(rows, ActuaryProcessRuleAmount::ifrsCyNet),
                    sum(rows, ActuaryProcessRuleAmount::ifrsPyGross),
                    sum(rows, ActuaryProcessRuleAmount::ifrsPyRe),
                    sum(rows, ActuaryProcessRuleAmount::ifrsPyNet)
            );
        }
    }
}

