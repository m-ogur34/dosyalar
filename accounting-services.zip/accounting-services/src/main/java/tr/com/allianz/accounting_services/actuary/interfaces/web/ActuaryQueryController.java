package tr.com.allianz.accounting_services.actuary.interfaces.web;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import tr.com.allianz.accounting_services.actuary.application.usecases.ListActuaryQueryResponse;
import tr.com.allianz.accounting_services.actuary.application.usecases.ListActuaryQueryUseCase;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.ActuaryProcessRuleAmount;
import tr.com.allianz.accounting_services.actuary.domain.valueobject.ActuaryQueryCriteria;
import tr.com.allianz.accounting_services.actuary.interfaces.web.dto.ActuaryQueryRequestDto;
import tr.com.allianz.accounting_services.actuary.interfaces.web.dto.ActuaryQueryResultDto;
import tr.com.allianz.accounting_services.actuary.interfaces.web.dto.ActuaryQuerySearchResponseDto;
import tr.com.allianz.accounting_services.shared.api.ApiResponse;

import java.util.List;

@RestController
@RequestMapping("/api/v1/actuary-query")
@CrossOrigin
@RequiredArgsConstructor
public class ActuaryQueryController {

    private final ListActuaryQueryUseCase listActuaryQueryUseCase;

    @PostMapping
    public ResponseEntity<ApiResponse<ActuaryQuerySearchResponseDto>> listActuaryQueryResults(
            @RequestBody ActuaryQueryRequestDto request
    ) {
        ActuaryQueryCriteria criteria = new ActuaryQueryCriteria(
                request.processId(),
                request.year(),
                request.month()
        );

        ListActuaryQueryResponse useCaseResponse = listActuaryQueryUseCase.handle(criteria);

        List<ActuaryQueryResultDto> dtos = useCaseResponse.results().stream()
                .map(this::mapToDto)
                .toList();

        ActuaryQuerySearchResponseDto responseDto = new ActuaryQuerySearchResponseDto(
                dtos,
                useCaseResponse.period()
        );

        return ResponseEntity.ok(
                ApiResponse.ok(
                        "SUCCESS",
                        "Actuary query executed successfully",
                        responseDto
                )
        );
    }


    private ActuaryQueryResultDto mapToDto(ActuaryProcessRuleAmount result) {
        return new ActuaryQueryResultDto(
                result.ruleName(),
                result.year(),
                result.month(),
                result.processId(),
                result.ruleId(),
                result.grossCyAmount(),
                result.reCyAmount(),
                result.netCyAmount(),
                result.grossPyAmount(),
                result.rePyAmount(),
                result.netPyAmount(),
                result.ifrsCyGross(),
                result.ifrsCyRe(),
                result.ifrsCyNet(),
                result.ifrsPyGross(),
                result.ifrsPyRe(),
                result.ifrsPyNet(),
                result.grossCyAmountRate(),
                result.reCyAmountRate(),
                result.netCyAmountRate(),
                result.grossPyAmountRate(),
                result.rePyAmountRate(),
                result.netPyAmountRate(),
                result.ifrsCyGrossRate(),
                result.ifrsCyReRate(),
                result.ifrsCyNetRate(),
                result.ifrsPyGrossRate(),
                result.ifrsPyReRate(),
                result.ifrsPyNetRate()
        );
    }
}

